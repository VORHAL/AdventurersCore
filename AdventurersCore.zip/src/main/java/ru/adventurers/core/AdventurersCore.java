package ru.adventurers.core;

import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import ru.adventurers.core.gear.GearListener;
import ru.adventurers.core.chat.ChatCommand;
import ru.adventurers.core.chat.ChatListener;
import ru.adventurers.core.chat.ChatManager;
import ru.adventurers.core.classes.ClassManager;
import ru.adventurers.core.classes.ClassCombatListener;
import ru.adventurers.core.gem.GemListener;
import ru.adventurers.core.healer.HealerListener;
import ru.adventurers.core.hud.PartyFrames;
import ru.adventurers.core.hud.SkillHud;
import ru.adventurers.core.tank.TankListener;
import ru.adventurers.core.tank.TankManager;
import ru.adventurers.core.healer.HealerManager;
import ru.adventurers.core.gem.GemManager;
import ru.adventurers.core.classes.ClassRepository;
import ru.adventurers.core.gear.GearManager;
import ru.adventurers.core.gear.GuildGearRepository;
import ru.adventurers.core.gear.GuildGearService;
import ru.adventurers.core.survival.SurvivalListener;
import ru.adventurers.core.survival.SurvivalManager;
import ru.adventurers.core.world.WorldRulesManager;
import ru.adventurers.core.dungeon.DungeonManager;
import ru.adventurers.core.rune.RuneManager;
import ru.adventurers.core.combat.WeaponSkills;
import ru.adventurers.core.combat.WeaponListener;
import ru.adventurers.core.economy.EconomyManager;
import ru.adventurers.core.economy.ShopManager;
import ru.adventurers.core.economy.AuctionManager;
import ru.adventurers.core.recipe.RecipeManager;
import ru.adventurers.core.hook.PapiHook;
import ru.adventurers.core.hud.ScoreboardManager;
import ru.adventurers.core.party.PartyManager;
import ru.adventurers.core.quest.QuestListener;
import ru.adventurers.core.rank.RankManager;
import ru.adventurers.core.rank.RankRepository;
import ru.adventurers.core.quest.QuestManager;
import ru.adventurers.core.quest.QuestRepository;
import ru.adventurers.core.gem.GemCatalog;
import ru.adventurers.core.hud.MotdManager;
import ru.adventurers.core.hud.TabListManager;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profession.ProfessionListener;
import ru.adventurers.core.profession.ProfessionManager;
import ru.adventurers.core.profession.ProfessionRepository;
import ru.adventurers.core.profile.ProfileManager;

import java.sql.SQLException;

public class AdventurersCore extends JavaPlugin implements Listener {

    private DatabaseManager databaseManager;
    private ProfileManager profileManager;
    private MessageManager messageManager;
    private GearManager gearManager;
    private ProfessionManager professionManager;
    private SurvivalManager survivalManager;
    private WorldRulesManager worldRules;
    private DungeonManager dungeons;
    private RuneManager runes;
    private WeaponSkills weapon;
    private EconomyManager economy;
    private ShopManager shop;
    private AuctionManager auction;
    private RecipeManager recipes;
    private ClassManager classManager;
    private ChatManager chatManager;
    private QuestManager questManager;
    private RankManager rankManager;
    private PartyManager partyManager;
    private ru.adventurers.core.covenant.CovenantManager covenants;
    private ru.adventurers.core.glory.GloryManager glory;
    private ru.adventurers.core.contract.ContractManager contracts;
    private ru.adventurers.core.invasion.InvasionManager invasions;
    private ru.adventurers.core.mentor.MentorManager mentors;
    private ru.adventurers.core.pet.PetManager pets;
    private GemManager gemManager;
    private HealerManager healerManager;
    private TankManager tankManager;
    private SkillHud skillHud;
    private PartyFrames partyFrames;
    private ru.adventurers.core.profession.ExtraEffects extraEffects;
    private ScoreboardManager scoreboardManager;
    private TabListManager tabListManager;
    private MotdManager motdManager;
    private GemCatalog gemCatalog;
    private GuildGearService guildGearService;
    private boolean papiEnabled;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        papiEnabled = getServer().getPluginManager().isPluginEnabled("PlaceholderAPI");
        messageManager = new MessageManager(this);

        databaseManager = new DatabaseManager(this);
        try {
            databaseManager.connect();
        } catch (SQLException exception) {
            getLogger().severe("Could not connect to MariaDB!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        profileManager = new ProfileManager(this, databaseManager);
        gearManager = new GearManager(this, profileManager);

        professionManager = new ProfessionManager(
                this, new ProfessionRepository(databaseManager), profileManager);
        try {
            professionManager.init();
        } catch (SQLException exception) {
            getLogger().severe("Could not prepare professions table!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        classManager = new ClassManager(this, new ClassRepository(databaseManager), profileManager);
        try {
            classManager.init();
        } catch (SQLException exception) {
            getLogger().severe("Could not prepare classes table!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        survivalManager = new SurvivalManager(this, professionManager);
        survivalManager.init();
        worldRules = new WorldRulesManager(this);
        worldRules.init();
        economy = new EconomyManager(this, databaseManager);
        shop = new ShopManager(this);
        auction = new AuctionManager(this, databaseManager);
        try {
            economy.init();
            auction.init();
        } catch (SQLException exception) {
            getLogger().severe("Could not prepare economy tables!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        shop.init();
        weapon = new WeaponSkills(this);
        weapon.init();
        runes = new RuneManager(this);
        runes.init();
        recipes = new RecipeManager(this);
        recipes.init();
        dungeons = new DungeonManager(this);
        dungeons.init();

        guildGearService = new GuildGearService(this, new GuildGearRepository(databaseManager), profileManager);
        try {
            guildGearService.init();
        } catch (SQLException exception) {
            getLogger().severe("Could not prepare gear claims table!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        questManager = new QuestManager(this, new QuestRepository(databaseManager));
        try {
            questManager.init();
        } catch (SQLException exception) {
            getLogger().severe("Could not prepare quests tables!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        rankManager = new RankManager(this, new RankRepository(databaseManager));
        try {
            rankManager.init();
        } catch (SQLException exception) {
            getLogger().severe("Could not prepare rank table!");
            exception.printStackTrace();
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        partyManager = new PartyManager(this);
        partyManager.init();
        covenants = new ru.adventurers.core.covenant.CovenantManager(this, databaseManager);
        covenants.init();
        getServer().getPluginManager().registerEvents(covenants, this);
        getServer().getPluginManager().registerEvents(covenants.getBank(), this);
        getServer().getPluginManager().registerEvents(covenants.getBanner(), this);
        glory = new ru.adventurers.core.glory.GloryManager(this);
        getServer().getPluginManager().registerEvents(glory, this);
        glory.init();
        contracts = new ru.adventurers.core.contract.ContractManager(this);
        getServer().getPluginManager().registerEvents(contracts, this);
        contracts.init();
        invasions = new ru.adventurers.core.invasion.InvasionManager(this);
        invasions.init();
        mentors = new ru.adventurers.core.mentor.MentorManager(this);
        getServer().getPluginManager().registerEvents(mentors, this);
        mentors.init();
        pets = new ru.adventurers.core.pet.PetManager(this);
        getServer().getPluginManager().registerEvents(pets, this);
        pets.init();

        gemManager = new GemManager(this);
        gemManager.init();
        healerManager = new HealerManager(this);
        healerManager.init();
        tankManager = new TankManager(this);
        tankManager.init();
        skillHud = new SkillHud(this);
        skillHud.init();
        extraEffects = new ru.adventurers.core.profession.ExtraEffects(this);
        extraEffects.reload();
        partyFrames = new PartyFrames(this);
        partyFrames.init();

        chatManager = new ChatManager(this);
        chatManager.init();
        scoreboardManager = new ScoreboardManager(this);
        scoreboardManager.init();
        tabListManager = new TabListManager(this);
        tabListManager.init();
        motdManager = new MotdManager(this);
        motdManager.init();
        getServer().getPluginManager().registerEvents(motdManager, this);

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new ChatListener(this, chatManager), this);
        getServer().getPluginManager().registerEvents(new QuestListener(questManager, partyManager), this);
        getServer().getPluginManager().registerEvents(new SurvivalListener(survivalManager), this);
        getServer().getPluginManager().registerEvents(worldRules, this);
        getServer().getPluginManager().registerEvents(dungeons, this);
        getServer().getPluginManager().registerEvents(recipes, this);
        getServer().getPluginManager().registerEvents(new WeaponListener(weapon), this);
        getServer().getPluginManager().registerEvents(economy, this);
        getServer().getPluginManager().registerEvents(shop, this);
        getServer().getPluginManager().registerEvents(auction, this);
        hookVault();
        getServer().getPluginManager().registerEvents(partyFrames, this);
        getServer().getPluginManager().registerEvents(extraEffects, this);
        getServer().getPluginManager().registerEvents(new HealerListener(healerManager), this);
        getServer().getPluginManager().registerEvents(new TankListener(tankManager), this);
        getServer().getPluginManager().registerEvents(new ClassCombatListener(classManager), this);
        gemCatalog = new GemCatalog(this);
        getServer().getPluginManager().registerEvents(gemCatalog, this);
        getServer().getPluginManager().registerEvents(new GemListener(this, gemManager, questManager.getGuard()), this);
        getServer().getPluginManager().registerEvents(new GearListener(gearManager), this);
        getServer().getPluginManager().registerEvents(new ProfessionListener(professionManager), this);

        AgCommand agCommand = new AgCommand(
                this, profileManager, messageManager, gearManager, professionManager);
        PluginCommand command = getCommand("ag");
        if (command != null) {
            command.setExecutor(agCommand);
            command.setTabCompleter(agCommand);
        }

        ChatCommand chatCommand = new ChatCommand(this, chatManager);
        for (String name : new String[]{"ch", "t", "g", "r", "c"}) {
            PluginCommand chatPluginCommand = getCommand(name);
            if (chatPluginCommand != null) {
                chatPluginCommand.setExecutor(chatCommand);
                chatPluginCommand.setTabCompleter(chatCommand);
            }
        }

        if (papiEnabled) {
            PapiHook.register(this, profileManager, messageManager);
            getLogger().info("PlaceholderAPI найден: плейсхолдеры %ag_*% зарегистрированы.");
        }

        // Если плагин включили посреди работы сервера (/reload, PlugMan), подгружаем тех, кто уже онлайн.
        getServer().getOnlinePlayers().forEach(player -> {
            profileManager.loadProfile(player);
            professionManager.load(player);
            classManager.load(player);
            questManager.load(player);
            rankManager.load(player);
        });

        getLogger().info("AdventurersCore enabled!");
    }

    @Override
    public void onDisable() {
        if (papiEnabled) {
            PapiHook.unregister();
        }
        if (gearManager != null) {
            gearManager.shutdown();
        }
        if (partyFrames != null) {
            partyFrames.shutdown();
        }
        if (skillHud != null) {
            skillHud.shutdown();
        }
        if (tankManager != null) {
            tankManager.shutdown();
        }
        if (healerManager != null) {
            healerManager.shutdown();
        }
        if (gemManager != null) {
            gemManager.shutdown();
        }
        if (partyManager != null) {
            partyManager.shutdown();
        }
        if (pets != null) {
            pets.shutdown();
        }
        if (invasions != null) {
            invasions.shutdown();
        }
        if (covenants != null) {
            covenants.shutdown();
        }
        if (questManager != null) {
            questManager.shutdown();
        }
        if (tabListManager != null) {
            tabListManager.shutdown();
        }
        if (scoreboardManager != null) {
            scoreboardManager.shutdown();
        }
        if (classManager != null) {
            classManager.shutdown();
        }
        if (economy != null) {
            economy.shutdown();
        }
        if (dungeons != null) {
            dungeons.shutdown();
        }
        if (worldRules != null) {
            worldRules.shutdown();
        }
        if (survivalManager != null) {
            survivalManager.shutdown();
        }
        if (professionManager != null) {
            professionManager.shutdown();
        }
        if (profileManager != null) {
            profileManager.saveAllSync();
        }
        if (databaseManager != null) {
            databaseManager.close();
        }
        getLogger().info("AdventurersCore disabled!");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        profileManager.loadProfile(event.getPlayer());
        professionManager.load(event.getPlayer());
        classManager.load(event.getPlayer());
        questManager.load(event.getPlayer());
        rankManager.load(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        profileManager.saveProfile(event.getPlayer().getUniqueId());
        professionManager.unload(event.getPlayer().getUniqueId());
        classManager.unload(event.getPlayer().getUniqueId());
        if (skillHud != null) {
            skillHud.forget(event.getPlayer().getUniqueId());
        }
        questManager.unload(event.getPlayer().getUniqueId());
        rankManager.unload(event.getPlayer().getUniqueId());
        partyManager.onQuit(event.getPlayer());
        scoreboardManager.remove(event.getPlayer().getUniqueId());
    }

    public MessageManager getMessages() {
        return messageManager;
    }

    public ProfessionManager getProfessions() {
        return professionManager;
    }

    public ProfileManager getProfileManager() {
        return profileManager;
    }

    public PartyManager getParties() {
        return partyManager;
    }

    public ru.adventurers.core.pet.PetManager getPets() {
        return pets;
    }

    public ru.adventurers.core.mentor.MentorManager getMentors() {
        return mentors;
    }

    public ru.adventurers.core.invasion.InvasionManager getInvasions() {
        return invasions;
    }

    public ru.adventurers.core.contract.ContractManager getContracts() {
        return contracts;
    }

    public ru.adventurers.core.glory.GloryManager getGlory() {
        return glory;
    }

    public ru.adventurers.core.covenant.CovenantManager getCovenants() {
        return covenants;
    }

    public RankManager getRanks() {
        return rankManager;
    }

    public QuestManager getQuests() {
        return questManager;
    }

    public ChatManager getChat() {
        return chatManager;
    }

    public MotdManager getMotd() {
        return motdManager;
    }

    public TabListManager getTabList() {
        return tabListManager;
    }

    public ScoreboardManager getScoreboard() {
        return scoreboardManager;
    }

    public ru.adventurers.core.profession.ExtraEffects getExtraEffects() {
        return extraEffects;
    }

    public PartyFrames getPartyFrames() {
        return partyFrames;
    }

    public SkillHud getSkillHud() {
        return skillHud;
    }

    public TankManager getTank() {
        return tankManager;
    }

    public HealerManager getHealer() {
        return healerManager;
    }

    public GemCatalog getGemCatalog() {
        return gemCatalog;
    }

    /** Меню мастерской для каждой профессии (DeluxeMenus). */
    public static String workshopMenu(ru.adventurers.core.profession.Profession profession) {
        return switch (profession) {
            case ARMORSMITH -> "ag_bsworkshop";
            case WEAPONSMITH -> "ag_wsworkshop";
            case JEWELER -> "ag_jewworkshop";
            case RUNESMITH -> "ag_rnworkshop";
            case COOK -> "ag_ckworkshop";
            case ALCHEMIST -> "ag_alworkshop";
            case HUNTER -> "ag_huworkshop";
            case MINER -> "ag_miworkshop";
        };
    }

    /**
     * Открывает мастерскую по профессии игрока. forced: явно названная профессия (или null).
     * Одна профессия: сразу её мастерская. Несколько: общий зал мастерских (ag_workshop).
     * Нет профессий: выбор профессий.
     */
    public void openWorkshop(Player player, ru.adventurers.core.profession.Profession forced) {
        String menu;
        if (forced != null) {
            if (!professionManager.has(player, forced)) {
                getMessages().send(player, "workshop.no-prof", java.util.Map.of("prof", professionManager.displayName(forced)));
                return;
            }
            menu = workshopMenu(forced);
        } else {
            java.util.List<ru.adventurers.core.profession.Profession> own = new java.util.ArrayList<>();
            for (ru.adventurers.core.profession.Profession profession : ru.adventurers.core.profession.Profession.values()) {
                if (professionManager.has(player, profession)) {
                    own.add(profession);
                }
            }
            if (own.isEmpty()) {
                menu = "ag_professions";
            } else if (own.size() == 1) {
                menu = workshopMenu(own.get(0));
            } else {
                menu = "ag_workshop";
            }
        }
        if (!getServer().getPluginManager().isPluginEnabled("DeluxeMenus")) {
            getMessages().send(player, "workshop.no-menus");
            return;
        }
        org.bukkit.Bukkit.dispatchCommand(org.bukkit.Bukkit.getConsoleSender(), "dm open " + menu + " " + player.getName());
    }

    public void openWorkshop(Player player) {
        openWorkshop(player, null);
    }

    public GemManager getGems() {
        return gemManager;
    }

    public ClassManager getClasses() {
        return classManager;
    }

    public EconomyManager getEconomy() {
        return economy;
    }

    public ShopManager getShop() {
        return shop;
    }

    public AuctionManager getAuction() {
        return auction;
    }

    /** Подключает Vault, если плагин есть и VaultHook добавлен в сборку (см. УСТАНОВКА.txt). */
    private void hookVault() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return;
        }
        try {
            Class<?> hook = Class.forName("ru.adventurers.core.economy.VaultHook");
            hook.getConstructor(AdventurersCore.class).newInstance(this);
            getLogger().info("Vault economy provider registered.");
        } catch (ClassNotFoundException exception) {
            getLogger().info("Vault found, but VaultHook is not compiled in (optional).");
        } catch (ReflectiveOperationException | LinkageError exception) {
            getLogger().warning("Could not register Vault provider: " + exception);
        }
    }

    public WeaponSkills getWeapon() {
        return weapon;
    }

    public RuneManager getRunes() {
        return runes;
    }

    public RecipeManager getRecipes() {
        return recipes;
    }

    public DungeonManager getDungeons() {
        return dungeons;
    }

    public WorldRulesManager getWorldRules() {
        return worldRules;
    }

    public SurvivalManager getSurvival() {
        return survivalManager;
    }

    public GuildGearService getGuildGear() {
        return guildGearService;
    }

    public boolean isPapiEnabled() {
        return papiEnabled;
    }
}
