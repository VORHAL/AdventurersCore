package ru.adventurers.core;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class DatabaseManager {

    private final AdventurersCore plugin;
    private HikariDataSource dataSource;

    public DatabaseManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void connect() throws SQLException {
        String host = plugin.getConfig().getString("database.host");
        int port = plugin.getConfig().getInt("database.port");
        String database = plugin.getConfig().getString("database.name");
        String username = plugin.getConfig().getString("database.username");
        String password = plugin.getConfig().getString("database.password");

        HikariConfig config = new HikariConfig();

        config.setJdbcUrl(
                "jdbc:mariadb://" + host + ":" + port + "/" + database
        );

        config.setUsername(username);
        config.setPassword(password);
        config.setMaximumPoolSize(
                plugin.getConfig().getInt("database.pool-size", 5)
        );

        config.setPoolName("AdventurersCore-Pool");
        config.setDriverClassName("org.mariadb.jdbc.Driver");
        dataSource = new HikariDataSource(config);

        createTables();

        plugin.getLogger().info("MariaDB connection established!");
    }

    private void createTables() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS players (
                    uuid CHAR(36) NOT NULL,
                    username VARCHAR(16) NOT NULL,
                    rank_name VARCHAR(10) NOT NULL DEFAULT 'F',
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (uuid),
                    INDEX idx_players_rank (rank_name)
                ) ENGINE=InnoDB
                  DEFAULT CHARSET=utf8mb4
                  COLLATE=utf8mb4_unicode_ci
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }
    }

    public PlayerProfile loadOrCreateProfile(UUID uuid, String username)
            throws SQLException {

        String insertSql = """
                INSERT INTO players (uuid, username, rank_name)
                VALUES (?, ?, 'F')
                ON DUPLICATE KEY UPDATE username = VALUES(username)
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(insertSql)) {

            statement.setString(1, uuid.toString());
            statement.setString(2, username);
            statement.executeUpdate();
        }

        String selectSql = """
                SELECT rank_name
                FROM players
                WHERE uuid = ?
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(selectSql)) {

            statement.setString(1, uuid.toString());

            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    Rank rank = Rank.fromDatabase(
                            result.getString("rank_name")
                    );

                    return new PlayerProfile(uuid, username, rank);
                }
            }
        }

        throw new SQLException("Could not load player profile: " + uuid);
    }

    public void saveProfile(PlayerProfile profile) throws SQLException {
        String sql = """
                UPDATE players
                SET username = ?, rank_name = ?
                WHERE uuid = ?
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, profile.getUsername());
            statement.setString(2, profile.getRank().getDatabaseName());
            statement.setString(3, profile.getUuid().toString());

            statement.executeUpdate();
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
