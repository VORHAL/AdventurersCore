package ru.adventurers.core.chat;

import java.util.Locale;

/** Каналы чата. Группа, рейд и ковенант заработают, когда появятся эти системы. */
public enum ChatChannel {
    GLOBAL("global"),
    TRADE("trade"),
    GROUP("group"),
    RAID("raid"),
    COVENANT("covenant");

    private final String id;

    ChatChannel(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static ChatChannel fromInput(String input) {
        if (input == null) {
            return null;
        }
        String value = input.trim().toLowerCase(Locale.ROOT);
        for (ChatChannel channel : values()) {
            if (channel.id.equals(value)) {
                return channel;
            }
        }
        return switch (value) {
            case "g", "мир", "общий" -> GLOBAL;
            case "t", "торг", "торговля", "торговый" -> TRADE;
            case "c", "cov", "к", "клан", "ковенант" -> COVENANT;
            default -> null;
        };
    }
}
