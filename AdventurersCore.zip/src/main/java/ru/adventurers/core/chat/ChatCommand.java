package ru.adventurers.core.chat;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Команды /ch (каналы) и /t (быстрое сообщение в торговый канал). */
public class ChatCommand implements CommandExecutor, TabCompleter {

    private final AdventurersCore plugin;
    private final ChatManager chat;

    public ChatCommand(AdventurersCore plugin, ChatManager chat) {
        this.plugin = plugin;
        this.chat = chat;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            plugin.getMessages().send(sender, "commands.only-players");
            return true;
        }
        String name = command.getName().toLowerCase(java.util.Locale.ROOT);
        if (name.equals("t")) {
            shortcut(player, args, ChatChannel.TRADE, "/t");
        } else if (name.equals("g")) {
            shortcut(player, args, ChatChannel.GROUP, "/g");
        } else if (name.equals("r")) {
            shortcut(player, args, ChatChannel.RAID, "/r");
        } else if (name.equals("c")) {
            shortcut(player, args, ChatChannel.COVENANT, "/c");
        } else {
            channelCommand(player, args);
        }
        return true;
    }

    /** /t, /g, /r: одно сообщение в канал без переключения. */
    private void shortcut(Player player, String[] args, ChatChannel channel, String command) {
        if (!chat.isChannelEnabled(channel)) {
            plugin.getMessages().send(player, "chat.channel-disabled");
            return;
        }
        if (!chat.isMember(player, channel)) {
            plugin.getMessages().send(player, "parties.chat-not-in");
            return;
        }
        if (args.length == 0) {
            plugin.getMessages().send(player, "parties.chat-usage", Map.of("command", command));
            return;
        }
        if (channel == ChatChannel.TRADE && chat.isTradeHidden(player)) {
            plugin.getMessages().send(player, "chat.trade-is-hidden");
            return;
        }
        if (!chat.checkCooldown(player)) {
            plugin.getMessages().send(player, "chat.cooldown");
            return;
        }
        chat.broadcast(player, channel, String.join(" ", args));
    }

    private void channelCommand(Player player, String[] args) {
        if (args.length == 0) {
            plugin.getMessages().send(player, "chat.usage", Map.of(
                    "channel", chat.channelName(chat.speaking(player))));
            return;
        }

        ChatChannel channel = ChatChannel.fromInput(args[0]);
        if (channel == null) {
            plugin.getMessages().send(player, "chat.unknown");
            return;
        }
        if (!chat.isChannelEnabled(channel)) {
            plugin.getMessages().send(player, "chat.channel-disabled");
            return;
        }

        // /ch trade on|off - видимость торгового канала
        if (channel == ChatChannel.TRADE && args.length > 1) {
            String value = args[1].toLowerCase(Locale.ROOT);
            if (value.equals("off") || value.equals("hide")) {
                chat.setTradeHidden(player, true);
                if (chat.speaking(player) == ChatChannel.TRADE) {
                    chat.setSpeaking(player, ChatChannel.GLOBAL);
                }
                plugin.getMessages().send(player, "chat.trade-hidden");
                return;
            }
            if (value.equals("on") || value.equals("show")) {
                chat.setTradeHidden(player, false);
                plugin.getMessages().send(player, "chat.trade-shown");
                return;
            }
            plugin.getMessages().send(player, "chat.usage", Map.of(
                    "channel", chat.channelName(chat.speaking(player))));
            return;
        }

        if (!chat.isMember(player, channel)) {
            plugin.getMessages().send(player, "parties.chat-not-in");
            return;
        }
        if (channel == ChatChannel.TRADE && chat.isTradeHidden(player)) {
            plugin.getMessages().send(player, "chat.trade-is-hidden");
            return;
        }
        chat.setSpeaking(player, channel);
        plugin.getMessages().send(player, "chat.switched", Map.of(
                "channel", chat.channelName(channel)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (command.getName().equalsIgnoreCase("ch")) {
            if (args.length == 1) {
                for (ChatChannel channel : ChatChannel.values()) {
                    if (chat.isChannelEnabled(channel)) {
                        result.add(channel.getId());
                    }
                }
            } else if (args.length == 2 && args[0].equalsIgnoreCase("trade")) {
                result.add("on");
                result.add("off");
            }
        }
        String typed = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        result.removeIf(option -> !option.startsWith(typed));
        return result;
    }
}
