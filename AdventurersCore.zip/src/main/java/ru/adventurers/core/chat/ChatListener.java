package ru.adventurers.core.chat;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.adventurers.core.AdventurersCore;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

public class ChatListener implements Listener {

    private final AdventurersCore plugin;
    private final ChatManager chat;

    public ChatListener(AdventurersCore plugin, ChatManager chat) {
        this.plugin = plugin;
        this.chat = chat;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!chat.isEnabled()) {
            return;
        }
        Player player = event.getPlayer();

        if (!chat.checkCooldown(player)) {
            event.setCancelled(true);
            plugin.getMessages().send(player, "chat.cooldown");
            return;
        }

        ChatChannel channel = chat.speaking(player);
        String message = chat.plain(event.message());

        // Всё, что читает данные игроков (плейсхолдеры, группы), делаем в основном потоке.
        record Prepared(Component line, Set<UUID> hidden) {
        }
        Prepared prepared;
        try {
            prepared = Bukkit.getScheduler().callSyncMethod(plugin, () -> {
                Set<UUID> hidden = new HashSet<>();
                for (Player viewer : Bukkit.getOnlinePlayers()) {
                    if (!chat.canSee(viewer, player, channel)) {
                        hidden.add(viewer.getUniqueId());
                    }
                }
                return new Prepared(chat.build(player, channel, message), hidden);
            }).get();
        } catch (InterruptedException | ExecutionException exception) {
            plugin.getLogger().warning("Chat format failed: " + exception.getMessage());
            return; // оставляем ванильное сообщение
        }

        Set<UUID> hidden = prepared.hidden();
        event.viewers().removeIf(audience -> audience instanceof Player viewer
                && hidden.contains(viewer.getUniqueId()));
        Component finalLine = prepared.line();
        event.renderer((source, sourceDisplayName, text, viewer) -> finalLine);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent event) {
        if (!chat.isEnabled()) {
            return;
        }
        Component line = chat.joinMessage(event.getPlayer(), true);
        if (line != null) {
            event.joinMessage(line);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent event) {
        if (chat.isEnabled()) {
            Component line = chat.joinMessage(event.getPlayer(), false);
            if (line != null) {
                event.quitMessage(line);
            }
        }
        chat.forget(event.getPlayer().getUniqueId());
    }
}
