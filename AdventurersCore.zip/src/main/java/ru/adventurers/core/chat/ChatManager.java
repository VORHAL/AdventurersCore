package ru.adventurers.core.chat;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;

import java.io.File;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Формат чата и каналы. Настройки: chat.yml. */
public class ChatManager {

    private static final class ChannelConfig {
        boolean enabled;
        String format;
        String name;
    }

    private final AdventurersCore plugin;
    private final NamespacedKey tradeOffKey;

    private final Map<ChatChannel, ChannelConfig> channels = new EnumMap<>(ChatChannel.class);
    private final Map<UUID, ChatChannel> speaking = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastMessage = new ConcurrentHashMap<>();

    private boolean enabled;
    private long cooldownMs;
    private boolean hoverEnabled;
    private List<String> hoverLines = new ArrayList<>();
    private String clickSuggest = "/msg {player} ";
    private String joinFormat = "";
    private String quitFormat = "";

    public ChatManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.tradeOffKey = new NamespacedKey(plugin, "trade_off");
    }

    public void init() {
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "chat.yml");
        if (!file.exists()) {
            plugin.saveResource("chat.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        cooldownMs = Math.max(0, cfg.getInt("cooldown-ms", 800));

        hoverEnabled = cfg.getBoolean("name-card.enabled", true);
        hoverLines = new ArrayList<>(cfg.getStringList("name-card.lines"));
        clickSuggest = cfg.getString("name-card.click-suggest", "/msg {player} ");
        joinFormat = cfg.getString("join-message", "");
        quitFormat = cfg.getString("quit-message", "");

        channels.clear();
        for (ChatChannel channel : ChatChannel.values()) {
            String path = "channels." + channel.getId() + ".";
            ChannelConfig config = new ChannelConfig();
            config.enabled = cfg.getBoolean(path + "enabled", channel == ChatChannel.GLOBAL
                    || channel == ChatChannel.TRADE);
            config.format = cfg.getString(path + "format", "&7{player}&8: &f{message}");
            config.name = cfg.getString(path + "name", channel.getId());
            channels.put(channel, config);
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isChannelEnabled(ChatChannel channel) {
        ChannelConfig config = channels.get(channel);
        return config != null && config.enabled;
    }

    public String channelName(ChatChannel channel) {
        ChannelConfig config = channels.get(channel);
        return config != null ? config.name : channel.getId();
    }

    // ---------------------------------------------------------------
    //  Состояние игрока
    // ---------------------------------------------------------------

    public ChatChannel speaking(Player player) {
        ChatChannel channel = speaking.getOrDefault(player.getUniqueId(), ChatChannel.GLOBAL);
        if (!isChannelEnabled(channel) || !isMember(player, channel)) {
            return ChatChannel.GLOBAL;
        }
        return channel;
    }

    public void setSpeaking(Player player, ChatChannel channel) {
        speaking.put(player.getUniqueId(), channel);
    }

    public void forget(UUID uuid) {
        speaking.remove(uuid);
        lastMessage.remove(uuid);
    }

    public boolean isTradeHidden(Player player) {
        Byte stored = player.getPersistentDataContainer().get(tradeOffKey, PersistentDataType.BYTE);
        return stored != null && stored == 1;
    }

    public void setTradeHidden(Player player, boolean hidden) {
        player.getPersistentDataContainer().set(tradeOffKey, PersistentDataType.BYTE, (byte) (hidden ? 1 : 0));
    }

    /** true, если игрок может писать (защита от спама). Обновляет время последнего сообщения. */
    public boolean checkCooldown(Player player) {
        if (cooldownMs <= 0 || player.hasPermission("ag.bypass.chat")) {
            return true;
        }
        long now = System.currentTimeMillis();
        Long last = lastMessage.get(player.getUniqueId());
        if (last != null && now - last < cooldownMs) {
            return false;
        }
        lastMessage.put(player.getUniqueId(), now);
        return true;
    }

    // ---------------------------------------------------------------
    //  Оформление сообщения
    // ---------------------------------------------------------------

    /**
     * Собирает готовую строку чата. Вызывать из основного потока (читает данные игроков).
     * Текст игрока без права ag.chat.color показывается как есть, без цветов.
     */
    public Component build(Player player, ChatChannel channel, String message) {
        ChannelConfig config = channels.get(channel);
        String format = config != null ? config.format : "&7{player}&8: &f{message}";

        Component text = player.hasPermission("ag.chat.color")
                ? Hud.legacy(message)
                : Component.text(message);

        int split = format.indexOf("{message}");
        String before = split >= 0 ? format.substring(0, split) : format;
        String after = split >= 0 ? format.substring(split + "{message}".length()) : "";

        Component result = decorate(player, before);
        result = result.append(text);
        if (!after.isEmpty()) {
            result = result.append(decorate(player, after));
        }
        return result;
    }

    /** Подставляет {class} и {player}; ник получает карточку при наведении и клик «написать лично». */
    private Component decorate(Player player, String template) {
        String prepared = template
                .replace("{class}", plugin.getClasses() != null ? plugin.getClasses().tag(player.getUniqueId()) : "")
                .replace("{covenant}", covenantName(player))
                .replace("{title}", titleText(player))
                .replace("{channel}", "");
        Component component = Hud.parse(plugin, player, prepared.replace("{player}", "\u0001"));
        Component name = Component.text(player.getName());
        if (hoverEnabled) {
            name = name.hoverEvent(HoverEvent.showText(nameCard(player)));
            if (!clickSuggest.isBlank()) {
                name = name.clickEvent(ClickEvent.suggestCommand(
                        clickSuggest.replace("{player}", player.getName())));
            }
        }
        Component finalName = name;
        component = component.replaceText(TextReplacementConfig.builder()
                .matchLiteral("{badge}")
                .replacement(badgeOf(player))
                .build());
        return component.replaceText(TextReplacementConfig.builder()
                .matchLiteral("\u0001")
                .replacement(finalName)
                .build());
    }

    private String titleText(Player player) {
        String title = plugin.getGlory() != null ? plugin.getGlory().titleName(player) : "";
        return title.isEmpty() ? "" : title + " ";
    }

    private String covenantName(Player player) {
        var cov = plugin.getCovenants() != null ? plugin.getCovenants().of(player.getUniqueId()) : null;
        return cov == null ? "" : cov.name;
    }

    private Component badgeOf(Player player) {
        var profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return ru.adventurers.core.hud.PackItems.badge(profile != null ? profile.getRank() : null);
    }

    private Component nameCard(Player player) {
        List<Component> lines = new ArrayList<>();
        String classTag = plugin.getClasses() != null ? plugin.getClasses().tag(player.getUniqueId()) : "";
        for (String line : hoverLines) {
            lines.add(Hud.parse(plugin, player, line
                    .replace("{player}", player.getName())
                    .replace("{class}", classTag)));
        }
        return Component.join(JoinConfiguration.newlines(), lines);
    }

    /** Сообщение о входе/выходе. Пустая строка в chat.yml: оставить ванильное. */
    public Component joinMessage(Player player, boolean join) {
        String format = join ? joinFormat : quitFormat;
        if (format == null || format.isBlank()) {
            return null;
        }
        return decorate(player, format);
    }

    public String plain(Component component) {
        return PlainTextComponentSerializer.plainText().serialize(component);
    }

    /** Отправка из команды (/t): тем, кто видит канал, и в консоль. */
    public void broadcast(Player sender, ChatChannel channel, String message) {
        Component line = build(sender, channel, message);
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (canSee(viewer, sender, channel)) {
                viewer.sendMessage(line);
            }
        }
        Bukkit.getConsoleSender().sendMessage(line);
    }

    /** Состоит ли игрок в группе/рейде для канала (для остальных каналов всегда true). */
    public boolean isMember(Player player, ChatChannel channel) {
        return switch (channel) {
            case GROUP -> plugin.getParties().group(player.getUniqueId()) != null;
            case RAID -> plugin.getParties().raid(player.getUniqueId()) != null;
            case COVENANT -> plugin.getCovenants() != null && plugin.getCovenants().of(player.getUniqueId()) != null;
            default -> true;
        };
    }

    /** Основной поток. */
    public boolean canSee(Player viewer, Player sender, ChatChannel channel) {
        if (viewer.equals(sender)) {
            return true;
        }
        return switch (channel) {
            case TRADE -> !isTradeHidden(viewer);
            case GROUP -> plugin.getParties().inSameGroup(viewer, sender);
            case RAID -> plugin.getParties().inSameRaid(viewer, sender);
            case COVENANT -> plugin.getCovenants() != null
                    && plugin.getCovenants().sameCovenant(viewer.getUniqueId(), sender.getUniqueId());
            default -> true;
        };
    }
}
