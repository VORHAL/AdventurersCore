package ru.adventurers.core.classes;

import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;

/** Бонусы класса при стрельбе: Боец с луком или арбалетом (раздел ranged в classes.yml). */
public class ClassCombatListener implements Listener {

    private final ClassManager classes;

    public ClassCombatListener(ClassManager classes) {
        this.classes = classes;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onShoot(EntityShootBowEvent event) {
        if (event.getEntity() instanceof Player player && event.getProjectile() instanceof AbstractArrow arrow) {
            double speed = classes.rangedVelocity(player.getUniqueId());
            if (speed > 0) {
                arrow.setVelocity(arrow.getVelocity().multiply(1.0 + speed));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArrowHit(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof AbstractArrow arrow && arrow.getShooter() instanceof Player player) {
            double bonus = classes.rangedDamage(player.getUniqueId());
            if (bonus > 0) {
                event.setDamage(event.getDamage() * (1.0 + bonus));
            }
        }
    }
}
