package ru.adventurers.core.classes;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.ProfileManager;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Классы игроков: выбор, смена, бонусы к характеристикам. */
public class ClassManager {

    public enum ChooseResult { OK, ALREADY_OWNED, NOT_CHOOSABLE, RANK_TOO_LOW, LIMIT, DISABLED, NO_COINS, NOT_LOADED }

    public enum SwitchResult { OK, ALREADY_ACTIVE, NOT_AVAILABLE, COOLDOWN, IN_COMBAT, NO_COINS, NOT_LOADED }

    private record Bonus(Attribute attribute, double value, AttributeModifier.Operation operation) {
    }

    private static final String MODIFIER_PREFIX = "class_";

    private final AdventurersCore plugin;
    private final ClassRepository repository;
    private final ProfileManager profiles;

    private final Map<UUID, PlayerClasses> cache = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastSwitch = new HashMap<>();
    private final Map<PlayerClass, List<Bonus>> bonuses = new EnumMap<>(PlayerClass.class);

    private final Map<PlayerClass, String> icons = new EnumMap<>(PlayerClass.class);
    private final Map<PlayerClass, double[]> ranged = new EnumMap<>(PlayerClass.class);

    private boolean secondEnabled;
    private Rank secondMinRank = Rank.A;
    private long switchCooldownMs;
    private BukkitTask autosaveTask;

    public ClassManager(AdventurersCore plugin, ClassRepository repository, ProfileManager profiles) {
        this.plugin = plugin;
        this.repository = repository;
        this.profiles = profiles;
    }

    public void init() throws SQLException {
        repository.createTable();
        reload();
        long ticks = 5L * 60L * 20L;
        autosaveTask = Bukkit.getScheduler().runTaskTimer(plugin, this::autosave, ticks, ticks);
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "classes.yml");
        if (!file.exists()) {
            plugin.saveResource("classes.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        secondEnabled = cfg.getBoolean("second-class.enabled", true);
        Rank parsed = Rank.fromInput(cfg.getString("second-class.min-rank"));
        secondMinRank = parsed != null ? parsed : Rank.A;
        switchCooldownMs = Math.max(0, cfg.getInt("switch-cooldown-seconds", 60)) * 1000L;

        ranged.clear();
        for (PlayerClass playerClass : PlayerClass.values()) {
            double damage = cfg.getDouble("ranged." + playerClass.getId() + ".damage", 0.0);
            double velocity = cfg.getDouble("ranged." + playerClass.getId() + ".velocity", 0.0);
            if (damage > 0 || velocity > 0) {
                ranged.put(playerClass, new double[]{damage, velocity});
            }
        }

        icons.clear();
        for (PlayerClass playerClass : PlayerClass.values()) {
            icons.put(playerClass, Hud.gradients(cfg.getString("icons." + playerClass.getId(),
                    defaultIcon(playerClass))));
        }

        bonuses.clear();
        for (PlayerClass playerClass : PlayerClass.values()) {
            List<Bonus> list = new ArrayList<>();
            for (Map<?, ?> raw : cfg.getMapList("classes." + playerClass.getId() + ".bonuses")) {
                Bonus bonus = parseBonus(raw, playerClass);
                if (bonus != null) {
                    list.add(bonus);
                }
            }
            bonuses.put(playerClass, list);
        }

        // Бонусы онлайн-игроков пересчитываем сразу.
        for (Player player : Bukkit.getOnlinePlayers()) {
            applyBonuses(player);
        }
    }

    private Bonus parseBonus(Map<?, ?> raw, PlayerClass playerClass) {
        Object attributeName = raw.get("attribute");
        Attribute attribute = attributeName == null ? null
                : Registry.ATTRIBUTE.get(NamespacedKey.minecraft(
                        String.valueOf(attributeName).toLowerCase(Locale.ROOT)));
        if (attribute == null || !(raw.get("value") instanceof Number number)) {
            plugin.getLogger().warning("classes.yml, класс " + playerClass.getId()
                    + ": неверный бонус " + raw);
            return null;
        }
        AttributeModifier.Operation operation = AttributeModifier.Operation.ADD_NUMBER;
        Object operationName = raw.get("operation");
        if (operationName != null) {
            try {
                operation = AttributeModifier.Operation.valueOf(
                        String.valueOf(operationName).toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("classes.yml: неизвестная операция " + operationName);
            }
        }
        return new Bonus(attribute, number.doubleValue(), operation);
    }

    public void shutdown() {
        if (autosaveTask != null) {
            autosaveTask.cancel();
            autosaveTask = null;
        }
        for (Map.Entry<UUID, PlayerClasses> entry : cache.entrySet()) {
            try {
                repository.save(entry.getKey(), entry.getValue());
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not save classes for " + entry.getKey());
                exception.printStackTrace();
            }
        }
        cache.clear();
    }

    // ---------------------------------------------------------------
    //  Загрузка и сохранение
    // ---------------------------------------------------------------

    public void load(Player player) {
        UUID uuid = player.getUniqueId();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            PlayerClasses data;
            try {
                data = repository.load(uuid);
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not load classes for " + player.getName());
                exception.printStackTrace();
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline()) {
                    return;
                }
                cache.put(uuid, data);
                validateActive(player, data);
                applyBonuses(player);
            });
        });
    }

    public void unload(UUID uuid) {
        PlayerClasses data = cache.remove(uuid);
        lastSwitch.remove(uuid);
        if (data == null) {
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveNow(uuid, data));
    }

    private void autosave() {
        for (Map.Entry<UUID, PlayerClasses> entry : cache.entrySet()) {
            saveAsync(entry.getKey());
        }
    }

    private void saveAsync(UUID uuid) {
        PlayerClasses data = cache.get(uuid);
        if (data == null) {
            return;
        }
        PlayerClasses snapshot = data.copy();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveNow(uuid, snapshot));
    }

    private void saveNow(UUID uuid, PlayerClasses data) {
        try {
            repository.save(uuid, data);
        } catch (SQLException exception) {
            plugin.getLogger().severe("Could not save classes for " + uuid);
            exception.printStackTrace();
        }
    }

    // ---------------------------------------------------------------
    //  Запросы
    // ---------------------------------------------------------------

    public PlayerClasses get(UUID uuid) {
        return cache.get(uuid);
    }

    public PlayerClass activeClass(UUID uuid) {
        PlayerClasses data = cache.get(uuid);
        return data != null ? data.getActive() : null;
    }

    public Rank secondClassRank() {
        return secondMinRank;
    }

    private Rank rankOf(Player player) {
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        return profile != null ? profile.getRank() : Rank.F;
    }

    /** Универсал доступен только на ранге S. */
    public boolean universalAvailable(Player player) {
        return rankOf(player).isAtLeast(Rank.S);
    }

    /** Можно ли сейчас выбрать новый класс (первый бесплатно, второй с нужного ранга). */
    public boolean canChooseNew(Player player) {
        PlayerClasses data = cache.get(player.getUniqueId());
        if (data == null) {
            return false;
        }
        if (data.count() == 0) {
            return true;
        }
        return data.count() == 1 && secondEnabled && rankOf(player).isAtLeast(secondMinRank);
    }

    /** Бонус урона стрел активного класса игрока (0.25 = +25%). */
    public double rangedDamage(UUID uuid) {
        PlayerClass active = activeClass(uuid);
        double[] bonus = active == null ? null : ranged.get(active);
        return bonus == null ? 0.0 : bonus[0];
    }

    /** Бонус скорости полёта стрел активного класса (0.15 = +15%). */
    public double rangedVelocity(UUID uuid) {
        PlayerClass active = activeClass(uuid);
        double[] bonus = active == null ? null : ranged.get(active);
        return bonus == null ? 0.0 : bonus[1];
    }

    private static String defaultIcon(PlayerClass playerClass) {
        return switch (playerClass) {
            case TANK -> "&9⛨";
            case HEALER -> "&a✚";
            case FIGHTER -> "&c⚔";
            case UNIVERSAL -> "&6✦❂✦";
        };
    }

    /** Значок класса (с цветовыми кодами &). Пусто, если класса нет. */
    public String icon(PlayerClass playerClass) {
        return playerClass == null ? "" : icons.getOrDefault(playerClass, "");
    }

    /** Значок активного класса игрока и пробел после него. Пусто, если класса нет. */
    public String tag(UUID uuid) {
        PlayerClass active = activeClass(uuid);
        return active == null ? "" : icon(active) + "&r ";
    }

    public String displayName(PlayerClass playerClass) {
        return plugin.getMessages().text("classes.names." + playerClass.getId(), playerClass.getId());
    }

    public String role(PlayerClass playerClass) {
        return plugin.getMessages().text("classes.roles." + playerClass.getId(), "");
    }

    // ---------------------------------------------------------------
    //  Действия
    // ---------------------------------------------------------------

    public ChooseResult choose(Player player, PlayerClass playerClass) {
        PlayerClasses data = cache.get(player.getUniqueId());
        if (data == null) {
            return ChooseResult.NOT_LOADED;
        }
        if (!playerClass.isChoosable()) {
            return ChooseResult.NOT_CHOOSABLE;
        }
        if (data.owns(playerClass)) {
            return ChooseResult.ALREADY_OWNED;
        }
        if (data.count() == 0) {
            data.setFirst(playerClass);
        } else {
            if (data.count() >= 2) {
                return ChooseResult.LIMIT;
            }
            if (!secondEnabled) {
                return ChooseResult.DISABLED;
            }
            if (!rankOf(player).isAtLeast(secondMinRank)) {
                return ChooseResult.RANK_TOO_LOW;
            }
            if (plugin.getEconomy() != null && !plugin.getEconomy().charge(player, plugin.getEconomy().classSecondCost())) {
                return ChooseResult.NO_COINS;
            }
            data.setSecond(playerClass);
        }
        data.setActive(playerClass);
        applyBonuses(player);
        saveAsync(player.getUniqueId());
        return ChooseResult.OK;
    }

    public SwitchResult switchTo(Player player, PlayerClass playerClass) {
        PlayerClasses data = cache.get(player.getUniqueId());
        if (data == null) {
            return SwitchResult.NOT_LOADED;
        }
        boolean available = data.owns(playerClass)
                || (playerClass == PlayerClass.UNIVERSAL && universalAvailable(player));
        if (!available) {
            return SwitchResult.NOT_AVAILABLE;
        }
        if (data.getActive() == playerClass) {
            return SwitchResult.ALREADY_ACTIVE;
        }
        if (plugin.getSurvival() != null && plugin.getSurvival().isInCombat(player.getUniqueId())) {
            return SwitchResult.IN_COMBAT;
        }
        long now = System.currentTimeMillis();
        Long last = lastSwitch.get(player.getUniqueId());
        if (last != null && now - last < switchCooldownMs) {
            return SwitchResult.COOLDOWN;
        }
        if (plugin.getEconomy() != null && !plugin.getEconomy().charge(player, plugin.getEconomy().classSwitchCost())) {
            return SwitchResult.NO_COINS;
        }
        lastSwitch.put(player.getUniqueId(), now);
        data.setActive(playerClass);
        applyBonuses(player);
        saveAsync(player.getUniqueId());
        return SwitchResult.OK;
    }

    /** Админ: выдаёт класс (в первый свободный слот) и делает активным. Универсал просто включается. */
    public boolean adminSet(Player player, PlayerClass playerClass) {
        PlayerClasses data = cache.get(player.getUniqueId());
        if (data == null) {
            return false;
        }
        if (playerClass.isChoosable() && !data.owns(playerClass)) {
            if (data.getFirst() == null) {
                data.setFirst(playerClass);
            } else {
                data.setSecond(playerClass);
            }
        }
        data.setActive(playerClass);
        applyBonuses(player);
        saveAsync(player.getUniqueId());
        return true;
    }

    public boolean adminReset(Player player) {
        PlayerClasses data = cache.get(player.getUniqueId());
        if (data == null) {
            return false;
        }
        data.clear();
        applyBonuses(player);
        saveAsync(player.getUniqueId());
        return true;
    }

    /** После смены ранга: универсал пропадает, если ранг упал ниже S. */
    public void refresh(Player player) {
        PlayerClasses data = cache.get(player.getUniqueId());
        if (data == null) {
            return;
        }
        validateActive(player, data);
        applyBonuses(player);
        saveAsync(player.getUniqueId());
    }

    private void validateActive(Player player, PlayerClasses data) {
        PlayerClass active = data.getActive();
        boolean valid = active == null
                || data.owns(active)
                || (active == PlayerClass.UNIVERSAL && universalAvailable(player));
        if (!valid) {
            data.setActive(data.getFirst());
        }
    }

    // ---------------------------------------------------------------
    //  Бонусы к характеристикам
    // ---------------------------------------------------------------

    public void applyBonuses(Player player) {
        PlayerClasses data = cache.get(player.getUniqueId());
        PlayerClass active = data != null ? data.getActive() : null;

        // Снимаем все наши старые бонусы (они сохраняются в данных игрока между входами).
        for (Attribute attribute : Registry.ATTRIBUTE) {
            AttributeInstance instance = player.getAttribute(attribute);
            if (instance == null) {
                continue;
            }
            for (AttributeModifier modifier : new ArrayList<>(instance.getModifiers())) {
                NamespacedKey key = modifier.getKey();
                if (key.getNamespace().equals(modifierNamespace())
                        && key.getKey().startsWith(MODIFIER_PREFIX)) {
                    instance.removeModifier(modifier);
                }
            }
        }

        if (active == null) {
            return;
        }
        int index = 0;
        for (Bonus bonus : bonuses.getOrDefault(active, List.of())) {
            AttributeInstance instance = player.getAttribute(bonus.attribute());
            if (instance == null) {
                continue;
            }
            NamespacedKey key = new NamespacedKey(plugin, MODIFIER_PREFIX + active.getId() + "_" + index++);
            instance.addModifier(new AttributeModifier(key, bonus.value(), bonus.operation()));
        }
    }

    private String modifierNamespace() {
        return new NamespacedKey(plugin, "x").getNamespace();
    }
}
