package ru.adventurers.core.classes;

import ru.adventurers.core.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

/** Таблица player_classes (одна строка на игрока). Методы блокирующие. */
public class ClassRepository {

    private final DatabaseManager database;

    public ClassRepository(DatabaseManager database) {
        this.database = database;
    }

    public void createTable() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS player_classes (
                    uuid CHAR(36) NOT NULL PRIMARY KEY,
                    class_first VARCHAR(16) NULL,
                    class_second VARCHAR(16) NULL,
                    class_active VARCHAR(16) NULL,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB
                  DEFAULT CHARSET=utf8mb4
                  COLLATE=utf8mb4_unicode_ci
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }
    }

    public PlayerClasses load(UUID uuid) throws SQLException {
        PlayerClasses data = new PlayerClasses();
        String sql = "SELECT class_first, class_second, class_active FROM player_classes WHERE uuid = ?";
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    data.setFirst(PlayerClass.fromInput(result.getString(1)));
                    data.setSecond(PlayerClass.fromInput(result.getString(2)));
                    data.setActive(PlayerClass.fromInput(result.getString(3)));
                }
            }
        }
        return data;
    }

    public void save(UUID uuid, PlayerClasses data) throws SQLException {
        String sql = """
                INSERT INTO player_classes (uuid, class_first, class_second, class_active)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    class_first = VALUES(class_first),
                    class_second = VALUES(class_second),
                    class_active = VALUES(class_active)
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, uuid.toString());
            statement.setString(2, data.getFirst() != null ? data.getFirst().getId() : null);
            statement.setString(3, data.getSecond() != null ? data.getSecond().getId() : null);
            statement.setString(4, data.getActive() != null ? data.getActive().getId() : null);
            statement.executeUpdate();
        }
    }
}
