package ru.adventurers.core.classes;

import java.util.Locale;

/** Классы. Универсал не выбирается: его получают игроки ранга S. */
public enum PlayerClass {
    TANK("tank"),
    HEALER("healer"),
    FIGHTER("fighter"),
    UNIVERSAL("universal");

    private final String id;

    PlayerClass(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    /** Классы, которые можно выбрать (без универсала). */
    public boolean isChoosable() {
        return this != UNIVERSAL;
    }

    public static PlayerClass fromInput(String input) {
        if (input == null) {
            return null;
        }
        String value = input.trim().toLowerCase(Locale.ROOT);
        for (PlayerClass playerClass : values()) {
            if (playerClass.id.equals(value)) {
                return playerClass;
            }
        }
        return switch (value) {
            case "танк" -> TANK;
            case "лекарь", "хилер" -> HEALER;
            case "боец" -> FIGHTER;
            case "универсал" -> UNIVERSAL;
            default -> null;
        };
    }
}
