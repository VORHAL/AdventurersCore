package ru.adventurers.core.classes;

/** Классы игрока: первый (бесплатный), второй (с ранга A) и активный. */
public class PlayerClasses {

    private PlayerClass first;
    private PlayerClass second;
    private PlayerClass active;

    public PlayerClass getFirst() {
        return first;
    }

    public void setFirst(PlayerClass first) {
        this.first = first;
    }

    public PlayerClass getSecond() {
        return second;
    }

    public void setSecond(PlayerClass second) {
        this.second = second;
    }

    public PlayerClass getActive() {
        return active;
    }

    public void setActive(PlayerClass active) {
        this.active = active;
    }

    public boolean owns(PlayerClass playerClass) {
        return playerClass != null && (playerClass == first || playerClass == second);
    }

    public int count() {
        return (first != null ? 1 : 0) + (second != null ? 1 : 0);
    }

    public void clear() {
        first = null;
        second = null;
        active = null;
    }

    public PlayerClasses copy() {
        PlayerClasses copy = new PlayerClasses();
        copy.first = first;
        copy.second = second;
        copy.active = active;
        return copy;
    }
}
