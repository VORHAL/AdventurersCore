package ru.adventurers.core.combat;

import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Управление умениями Бойца и Стрелка (с Shift) и действие «меткого выстрела». */
public class WeaponListener implements Listener {

    private final WeaponSkills skills;
    private final Map<UUID, Long> lastClick = new HashMap<>();

    public WeaponListener(WeaponSkills skills) {
        this.skills = skills;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.LEFT_CLICK_AIR) {
            return;
        }
        Player player = event.getPlayer();
        boolean melee = skills.meleeReady(player);
        boolean ranged = skills.rangedReady(player);
        if (!melee && !ranged) {
            return;
        }
        long now = System.currentTimeMillis();
        Long last = lastClick.get(player.getUniqueId());
        if (last != null && now - last < 150) {
            return;
        }
        lastClick.put(player.getUniqueId(), now);
        if (action == Action.RIGHT_CLICK_AIR) {
            event.setCancelled(true);
            if (melee) {
                skills.sweep(player);
            } else {
                skills.volley(player);
            }
        } else if (melee) {
            skills.lunge(player);
        } else {
            skills.backstep(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (skills.meleeReady(player)) {
            event.setCancelled(true);
            skills.rage(player);
        } else if (skills.rangedReady(player)) {
            event.setCancelled(true);
            skills.aim(player);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onShoot(EntityShootBowEvent event) {
        if (event.getEntity() instanceof Player player && event.getProjectile() instanceof AbstractArrow arrow) {
            skills.onShoot(player, arrow);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof AbstractArrow arrow && event.getEntity() instanceof LivingEntity victim) {
            double bonus = skills.aimedBonus(arrow);
            if (bonus > 0) {
                event.setDamage(event.getDamage() * (1.0 + bonus));
                skills.glow(victim);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        skills.forget(event.getPlayer().getUniqueId());
        lastClick.remove(event.getPlayer().getUniqueId());
    }
}
