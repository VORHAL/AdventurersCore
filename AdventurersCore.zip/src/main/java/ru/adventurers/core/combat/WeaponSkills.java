package ru.adventurers.core.combat;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Умения Бойца (меч/топор) и Стрелка (лук/арбалет). Настройки: weapon.yml.
 * Управление и урон описаны в {@link WeaponListener}. Только основной поток.
 */
public class WeaponSkills {

    private final AdventurersCore plugin;
    private final NamespacedKey aimKey;
    private final Map<UUID, Long> sweepReady = new HashMap<>();
    private final Map<UUID, Long> rageReady = new HashMap<>();
    private final Map<UUID, Long> lungeReady = new HashMap<>();
    private final Map<UUID, Long> volleyReady = new HashMap<>();
    private final Map<UUID, Long> aimReady = new HashMap<>();
    private final Map<UUID, Long> backstepReady = new HashMap<>();
    private final Map<UUID, Long> aimUntil = new HashMap<>();
    private final Map<UUID, Double> aimBonus = new HashMap<>();

    private boolean enabled = true;
    private double universalFactor = 0.6;
    private YamlConfiguration cfg = new YamlConfiguration();

    public WeaponSkills(AdventurersCore plugin) {
        this.plugin = plugin;
        this.aimKey = new NamespacedKey(plugin, "aim_bonus");
    }

    public void init() {
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "weapon.yml");
        if (!file.exists()) {
            plugin.saveResource("weapon.yml", false);
        }
        cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        universalFactor = cfg.getDouble("universal-factor", 0.6);
    }

    public boolean isEnabled() {
        return enabled;
    }

    // ---------------------------------------------------------------
    //  Условия
    // ---------------------------------------------------------------

    private PlayerClass active(Player player) {
        return plugin.getClasses().activeClass(player.getUniqueId());
    }

    private double factor(Player player) {
        return active(player) == PlayerClass.UNIVERSAL ? universalFactor : 1.0;
    }

    private int rank(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? 0 : Math.min(7, profile.getRank().ordinal());
    }

    private double at(String path, Player player, double fallback) {
        List<?> list = cfg.getList(path);
        int index = rank(player);
        if (list != null && index < list.size() && list.get(index) instanceof Number number) {
            return number.doubleValue();
        }
        return fallback;
    }

    private double rune(Player player, String stat) {
        return plugin.getRunes() == null ? 0 : plugin.getRunes().bonus(player, stat);
    }

    private long cooldown(Player player, String path, double base, String runeStat) {
        double seconds = cfg.getDouble(path, base) * Math.max(0.3, 1.0 - rune(player, runeStat));
        return (long) (seconds * 1000);
    }

    public static boolean isMelee(ItemStack item) {
        if (item == null) {
            return false;
        }
        String name = item.getType().name();
        return name.endsWith("_SWORD") || name.endsWith("_AXE");
    }

    public static boolean isRanged(ItemStack item) {
        return item != null && (item.getType() == Material.BOW || item.getType() == Material.CROSSBOW);
    }

    private boolean classOk(Player player) {
        PlayerClass active = active(player);
        return active == PlayerClass.FIGHTER || active == PlayerClass.UNIVERSAL;
    }

    private boolean shieldInOffhand(Player player) {
        return player.getInventory().getItemInOffHand().getType() == Material.SHIELD;
    }

    /** Умения Бойца: класс подходит, в руке меч/топор; у Универсала нет щита в левой руке. */
    public boolean meleeReady(Player player) {
        if (!enabled || !player.isSneaking() || !classOk(player) || !isMelee(player.getInventory().getItemInMainHand())) {
            return false;
        }
        return !(active(player) == PlayerClass.UNIVERSAL && shieldInOffhand(player));
    }

    /** Умения Стрелка: класс подходит, в руке лук/арбалет. */
    public boolean rangedReady(Player player) {
        if (!enabled || !player.isSneaking() || !classOk(player) || !isRanged(player.getInventory().getItemInMainHand())) {
            return false;
        }
        return !(active(player) == PlayerClass.UNIVERSAL && shieldInOffhand(player));
    }

    public long remaining(Player player, String skill) {
        Map<UUID, Long> map = switch (skill) {
            case "sweep" -> sweepReady;
            case "rage" -> rageReady;
            case "lunge" -> lungeReady;
            case "volley" -> volleyReady;
            case "aim" -> aimReady;
            default -> backstepReady;
        };
        Long until = map.get(player.getUniqueId());
        return until == null ? 0 : Math.max(0, until - System.currentTimeMillis());
    }

    public long total(String skill) {
        String path = switch (skill) {
            case "sweep" -> "fighter.sweep.cooldown-seconds";
            case "rage" -> "fighter.rage.cooldown-seconds";
            case "lunge" -> "fighter.lunge.cooldown-seconds";
            case "volley" -> "archer.volley.cooldown-seconds";
            case "aim" -> "archer.aim.cooldown-seconds";
            default -> "archer.backstep.cooldown-seconds";
        };
        return (long) (cfg.getDouble(path, 10) * 1000);
    }

    private boolean ready(Map<UUID, Long> map, Player player, String name) {
        Long until = map.get(player.getUniqueId());
        long now = System.currentTimeMillis();
        if (until != null && now < until) {
            say(player, "&7" + name + " ещё не готов: &f" + ((until - now) / 1000 + 1) + "с");
            return false;
        }
        return true;
    }

    private void start(Map<UUID, Long> map, Player player, long cooldown) {
        map.put(player.getUniqueId(), System.currentTimeMillis() + cooldown);
    }

    private void say(Player player, String text) {
        plugin.getSkillHud().flash(player, Hud.legacy(text));
    }

    private static boolean target(org.bukkit.entity.Entity entity, Player self) {
        return entity instanceof LivingEntity && !(entity instanceof Player) && !(entity instanceof ArmorStand)
                && !entity.equals(self);
    }

    // ---------------------------------------------------------------
    //  Боец
    // ---------------------------------------------------------------

    /** Shift + ПКМ: удар по дуге. */
    public void sweep(Player player) {
        if (!ready(sweepReady, player, "Рассекающий удар")) {
            return;
        }
        double radius = at("fighter.sweep.radius", player, 3.5);
        double angle = Math.toRadians(cfg.getDouble("fighter.sweep.angle-degrees", 110) / 2.0);
        double damage = at("fighter.sweep.damage", player, 5) * factor(player) * (1.0 + rune(player, "sweep_damage"));
        double knock = cfg.getDouble("fighter.sweep.knockback", 0.6);
        Vector look = player.getLocation().getDirection().setY(0).normalize();
        int hits = 0;
        for (var entity : player.getNearbyEntities(radius, 2, radius)) {
            if (!target(entity, player)) {
                continue;
            }
            Vector to = entity.getLocation().toVector().subtract(player.getLocation().toVector()).setY(0);
            if (to.lengthSquared() < 0.0001 || look.angle(to.normalize()) > angle) {
                continue;
            }
            ((LivingEntity) entity).damage(damage, player);
            entity.setVelocity(to.normalize().multiply(knock).setY(0.25));
            hits++;
        }
        start(sweepReady, player, cooldown(player, "fighter.sweep.cooldown-seconds", 8, "sweep_cooldown"));
        Location at = player.getLocation().add(look.clone().multiply(1.5)).add(0, 1, 0);
        player.getWorld().spawnParticle(Particle.SWEEP_ATTACK, at, 3, 0.6, 0.2, 0.6, 0);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1.0f, 0.9f);
        say(player, "&c⚔ Рассекающий удар: &f" + hits + "&c целей");
    }

    /** Shift + F: сила и скорость. */
    public void rage(Player player) {
        if (!ready(rageReady, player, "Боевой раж")) {
            return;
        }
        double seconds = at("fighter.rage.duration-seconds", player, 8) * factor(player) * (1.0 + rune(player, "rage_duration"));
        int ticks = (int) (seconds * 20);
        int strength = (int) at("fighter.rage.strength", player, 0);
        int speed = (int) at("fighter.rage.speed", player, 0);
        player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, ticks, strength, false, true, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, ticks, speed, false, true, true));
        start(rageReady, player, cooldown(player, "fighter.rage.cooldown-seconds", 40, "rage_cooldown"));
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 0.7f, 1.4f);
        player.getWorld().spawnParticle(Particle.ANGRY_VILLAGER, player.getLocation().add(0, 1.8, 0), 10, 0.5, 0.3, 0.5, 0);
        say(player, "&c⚔ Боевой раж: &f" + (int) seconds + "с");
    }

    /** Shift + ЛКМ: рывок с уроном. */
    public void lunge(Player player) {
        if (!ready(lungeReady, player, "Выпад")) {
            return;
        }
        start(lungeReady, player, cooldown(player, "fighter.lunge.cooldown-seconds", 10, "lunge_cooldown"));
        double damage = at("fighter.lunge.damage", player, 4) * factor(player) * (1.0 + rune(player, "lunge_damage"));
        double speed = cfg.getDouble("fighter.lunge.speed", 1.6);
        int slow = cfg.getInt("fighter.lunge.slow-ticks", 40);
        Vector direction = player.getLocation().getDirection().setY(0).normalize();
        player.setVelocity(direction.clone().multiply(speed).setY(0.2));
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.2f);
        Set<UUID> hit = new HashSet<>();
        int[] ticks = {0};
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!player.isOnline() || ticks[0]++ > 8) {
                task.cancel();
                return;
            }
            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().add(0, 0.3, 0), 2, 0.2, 0.1, 0.2, 0.01);
            for (var entity : player.getNearbyEntities(1.6, 1.2, 1.6)) {
                if (target(entity, player) && hit.add(entity.getUniqueId())) {
                    LivingEntity living = (LivingEntity) entity;
                    living.damage(damage, player);
                    living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slow, 1, false, true, true));
                }
            }
        }, 1L, 1L);
        say(player, "&c⚔ Выпад!");
    }

    // ---------------------------------------------------------------
    //  Стрелок
    // ---------------------------------------------------------------

    /** Shift + ЛКМ: прыжок назад. */
    public void backstep(Player player) {
        if (!ready(backstepReady, player, "Отскок")) {
            return;
        }
        start(backstepReady, player, cooldown(player, "archer.backstep.cooldown-seconds", 10, "backstep_cooldown"));
        Vector back = player.getLocation().getDirection().setY(0).normalize().multiply(-cfg.getDouble("archer.backstep.speed", 1.3));
        back.setY(cfg.getDouble("archer.backstep.height", 0.45));
        player.setVelocity(back);
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, cfg.getInt("archer.backstep.speed-ticks", 40), 1, false, false, true));
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().add(0, 0.2, 0), 8, 0.3, 0.1, 0.3, 0.02);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 0.8f, 1.3f);
        say(player, "&6➹ Отскок!");
    }

    /** Shift + F: следующая стрела сильнее. */
    public void aim(Player player) {
        if (!ready(aimReady, player, "Меткий выстрел")) {
            return;
        }
        start(aimReady, player, cooldown(player, "archer.aim.cooldown-seconds", 20, "aim_cooldown"));
        double bonus = at("archer.aim.damage-bonus", player, 0.6) * factor(player) * (1.0 + rune(player, "aim_damage"));
        aimBonus.put(player.getUniqueId(), bonus);
        aimUntil.put(player.getUniqueId(), System.currentTimeMillis() + (long) (cfg.getDouble("archer.aim.window-seconds", 10) * 1000));
        player.playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.7f, 1.6f);
        say(player, "&6➹ Меткий выстрел готов: следующая стрела +" + Math.round(bonus * 100) + "% урона");
    }

    /** Вызывается при выстреле из лука: если «меткий выстрел» активен, помечаем стрелу. */
    public void onShoot(Player player, AbstractArrow arrow) {
        Long until = aimUntil.get(player.getUniqueId());
        if (until == null || System.currentTimeMillis() > until) {
            aimUntil.remove(player.getUniqueId());
            return;
        }
        aimUntil.remove(player.getUniqueId());
        Double bonus = aimBonus.remove(player.getUniqueId());
        if (bonus != null) {
            arrow.getPersistentDataContainer().set(aimKey, PersistentDataType.DOUBLE, bonus);
            arrow.setGlowing(true);
        }
    }

    /** Множитель урона помеченной стрелы (0 = не помечена). */
    public double aimedBonus(AbstractArrow arrow) {
        Double value = arrow.getPersistentDataContainer().get(aimKey, PersistentDataType.DOUBLE);
        return value == null ? 0 : value;
    }

    public void glow(LivingEntity victim) {
        victim.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,
                (int) (cfg.getDouble("archer.aim.glow-seconds", 5) * 20), 0, false, false, true));
    }

    /** Shift + ПКМ: веер стрел (тратит одну стрелу, если нет бесконечности). */
    public void volley(Player player) {
        if (!ready(volleyReady, player, "Град стрел")) {
            return;
        }
        ItemStack bow = player.getInventory().getItemInMainHand();
        boolean infinity = bow.containsEnchantment(org.bukkit.enchantments.Enchantment.INFINITY);
        if (!infinity && !takeArrow(player)) {
            say(player, "&cНет стрел");
            return;
        }
        start(volleyReady, player, cooldown(player, "archer.volley.cooldown-seconds", 25, "volley_cooldown"));
        int count = (int) at("archer.volley.arrows", player, 4) + (int) Math.round(rune(player, "volley_arrows"));
        double spread = Math.toRadians(cfg.getDouble("archer.volley.spread-degrees", 9));
        double damageFactor = cfg.getDouble("archer.volley.damage-factor", 0.7) * factor(player);
        Vector direction = player.getEyeLocation().getDirection();
        for (int i = 0; i < count; i++) {
            double offset = count == 1 ? 0 : (i - (count - 1) / 2.0) * spread;
            Vector velocity = direction.clone().rotateAroundY(offset).multiply(2.6);
            Arrow arrow = player.launchProjectile(Arrow.class, velocity);
            arrow.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
            arrow.setDamage(arrow.getDamage() * Math.max(0.3, damageFactor) * 1.5);
        }
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 0.8f);
        say(player, "&6➹ Град стрел: &f" + count);
    }

    private boolean takeArrow(Player player) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null && (item.getType() == Material.ARROW || item.getType() == Material.TIPPED_ARROW
                    || item.getType() == Material.SPECTRAL_ARROW)) {
                item.setAmount(item.getAmount() - 1);
                player.getInventory().setItem(i, item.getAmount() <= 0 ? null : item);
                return true;
            }
        }
        return false;
    }

    public void forget(UUID uuid) {
        for (Map<UUID, Long> map : List.of(sweepReady, rageReady, lungeReady, volleyReady, aimReady, backstepReady, aimUntil)) {
            map.remove(uuid);
        }
        aimBonus.remove(uuid);
    }
}
