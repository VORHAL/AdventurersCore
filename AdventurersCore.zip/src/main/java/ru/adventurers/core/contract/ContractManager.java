package ru.adventurers.core.contract;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.IsoFields;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Контракты гильдии: недельные, месячные и редкие заказы.
 * Недельные и месячные меняются по календарю (набор зависит от ранга игрока), редкие выпадают случайно
 * в течение дня и после принятия действуют несколько дней. Настройки: contracts.yml.
 * Состояние игрока лежит в его PDC.
 */
public class ContractManager implements Listener {

    public enum Period { WEEKLY, MONTHLY, RARE }

    record Def(String id, Period period, String name, String desc, String type, String target, int amount,
               Rank min, Rank max, long coins, int points, double chance, int days) {
    }

    /** Запись игрока: key - ключ периода (для редких - день принятия), status 0 принят, 1 награда получена. */
    private static final class Entry {
        String key;
        int progress;
        int status;
    }

    private static final class Menu implements InventoryHolder {
        final Map<Integer, String> ids = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final ZoneId ZONE = ZoneId.of("Europe/Moscow");

    private final AdventurersCore plugin;
    private final NamespacedKey dataKey;
    private final List<Def> defs = new ArrayList<>();
    private final Map<UUID, Map<String, Entry>> cache = new HashMap<>();
    private boolean enabled = true;
    private int weeklyCount = 3;
    private int monthlyCount = 2;

    public ContractManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.dataKey = new NamespacedKey(plugin, "contracts");
    }

    // ---------------------------------------------------------------
    //  Настройки
    // ---------------------------------------------------------------

    public void init() {
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "contracts.yml");
        if (!file.exists()) {
            plugin.saveResource("contracts.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        weeklyCount = Math.max(1, Math.min(3, cfg.getInt("weekly-count", 3)));
        monthlyCount = Math.max(1, Math.min(2, cfg.getInt("monthly-count", 2)));
        defs.clear();
        for (Map<?, ?> map : cfg.getMapList("contracts")) {
            try {
                Period period = Period.valueOf(String.valueOf(map.get("period")).toUpperCase(Locale.ROOT));
                Rank min = Rank.fromInput(map.get("rank") == null ? "F" : String.valueOf(map.get("rank")));
                Rank max = map.get("max-rank") == null ? null : Rank.fromInput(String.valueOf(map.get("max-rank")));
                defs.add(new Def(String.valueOf(map.get("id")), period, String.valueOf(map.get("name")),
                        map.get("desc") == null ? "" : String.valueOf(map.get("desc")),
                        String.valueOf(map.get("type")).toUpperCase(Locale.ROOT),
                        map.get("target") == null ? "ANY" : String.valueOf(map.get("target")).toUpperCase(Locale.ROOT),
                        num(map.get("amount"), 1).intValue(), min == null ? Rank.F : min, max,
                        num(map.get("coins"), 0).longValue(), num(map.get("points"), 0).intValue(),
                        num(map.get("chance"), 0.2).doubleValue(), num(map.get("days"), 3).intValue()));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("contracts.yml: bad contract " + map.get("id"));
            }
        }
    }

    private static Number num(Object value, Number fallback) {
        return value instanceof Number n ? n : fallback;
    }

    public boolean isEnabled() {
        return enabled;
    }

    // ---------------------------------------------------------------
    //  Состояние
    // ---------------------------------------------------------------

    private Map<String, Entry> entries(Player player) {
        return cache.computeIfAbsent(player.getUniqueId(), id -> {
            Map<String, Entry> map = new HashMap<>();
            String raw = player.getPersistentDataContainer().get(dataKey, PersistentDataType.STRING);
            if (raw != null && !raw.isEmpty()) {
                for (String part : raw.split(";")) {
                    String[] f = part.split("\\|");
                    if (f.length == 4) {
                        try {
                            Entry entry = new Entry();
                            entry.key = f[1];
                            entry.progress = Integer.parseInt(f[2]);
                            entry.status = Integer.parseInt(f[3]);
                            map.put(f[0], entry);
                        } catch (NumberFormatException ignored) {
                            // повреждённая запись пропускается
                        }
                    }
                }
            }
            return map;
        });
    }

    private void save(Player player) {
        StringBuilder out = new StringBuilder();
        entries(player).forEach((id, e) -> out.append(out.length() > 0 ? ";" : "")
                .append(id).append('|').append(e.key).append('|').append(e.progress).append('|').append(e.status));
        player.getPersistentDataContainer().set(dataKey, PersistentDataType.STRING, out.toString());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        cache.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cache.remove(event.getPlayer().getUniqueId());
    }

    // ---------------------------------------------------------------
    //  Периоды и набор заказов
    // ---------------------------------------------------------------

    private static String weekKey() {
        LocalDate now = LocalDate.now(ZONE);
        return now.get(IsoFields.WEEK_BASED_YEAR) + "W" + now.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
    }

    private static String monthKey() {
        LocalDate now = LocalDate.now(ZONE);
        return now.getYear() + "M" + now.getMonthValue();
    }

    private static long today() {
        return LocalDate.now(ZONE).toEpochDay();
    }

    private String keyOf(Def def) {
        return switch (def.period()) {
            case WEEKLY -> weekKey();
            case MONTHLY -> monthKey();
            case RARE -> "R";
        };
    }

    private Rank rankOf(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? Rank.F : profile.getRank();
    }

    private boolean fits(Def def, Rank rank) {
        return rank.isAtLeast(def.min()) && (def.max() == null || def.max().isAtLeast(rank));
    }

    /** Действующая запись по заказу или null (старый период, истёкший редкий). */
    private Entry current(Player player, Def def) {
        Entry entry = entries(player).get(def.id());
        if (entry == null) {
            return null;
        }
        if (def.period() == Period.RARE) {
            if (entry.status == 1) {
                return entry;
            }
            long accepted = Long.parseLong(entry.key.startsWith("D") ? entry.key.substring(1) : "0");
            return today() - accepted >= def.days() ? null : entry;
        }
        return entry.key.equals(keyOf(def)) ? entry : null;
    }

    /** Заказы периода, которые видит игрок. */
    private List<Def> offers(Player player, Period period) {
        Rank rank = rankOf(player);
        if (period == Period.RARE) {
            List<Def> list = new ArrayList<>();
            for (Def def : defs) {
                if (def.period() != Period.RARE || !fits(def, rank)) {
                    continue;
                }
                Entry entry = entries(player).get(def.id());
                if (entry != null && entry.status == 1) {
                    continue; // редкий заказ выполняется один раз
                }
                if (current(player, def) != null || roll(player, def)) {
                    list.add(def);
                }
            }
            return list.size() > 2 ? list.subList(0, 2) : list;
        }
        List<Def> pool = new ArrayList<>();
        for (Def def : defs) {
            if (def.period() == period && fits(def, rank)) {
                pool.add(def);
            }
        }
        String key = period == Period.WEEKLY ? weekKey() : monthKey();
        Collections.shuffle(pool, new Random((key + rank.name()).hashCode() * 31L + period.ordinal()));
        int count = period == Period.WEEKLY ? weeklyCount : monthlyCount;
        return pool.size() > count ? new ArrayList<>(pool.subList(0, count)) : pool;
    }

    private boolean roll(Player player, Def def) {
        long seed = player.getUniqueId().hashCode() * 31L + today() * 17L + def.id().hashCode();
        return new Random(seed).nextDouble() < def.chance();
    }

    private Def find(String id) {
        return defs.stream().filter(d -> d.id().equals(id)).findFirst().orElse(null);
    }

    // ---------------------------------------------------------------
    //  Прогресс
    // ---------------------------------------------------------------

    /**
     * Зачесть событие. type: KILL (target - тип существа), DUNGEON (target - NORMAL/HEROIC/RAID),
     * QUEST (сдача обычного задания).
     */
    public void progress(Player player, String type, String target, int amount) {
        if (!enabled || amount <= 0) {
            return;
        }
        boolean changed = false;
        for (Def def : defs) {
            if (!def.type().equals(type) || def.type().equals("DELIVER")) {
                continue;
            }
            if (!def.target().equals("ANY") && !def.target().equalsIgnoreCase(target)) {
                continue;
            }
            Entry entry = current(player, def);
            if (entry == null || entry.status != 0 || entry.progress >= def.amount()) {
                continue;
            }
            entry.progress = Math.min(def.amount(), entry.progress + amount);
            changed = true;
            if (entry.progress >= def.amount()) {
                plugin.getMessages().send(player, "contracts.ready", Map.of("name", def.name()));
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.6f, 1.4f);
            }
        }
        if (changed) {
            save(player);
        }
    }

    private int have(Player player, Def def) {
        Material material = Material.matchMaterial(def.target());
        if (material == null) {
            return 0;
        }
        int total = 0;
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack != null && stack.getType() == material) {
                total += stack.getAmount();
            }
        }
        return total;
    }

    private int shown(Player player, Def def, Entry entry) {
        if (def.type().equals("DELIVER")) {
            return Math.min(def.amount(), have(player, def));
        }
        return entry == null ? 0 : entry.progress;
    }

    // ---------------------------------------------------------------
    //  Принять / сдать
    // ---------------------------------------------------------------

    private void accept(Player player, Def def) {
        Entry entry = new Entry();
        entry.key = def.period() == Period.RARE ? "D" + today() : keyOf(def);
        entry.progress = 0;
        entry.status = 0;
        entries(player).put(def.id(), entry);
        save(player);
        plugin.getMessages().send(player, "contracts.accepted", Map.of("name", def.name()));
        player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1f);
    }

    private void claim(Player player, Def def, Entry entry) {
        if (def.type().equals("DELIVER")) {
            Material material = Material.matchMaterial(def.target());
            if (material == null || have(player, def) < def.amount()) {
                plugin.getMessages().send(player, "contracts.no-items");
                return;
            }
            int left = def.amount();
            ItemStack[] contents = player.getInventory().getContents();
            for (int i = 0; i < contents.length && left > 0; i++) {
                ItemStack stack = contents[i];
                if (stack != null && stack.getType() == material) {
                    int take = Math.min(left, stack.getAmount());
                    stack.setAmount(stack.getAmount() - take);
                    player.getInventory().setItem(i, stack.getAmount() <= 0 ? null : stack);
                    left -= take;
                }
            }
            entry.progress = def.amount();
        }
        entry.status = 1;
        save(player);
        if (def.coins() > 0 && plugin.getEconomy() != null) {
            plugin.getEconomy().give(player, def.coins());
        }
        if (def.points() > 0 && plugin.getQuests() != null) {
            plugin.getQuests().adminAddPoints(player, def.points());
        }
        plugin.getMessages().send(player, "contracts.claimed", Map.of("name", def.name(),
                "coins", def.coins() > 0 && plugin.getEconomy() != null ? plugin.getEconomy().format(def.coins()) : "-",
                "points", String.valueOf(def.points())));
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.1f);
        if (plugin.getGlory() != null) {
            plugin.getGlory().add(player, "CONTRACTS", 1);
        }
    }

    // ---------------------------------------------------------------
    //  Меню
    // ---------------------------------------------------------------

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Hud.legacy(name).decoration(TextDecoration.ITALIC, false));
        List<Component> lines = new ArrayList<>();
        lore.forEach(line -> lines.add(Hud.legacy(line).decoration(TextDecoration.ITALIC, false)));
        meta.lore(lines);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        stack.setItemMeta(meta);
        return stack;
    }

    private String timeLeft(Period period) {
        LocalDate now = LocalDate.now(ZONE);
        long days = period == Period.WEEKLY ? 7 - now.getDayOfWeek().getValue() + 1
                : now.lengthOfMonth() - now.getDayOfMonth() + 1;
        return days + " дн.";
    }

    private String goal(Def def) {
        return switch (def.type()) {
            case "KILL" -> "Убить: " + (def.target().equals("ANY") ? "любых существ" : def.target());
            case "DUNGEON" -> "Пройти подземелий" + (def.target().equals("ANY") ? "" : " (" + def.target() + ")");
            case "QUEST" -> "Сдать заданий гильдии";
            case "DELIVER" -> "Принести: " + def.target();
            default -> def.type();
        };
    }

    private void place(Player player, Menu menu, Inventory inventory, int slot, Def def) {
        Entry entry = current(player, def);
        int value = shown(player, def, entry);
        boolean claimed = entry != null && entry.status == 1;
        boolean ready = entry != null && !claimed && (def.type().equals("DELIVER") ? value >= def.amount() : entry.progress >= def.amount());
        List<String> lore = new ArrayList<>();
        if (!def.desc().isEmpty()) {
            lore.add("&7" + def.desc());
        }
        lore.add("&8" + goal(def));
        int filled = (int) ((long) value * 12 / def.amount());
        lore.add((ready || claimed ? "&a" : "&e") + "▌".repeat(filled) + "&8" + "▌".repeat(12 - filled)
                + " &f" + value + "&7/&f" + def.amount());
        List<String> reward = new ArrayList<>();
        if (def.coins() > 0 && plugin.getEconomy() != null) {
            reward.add(plugin.getEconomy().format(def.coins()));
        }
        if (def.points() > 0) {
            reward.add(def.points() + " оч. гильдии");
        }
        lore.add("&7Награда: &f" + (reward.isEmpty() ? "-" : String.join("&7, &f", reward)));
        if (def.period() == Period.RARE) {
            lore.add("&7Срок после принятия: &f" + def.days() + " дн.");
        } else {
            lore.add("&7Осталось: &f" + timeLeft(def.period()));
        }
        lore.add("");
        Material icon;
        if (claimed) {
            lore.add("&aВыполнено");
            icon = Material.LIME_DYE;
        } else if (ready) {
            lore.add("&aЛКМ &7- получить награду");
            icon = Material.EMERALD;
        } else if (entry != null) {
            lore.add(def.type().equals("DELIVER") ? "&7Соберите предметы и сдайте здесь" : "&7В работе");
            icon = def.type().equals("DELIVER") ? Material.CHEST : Material.WRITABLE_BOOK;
        } else {
            lore.add("&eЛКМ &7- принять");
            icon = def.period() == Period.RARE ? Material.NETHER_STAR : Material.BOOK;
        }
        if (entry != null && !claimed && def.type().equals("DELIVER") && value >= def.amount()) {
            lore.set(lore.size() - 1, "&aЛКМ &7- сдать и получить награду");
        }
        inventory.setItem(slot, item(icon, (def.period() == Period.RARE ? "&d" : "&6") + def.name(), lore));
        menu.ids.put(slot, def.id());
    }

    public void open(Player player) {
        if (!enabled) {
            plugin.getMessages().send(player, "contracts.disabled");
            return;
        }
        Menu menu = new Menu();
        Inventory inventory = Bukkit.createInventory(menu, 54, Hud.legacy("&8Контракты гильдии"));
        ItemStack pane = item(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 54; i++) {
            inventory.setItem(i, pane);
        }
        inventory.setItem(4, item(Material.WRITABLE_BOOK, "&6Контракты", List.of(
                "&7Долгие заказы гильдии: за неделю,",
                "&7за месяц и редкие, что появляются",
                "&7случайно. Принимайте и выполняйте.")));
        inventory.setItem(9, item(Material.CLOCK, "&eНа неделю", List.of("&7Обновляются по понедельникам.")));
        inventory.setItem(27, item(Material.CLOCK, "&bНа месяц", List.of("&7Обновляются с первого числа.")));
        inventory.setItem(33, item(Material.ENDER_EYE, "&dРедкие", List.of("&7Выпадают случайно и недолго.")));
        int[] weekly = {11, 13, 15};
        int[] monthly = {29, 31};
        int[] rare = {34, 35};
        List<Def> list = offers(player, Period.WEEKLY);
        for (int i = 0; i < list.size() && i < weekly.length; i++) {
            place(player, menu, inventory, weekly[i], list.get(i));
        }
        list = offers(player, Period.MONTHLY);
        for (int i = 0; i < list.size() && i < monthly.length; i++) {
            place(player, menu, inventory, monthly[i], list.get(i));
        }
        list = offers(player, Period.RARE);
        if (list.isEmpty()) {
            inventory.setItem(34, item(Material.GRAY_DYE, "&8Сегодня тихо", List.of("&7Загляните завтра.")));
        }
        for (int i = 0; i < list.size() && i < rare.length; i++) {
            place(player, menu, inventory, rare[i], list.get(i));
        }
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Menu menu) || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        Def def = find(menu.ids.get(event.getSlot()));
        if (def == null) {
            return;
        }
        Entry entry = current(player, def);
        if (entry == null) {
            accept(player, def);
        } else if (entry.status == 0) {
            boolean done = def.type().equals("DELIVER") ? have(player, def) >= def.amount() : entry.progress >= def.amount();
            if (done) {
                claim(player, def, entry);
            }
        }
        open(player);
    }

    // ---------------------------------------------------------------
    //  Админ: /ag admin contracts reset <ник> | reload
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        String action = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
        if (action.equals("reload")) {
            reload();
            sender.sendMessage(Hud.legacy("&aКонтракты перечитаны: " + defs.size()));
        } else if (action.equals("reset") && args.length > 3) {
            Player target = Bukkit.getPlayerExact(args[3]);
            if (target == null) {
                sender.sendMessage(Hud.legacy("&cИгрок не в сети."));
                return;
            }
            entries(target).clear();
            save(target);
            sender.sendMessage(Hud.legacy("&aКонтракты игрока сброшены."));
        } else {
            sender.sendMessage(Hud.legacy("&7/ag admin contracts reset <ник>|reload"));
        }
    }
}
