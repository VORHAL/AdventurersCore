package ru.adventurers.core.covenant;

import org.bukkit.Location;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Ковенант (клан): состав, казна и участок земли. Данные хранит CovenantManager. */
public final class Covenant {

    public enum Role {
        LEADER("Глава", "&6"),
        OFFICER("Офицер", "&b"),
        MEMBER("Участник", "&7");

        public final String title;
        public final String color;

        Role(String title, String color) {
            this.title = title;
            this.color = color;
        }
    }

    public static final class Member {
        public String name;
        public Role role;
        public final long joined;
        /** Сколько монет игрок за всё время внёс в казну. */
        public long contrib;

        public Member(String name, Role role, long joined) {
            this.name = name;
            this.role = role;
            this.joined = joined;
        }
    }

    public final int id;
    public String name;
    public UUID leader;
    public long bank;
    public final long created;
    public final Map<UUID, Member> members = new LinkedHashMap<>();
    public String motd = "";
    /** Сколько вкладок банка уже куплено (первая открыта сразу). */
    public int tabsOpen = 1;
    // неделя ковенантов: очки рейтинга и цель недели
    public long weekScore;
    public long goalProgress;
    public boolean goalDone;
    public int weekId;
    /** Всего внесено в казну за всё время: от этого растёт уровень ковенанта. */
    public long contributed;

    // банк предметов: вкладки по 45 ячеек; живые инвентари общие для всех, кто смотрит вкладку
    public static final int TABS = 6;
    public static final int SLOTS = 45;
    public final org.bukkit.inventory.ItemStack[][] saved = new org.bukkit.inventory.ItemStack[TABS][SLOTS];
    public final org.bukkit.inventory.Inventory[] live = new org.bukkit.inventory.Inventory[TABS];
    /** Последние записи журнала: {время, текст}. Новые в конце. */
    public final java.util.ArrayList<Object[]> log = new java.util.ArrayList<>();

    // участок: квадрат со стороной 2*half вокруг (cx, cz), по всей высоте мира
    public String world;
    public int cx;
    public int cz;
    public int half;
    public String sizeId;

    public Covenant(int id, String name, UUID leader, long bank, long created) {
        this.id = id;
        this.name = name;
        this.leader = leader;
        this.bank = bank;
        this.created = created;
    }

    public boolean hasTerritory() {
        return world != null && half > 0;
    }

    public boolean contains(Location location) {
        return hasTerritory() && location.getWorld() != null && location.getWorld().getName().equals(world)
                && contains(location.getBlockX(), location.getBlockZ(), 0);
    }

    /** Попадает ли точка в участок, расширенный на margin блоков. */
    public boolean contains(int x, int z, int margin) {
        return x >= cx - half - margin && x < cx + half + margin && z >= cz - half - margin && z < cz + half + margin;
    }

    /** Пересекается ли участок с квадратом (x, z, h) с зазором gap. */
    public boolean overlaps(String otherWorld, int x, int z, int h, int gap) {
        return hasTerritory() && world.equals(otherWorld)
                && Math.abs(cx - x) < half + h + gap && Math.abs(cz - z) < half + h + gap;
    }

    public Role role(UUID uuid) {
        Member member = members.get(uuid);
        return member == null ? null : member.role;
    }

    public boolean atLeast(UUID uuid, Role role) {
        Role own = role(uuid);
        return own != null && own.ordinal() <= role.ordinal();
    }
}
