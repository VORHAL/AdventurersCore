package ru.adventurers.core.covenant;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import ru.adventurers.core.AdventurersCore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Банк ковенанта в духе гильдейского банка WoW: вкладки с предметами, права по ролям,
 * суточный лимит выдачи для рядовых, журнал операций. Настройки: covenants.yml, раздел bank.
 * Каждая вкладка - один общий инвентарь: все, кто её смотрят, видят изменения сразу, дублировать предметы нельзя.
 */
public class CovenantBank implements Listener {

    public record Tab(String name, Material icon, Covenant.Role view, Covenant.Role deposit,
                      Covenant.Role withdraw, int level, long price) {
    }

    private static final int CONTROL_ROW = 45;
    private static final int LOG_KEEP = 60;

    private abstract static class Holder implements InventoryHolder {
        final int covenant;

        Holder(int covenant) {
            this.covenant = covenant;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final class HubHolder extends Holder {
        HubHolder(int covenant) {
            super(covenant);
        }
    }

    private static final class TabHolder extends Holder {
        final int tab;

        TabHolder(int covenant, int tab) {
            super(covenant);
            this.tab = tab;
        }
    }

    private final AdventurersCore plugin;
    private final CovenantManager manager;
    private final List<Tab> tabs = new ArrayList<>();
    private int memberDaily = 64;
    /** uuid -> {epochDay, выдано предметов за день} */
    private final Map<UUID, long[]> taken = new HashMap<>();

    public CovenantBank(AdventurersCore plugin, CovenantManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    // ---------------------------------------------------------------
    //  Настройки и загрузка
    // ---------------------------------------------------------------

    public void reload(ConfigurationSection cfg) {
        tabs.clear();
        memberDaily = cfg == null ? 64 : Math.max(0, cfg.getInt("member-daily-withdraw-items", 64));
        ConfigurationSection section = cfg == null ? null : cfg.getConfigurationSection("tabs");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                ConfigurationSection t = section.getConfigurationSection(key);
                if (t == null || tabs.size() >= Covenant.TABS) {
                    continue;
                }
                Material icon = Material.matchMaterial(t.getString("icon", "CHEST"));
                tabs.add(new Tab(t.getString("name", key), icon == null ? Material.CHEST : icon,
                        role(t.getString("view"), Covenant.Role.MEMBER), role(t.getString("deposit"), Covenant.Role.MEMBER),
                        role(t.getString("withdraw"), Covenant.Role.OFFICER), Math.max(1, t.getInt("level", 1)), Math.max(0, t.getLong("price", 0))));
            }
        }
        if (tabs.isEmpty()) {
            tabs.add(new Tab("Общий склад", Material.CHEST, Covenant.Role.MEMBER, Covenant.Role.MEMBER,
                    Covenant.Role.MEMBER, 1, 0));
        }
    }

    private static Covenant.Role role(String text, Covenant.Role fallback) {
        if (text == null) {
            return fallback;
        }
        try {
            return Covenant.Role.valueOf(text.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            return fallback;
        }
    }

    public void load(Connection connection, Map<Integer, Covenant> covenants) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT covenant, tab, slot, data FROM ag_covenant_item")) {
            while (rs.next()) {
                Covenant cov = covenants.get(rs.getInt("covenant"));
                int tab = rs.getInt("tab");
                int slot = rs.getInt("slot");
                if (cov == null || tab < 0 || tab >= Covenant.TABS || slot < 0 || slot >= Covenant.SLOTS) {
                    continue;
                }
                try {
                    cov.saved[tab][slot] = ItemStack.deserializeBytes(rs.getBytes("data"));
                } catch (RuntimeException exception) {
                    plugin.getLogger().warning("Covenant bank: bad item skipped (" + cov.id + "/" + tab + "/" + slot + ")");
                }
            }
        }
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT covenant, ts, text FROM ag_covenant_log ORDER BY id")) {
            while (rs.next()) {
                Covenant cov = covenants.get(rs.getInt("covenant"));
                if (cov != null) {
                    cov.log.add(new Object[]{rs.getLong("ts"), rs.getString("text")});
                    while (cov.log.size() > LOG_KEEP) {
                        cov.log.remove(0);
                    }
                }
            }
        }
    }

    public int tabCount() {
        return tabs.size();
    }

    // ---------------------------------------------------------------
    //  Журнал
    // ---------------------------------------------------------------

    public void log(Covenant cov, String text) {
        long now = System.currentTimeMillis();
        cov.log.add(new Object[]{now, text});
        while (cov.log.size() > LOG_KEEP) {
            cov.log.remove(0);
        }
        manager.io("INSERT INTO ag_covenant_log (covenant, ts, text) VALUES (?,?,?)", cov.id, now,
                text.length() > 230 ? text.substring(0, 230) : text);
    }

    private static String when(long ts) {
        java.time.LocalDateTime time = java.time.LocalDateTime.ofInstant(java.time.Instant.ofEpochMilli(ts),
                java.time.ZoneId.systemDefault());
        return String.format(Locale.ROOT, "%02d.%02d %02d:%02d", time.getDayOfMonth(), time.getMonthValue(),
                time.getHour(), time.getMinute());
    }

    /** Последние записи журнала в чат. */
    public void printLog(Player player, Covenant cov, int count) {
        manager.say(player, "log-header");
        if (cov.log.isEmpty()) {
            manager.say(player, "log-empty");
            return;
        }
        for (int i = Math.max(0, cov.log.size() - count); i < cov.log.size(); i++) {
            Object[] entry = cov.log.get(i);
            manager.say(player, "log-line", "time", when((Long) entry[0]), "text", entry[1]);
        }
    }

    private List<String> logLore(Covenant cov, int count) {
        List<String> lore = new ArrayList<>();
        if (cov.log.isEmpty()) {
            lore.add("&8Записей пока нет.");
            return lore;
        }
        for (int i = Math.max(0, cov.log.size() - count); i < cov.log.size(); i++) {
            Object[] entry = cov.log.get(i);
            lore.add("&8" + when((Long) entry[0]) + " &7" + entry[1]);
        }
        return lore;
    }

    // ---------------------------------------------------------------
    //  Доступ
    // ---------------------------------------------------------------

    /** Вкладка открыта, если куплена (они покупаются по порядку, первая открыта сразу). */
    private boolean unlocked(Covenant cov, int tab) {
        return tab < tabs.size() && tab < cov.tabsOpen;
    }

    /** Глава открывает следующую вкладку за монеты из казны. */
    public void buyTab(Player player, Covenant cov) {
        if (!cov.leader.equals(player.getUniqueId())) {
            manager.say(player, "need-leader");
            return;
        }
        int index = cov.tabsOpen;
        if (index >= tabs.size()) {
            manager.say(player, "tab-all");
            return;
        }
        Tab tab = tabs.get(index);
        if (manager.level(cov) < tab.level()) {
            manager.say(player, "tab-level", "name", tab.name(), "level", tab.level());
            return;
        }
        if (cov.bank < tab.price()) {
            manager.say(player, "tab-poor", "name", tab.name(), "price", manager.money(tab.price()),
                    "bank", manager.money(cov.bank));
            return;
        }
        manager.addBank(cov, -tab.price());
        cov.tabsOpen = index + 1;
        manager.io("UPDATE ag_covenant SET tabs_open=? WHERE id=?", cov.tabsOpen, cov.id);
        log(cov, player.getName() + " открыл вкладку «" + tab.name() + "» за " + plugin.getEconomy().plain(tab.price()));
        manager.broadcastTo(cov, "tab-bought", "name", tab.name(), "price", manager.money(tab.price()));
    }

    private boolean allowed(Covenant cov, Player player, Covenant.Role need) {
        return player.hasPermission("ag.admin") && cov.members.containsKey(player.getUniqueId())
                || cov.atLeast(player.getUniqueId(), need);
    }

    // ---------------------------------------------------------------
    //  Окна
    // ---------------------------------------------------------------

    public void openHub(Player player, Covenant cov) {
        Inventory inventory = Bukkit.createInventory(new HubHolder(cov.id), 36,
                ru.adventurers.core.hud.Hud.legacy("&8Банк ковенанта: " + cov.name));
        manager.filler(inventory);
        int level = manager.level(cov);
        inventory.setItem(4, manager.item(Material.GOLD_BLOCK, "&6Казна: " + manager.money(cov.bank), List.of(
                "&7Уровень ковенанта: &f" + level + "&7, вкладов всего: " + manager.money(cov.contributed),
                "&7Земли покупаются из казны.", "",
                "&eЛКМ по кнопкам ниже &7- положить монеты",
                "&7Снять (глава): &f/ag covenant withdraw <сумма>")));
        for (int i = 0; i < tabs.size() && i < 7; i++) {
            Tab tab = tabs.get(i);
            boolean open = unlocked(cov, i);
            boolean view = allowed(cov, player, tab.view());
            int filled = 0;
            Inventory live = cov.live[i];
            for (int s = 0; s < Covenant.SLOTS; s++) {
                ItemStack stack = live != null ? live.getItem(s) : cov.saved[i][s];
                if (stack != null && !stack.getType().isAir()) {
                    filled++;
                }
            }
            List<String> lore = new ArrayList<>();
            if (!open) {
                if (i == cov.tabsOpen) {
                    lore.add("&7Цена: " + manager.money(tab.price()) + "&7 из казны");
                    if (manager.level(cov) < tab.level()) {
                        lore.add("&cНужен уровень ковенанта &f" + tab.level());
                    }
                    lore.add("");
                    lore.add(cov.leader.equals(player.getUniqueId()) ? "&eЛКМ &7- открыть вкладку" : "&8Открывает глава");
                } else {
                    lore.add("&8Сначала откройте предыдущую вкладку");
                }
            } else {
                lore.add("&7Занято ячеек: &f" + filled + "&7/&f" + Covenant.SLOTS);
                lore.add("&7Смотреть: &f" + tab.view().title + "&7+");
                lore.add("&7Положить: &f" + tab.deposit().title + "&7+");
                lore.add("&7Взять: &f" + tab.withdraw().title + "&7+" + (tab.withdraw() == Covenant.Role.MEMBER && memberDaily > 0
                        ? " &8(рядовым до " + memberDaily + " предметов в день)" : ""));
                lore.add("");
                lore.add(view ? "&eЛКМ &7- открыть" : "&cНет доступа по роли");
            }
            inventory.setItem(10 + i, manager.item(open ? tab.icon() : Material.BARRIER,
                    (open ? "&e" : i == cov.tabsOpen ? "&6" : "&8") + tab.name(), lore));
        }
        List<String> logLore = new ArrayList<>(logLore(cov, 8));
        logLore.add(0, "&7Последние операции:");
        logLore.add("");
        logLore.add("&eЛКМ &7- показать в чате");
        inventory.setItem(22, manager.item(Material.BOOK, "&bЖурнал банка", logLore));
        inventory.setItem(28, manager.item(Material.COPPER_INGOT, "&6Положить 100", List.of("&eЛКМ")));
        inventory.setItem(29, manager.item(Material.IRON_INGOT, "&6Положить 1 000", List.of("&eЛКМ")));
        inventory.setItem(30, manager.item(Material.GOLD_INGOT, "&6Положить 10 000", List.of("&eЛКМ")));
        inventory.setItem(31, manager.item(Material.ARROW, "&7Назад", List.of()));
        player.openInventory(inventory);
    }

    public void openTab(Player player, Covenant cov, int index) {
        if (index < 0 || index >= tabs.size() || !unlocked(cov, index)) {
            manager.say(player, "bank-locked");
            return;
        }
        Tab tab = tabs.get(index);
        if (!allowed(cov, player, tab.view())) {
            manager.say(player, "bank-no-access", "role", tab.view().title);
            return;
        }
        Inventory inventory = cov.live[index];
        if (inventory == null) {
            inventory = Bukkit.createInventory(new TabHolder(cov.id, index), 54,
                    ru.adventurers.core.hud.Hud.legacy("&8Банк: " + tab.name()));
            for (int s = 0; s < Covenant.SLOTS; s++) {
                inventory.setItem(s, cov.saved[index][s] == null ? null : cov.saved[index][s].clone());
            }
            ItemStack pane = manager.item(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
            for (int s = CONTROL_ROW; s < 54; s++) {
                inventory.setItem(s, pane);
            }
            for (int i = 0; i < tabs.size() && i < 6; i++) {
                boolean open = unlocked(cov, i);
                boolean current = i == index;
                inventory.setItem(CONTROL_ROW + i, manager.item(open ? tabs.get(i).icon() : Material.BARRIER,
                        (current ? "&6» " : open ? "&e" : "&8") + tabs.get(i).name(),
                        List.of(open ? (current ? "&7Открыта сейчас" : "&eЛКМ &7- открыть") : "&cНе открыта")));
            }
            inventory.setItem(52, manager.item(Material.ARROW, "&7К банку", List.of()));
            cov.live[index] = inventory;
        }
        player.openInventory(inventory);
    }

    // ---------------------------------------------------------------
    //  Клики
    // ---------------------------------------------------------------

    private boolean isTop(InventoryClickEvent event) {
        return event.getRawSlot() < event.getView().getTopInventory().getSize();
    }

    private static boolean empty(ItemStack stack) {
        return stack == null || stack.getType().isAir();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (!(holder instanceof Holder base)) {
            return;
        }
        Covenant cov = manager.byId(base.covenant);
        if (cov == null || !cov.members.containsKey(player.getUniqueId())) {
            event.setCancelled(true);
            player.closeInventory();
            return;
        }
        if (holder instanceof HubHolder) {
            event.setCancelled(true);
            if (event.getClickedInventory() != event.getView().getTopInventory()) {
                return;
            }
            hubClick(player, cov, event.getSlot());
            return;
        }
        TabHolder tabHolder = (TabHolder) holder;
        Tab tab = tabs.get(tabHolder.tab);
        boolean top = isTop(event);
        if (top && event.getRawSlot() >= CONTROL_ROW) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (slot == 52) {
                openHub(player, cov);
            } else if (slot - CONTROL_ROW < tabs.size() && slot - CONTROL_ROW != tabHolder.tab) {
                openTab(player, cov, slot - CONTROL_ROW);
            }
            return;
        }
        if (!allowed(cov, player, tab.view())) {
            event.setCancelled(true);
            player.closeInventory();
            return;
        }
        boolean deposit = false;
        boolean withdraw = false;
        int estimate = 0;
        InventoryAction action = event.getAction();
        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        if (top) {
            switch (action) {
                case PICKUP_ALL, PICKUP_SOME, MOVE_TO_OTHER_INVENTORY, DROP_ALL_SLOT, PICKUP_ONE -> {
                    withdraw = !empty(current);
                    estimate = empty(current) ? 0 : action == InventoryAction.PICKUP_ONE ? 1 : current.getAmount();
                }
                case PICKUP_HALF -> {
                    withdraw = !empty(current);
                    estimate = empty(current) ? 0 : (current.getAmount() + 1) / 2;
                }
                case DROP_ONE_SLOT -> {
                    withdraw = !empty(current);
                    estimate = 1;
                }
                case PLACE_ALL, PLACE_SOME, PLACE_ONE -> deposit = true;
                case SWAP_WITH_CURSOR -> {
                    deposit = !empty(cursor);
                    withdraw = !empty(current);
                    estimate = empty(current) ? 0 : current.getAmount();
                }
                case HOTBAR_SWAP, HOTBAR_MOVE_AND_READD -> {
                    ItemStack hotbar = event.getClick() == ClickType.SWAP_OFFHAND ? player.getInventory().getItemInOffHand()
                            : event.getHotbarButton() >= 0 ? player.getInventory().getItem(event.getHotbarButton()) : null;
                    deposit = !empty(hotbar);
                    withdraw = !empty(current);
                    estimate = empty(current) ? 0 : current.getAmount();
                }
                default -> {
                    event.setCancelled(true);
                    return;
                }
            }
        } else if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            deposit = true;
        } else if (action == InventoryAction.COLLECT_TO_CURSOR) {
            event.setCancelled(true);
            return;
        }
        if (deposit && !allowed(cov, player, tab.deposit())) {
            event.setCancelled(true);
            manager.say(player, "bank-no-deposit", "role", tab.deposit().title);
            return;
        }
        if (withdraw) {
            if (!allowed(cov, player, tab.withdraw())) {
                event.setCancelled(true);
                manager.say(player, "bank-no-withdraw", "role", tab.withdraw().title);
                return;
            }
            if (!limitOk(cov, player, estimate)) {
                event.setCancelled(true);
                return;
            }
        }
        if (deposit || withdraw) {
            // после клика сверяем содержимое, пишем журнал и сохраняем
            Bukkit.getScheduler().runTask(plugin, () -> sync(cov, tabHolder.tab, player.getName()));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (!(holder instanceof Holder base) || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int size = event.getView().getTopInventory().getSize();
        boolean touchesTop = event.getRawSlots().stream().anyMatch(slot -> slot < size);
        if (!touchesTop) {
            return;
        }
        Covenant cov = manager.byId(base.covenant);
        if (!(holder instanceof TabHolder tabHolder) || cov == null
                || event.getRawSlots().stream().anyMatch(slot -> slot >= CONTROL_ROW && slot < size)
                || !allowed(cov, player, tabs.get(tabHolder.tab).deposit())) {
            event.setCancelled(true);
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> sync(cov, tabHolder.tab, player.getName()));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof TabHolder holder) {
            Covenant cov = manager.byId(holder.covenant);
            if (cov != null && event.getPlayer() instanceof Player player) {
                sync(cov, holder.tab, player.getName());
                // пустую вкладку без зрителей не держим в памяти
                Inventory inventory = cov.live[holder.tab];
                if (inventory != null && inventory.getViewers().size() <= 1) {
                    cov.live[holder.tab] = null;
                }
            }
        }
    }

    private void hubClick(Player player, Covenant cov, int slot) {
        if (slot >= 10 && slot < 10 + Math.min(7, tabs.size())) {
            int index = slot - 10;
            if (!unlocked(cov, index) && index == cov.tabsOpen) {
                buyTab(player, cov);
                openHub(player, cov);
            } else {
                openTab(player, cov, index);
            }
        } else if (slot == 22) {
            printLog(player, cov, 15);
        } else if (slot == 28) {
            manager.depositMoney(player, cov, 100);
            openHub(player, cov);
        } else if (slot == 29) {
            manager.depositMoney(player, cov, 1000);
            openHub(player, cov);
        } else if (slot == 30) {
            manager.depositMoney(player, cov, 10000);
            openHub(player, cov);
        } else if (slot == 31) {
            manager.openMain(player, cov);
        }
    }

    // ---------------------------------------------------------------
    //  Лимит выдачи, сохранение
    // ---------------------------------------------------------------

    private boolean limitOk(Covenant cov, Player player, int amount) {
        if (memberDaily <= 0 || amount <= 0 || cov.atLeast(player.getUniqueId(), Covenant.Role.OFFICER)) {
            return true;
        }
        long day = LocalDate.now().toEpochDay();
        long[] state = taken.computeIfAbsent(player.getUniqueId(), k -> new long[]{day, 0});
        if (state[0] != day) {
            state[0] = day;
            state[1] = 0;
        }
        if (state[1] + amount > memberDaily) {
            manager.say(player, "bank-limit", "limit", memberDaily, "left", Math.max(0, memberDaily - state[1]));
            return false;
        }
        state[1] += amount;
        return true;
    }

    private static String name(ItemStack stack) {
        if (stack.hasItemMeta() && stack.getItemMeta().hasDisplayName()) {
            return net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                    .serialize(stack.getItemMeta().displayName());
        }
        return stack.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private static boolean same(ItemStack a, ItemStack b) {
        if (empty(a) && empty(b)) {
            return true;
        }
        return !empty(a) && !empty(b) && a.getAmount() == b.getAmount() && a.isSimilar(b);
    }

    /** Сверяет живую вкладку с сохранённой копией: пишет в БД изменённые ячейки и в журнал, что произошло. */
    public void sync(Covenant cov, int tab, String who) {
        Inventory inventory = cov.live[tab];
        if (inventory == null) {
            return;
        }
        for (int slot = 0; slot < Covenant.SLOTS; slot++) {
            ItemStack now = inventory.getItem(slot);
            ItemStack before = cov.saved[tab][slot];
            if (same(now, before)) {
                continue;
            }
            if (!empty(before) && (empty(now) || !before.isSimilar(now))) {
                log(cov, who + " взял " + before.getAmount() + "× " + name(before) + " (" + tabs.get(tab).name() + ")");
            }
            if (!empty(now)) {
                int delta = !empty(before) && before.isSimilar(now) ? now.getAmount() - before.getAmount() : now.getAmount();
                if (delta > 0) {
                    log(cov, who + " положил " + delta + "× " + name(now) + " (" + tabs.get(tab).name() + ")");
                } else if (delta < 0) {
                    log(cov, who + " взял " + (-delta) + "× " + name(now) + " (" + tabs.get(tab).name() + ")");
                }
            }
            cov.saved[tab][slot] = empty(now) ? null : now.clone();
            if (empty(now)) {
                manager.io("DELETE FROM ag_covenant_item WHERE covenant=? AND tab=? AND slot=?", cov.id, tab, slot);
            } else {
                manager.io("REPLACE INTO ag_covenant_item (covenant, tab, slot, data) VALUES (?,?,?,?)",
                        cov.id, tab, slot, now.serializeAsBytes());
            }
        }
    }

    public void syncAll(Iterable<Covenant> all) {
        for (Covenant cov : all) {
            for (int tab = 0; tab < Covenant.TABS; tab++) {
                sync(cov, tab, "?");
            }
        }
    }

    /** Есть ли в банке хоть один предмет (нужно для роспуска). */
    public boolean hasItems(Covenant cov) {
        for (int tab = 0; tab < Covenant.TABS; tab++) {
            for (int slot = 0; slot < Covenant.SLOTS; slot++) {
                ItemStack stack = cov.live[tab] != null ? cov.live[tab].getItem(slot) : cov.saved[tab][slot];
                if (!empty(stack)) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Закрывает окна банка у игрока (если его исключили). */
    public void closeFor(Player player) {
        if (player.getOpenInventory().getTopInventory().getHolder() instanceof Holder) {
            player.closeInventory();
        }
    }

    public void deleteAll(int covenantId) {
        manager.io("DELETE FROM ag_covenant_item WHERE covenant=?", covenantId);
        manager.io("DELETE FROM ag_covenant_log WHERE covenant=?", covenantId);
    }
}
