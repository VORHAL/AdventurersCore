package ru.adventurers.core.covenant;

import org.bukkit.Bukkit;
import org.bukkit.DyeColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BannerMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Знамя ковенанта: предмет, который глава или офицер покупает из казны и ставит на землях ковенанта.
 * Рядом со знамёнами участники получают лёгкий бафф. Настройки: covenants.yml, раздел banner.
 */
public class CovenantBanner implements Listener {

    private record Pos(String world, int x, int y, int z) {
    }

    private final AdventurersCore plugin;
    private final CovenantManager manager;
    private final NamespacedKey idKey;
    private final Map<Integer, List<Pos>> placed = new HashMap<>();
    private final List<PotionEffect> effects = new ArrayList<>();
    private long cost = 2000;
    private int max = 2;
    private int radius = 16;
    private int minLevel = 2;

    public CovenantBanner(AdventurersCore plugin, CovenantManager manager) {
        this.plugin = plugin;
        this.manager = manager;
        this.idKey = new NamespacedKey(plugin, "covenant_banner");
    }

    public void reload(ConfigurationSection cfg) {
        effects.clear();
        cost = cfg == null ? 2000 : Math.max(0, cfg.getLong("cost", 2000));
        max = cfg == null ? 2 : Math.max(1, cfg.getInt("max", 2));
        radius = cfg == null ? 16 : Math.max(4, cfg.getInt("radius", 16));
        minLevel = cfg == null ? 2 : Math.max(1, cfg.getInt("min-level", 2));
        List<String> list = cfg == null ? List.of("REGENERATION:0", "RESISTANCE:0") : cfg.getStringList("buff");
        for (String entry : list) {
            String[] parts = entry.split(":");
            PotionEffectType type = PotionEffectType.getByName(parts[0].toUpperCase(Locale.ROOT));
            if (type == null) {
                continue;
            }
            int level = 0;
            try {
                level = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
            } catch (NumberFormatException ignored) {
                // уровень по умолчанию
            }
            effects.add(new PotionEffect(type, 20 * 8, level, true, false, true));
        }
    }

    public void load(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS ag_covenant_banner (
                        covenant INT NOT NULL,
                        world VARCHAR(64) NOT NULL,
                        x INT NOT NULL, y INT NOT NULL, z INT NOT NULL,
                        PRIMARY KEY (world, x, y, z)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                    """);
        }
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT * FROM ag_covenant_banner")) {
            while (rs.next()) {
                placed.computeIfAbsent(rs.getInt("covenant"), k -> new ArrayList<>())
                        .add(new Pos(rs.getString("world"), rs.getInt("x"), rs.getInt("y"), rs.getInt("z")));
            }
        }
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, 100L);
    }

    private void tick() {
        if (!manager.isEnabled() || effects.isEmpty()) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            Covenant cov = manager.of(player.getUniqueId());
            List<Pos> list = cov == null ? null : placed.get(cov.id);
            if (list == null || list.isEmpty()) {
                continue;
            }
            Location at = player.getLocation();
            for (Pos pos : list) {
                if (pos.world().equals(at.getWorld().getName())
                        && Math.abs(pos.x() - at.getX()) <= radius && Math.abs(pos.z() - at.getZ()) <= radius
                        && Math.abs(pos.y() - at.getY()) <= radius) {
                    effects.forEach(player::addPotionEffect);
                    break;
                }
            }
        }
    }

    public int count(Covenant cov) {
        return placed.getOrDefault(cov.id, List.of()).size();
    }

    /** Выдаёт знамя за монеты из казны. */
    public void give(Player player, Covenant cov) {
        if (!cov.atLeast(player.getUniqueId(), Covenant.Role.OFFICER)) {
            manager.say(player, "need-officer");
            return;
        }
        if (manager.level(cov) < minLevel) {
            manager.say(player, "banner-level", "level", minLevel);
            return;
        }
        if (!cov.hasTerritory()) {
            manager.say(player, "banner-no-land");
            return;
        }
        if (count(cov) >= max) {
            manager.say(player, "banner-max", "max", max);
            return;
        }
        if (cov.bank < cost) {
            manager.say(player, "banner-poor", "cost", manager.money(cost), "bank", manager.money(cov.bank));
            return;
        }
        manager.addBank(cov, -cost);
        ItemStack banner = new ItemStack(Material.PURPLE_BANNER);
        BannerMeta meta = (BannerMeta) banner.getItemMeta();
        meta.addPattern(new Pattern(DyeColor.YELLOW, PatternType.BORDER));
        meta.addPattern(new Pattern(DyeColor.YELLOW, PatternType.CIRCLE));
        meta.displayName(Hud.legacy("&6Знамя «" + cov.name + "»")
                .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        meta.lore(List.of(Hud.legacy("&7Ставится на землях ковенанта.").decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false),
                Hud.legacy("&7Рядом участники получают бафф.").decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.INTEGER, cov.id);
        banner.setItemMeta(meta);
        player.getInventory().addItem(banner).values()
                .forEach(rest -> player.getWorld().dropItemNaturally(player.getLocation(), rest));
        manager.getBank().log(cov, player.getName() + " купил знамя за " + plugin.getEconomy().plain(cost));
        manager.say(player, "banner-given", "cost", manager.money(cost), "max", max);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        ItemStack hand = event.getItemInHand();
        if (hand == null || !hand.hasItemMeta()) {
            return;
        }
        Integer id = hand.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.INTEGER);
        if (id == null) {
            return;
        }
        Player player = event.getPlayer();
        Covenant cov = manager.byId(id);
        Block block = event.getBlock();
        if (cov == null || !cov.members.containsKey(player.getUniqueId()) || !cov.contains(block.getLocation())) {
            event.setCancelled(true);
            manager.say(player, "banner-place-bad");
            return;
        }
        Pos pos = new Pos(block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
        placed.computeIfAbsent(cov.id, k -> new ArrayList<>()).add(pos);
        manager.io("REPLACE INTO ag_covenant_banner (covenant, world, x, y, z) VALUES (?,?,?,?,?)",
                cov.id, pos.world(), pos.x(), pos.y(), pos.z());
        manager.say(player, "banner-placed");
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (!block.getType().name().endsWith("BANNER")) {
            return;
        }
        for (Map.Entry<Integer, List<Pos>> entry : placed.entrySet()) {
            boolean removed = entry.getValue().removeIf(pos -> pos.world().equals(block.getWorld().getName())
                    && pos.x() == block.getX() && pos.y() == block.getY() && pos.z() == block.getZ());
            if (removed) {
                manager.io("DELETE FROM ag_covenant_banner WHERE world=? AND x=? AND y=? AND z=?",
                        block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
                return;
            }
        }
    }

    /** Сносит записи знамён ковенанта (роспуск, снятие земель). */
    public void clear(int covenantId) {
        placed.remove(covenantId);
        manager.io("DELETE FROM ag_covenant_banner WHERE covenant=?", covenantId);
    }
}
