package ru.adventurers.core.covenant;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Неделя ковенантов: очки за подземелья, задания и вклады в казну, рейтинг с наградами топ-3
 * и общая цель недели. Настройки: covenants.yml, раздел weekly. Неделя меняется в понедельник по ISO.
 */
public class CovenantWeekly {

    public record Goal(String type, long target, String name, long reward) {
    }

    private final AdventurersCore plugin;
    private final CovenantManager manager;
    private final List<Goal> goals = new ArrayList<>();
    private long[] rewards = {20000, 10000, 5000};
    private int scoreQuest = 2;
    private int scoreDungeon = 10;
    private int scoreHeroic = 25;
    private int scoreRaid = 50;
    private int coinsPerPoint = 100;
    private int weekId;
    private List<String> lastTop = new ArrayList<>();
    private File dataFile;

    public CovenantWeekly(AdventurersCore plugin, CovenantManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    static int currentWeek() {
        LocalDate now = LocalDate.now();
        return now.get(IsoFields.WEEK_BASED_YEAR) * 100 + now.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR);
    }

    public void reload(ConfigurationSection cfg) {
        goals.clear();
        if (cfg == null) {
            cfg = new YamlConfiguration();
        }
        scoreQuest = cfg.getInt("score.quest", 2);
        scoreDungeon = cfg.getInt("score.dungeon", 10);
        scoreHeroic = cfg.getInt("score.heroic", 25);
        scoreRaid = cfg.getInt("score.raid", 50);
        coinsPerPoint = Math.max(1, cfg.getInt("score.coins-per-point", 100));
        List<Long> list = cfg.getLongList("rewards");
        if (!list.isEmpty()) {
            rewards = list.stream().mapToLong(Long::longValue).toArray();
        }
        for (Map<?, ?> map : cfg.getMapList("goals")) {
            String type = String.valueOf(map.get("type")).toUpperCase();
            long target = map.get("target") instanceof Number n ? n.longValue() : 1;
            long reward = map.get("reward") instanceof Number n ? n.longValue() : 0;
            String name = map.get("name") == null ? type : String.valueOf(map.get("name"));
            if (type.equals("DEPOSIT") || type.equals("DUNGEON") || type.equals("QUEST")) {
                goals.add(new Goal(type, Math.max(1, target), name, Math.max(0, reward)));
            }
        }
        if (goals.isEmpty()) {
            goals.add(new Goal("DEPOSIT", 20000, "Пополнить казну на {target} монет", 5000));
        }
    }

    public void init() {
        dataFile = new File(plugin.getDataFolder(), "covenant-weekly.yml");
        YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
        weekId = data.getInt("week", 0);
        lastTop = new ArrayList<>(data.getStringList("last-top"));
        checkWeek();
        Bukkit.getScheduler().runTaskTimer(plugin, this::checkWeek, 20L * 60 * 5, 20L * 60 * 5);
    }

    private void saveData() {
        YamlConfiguration data = new YamlConfiguration();
        data.set("week", weekId);
        data.set("last-top", lastTop);
        try {
            data.save(dataFile);
        } catch (IOException exception) {
            plugin.getLogger().warning("covenant-weekly.yml: " + exception.getMessage());
        }
    }

    // ---------------------------------------------------------------
    //  Смена недели
    // ---------------------------------------------------------------

    private void checkWeek() {
        int now = currentWeek();
        if (weekId == now) {
            return;
        }
        if (weekId != 0) {
            rollover();
        }
        weekId = now;
        for (Covenant cov : manager.all()) {
            cov.weekScore = 0;
            cov.goalProgress = 0;
            cov.goalDone = false;
            cov.weekId = now;
            manager.saveWeekly(cov);
        }
        saveData();
    }

    private void rollover() {
        List<Covenant> ranked = new ArrayList<>();
        for (Covenant cov : manager.all()) {
            if (cov.weekScore > 0) {
                ranked.add(cov);
            }
        }
        ranked.sort((a, b) -> Long.compare(b.weekScore, a.weekScore));
        lastTop = new ArrayList<>();
        for (int i = 0; i < Math.min(3, ranked.size()); i++) {
            Covenant cov = ranked.get(i);
            long reward = i < rewards.length ? rewards[i] : 0;
            lastTop.add(cov.name + "|" + cov.weekScore + "|" + reward);
            if (reward > 0) {
                manager.addBank(cov, reward);
            }
            manager.getBank().log(cov, "Итог недели: " + (i + 1) + " место, награда в казну " + reward);
            manager.broadcastTo(cov, "weekly-reward", "place", i + 1, "reward", manager.money(reward));
        }
        if (!ranked.isEmpty()) {
            Bukkit.broadcast(ru.adventurers.core.hud.Hud.legacy(plugin.getMessages().text("covenant.weekly-announce",
                    "{prefix}&6Итоги недели ковенантов: &f{first}&6 впереди!")
                    .replace("{prefix}", plugin.getMessages().text("prefix", ""))
                    .replace("{first}", ranked.get(0).name)));
        }
    }

    // ---------------------------------------------------------------
    //  Очки и цель
    // ---------------------------------------------------------------

    public Goal goal() {
        return goals.get(Math.floorMod(weekId == 0 ? currentWeek() : weekId, goals.size()));
    }

    private void score(Covenant cov, long points) {
        checkWeek();
        cov.weekScore += points;
        manager.saveWeekly(cov);
    }

    private void progress(Covenant cov, String type, long amount) {
        Goal goal = goal();
        if (!goal.type().equals(type) || cov.goalDone) {
            return;
        }
        cov.goalProgress += amount;
        if (cov.goalProgress >= goal.target()) {
            cov.goalDone = true;
            cov.weekScore += 20;
            if (goal.reward() > 0) {
                manager.addBank(cov, goal.reward());
            }
            manager.getBank().log(cov, "Цель недели выполнена, награда в казну " + goal.reward());
            manager.broadcastTo(cov, "goal-done", "reward", manager.money(goal.reward()));
        }
        manager.saveWeekly(cov);
    }

    public void questDone(Player player) {
        Covenant cov = manager.of(player.getUniqueId());
        if (cov != null && manager.isEnabled()) {
            score(cov, scoreQuest);
            progress(cov, "QUEST", 1);
        }
    }

    public void dungeonCleared(Player player, boolean heroic, boolean raid) {
        Covenant cov = manager.of(player.getUniqueId());
        if (cov != null && manager.isEnabled()) {
            score(cov, raid ? scoreRaid : heroic ? scoreHeroic : scoreDungeon);
            progress(cov, "DUNGEON", 1);
        }
    }

    public void deposited(Covenant cov, long coins) {
        score(cov, coins / coinsPerPoint);
        progress(cov, "DEPOSIT", coins);
    }

    // ---------------------------------------------------------------
    //  Показ
    // ---------------------------------------------------------------

    public String goalText(Covenant cov) {
        Goal goal = goal();
        return goal.name().replace("{target}", String.valueOf(goal.target())) + " (" + Math.min(cov.goalProgress, goal.target())
                + "/" + goal.target() + (cov.goalDone ? ", выполнено" : "") + ")";
    }

    public List<String> goalLore(Covenant cov) {
        Goal goal = goal();
        long done = Math.min(cov.goalProgress, goal.target());
        int filled = (int) (done * 20 / goal.target());
        String bar = "&a" + "▌".repeat(filled) + "&8" + "▌".repeat(20 - filled);
        List<String> lore = new ArrayList<>();
        lore.add("&7" + goal.name().replace("{target}", String.valueOf(goal.target())));
        lore.add(bar + " &f" + done + "&7/&f" + goal.target());
        lore.add(cov.goalDone ? "&aВыполнено! Награда в казне." : "&7Награда в казну: " + manager.money(goal.reward()));
        return lore;
    }

    public void printTop(Player player) {
        checkWeek();
        manager.say(player, "top-header");
        List<Covenant> ranked = new ArrayList<>(manager.all());
        ranked.removeIf(cov -> cov.weekScore <= 0);
        ranked.sort((a, b) -> Long.compare(b.weekScore, a.weekScore));
        if (ranked.isEmpty()) {
            manager.say(player, "top-empty");
        }
        Covenant mine = manager.of(player.getUniqueId());
        for (int i = 0; i < Math.min(10, ranked.size()); i++) {
            Covenant cov = ranked.get(i);
            manager.say(player, mine == cov ? "top-line-mine" : "top-line", "place", i + 1, "name", cov.name,
                    "score", cov.weekScore);
        }
        if (mine != null && !ranked.contains(mine)) {
            manager.say(player, "top-line-mine", "place", "-", "name", mine.name, "score", mine.weekScore);
        }
        if (!lastTop.isEmpty()) {
            manager.say(player, "top-last");
            for (int i = 0; i < lastTop.size(); i++) {
                String[] parts = lastTop.get(i).split("\\|");
                manager.say(player, "top-last-line", "place", i + 1, "name", parts[0], "score", parts.length > 1 ? parts[1] : "?");
            }
        }
        manager.say(player, "top-points-help");
    }
}
