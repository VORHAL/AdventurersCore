package ru.adventurers.core.dungeon;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.gem.GemManager;
import ru.adventurers.core.party.Party;
import ru.adventurers.core.party.PartyManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Подземелья: у каждой группы своя копия карты в отдельном мире, комнаты с волнами,
 * мини-боссы и финальный босс, жизни, награда. Настройки: dungeons.yml и dungeons/&lt;id&gt;.yml.
 * Все методы вызываются из основного потока.
 */
public class DungeonManager implements Listener {

    /** Пустой мир без генерации. */
    private static final class VoidGenerator extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World world, Random random) {
            return new Location(world, 0.5, 100, 0.5);
        }
    }

    private enum State { LOADING, RUNNING, COMPLETE, CLOSING }

    private final class Instance {
        final int slot;
        final DungeonDef def;
        final Location origin;          // нижний угол копии
        final Set<UUID> members = new HashSet<>();
        final Map<UUID, Integer> lives = new HashMap<>();
        final Set<UUID> mobs = new HashSet<>();
        final Set<Integer> phasesDone = new HashSet<>();
        final long created = System.currentTimeMillis();
        State state = State.LOADING;
        int room = 0;
        int wave = -1;                  // -1: комната ещё не начата
        UUID boss;
        double bossMax;
        BossBar bar;
        Location checkpoint;
        long closeAt;
        boolean admin;
        boolean heroic;
        String invasion;                // метка вторжения (null: обычное подземелье)
        long copyIndex;
        BukkitTask copyTask;

        Instance(int slot, DungeonDef def, Location origin) {
            this.slot = slot;
            this.def = def;
            this.origin = origin;
        }

        int lives() {
            return heroic ? def.heroic.lives() : def.lives;
        }

        double mobHealth() {
            return heroic ? def.heroic.mobHealth() : def.mobHealth;
        }

        double mobDamage() {
            return heroic ? def.heroic.mobDamage() : def.mobDamage;
        }

        int timeLimit() {
            return heroic ? def.heroic.timeLimitMinutes() : def.timeLimitMinutes;
        }

        Location abs(double[] rel) {
            return origin.clone().add(rel[0], rel[1], rel[2]);
        }
    }

    private final AdventurersCore plugin;
    private final NamespacedKey mobKey;
    private final NamespacedKey runsKey;
    private final Random random = new Random();

    private final Map<String, DungeonDef> defs = new LinkedHashMap<>();
    private final Map<Integer, Instance> instances = new HashMap<>();
    private final Map<UUID, Instance> byPlayer = new HashMap<>();
    private final Map<UUID, Location> returnTo = new HashMap<>();
    private final Map<UUID, Inventory> rewards = new HashMap<>();
    private BukkitTask task;

    private boolean enabled = true;
    private String hubWorld = "";
    private String instanceWorldName = "dungeon_instances";
    private int spacing = 512;
    private int maxInstances = 4;
    private int copyPerTick = 12000;
    private int dailyLimit = 1;
    private boolean soloNeedsPass = true;
    private boolean showAllInMenu = false;
    private final NamespacedKey passKey;
    private int closeDelaySeconds = 120;
    private boolean heroicNeedsNormal = true;
    private double healthPerExtra = 0.35;
    private double damagePerExtra = 0.10;

    public DungeonManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.mobKey = new NamespacedKey(plugin, "dungeon_mob");
        this.runsKey = new NamespacedKey(plugin, "dungeon_runs");
        this.passKey = new NamespacedKey(plugin, "dungeon_solo_pass");
    }

    // ---------------------------------------------------------------
    //  Запуск и настройки
    // ---------------------------------------------------------------

    public void init() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 10L);
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
        }
        for (Instance instance : new ArrayList<>(instances.values())) {
            close(instance, false);
        }
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "dungeons.yml");
        if (!file.exists()) {
            plugin.saveResource("dungeons.yml", false);
        }
        File dir = new File(plugin.getDataFolder(), "dungeons");
        if (!dir.exists()) {
            plugin.saveResource("dungeons/test.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        hubWorld = cfg.getString("hub-world", "");
        instanceWorldName = cfg.getString("instance-world", "dungeon_instances");
        spacing = Math.max(128, cfg.getInt("instance-spacing", 512));
        maxInstances = Math.max(1, cfg.getInt("max-instances", 4));
        copyPerTick = Math.max(1000, cfg.getInt("copy-blocks-per-tick", 12000));
        dailyLimit = cfg.getInt("daily-limit", 1);
        soloNeedsPass = cfg.getBoolean("solo.requires-pass", true);
        showAllInMenu = cfg.getBoolean("menu.show-all-ranks", false);
        closeDelaySeconds = Math.max(10, cfg.getInt("close-delay-seconds", 120));
        heroicNeedsNormal = cfg.getBoolean("heroic-requires-normal-clear", true);
        healthPerExtra = cfg.getDouble("scaling.health-per-extra-player", 0.35);
        damagePerExtra = cfg.getDouble("scaling.damage-per-extra-player", 0.10);

        defs.clear();
        File[] files = dir.listFiles((d, name) -> name.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                String id = f.getName().substring(0, f.getName().length() - 4).toLowerCase(Locale.ROOT);
                try {
                    defs.put(id, new DungeonDef(id, YamlConfiguration.loadConfiguration(f)));
                } catch (RuntimeException exception) {
                    plugin.getLogger().warning("Dungeon " + id + ": " + exception.getMessage());
                }
            }
        }
    }

    public java.util.Collection<DungeonDef> definitions() {
        return defs.values();
    }

    private World voidWorld(String name) {
        World world = Bukkit.getWorld(name);
        if (world == null) {
            WorldCreator creator = new WorldCreator(name);
            creator.generator(new VoidGenerator());
            world = creator.createWorld();
        }
        if (world != null) {
            world.setAutoSave(false);
            world.setPVP(false);
            world.setTime(6000);
            world.setSpawnLocation(0, 100, 0);
        }
        return world;
    }

    private void say(Player player, String key, Map<String, ?> placeholders) {
        plugin.getMessages().send(player, key, placeholders);
    }

    private void sayAll(Instance instance, String key, Map<String, ?> placeholders) {
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                say(player, key, placeholders);
            }
        }
    }

    private void titleAll(Instance instance, String title, String subtitle) {
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                player.showTitle(Title.title(Hud.legacy(title), Hud.legacy(subtitle)));
            }
        }
    }

    // ---------------------------------------------------------------
    //  Суточный лимит и прохождения
    // ---------------------------------------------------------------

    private int runsToday(Player player) {
        String value = player.getPersistentDataContainer().get(runsKey, PersistentDataType.STRING);
        if (value == null) {
            return 0;
        }
        String[] parts = value.split("\\|");
        if (parts.length != 2 || !parts[0].equals(LocalDate.now().toString())) {
            return 0;
        }
        try {
            return Integer.parseInt(parts[1]);
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private void addRun(Player player) {
        player.getPersistentDataContainer().set(runsKey, PersistentDataType.STRING,
                LocalDate.now() + "|" + (runsToday(player) + 1));
    }

    // ---------------------------------------------------------------
    //  Блокировка после прохождения и пропуска для соло
    // ---------------------------------------------------------------

    private NamespacedKey lockKey(DungeonDef def, boolean heroic) {
        return new NamespacedKey(plugin, "dungeon_lock_" + def.id + (heroic ? "_h" : "_n"));
    }

    /** Сколько дней осталось до повторного захода (0 = можно). Блокировка ставится при победе. */
    public int lockDaysLeft(Player player, DungeonDef def, boolean heroic) {
        Long day = player.getPersistentDataContainer().get(lockKey(def, heroic), PersistentDataType.LONG);
        if (day == null) {
            return 0;
        }
        int days = heroic ? def.heroicLockoutDays : def.lockoutDays;
        long left = day + days - LocalDate.now().toEpochDay();
        return (int) Math.max(0, left);
    }

    private void setLock(Player player, DungeonDef def, boolean heroic) {
        player.getPersistentDataContainer().set(lockKey(def, heroic), PersistentDataType.LONG,
                LocalDate.now().toEpochDay());
    }

    /** Сбросить блокировки игрока (id = null: все подземелья). Возвращает число сброшенных. */
    public int resetLocks(Player player, String id) {
        int count = 0;
        for (DungeonDef def : defs.values()) {
            if (id != null && !def.id.equalsIgnoreCase(id)) {
                continue;
            }
            for (boolean heroic : new boolean[]{false, true}) {
                if (player.getPersistentDataContainer().has(lockKey(def, heroic), PersistentDataType.LONG)) {
                    player.getPersistentDataContainer().remove(lockKey(def, heroic));
                    count++;
                }
            }
        }
        if (id == null) {
            player.getPersistentDataContainer().remove(runsKey);
        }
        return count;
    }

    public int soloPasses(Player player) {
        Integer value = player.getPersistentDataContainer().get(passKey, PersistentDataType.INTEGER);
        return value == null ? 0 : value;
    }

    /** Выдать пропуски на одиночный вход (вызывается заданием гильдии или админом). */
    public void grantSoloPass(Player player, int amount) {
        player.getPersistentDataContainer().set(passKey, PersistentDataType.INTEGER,
                Math.max(0, soloPasses(player) + amount));
    }

    // ---------------------------------------------------------------
    //  Вход
    // ---------------------------------------------------------------

    private String modeName(Instance instance) {
        return instance.def.name + (instance.heroic ? " &c[Героический]" : "");
    }

    private NamespacedKey clearKey(DungeonDef def) {
        return new NamespacedKey(plugin, "dungeon_clear_" + def.id);
    }

    private boolean cleared(Player player, DungeonDef def) {
        return player.getPersistentDataContainer().has(clearKey(def), PersistentDataType.BYTE);
    }

    /** Меню выбора: ЛКМ по предмету - обычное, ПКМ - героическое. */
    private static final class MenuHolder implements org.bukkit.inventory.InventoryHolder {
        final List<DungeonDef> shown = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    public void list(Player player) {
        if (defs.isEmpty()) {
            say(player, "dungeon.none", Map.of());
            return;
        }
        if (!hubWorld.isEmpty() && !player.getWorld().getName().equalsIgnoreCase(hubWorld)
                && !player.hasPermission("ag.admin")) {
            say(player, "dungeon.only-hub", Map.of());
            return;
        }
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        boolean admin = player.hasPermission("ag.admin");
        List<DungeonDef> visible = new ArrayList<>();
        for (DungeonDef def : defs.values()) {
            boolean fits = profile != null && def.rankInRange(profile.getRank(), def.minRank);
            boolean heroicFits = def.heroic.enabled() && profile != null
                    && def.rankInRange(profile.getRank(), def.heroic.minRank());
            // игроку показываем то, что подходит его рангу (и рейды при ранге от минимального)
            if (showAllInMenu || admin || fits || heroicFits) {
                visible.add(def);
            }
        }
        visible.sort(java.util.Comparator.comparing((DungeonDef d) -> d.raid)
                .thenComparingInt(d -> d.minRank.ordinal())
                .thenComparingInt(d -> d.maxRank == null ? 99 : d.maxRank.ordinal())
                .thenComparing(d -> d.id));
        MenuHolder holder = new MenuHolder();
        int rows = Math.max(2, Math.min(6, (visible.size() + 8) / 9 + 1));
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, Hud.legacy("&8Подземелья"));
        var noItalic = net.kyori.adventure.text.format.TextDecoration.ITALIC;
        int slot = 0;
        for (DungeonDef def : visible) {
            if (slot >= rows * 9 - 9) {
                break;
            }
            holder.shown.add(def);
            Material icon = Material.matchMaterial(def.icon);
            ItemStack item = new ItemStack(icon == null ? Material.IRON_DOOR : icon);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Hud.legacy((def.raid ? "&5[Рейд] " : "") + def.name).decoration(noItalic, false));
            List<Component> lore = new ArrayList<>();
            if (!def.description.isEmpty()) {
                lore.add(Hud.legacy("&7" + def.description));
                lore.add(Component.empty());
            }
            boolean okNormal = profile != null && def.rankInRange(profile.getRank(), def.minRank);
            int lockN = lockDaysLeft(player, def, false);
            lore.add(Hud.legacy("&8Ранги: &f" + def.rankText()));
            lore.add(Hud.legacy("&8Обычный: " + (okNormal ? "&a" : "&c") + "доступен"
                    + "&7, жизней &f" + def.lives + "&7, " + (def.raid ? "рейд" : "игроков &f" + def.minPlayers + "-" + def.maxPlayers)));
            lore.add(Hud.legacy("&7  награда: &6" + def.points + " очков"
                    + (lockN > 0 ? "  &cдоступно через " + lockN + " дн." : "")));
            if (def.heroic.enabled()) {
                boolean okHeroic = profile != null && def.rankInRange(profile.getRank(), def.heroic.minRank());
                boolean open = !heroicNeedsNormal || cleared(player, def);
                int lockH = lockDaysLeft(player, def, true);
                lore.add(Hud.legacy("&8Героический: " + (okHeroic && open ? "&a" : "&c") + "ранг от "
                        + def.heroic.minRank().getDisplayName() + "&7, мобы сильнее, награда &6"
                        + def.heroic.points() + " очков&7 + руны"
                        + (open ? "" : " &8(сначала пройдите обычный)")
                        + (lockH > 0 ? " &cчерез " + lockH + " дн." : "")));
            }
            if (def.raid) {
                PartyManager parties = plugin.getParties();
                lore.add(Hud.legacy("&7Состав: &f" + parties.maxSize(Party.Type.RAID) + " &7игроков: танков &f"
                        + parties.need("tank") + "&7, лекарей &f" + parties.need("healer")
                        + "&7, бойцов &f" + parties.need("fighter")));
                lore.add(Hud.legacy("&7Вход через рейд: &f/ag raid"));
            } else {
                lore.add(Hud.legacy("&7Состав: танков &f" + def.needTanks + "&7, лекарей &f" + def.needHealers));
                if (soloNeedsPass) {
                    lore.add(Hud.legacy("&8Один можно только по пропуску гильдии (у вас: &f" + soloPasses(player) + "&8)"));
                }
            }
            lore.add(Component.empty());
            lore.add(Hud.legacy("&eЛКМ &7- обычный" + (def.heroic.enabled() ? "   &cПКМ &7- героический" : "")));
            lore.replaceAll(c -> c.decoration(noItalic, false));
            meta.lore(lore);
            item.setItemMeta(meta);
            inventory.setItem(slot++, item);
        }
        player.openInventory(inventory);
    }

    @EventHandler
    public void onMenuClick(org.bukkit.event.inventory.InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof MenuHolder holder)
                || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        if (slot < 0 || slot >= holder.shown.size()) {
            return;
        }
        boolean heroic = event.getClick().isRightClick();
        DungeonDef def = holder.shown.get(slot);
        player.closeInventory();
        enter(player, def.id, heroic, false);
    }

    public void enter(Player leader, String id, boolean heroic, boolean adminTest) {
        DungeonDef def = defs.get(id.toLowerCase(Locale.ROOT));
        if (def == null) {
            say(leader, "dungeon.unknown", Map.of());
            return;
        }
        if (heroic && !def.heroic.enabled()) {
            say(leader, "dungeon.no-heroic", Map.of());
            return;
        }
        Rank needRank = heroic ? def.heroic.minRank() : def.minRank;
        boolean solo = false;
        boolean usePass = false;
        if (!enabled && !adminTest) {
            say(leader, "dungeon.disabled", Map.of());
            return;
        }
        if (byPlayer.containsKey(leader.getUniqueId())) {
            say(leader, "dungeon.already-in", Map.of());
            return;
        }
        List<Player> team = new ArrayList<>();
        if (adminTest) {
            team.add(leader);
        } else {
            PartyManager parties = plugin.getParties();
            Party group = def.raid ? parties.raid(leader.getUniqueId()) : parties.group(leader.getUniqueId());
            if (group != null && !group.getLeader().equals(leader.getUniqueId())) {
                say(leader, "dungeon.not-leader", Map.of());
                return;
            }
            if (group == null || (!def.raid && group.size() == 1)) {
                if (def.raid) {
                    say(leader, "dungeon.no-raid", Map.of());
                    return;
                }
                // одиночный вход: только по пропуску гильдии
                solo = true;
                if (soloNeedsPass && !leader.hasPermission("ag.admin") && soloPasses(leader) <= 0) {
                    say(leader, "dungeon.solo-denied", Map.of());
                    return;
                }
                group = null;
            }
            List<UUID> ids = new ArrayList<>();
            if (group == null) {
                ids.add(leader.getUniqueId());
            } else {
                if (def.raid) {
                    if (group.size() != parties.maxSize(Party.Type.RAID) || !parties.raidReady(group)) {
                        say(leader, "dungeon.raid-composition", Map.of("size", parties.maxSize(Party.Type.RAID),
                                "tanks", parties.need("tank"), "healers", parties.need("healer"),
                                "fighters", parties.need("fighter")));
                        return;
                    }
                } else if (group.size() < def.minPlayers || group.size() > def.maxPlayers) {
                    say(leader, "dungeon.size", Map.of("min", def.minPlayers, "max", def.maxPlayers));
                    return;
                }
                ids.addAll(group.members());
            }
            for (UUID member : ids) {
                Player player = Bukkit.getPlayer(member);
                if (player == null) {
                    say(leader, "dungeon.offline", Map.of());
                    return;
                }
                PlayerProfile profile = plugin.getProfileManager().getProfile(member);
                if (profile == null || !profile.getRank().isAtLeast(needRank)) {
                    say(leader, "dungeon.rank-low", Map.of("player", player.getName(), "rank", needRank.getDisplayName()));
                    return;
                }
                if (def.maxRank != null && !def.maxRank.isAtLeast(profile.getRank())) {
                    say(leader, "dungeon.rank-high", Map.of("player", player.getName(), "rank", def.maxRank.getDisplayName()));
                    return;
                }
                if (byPlayer.containsKey(member)) {
                    say(leader, "dungeon.member-busy", Map.of("player", player.getName()));
                    return;
                }
                if (heroic && heroicNeedsNormal && !cleared(player, def)) {
                    say(leader, "dungeon.heroic-locked", Map.of("player", player.getName()));
                    return;
                }
                int left = lockDaysLeft(player, def, heroic);
                if (left > 0) {
                    say(leader, "dungeon.locked", Map.of("player", player.getName(), "days", left));
                    return;
                }
                if (dailyLimit > 0 && runsToday(player) >= dailyLimit) {
                    say(leader, "dungeon.limit-daily", Map.of("player", player.getName(), "limit", dailyLimit));
                    return;
                }
                team.add(player);
            }
            if (!solo && !def.raid) {
                PartyManager.Composition comp = parties.composition(group);
                if (comp.tanks() < def.needTanks || comp.healers() < def.needHealers) {
                    say(leader, "dungeon.composition", Map.of("tanks", def.needTanks, "healers", def.needHealers));
                    return;
                }
            }
            usePass = solo && soloNeedsPass && !leader.hasPermission("ag.admin");
        }

        int slot = freeSlot();
        if (slot < 0) {
            say(leader, "dungeon.busy", Map.of());
            return;
        }
        World world = voidWorld(instanceWorldName);
        World template = voidWorld(def.templateWorld);
        if (world == null || template == null) {
            say(leader, "dungeon.world-error", Map.of());
            return;
        }
        int minY = Math.min(def.pos1[1], def.pos2[1]);
        Instance instance = new Instance(slot, def, new Location(world, 1000 + (double) slot * spacing, minY, 0));
        instance.admin = adminTest;
        instance.heroic = heroic;
        instances.put(slot, instance);
        if (usePass) {
            grantSoloPass(leader, -1);
            say(leader, "dungeon.solo-used", Map.of("left", soloPasses(leader)));
        }
        for (Player player : team) {
            instance.members.add(player.getUniqueId());
            instance.lives.put(player.getUniqueId(), instance.lives());
            byPlayer.put(player.getUniqueId(), instance);
            returnTo.put(player.getUniqueId(), player.getLocation().clone());
            if (!adminTest) {
                addRun(player);
            }
            say(player, "dungeon.loading", Map.of("name", modeName(instance)));
        }
        startCopy(instance, template);
    }

    /**
     * Запуск подземелья для вторжения: без проверок ранга, блокировок и дневного лимита.
     * Возвращает null при успехе или ключ ошибки из messages.yml (раздел dungeon).
     */
    public String startInvasion(Player leader, List<Player> team, String id, String tag) {
        DungeonDef def = defs.get(id.toLowerCase(Locale.ROOT));
        if (def == null) {
            return "dungeon.unknown";
        }
        for (Player player : team) {
            if (byPlayer.containsKey(player.getUniqueId())) {
                return "dungeon.already-in";
            }
        }
        if (team.size() > def.maxPlayers) {
            return "dungeon.size";
        }
        int slot = freeSlot();
        World world = voidWorld(instanceWorldName);
        World template = voidWorld(def.templateWorld);
        if (slot < 0) {
            return "dungeon.busy";
        }
        if (world == null || template == null) {
            return "dungeon.world-error";
        }
        int minY = Math.min(def.pos1[1], def.pos2[1]);
        Instance instance = new Instance(slot, def, new Location(world, 1000 + (double) slot * spacing, minY, 0));
        instance.invasion = tag;
        instances.put(slot, instance);
        for (Player player : team) {
            instance.members.add(player.getUniqueId());
            instance.lives.put(player.getUniqueId(), instance.lives());
            byPlayer.put(player.getUniqueId(), instance);
            returnTo.put(player.getUniqueId(), player.getLocation().clone());
            say(player, "dungeon.loading", Map.of("name", modeName(instance)));
        }
        startCopy(instance, template);
        return null;
    }

    private int freeSlot() {
        for (int i = 0; i < maxInstances; i++) {
            if (!instances.containsKey(i)) {
                return i;
            }
        }
        return -1;
    }

    // ---------------------------------------------------------------
    //  Копирование карты порциями (без лагов)
    // ---------------------------------------------------------------

    private void startCopy(Instance instance, World template) {
        DungeonDef def = instance.def;
        int minX = Math.min(def.pos1[0], def.pos2[0]);
        int minY = Math.min(def.pos1[1], def.pos2[1]);
        int minZ = Math.min(def.pos1[2], def.pos2[2]);
        int sx = Math.abs(def.pos1[0] - def.pos2[0]) + 1;
        int sy = Math.abs(def.pos1[1] - def.pos2[1]) + 1;
        int sz = Math.abs(def.pos1[2] - def.pos2[2]) + 1;
        long total = (long) sx * sy * sz;
        World world = instance.origin.getWorld();
        int ox = instance.origin.getBlockX();
        int oy = instance.origin.getBlockY();
        int oz = instance.origin.getBlockZ();
        instance.copyTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long end = Math.min(total, instance.copyIndex + copyPerTick);
            for (long i = instance.copyIndex; i < end; i++) {
                int x = (int) (i % sx);
                int z = (int) ((i / sx) % sz);
                int y = (int) (i / ((long) sx * sz));
                org.bukkit.block.Block source = template.getBlockAt(minX + x, minY + y, minZ + z);
                if (!source.getType().isAir()) {
                    world.getBlockAt(ox + x, oy + y, oz + z).setBlockData(source.getBlockData(), false);
                }
            }
            instance.copyIndex = end;
            if (end >= total) {
                instance.copyTask.cancel();
                onCopied(instance);
            }
        }, 1L, 1L);
    }

    private void onCopied(Instance instance) {
        if (instance.state != State.LOADING) {
            return;
        }
        instance.state = State.RUNNING;
        instance.checkpoint = instance.abs(instance.def.spawn);
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                player.teleport(instance.checkpoint);
                player.setFallDistance(0);
                if (instance.bar == null) {
                    instance.bar = BossBar.bossBar(Hud.legacy(instance.def.name), 1f,
                            BossBar.Color.PURPLE, BossBar.Overlay.PROGRESS);
                }
                say(player, "dungeon.started", Map.of("name", modeName(instance), "lives", instance.lives()));
            }
        }
    }

    // ---------------------------------------------------------------
    //  Ход подземелья
    // ---------------------------------------------------------------

    private void tick() {
        for (Instance instance : new ArrayList<>(instances.values())) {
            switch (instance.state) {
                case RUNNING -> tickRunning(instance);
                case COMPLETE, CLOSING -> {
                    if (System.currentTimeMillis() >= instance.closeAt) {
                        close(instance, true);
                    }
                }
                default -> {
                    // идёт копирование
                }
            }
        }
    }

    private List<Player> alive(Instance instance) {
        List<Player> result = new ArrayList<>();
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline() && !player.isDead()
                    && player.getWorld().equals(instance.origin.getWorld())) {
                result.add(player);
            }
        }
        return result;
    }

    private void tickRunning(Instance instance) {
        DungeonDef def = instance.def;
        List<Player> players = alive(instance);
        if (instance.members.isEmpty()) {
            fail(instance, "dungeon.fail-empty");
            return;
        }
        if (instance.timeLimit() > 0
                && System.currentTimeMillis() - instance.created > instance.timeLimit() * 60_000L) {
            fail(instance, "dungeon.fail-time");
            return;
        }
        if (instance.room >= def.rooms.size()) {
            complete(instance);
            return;
        }
        DungeonDef.RoomDef room = def.rooms.get(instance.room);
        if (instance.wave == -1) {
            Location trigger = instance.abs(room.trigger());
            for (Player player : players) {
                if (player.getLocation().distanceSquared(trigger) <= room.radius() * room.radius()) {
                    startRoom(instance, room);
                    return;
                }
            }
            return;
        }
        // сколько живых мобов комнаты осталось
        instance.mobs.removeIf(id -> {
            Entity entity = Bukkit.getEntity(id);
            return entity == null || entity.isDead() || !entity.isValid();
        });
        if (room.isBoss()) {
            tickBoss(instance, room);
            return;
        }
        if (instance.mobs.isEmpty()) {
            if (instance.wave + 1 < room.waves().size()) {
                spawnWave(instance, room, instance.wave + 1);
            } else {
                clearRoom(instance, room);
            }
        }
    }

    private void startRoom(Instance instance, DungeonDef.RoomDef room) {
        for (DungeonDef.Region region : room.seal()) {
            fill(instance, region, region.material());
        }
        titleAll(instance, "&6" + room.name(), "&7Комната " + (instance.room + 1) + " из " + instance.def.rooms.size());
        if (room.isBoss()) {
            spawnBoss(instance, room);
            instance.wave = 0;
        } else if (!room.waves().isEmpty()) {
            spawnWave(instance, room, 0);
        } else {
            clearRoom(instance, room);
        }
    }

    private void spawnWave(Instance instance, DungeonDef.RoomDef room, int index) {
        DungeonDef.WaveDef wave = room.waves().get(index);
        instance.wave = index;
        sayAll(instance, "dungeon.wave", Map.of("n", index + 1, "total", room.waves().size()));
        if (wave.say() != null) {
            sayAll(instance, "dungeon.say", Map.of("text", wave.say()));
        }
        for (Map.Entry<EntityType, Integer> entry : wave.mobs().entrySet()) {
            for (int i = 0; i < entry.getValue(); i++) {
                spawnMob(instance, entry.getKey(), around(instance, wave.at(), wave.spread()), 0, 0, null);
            }
        }
    }

    private void spawnBoss(Instance instance, DungeonDef.RoomDef room) {
        DungeonDef.BossDef boss = room.boss();
        if (boss == null) {
            return;
        }
        LivingEntity entity = spawnMob(instance, boss.type(), instance.abs(boss.at()),
                boss.health(), boss.damage(), boss.name());
        if (entity != null) {
            instance.boss = entity.getUniqueId();
            instance.bossMax = entity.getAttribute(Attribute.MAX_HEALTH) != null
                    ? entity.getAttribute(Attribute.MAX_HEALTH).getValue() : entity.getHealth();
            instance.phasesDone.clear();
            if (instance.bar != null) {
                instance.bar.name(Hud.legacy(boss.name()));
                instance.bar.progress(1f);
                for (Player player : alive(instance)) {
                    player.showBossBar(instance.bar);
                }
            }
        }
    }

    private void tickBoss(Instance instance, DungeonDef.RoomDef room) {
        Entity entity = instance.boss == null ? null : Bukkit.getEntity(instance.boss);
        if (!(entity instanceof LivingEntity boss) || boss.isDead() || !boss.isValid()) {
            // босс убит
            for (Player player : alive(instance)) {
                if (instance.bar != null) {
                    player.hideBossBar(instance.bar);
                }
            }
            killMobs(instance);
            clearRoom(instance, room);
            return;
        }
        double ratio = Math.max(0, Math.min(1, boss.getHealth() / Math.max(1, instance.bossMax)));
        if (instance.bar != null) {
            instance.bar.progress((float) ratio);
        }
        List<DungeonDef.PhaseDef> phases = room.boss().phases();
        for (int i = 0; i < phases.size(); i++) {
            DungeonDef.PhaseDef phase = phases.get(i);
            if (ratio <= phase.atHealth() && instance.phasesDone.add(i)) {
                if (phase.say() != null) {
                    titleAll(instance, "&c" + room.boss().name(), phase.say());
                    sayAll(instance, "dungeon.say", Map.of("text", phase.say()));
                }
                for (Map.Entry<EntityType, Integer> entry : phase.summon().entrySet()) {
                    for (int n = 0; n < entry.getValue(); n++) {
                        spawnMob(instance, entry.getKey(), boss.getLocation().clone().add(
                                random.nextDouble() * 6 - 3, 0, random.nextDouble() * 6 - 3), 0, 0, null);
                    }
                }
                applyEffect(boss, phase.effect());
            }
        }
    }

    private void applyEffect(LivingEntity target, String spec) {
        if (spec == null) {
            return;
        }
        String[] parts = spec.split(":");
        PotionEffectType type = org.bukkit.Registry.EFFECT.get(org.bukkit.NamespacedKey.minecraft(parts[0].toLowerCase(Locale.ROOT)));
        if (type == null) {
            return;
        }
        int seconds = parts.length > 1 ? Integer.parseInt(parts[1]) : 10;
        int amp = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
        target.addPotionEffect(new PotionEffect(type, seconds * 20, amp));
    }

    private void clearRoom(Instance instance, DungeonDef.RoomDef room) {
        for (DungeonDef.Region region : room.seal()) {
            fill(instance, region, Material.AIR);
        }
        for (DungeonDef.Region region : room.unlock()) {
            fill(instance, region, Material.AIR);
        }
        instance.checkpoint = instance.abs(room.trigger());
        instance.room++;
        instance.wave = -1;
        instance.mobs.clear();
        sayAll(instance, "dungeon.room-clear", Map.of("room", room.name()));
        if (instance.room >= instance.def.rooms.size()) {
            complete(instance);
        }
    }

    private Location around(Instance instance, double[] rel, double spread) {
        Location base = instance.abs(rel);
        return base.add((random.nextDouble() * 2 - 1) * spread, 0, (random.nextDouble() * 2 - 1) * spread);
    }

    private LivingEntity spawnMob(Instance instance, EntityType type, Location where,
                                  double health, double damage, String name) {
        World world = where.getWorld();
        Entity entity = world.spawnEntity(where, type);
        if (!(entity instanceof LivingEntity living)) {
            entity.remove();
            return null;
        }
        int extra = Math.max(0, instance.members.size() - 1);
        double healthScale = instance.mobHealth() * (1 + healthPerExtra * extra);
        double damageScale = instance.mobDamage() * (1 + damagePerExtra * extra);
        AttributeInstance hp = living.getAttribute(Attribute.MAX_HEALTH);
        if (hp != null) {
            double base = health > 0 ? health : hp.getBaseValue();
            hp.setBaseValue(Math.max(1, base * healthScale));
            living.setHealth(Math.max(1, base * healthScale));
        }
        AttributeInstance dmg = living.getAttribute(Attribute.ATTACK_DAMAGE);
        if (dmg != null) {
            double base = damage > 0 ? damage : dmg.getBaseValue();
            dmg.setBaseValue(base * damageScale);
        }
        if (name != null) {
            living.customName(Hud.legacy(name));
            living.setCustomNameVisible(true);
        }
        living.setRemoveWhenFarAway(false);
        living.setPersistent(true);
        living.getPersistentDataContainer().set(mobKey, PersistentDataType.INTEGER, instance.slot);
        instance.mobs.add(living.getUniqueId());
        if (living instanceof Mob mob) {
            Player nearest = null;
            double best = Double.MAX_VALUE;
            for (Player player : alive(instance)) {
                double dist = player.getLocation().distanceSquared(where);
                if (dist < best) {
                    best = dist;
                    nearest = player;
                }
            }
            if (nearest != null) {
                mob.setTarget(nearest);
            }
        }
        return living;
    }

    private void killMobs(Instance instance) {
        for (UUID id : new ArrayList<>(instance.mobs)) {
            Entity entity = Bukkit.getEntity(id);
            if (entity != null) {
                entity.remove();
            }
        }
        instance.mobs.clear();
    }

    private void fill(Instance instance, DungeonDef.Region region, Material material) {
        World world = instance.origin.getWorld();
        int ox = instance.origin.getBlockX();
        int oy = instance.origin.getBlockY();
        int oz = instance.origin.getBlockZ();
        int x1 = Math.min(region.from()[0], region.to()[0]);
        int x2 = Math.max(region.from()[0], region.to()[0]);
        int y1 = Math.min(region.from()[1], region.to()[1]);
        int y2 = Math.max(region.from()[1], region.to()[1]);
        int z1 = Math.min(region.from()[2], region.to()[2]);
        int z2 = Math.max(region.from()[2], region.to()[2]);
        for (int x = x1; x <= x2; x++) {
            for (int y = y1; y <= y2; y++) {
                for (int z = z1; z <= z2; z++) {
                    world.getBlockAt(ox + x, oy + y, oz + z).setType(material, false);
                }
            }
        }
    }

    // ---------------------------------------------------------------
    //  Завершение, награда, закрытие
    // ---------------------------------------------------------------

    private void complete(Instance instance) {
        if (instance.state != State.RUNNING) {
            return;
        }
        instance.state = State.COMPLETE;
        instance.closeAt = System.currentTimeMillis() + closeDelaySeconds * 1000L;
        killMobs(instance);
        titleAll(instance, "&a&lПобеда!", "&7" + modeName(instance));
        sayAll(instance, "dungeon.complete", Map.of("seconds", closeDelaySeconds));
        for (Player player : alive(instance)) {
            if (instance.bar != null) {
                player.hideBossBar(instance.bar);
            }
            if (!instance.admin) {
                if (!instance.heroic && instance.invasion == null) {
                    player.getPersistentDataContainer().set(clearKey(instance.def), PersistentDataType.BYTE, (byte) 1);
                }
                if (instance.invasion == null) {
                    setLock(player, instance.def, instance.heroic);
                }
                if (plugin.getCovenants() != null) {
                    plugin.getCovenants().getWeekly().dungeonCleared(player, instance.heroic, instance.def.raid);
                }
                if (plugin.getPets() != null) {
                    plugin.getPets().onDungeon(player);
                }
                if (plugin.getContracts() != null) {
                    plugin.getContracts().progress(player, "DUNGEON", instance.def.raid ? "RAID" : instance.heroic ? "HEROIC" : "NORMAL", 1);
                }
                if (plugin.getGlory() != null) {
                    plugin.getGlory().add(player, instance.def.raid ? "RAIDS" : instance.heroic ? "HEROICS" : "DUNGEONS", 1);
                }
            }
            giveRewards(player, instance);
        }
        if (instance.invasion != null && plugin.getInvasions() != null) {
            plugin.getInvasions().cleared(instance.invasion, alive(instance));
        }
    }

    private void giveRewards(Player player, Instance instance) {
        DungeonDef def = instance.def;
        int points = instance.heroic ? def.heroic.points() : def.points;
        long coins = instance.heroic ? def.heroic.coins() : def.coins;
        if (coins > 0 && plugin.getEconomy() != null) {
            plugin.getEconomy().reward(player, coins, "economy.reward-dungeon");
        }
        List<DungeonDef.Loot> lootList = instance.heroic ? def.heroic.loot() : def.loot;
        if (points > 0) {
            plugin.getQuests().adminAddPoints(player, points);
            say(player, "dungeon.points", Map.of("points", points));
        }
        Inventory inventory = Bukkit.createInventory(null, 27, Hud.legacy("&6Награда: " + modeName(instance)));
        GemManager gems = plugin.getGems();
        for (DungeonDef.Loot loot : lootList) {
            if (random.nextDouble() >= loot.chance()) {
                continue;
            }
            ItemStack stack = null;
            if (loot.gem() != null && gems != null && gems.type(loot.gem()) != null) {
                stack = gems.createGem(gems.type(loot.gem()), Math.max(1, loot.level()), false);
            } else if (loot.rune() != null && plugin.getRunes() != null) {
                stack = plugin.getRunes().create(loot.rune(), Math.max(1, loot.level()));
            } else if (loot.item() != null) {
                Material material = Material.matchMaterial(loot.item());
                if (material != null) {
                    stack = new ItemStack(material, loot.min() + random.nextInt(loot.max() - loot.min() + 1));
                }
            }
            if (stack != null) {
                inventory.addItem(stack);
            }
        }
        rewards.put(player.getUniqueId(), inventory);
        say(player, "dungeon.reward-ready", Map.of());
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && rewards.get(player.getUniqueId()) == inventory) {
                player.openInventory(inventory);
            }
        }, 60L);
    }

    public void openReward(Player player) {
        Inventory inventory = rewards.get(player.getUniqueId());
        if (inventory == null) {
            say(player, "dungeon.no-reward", Map.of());
            return;
        }
        player.openInventory(inventory);
    }

    @EventHandler
    public void onRewardClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) {
            return;
        }
        Inventory inventory = rewards.get(player.getUniqueId());
        if (inventory == null || event.getInventory() != inventory) {
            return;
        }
        boolean empty = true;
        for (ItemStack item : inventory.getContents()) {
            if (item != null && !item.getType().isAir()) {
                empty = false;
            }
        }
        if (empty) {
            rewards.remove(player.getUniqueId());
        }
    }

    private void fail(Instance instance, String key) {
        if (instance.state == State.CLOSING) {
            return;
        }
        instance.state = State.CLOSING;
        instance.closeAt = System.currentTimeMillis() + 5000L;
        killMobs(instance);
        sayAll(instance, key, Map.of());
        for (Player player : alive(instance)) {
            if (instance.bar != null) {
                player.hideBossBar(instance.bar);
            }
        }
    }

    private void returnPlayer(Player player) {
        Location back = returnTo.remove(player.getUniqueId());
        if (back == null || back.getWorld() == null) {
            back = Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        if (instancesWorld(player.getWorld())) {
            player.teleport(back);
        }
        player.removePotionEffect(PotionEffectType.GLOWING);
    }

    public boolean isInstanceWorld(World world) {
        return instancesWorld(world);
    }

    private boolean instancesWorld(World world) {
        return world != null && world.getName().equals(instanceWorldName);
    }

    private void close(Instance instance, boolean teleport) {
        instance.state = State.CLOSING;
        if (instance.copyTask != null) {
            instance.copyTask.cancel();
        }
        killMobs(instance);
        for (UUID id : new ArrayList<>(instance.members)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                if (instance.bar != null) {
                    player.hideBossBar(instance.bar);
                }
                if (teleport) {
                    returnPlayer(player);
                }
            }
            byPlayer.remove(id);
        }
        instance.members.clear();
        instances.remove(instance.slot);
        clearArea(instance);
    }

    /** Чистим копию порциями, чтобы слот можно было занять снова. */
    private void clearArea(Instance instance) {
        DungeonDef def = instance.def;
        int sx = Math.abs(def.pos1[0] - def.pos2[0]) + 1;
        int sy = Math.abs(def.pos1[1] - def.pos2[1]) + 1;
        int sz = Math.abs(def.pos1[2] - def.pos2[2]) + 1;
        World world = instance.origin.getWorld();
        int ox = instance.origin.getBlockX();
        int oy = instance.origin.getBlockY();
        int oz = instance.origin.getBlockZ();
        long total = (long) sx * sy * sz;
        BoundingBox box = new BoundingBox(ox, oy, oz, ox + sx, oy + sy, oz + sz);
        for (Entity entity : world.getNearbyEntities(box)) {
            if (!(entity instanceof Player)) {
                entity.remove();
            }
        }
        final long[] index = {0};
        BukkitTask[] holder = new BukkitTask[1];
        holder[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long end = Math.min(total, index[0] + copyPerTick);
            for (long i = index[0]; i < end; i++) {
                int x = (int) (i % sx);
                int z = (int) ((i / sx) % sz);
                int y = (int) (i / ((long) sx * sz));
                org.bukkit.block.Block block = world.getBlockAt(ox + x, oy + y, oz + z);
                if (!block.getType().isAir()) {
                    block.setType(Material.AIR, false);
                }
            }
            index[0] = end;
            if (end >= total) {
                holder[0].cancel();
            }
        }, 1L, 1L);
    }

    // ---------------------------------------------------------------
    //  Игроки: выход, смерть, вход в игру
    // ---------------------------------------------------------------

    public void leave(Player player) {
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null) {
            say(player, "dungeon.not-in", Map.of());
            return;
        }
        removeMember(instance, player, true);
        say(player, "dungeon.left", Map.of());
    }

    private void removeMember(Instance instance, Player player, boolean teleport) {
        instance.members.remove(player.getUniqueId());
        instance.lives.remove(player.getUniqueId());
        byPlayer.remove(player.getUniqueId());
        if (instance.bar != null) {
            player.hideBossBar(instance.bar);
        }
        if (teleport) {
            returnPlayer(player);
        }
        if (instance.members.isEmpty() && instance.state != State.CLOSING) {
            close(instance, false);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getPlayer();
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null) {
            return;
        }
        event.setKeepInventory(true);
        event.setKeepLevel(true);
        event.getDrops().clear();
        event.setDroppedExp(0);
        int left = instance.lives.merge(player.getUniqueId(), -1, Integer::sum);
        if (left > 0) {
            say(player, "dungeon.lives-left", Map.of("lives", left));
        } else {
            say(player, "dungeon.eliminated", Map.of());
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null) {
            return;
        }
        if (instance.lives.getOrDefault(player.getUniqueId(), 0) > 0 && instance.checkpoint != null
                && instance.state != State.CLOSING) {
            event.setRespawnLocation(instance.checkpoint);
            return;
        }
        Location back = returnTo.get(player.getUniqueId());
        if (back != null && back.getWorld() != null) {
            event.setRespawnLocation(back);
        }
        returnTo.remove(player.getUniqueId());
        Bukkit.getScheduler().runTask(plugin, () -> {
            instance.members.remove(player.getUniqueId());
            instance.lives.remove(player.getUniqueId());
            byPlayer.remove(player.getUniqueId());
            if (instance.bar != null) {
                player.hideBossBar(instance.bar);
            }
            if (alive(instance).isEmpty() && instance.state == State.RUNNING) {
                fail(instance, "dungeon.fail-wipe");
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance != null && alive(instance).size() <= 1 && instance.state == State.RUNNING) {
            // последний вышедший: подземелье закрывается, игрок вернётся на прежнее место при входе
            fail(instance, "dungeon.fail-empty");
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (instancesWorld(player.getWorld()) && !byPlayer.containsKey(player.getUniqueId())) {
            Location back = returnTo.remove(player.getUniqueId());
            Location target = back != null && back.getWorld() != null
                    ? back : Bukkit.getWorlds().get(0).getSpawnLocation();
            Bukkit.getScheduler().runTask(plugin, () -> player.teleport(target));
        }
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        if (event.getEntity().getPersistentDataContainer().has(mobKey, PersistentDataType.INTEGER)) {
            event.getDrops().clear();
            event.setDroppedExp(0);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (instancesWorld(event.getBlock().getWorld()) && !(event.getPlayer().hasPermission("ag.admin")
                && event.getPlayer().getGameMode() == GameMode.CREATIVE)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (instancesWorld(event.getBlock().getWorld()) && !(event.getPlayer().hasPermission("ag.admin")
                && event.getPlayer().getGameMode() == GameMode.CREATIVE)) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------
    //  Админ: ключи, тест, построить пример, координаты
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        // args: ag admin dungeon <действие> ...
        String action = args.length > 3 ? args[3].toLowerCase(Locale.ROOT) : "status";
        switch (action) {
            case "reload" -> {
                reload();
                plugin.getMessages().send(sender, "dungeon.reloaded", Map.of("count", defs.size()));
            }
            case "status" -> {
                sender.sendMessage(Hud.legacy("&6Подземелья: &f" + defs.size() + " &7описано, &f"
                        + instances.size() + "&7/&f" + maxInstances + " &7запущено"));
                for (Instance instance : instances.values()) {
                    sender.sendMessage(Hud.legacy("&8» &f" + instance.def.id + " &7слот " + instance.slot
                            + ", игроков " + instance.members.size() + ", комната "
                            + Math.min(instance.room + 1, instance.def.rooms.size()) + "/" + instance.def.rooms.size()
                            + ", " + instance.state));
                }
            }
            case "close" -> {
                for (Instance instance : new ArrayList<>(instances.values())) {
                    close(instance, true);
                }
                sender.sendMessage(Hud.legacy("&aВсе подземелья закрыты."));
            }
            case "test" -> {
                if (sender instanceof Player player && args.length > 4) {
                    enter(player, args[4], args.length > 5 && args[5].equalsIgnoreCase("heroic"), true);
                } else {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon test <id>"));
                }
            }
            case "rel" -> {
                // rel <id>: координаты под ногами относительно угла шаблона
                if (!(sender instanceof Player player) || args.length < 5) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon rel <id>"));
                    return;
                }
                DungeonDef def = defs.get(args[4].toLowerCase(Locale.ROOT));
                if (def == null) {
                    sender.sendMessage(Hud.legacy("&cПодземелье не найдено."));
                    return;
                }
                Location loc = player.getLocation();
                int rx = loc.getBlockX() - Math.min(def.pos1[0], def.pos2[0]);
                int ry = loc.getBlockY() - Math.min(def.pos1[1], def.pos2[1]);
                int rz = loc.getBlockZ() - Math.min(def.pos1[2], def.pos2[2]);
                sender.sendMessage(Hud.legacy("&6Относительные координаты: &f[" + rx + ", " + ry + ", " + rz + "]"));
            }
            case "buildtest" -> buildTest(sender, args);
            case "reset" -> {
                // reset <игрок> [id]: снять блокировки и суточный лимит
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4]) : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon reset <игрок> [id]"));
                    return;
                }
                int count = resetLocks(target, args.length > 5 ? args[5] : null);
                sender.sendMessage(Hud.legacy("&aСброшено блокировок у &f" + target.getName() + "&a: " + count
                        + (args.length > 5 ? "" : " &7(и суточный лимит)")));
            }
            case "pass" -> {
                // pass <игрок> [число]: пропуск на одиночный вход (отрицательное число - забрать)
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4]) : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon pass <игрок> [число]"));
                    return;
                }
                int amount = 1;
                if (args.length > 5) {
                    try {
                        amount = Integer.parseInt(args[5]);
                    } catch (NumberFormatException exception) {
                        sender.sendMessage(Hud.legacy("&cЧисло введено неверно."));
                        return;
                    }
                }
                grantSoloPass(target, amount);
                say(target, "dungeon.pass-granted", Map.of("total", soloPasses(target)));
                sender.sendMessage(Hud.legacy("&aПропусков у &f" + target.getName() + "&a: " + soloPasses(target)));
            }
            case "locks" -> {
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4]) : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon locks <игрок>"));
                    return;
                }
                sender.sendMessage(Hud.legacy("&6Блокировки &f" + target.getName() + "&7 (заходов сегодня " + runsToday(target)
                        + "/" + dailyLimit + ", пропусков " + soloPasses(target) + ")"));
                for (DungeonDef def : defs.values()) {
                    int n = lockDaysLeft(target, def, false);
                    int h = lockDaysLeft(target, def, true);
                    if (n > 0 || h > 0) {
                        sender.sendMessage(Hud.legacy("&8» &f" + def.id + " &7обычный: " + n + " дн., героический: " + h + " дн."));
                    }
                }
            }
            default -> sender.sendMessage(Hud.legacy("&7/ag admin dungeon status|reload|close|test <id> [heroic]|rel <id>|buildtest <id>|reset <игрок> [id]|pass <игрок> [n]|locks <игрок>"));
        }
    }

    /** Строит пример карты (3 комнаты) в мире шаблонов: для проверки без собственной постройки. */
    private void buildTest(CommandSender sender, String[] args) {
        DungeonDef def = defs.get(args.length > 4 ? args[4].toLowerCase(Locale.ROOT) : "test");
        if (def == null) {
            sender.sendMessage(Hud.legacy("&cПодземелье не найдено (нужен файл dungeons/test.yml)."));
            return;
        }
        World world = voidWorld(def.templateWorld);
        if (world == null) {
            sender.sendMessage(Hud.legacy("&cНе удалось открыть мир шаблонов."));
            return;
        }
        int x0 = Math.min(def.pos1[0], def.pos2[0]);
        int y0 = Math.min(def.pos1[1], def.pos2[1]);
        int z0 = Math.min(def.pos1[2], def.pos2[2]);
        int sx = Math.abs(def.pos1[0] - def.pos2[0]) + 1;
        int sy = Math.abs(def.pos1[1] - def.pos2[1]) + 1;
        int sz = Math.abs(def.pos1[2] - def.pos2[2]) + 1;
        for (int x = 0; x < sx; x++) {
            for (int y = 0; y < sy; y++) {
                for (int z = 0; z < sz; z++) {
                    boolean shell = x == 0 || y == 0 || z == 0 || x == sx - 1 || y == sy - 1 || z == sz - 1;
                    boolean divider = (x == 13 || x == 27 || x == 41) && !(z >= 6 && z <= 8 && y >= 1 && y <= 3);
                    Material material = shell || divider ? Material.STONE_BRICKS : Material.AIR;
                    if (y == 0) {
                        material = Material.POLISHED_DEEPSLATE;
                    }
                    if ((x == 13 || x == 27 || x == 41) && z >= 6 && z <= 8 && y >= 1 && y <= 3 && x != 13) {
                        material = Material.IRON_BARS;
                    }
                    if (y == 4 && (x % 6 == 3) && (z == 1 || z == sz - 2) && material == Material.AIR) {
                        material = Material.LANTERN;
                    }
                    world.getBlockAt(x0 + x, y0 + y, z0 + z).setType(material, false);
                }
            }
        }
        sender.sendMessage(Hud.legacy("&aПример построен в мире &f" + def.templateWorld
                + "&a. Перейдите: &f/mv tp " + def.templateWorld + "&7 или телепорт на " + x0 + " " + y0 + " " + z0));
    }
}
