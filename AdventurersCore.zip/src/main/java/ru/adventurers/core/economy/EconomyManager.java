package ru.adventurers.core.economy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.DatabaseManager;
import ru.adventurers.core.hud.Hud;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Монеты гильдии: баланс в базе (таблица ag_balance), заработок (задания, подземелья, мобы, продажа),
 * траты (магазин, ранг, класс, профессии, аукцион, /pay). Настройки: economy.yml.
 * Вызывается из основного потока; запись в БД идёт асинхронно.
 */
public class EconomyManager implements Listener {

    private static final class SellHolder implements InventoryHolder {
        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final AdventurersCore plugin;
    private final DatabaseManager database;
    /** Монеты-предметы: медная, серебряная, золотая. */
    public enum Denom {
        COPPER("copper", "&6Медная монета", Material.COPPER_INGOT),
        SILVER("silver", "&fСеребряная монета", Material.IRON_NUGGET),
        GOLD("gold", "&eЗолотая монета", Material.GOLD_NUGGET);

        final String id;
        final String title;
        final Material base;

        Denom(String id, String title, Material base) {
            this.id = id;
            this.title = title;
            this.base = base;
        }
    }

    private NamespacedKey coinKey;
    private boolean physical = true;
    private long silverValue = 100;
    private long goldValue = 10_000;

    private final Map<UUID, Long> cache = new HashMap<>();
    private final Set<UUID> dirty = new HashSet<>();
    private final Map<UUID, long[]> mobWindow = new HashMap<>();
    private final Map<String, Integer> soldToday = new HashMap<>();
    private String soldDay = "";

    private String currencyName = "монет";
    private String symbol = "⛁";
    private long startBalance = 50;
    private double questCoinsPerPoint = 3.0;
    private final Map<String, Long> questOverride = new HashMap<>();
    private final Map<EntityType, Long> mobCoins = new HashMap<>();
    private long mobDefault = 0;
    private long mobHourlyCap = 150;
    private final Map<Material, Double> sell = new HashMap<>();
    private int sellSoftCap = 320;
    private double sellOverCapFactor = 0.4;
    private long payMin = 1;
    private final Map<String, Long> promotionCost = new HashMap<>();
    private long classSwitchCost = 0;
    private long classSecondCost = 0;
    private long learnMainCost = 0;
    private long learnExtraCost = 0;

    public EconomyManager(AdventurersCore plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
        this.coinKey = new NamespacedKey(plugin, "coin");
    }

    // ---------------------------------------------------------------
    //  Запуск
    // ---------------------------------------------------------------

    public void init() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS ag_balance (
                    uuid CHAR(36) NOT NULL PRIMARY KEY,
                    coins BIGINT NOT NULL DEFAULT 0
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }
        reload();
        Bukkit.getScheduler().runTaskTimer(plugin, this::flush, 20L * 30, 20L * 30);
        for (Player player : Bukkit.getOnlinePlayers()) {
            load(player.getUniqueId());
        }
    }

    public void shutdown() {
        List<Object[]> rows = new ArrayList<>();
        for (UUID uuid : dirty) {
            rows.add(new Object[]{uuid, cache.get(uuid)});
        }
        dirty.clear();
        writeRows(rows);
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "economy.yml");
        if (!file.exists()) {
            plugin.saveResource("economy.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        currencyName = cfg.getString("currency.name", "монет");
        symbol = cfg.getString("currency.symbol", "⛁");
        startBalance = cfg.getLong("start-balance", 50);
        physical = cfg.getBoolean("physical.enabled", true);
        silverValue = Math.max(2, cfg.getLong("physical.silver-value", 100));
        goldValue = Math.max(silverValue + 1, cfg.getLong("physical.gold-value", 10_000));
        questCoinsPerPoint = cfg.getDouble("quests.coins-per-point", 3.0);
        questOverride.clear();
        ConfigurationSection qo = cfg.getConfigurationSection("quests.override");
        if (qo != null) {
            for (String id : qo.getKeys(false)) {
                questOverride.put(id, qo.getLong(id));
            }
        }
        mobCoins.clear();
        mobDefault = cfg.getLong("mobs.default", 0);
        mobHourlyCap = cfg.getLong("mobs.hourly-cap", 150);
        ConfigurationSection mobs = cfg.getConfigurationSection("mobs.rewards");
        if (mobs != null) {
            for (String key : mobs.getKeys(false)) {
                try {
                    mobCoins.put(EntityType.valueOf(key.toUpperCase(Locale.ROOT)), mobs.getLong(key));
                } catch (IllegalArgumentException ignored) {
                    plugin.getLogger().warning("economy.yml: unknown mob " + key);
                }
            }
        }
        sell.clear();
        ConfigurationSection prices = cfg.getConfigurationSection("sell.prices");
        if (prices != null) {
            for (String key : prices.getKeys(false)) {
                Material material = Material.matchMaterial(key);
                if (material != null) {
                    sell.put(material, prices.getDouble(key));
                }
            }
        }
        sellSoftCap = cfg.getInt("sell.soft-cap-per-day", 320);
        sellOverCapFactor = cfg.getDouble("sell.over-cap-factor", 0.4);
        payMin = Math.max(1, cfg.getLong("pay.min", 1));
        promotionCost.clear();
        ConfigurationSection pc = cfg.getConfigurationSection("costs.promotion");
        if (pc != null) {
            for (String rank : pc.getKeys(false)) {
                promotionCost.put(rank.toUpperCase(Locale.ROOT), pc.getLong(rank));
            }
        }
        classSwitchCost = cfg.getLong("costs.class-switch", 0);
        classSecondCost = cfg.getLong("costs.class-second", 0);
        learnMainCost = cfg.getLong("costs.profession-main", 0);
        learnExtraCost = cfg.getLong("costs.profession-extra", 0);
    }

    // ---------------------------------------------------------------
    //  Баланс
    // ---------------------------------------------------------------

    private void load(UUID uuid) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            Long value = null;
            try (Connection connection = database.getConnection();
                 PreparedStatement statement = connection.prepareStatement("SELECT coins FROM ag_balance WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                try (ResultSet result = statement.executeQuery()) {
                    if (result.next()) {
                        value = result.getLong(1);
                    }
                }
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not load balance: " + uuid);
                exception.printStackTrace();
                return;
            }
            Long loaded = value;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (Bukkit.getPlayer(uuid) == null) {
                    return;
                }
                if (loaded == null) {
                    cache.put(uuid, startBalance);
                    dirty.add(uuid);
                } else {
                    cache.put(uuid, loaded);
                }
            });
        });
    }

    private Long readDirect(UUID uuid) {
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT coins FROM ag_balance WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? result.getLong(1) : null;
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
            return null;
        }
    }

    private void writeRows(List<Object[]> rows) {
        if (rows.isEmpty()) {
            return;
        }
        String sql = "INSERT INTO ag_balance (uuid, coins) VALUES (?, ?) ON DUPLICATE KEY UPDATE coins = VALUES(coins)";
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (Object[] row : rows) {
                statement.setString(1, row[0].toString());
                statement.setLong(2, (Long) row[1]);
                statement.addBatch();
            }
            statement.executeBatch();
        } catch (SQLException exception) {
            plugin.getLogger().severe("Could not save balances");
            exception.printStackTrace();
        }
    }

    private void flush() {
        if (dirty.isEmpty()) {
            return;
        }
        List<Object[]> rows = new ArrayList<>();
        for (UUID uuid : dirty) {
            Long value = cache.get(uuid);
            if (value != null) {
                rows.add(new Object[]{uuid, value});
            }
        }
        dirty.clear();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> writeRows(rows));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        load(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        Long value = cache.remove(uuid);
        mobWindow.remove(uuid);
        if (value != null && dirty.remove(uuid)) {
            List<Object[]> rows = List.<Object[]>of(new Object[]{uuid, value});
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> writeRows(rows));
        }
    }

    /** Всего монет: банк и (если игрок в сети) монеты в инвентаре. */
    public long balance(UUID uuid) {
        long total = bank(uuid);
        Player online = Bukkit.getPlayer(uuid);
        return online != null ? total + purse(online) : total;
    }

    /** Только вклад в банке. */
    public long bank(UUID uuid) {
        Long value = cache.get(uuid);
        if (value != null) {
            return value;
        }
        Long direct = readDirect(uuid);
        return direct == null ? 0 : direct;
    }

    public boolean has(UUID uuid, long amount) {
        return balance(uuid) >= amount;
    }

    /** Меняет баланс (может быть отрицательным). Для вышедших игроков пишет в базу сразу. */
    private boolean change(UUID uuid, long delta) {
        Long value = cache.get(uuid);
        if (value != null) {
            if (value + delta < 0) {
                return false;
            }
            cache.put(uuid, value + delta);
            dirty.add(uuid);
            return true;
        }
        Long direct = readDirect(uuid);
        long current = direct == null ? startBalance : direct;
        if (current + delta < 0) {
            return false;
        }
        long result = current + delta;
        List<Object[]> rows = List.<Object[]>of(new Object[]{uuid, result});
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> writeRows(rows));
        return true;
    }

    public boolean deposit(UUID uuid, long amount) {
        return amount >= 0 && change(uuid, amount);
    }

    /** Списывает сначала монеты из инвентаря (сдача возвращается монетами), остаток из банка. */
    public boolean withdraw(UUID uuid, long amount) {
        if (amount < 0) {
            return false;
        }
        Player online = Bukkit.getPlayer(uuid);
        if (online == null || !physical) {
            return change(uuid, -amount);
        }
        long purse = purse(online);
        if (purse + bank(uuid) < amount) {
            return false;
        }
        long fromPurse = Math.min(purse, amount);
        if (fromPurse > 0) {
            takePurse(online, fromPurse);
        }
        long rest = amount - fromPurse;
        return rest <= 0 || change(uuid, -rest);
    }

    public void set(UUID uuid, long amount) {
        long current = bank(uuid);
        change(uuid, Math.max(0, amount) - current);
    }

    public String format(long amount) {
        return "&6" + String.format(Locale.ROOT, "%,d", amount).replace(',', ' ') + " " + symbol;
    }

    public String plain(long amount) {
        return String.format(Locale.ROOT, "%,d", amount).replace(',', ' ');
    }

    public String currencyName() {
        return currencyName;
    }

    // ---------------------------------------------------------------
    //  Награды
    // ---------------------------------------------------------------

    public long questCoins(String questId, int points) {
        Long override = questOverride.get(questId);
        return override != null ? override : Math.round(points * questCoinsPerPoint);
    }

    public void reward(Player player, long amount, String reasonKey) {
        if (amount <= 0) {
            return;
        }
        give(player, amount);
        plugin.getMessages().send(player, reasonKey, Map.of("coins", format(amount)));
    }

    // ---------------------------------------------------------------
    //  Физические монеты
    // ---------------------------------------------------------------

    public boolean isPhysical() {
        return physical;
    }

    public long valueOf(Denom denom) {
        return switch (denom) {
            case COPPER -> 1;
            case SILVER -> silverValue;
            case GOLD -> goldValue;
        };
    }

    public ItemStack coin(Denom denom, int amount) {
        ItemStack item = new ItemStack(denom.base, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(denom.title));
        meta.lore(List.of(line("&7Номинал: &6" + plain(valueOf(denom)) + " " + symbol),
                line("&8Монета Гильдии. Хранится в банке: /ag bank")));
        meta.getPersistentDataContainer().set(coinKey, PersistentDataType.STRING, denom.id);
        ru.adventurers.core.hud.PackItems.model(meta, "coin_" + denom.id);
        item.setItemMeta(meta);
        return item;
    }

    /** Номинал монеты в стопке или null, если предмет не монета. */
    public Denom denomOf(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return null;
        }
        String id = item.getItemMeta().getPersistentDataContainer().get(coinKey, PersistentDataType.STRING);
        if (id == null) {
            return null;
        }
        for (Denom denom : Denom.values()) {
            if (denom.id.equals(id)) {
                return denom;
            }
        }
        return null;
    }

    /** Сумма монет-предметов в инвентаре игрока. */
    public long purse(Player player) {
        if (!physical) {
            return 0;
        }
        long total = 0;
        for (ItemStack stack : player.getInventory().getContents()) {
            Denom denom = denomOf(stack);
            if (denom != null) {
                total += valueOf(denom) * stack.getAmount();
            }
        }
        return total;
    }

    /** Раскладывает сумму на монеты крупными номиналами. */
    private List<ItemStack> coinsFor(long amount) {
        List<ItemStack> result = new ArrayList<>();
        for (Denom denom : new Denom[]{Denom.GOLD, Denom.SILVER, Denom.COPPER}) {
            long value = valueOf(denom);
            long count = amount / value;
            amount -= count * value;
            while (count > 0) {
                int stack = (int) Math.min(64, count);
                result.add(coin(denom, stack));
                count -= stack;
            }
        }
        return result;
    }

    /** Кладёт монеты в инвентарь; что не влезло, уходит в банк. Возвращает сумму, ушедшую в банк. */
    public long give(Player player, long amount) {
        if (amount <= 0) {
            return 0;
        }
        if (!physical) {
            deposit(player.getUniqueId(), amount);
            return amount;
        }
        long overflow = 0;
        for (ItemStack stack : coinsFor(amount)) {
            for (ItemStack rest : player.getInventory().addItem(stack).values()) {
                overflow += valueOf(denomOf(rest)) * rest.getAmount();
            }
        }
        if (overflow > 0) {
            deposit(player.getUniqueId(), overflow);
            plugin.getMessages().send(player, "bank.overflow", Map.of("coins", format(overflow)));
        }
        return overflow;
    }

    /** Забирает монеты из инвентаря на сумму amount (<= purse), сдачу выдаёт монетами. */
    private void takePurse(Player player, long amount) {
        long taken = 0;
        ItemStack[] contents = player.getInventory().getContents();
        for (Denom denom : new Denom[]{Denom.COPPER, Denom.SILVER, Denom.GOLD}) {
            for (int i = 0; i < contents.length && taken < amount; i++) {
                ItemStack stack = contents[i];
                if (denomOf(stack) != denom) {
                    continue;
                }
                long value = valueOf(denom);
                long need = (amount - taken + value - 1) / value;
                int take = (int) Math.min(need, stack.getAmount());
                taken += take * value;
                if (take >= stack.getAmount()) {
                    player.getInventory().setItem(i, null);
                    contents[i] = null;
                } else {
                    stack.setAmount(stack.getAmount() - take);
                }
            }
            if (taken >= amount) {
                break;
            }
        }
        long change = taken - amount;
        if (change > 0) {
            for (ItemStack stack : coinsFor(change)) {
                for (ItemStack rest : player.getInventory().addItem(stack).values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), rest);
                }
            }
        }
    }

    /** /ag bank [deposit|withdraw] <сумма|all> */
    public void bankCommand(Player player, String[] args) {
        UUID uuid = player.getUniqueId();
        String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        if (sub.equals("deposit") || sub.equals("withdraw")) {
            long purse = purse(player);
            long bank = bank(uuid);
            long amount;
            String word = args.length > 2 ? args[2] : "all";
            if (word.equalsIgnoreCase("all")) {
                amount = sub.equals("deposit") ? purse : bank;
            } else {
                try {
                    amount = Long.parseLong(word);
                } catch (NumberFormatException exception) {
                    plugin.getMessages().send(player, "bank.usage");
                    return;
                }
            }
            if (amount <= 0) {
                plugin.getMessages().send(player, "bank.nothing");
                return;
            }
            if (sub.equals("deposit")) {
                if (amount > purse) {
                    plugin.getMessages().send(player, "bank.no-purse", Map.of("have", format(purse)));
                    return;
                }
                takePurse(player, amount);
                deposit(uuid, amount);
                plugin.getMessages().send(player, "bank.deposited", Map.of("coins", format(amount)));
            } else {
                if (amount > bank) {
                    plugin.getMessages().send(player, "bank.no-bank", Map.of("have", format(bank)));
                    return;
                }
                withdrawBankOnly(uuid, amount);
                long back = give(player, amount);
                plugin.getMessages().send(player, "bank.withdrawn", Map.of("coins", format(amount - back)));
            }
        }
        plugin.getMessages().send(player, "bank.status", Map.of("purse", format(purse(player)), "bank", format(bank(uuid)),
                "total", format(balance(uuid))));
    }

    private boolean withdrawBankOnly(UUID uuid, long amount) {
        return change(uuid, -amount);
    }

    /** Монеты не крафтятся в слитки и блоки. */
    @EventHandler
    public void onCraft(PrepareItemCraftEvent event) {
        for (ItemStack stack : event.getInventory().getMatrix()) {
            if (denomOf(stack) != null) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        if (event.getEntity() instanceof Player) {
            return;
        }
        Player killer = event.getEntity().getKiller();
        if (killer == null || plugin.getDungeons().isInstanceWorld(killer.getWorld())) {
            return;
        }
        if (plugin.getQuests() != null && !plugin.getQuests().getGuard().allow(killer, event.getEntity())) {
            return;
        }
        long coins = mobCoins.getOrDefault(event.getEntity().getType(), mobDefault);
        if (coins <= 0) {
            return;
        }
        long now = System.currentTimeMillis();
        long[] window = mobWindow.computeIfAbsent(killer.getUniqueId(), k -> new long[]{now, 0});
        if (now - window[0] > 3_600_000L) {
            window[0] = now;
            window[1] = 0;
        }
        if (window[1] >= mobHourlyCap) {
            return;
        }
        coins = Math.min(coins, mobHourlyCap - window[1]);
        window[1] += coins;
        give(killer, coins);
        plugin.getSkillHud().flash(killer, Hud.legacy("&6+" + coins + " " + symbol));
    }

    // ---------------------------------------------------------------
    //  Траты: ранг, класс, профессии
    // ---------------------------------------------------------------

    public long promotionCost(String rank) {
        return promotionCost.getOrDefault(rank.toUpperCase(Locale.ROOT), 0L);
    }

    public long classSwitchCost() {
        return classSwitchCost;
    }

    public long classSecondCost() {
        return classSecondCost;
    }

    public long learnCost(boolean main) {
        return main ? learnMainCost : learnExtraCost;
    }

    /** Списывает цену; false = не хватает (сообщение отправлено). */
    public boolean charge(Player player, long cost) {
        if (cost <= 0) {
            return true;
        }
        if (!has(player.getUniqueId(), cost)) {
            plugin.getMessages().send(player, "economy.not-enough", Map.of("cost", format(cost),
                    "have", format(balance(player.getUniqueId()))));
            return false;
        }
        withdraw(player.getUniqueId(), cost);
        plugin.getMessages().send(player, "economy.paid", Map.of("cost", format(cost)));
        return true;
    }

    // ---------------------------------------------------------------
    //  /pay
    // ---------------------------------------------------------------

    public void pay(Player from, String targetName, String amountText) {
        OfflinePlayer target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            plugin.getMessages().send(from, "economy.player-offline");
            return;
        }
        if (target.getUniqueId().equals(from.getUniqueId())) {
            plugin.getMessages().send(from, "economy.pay-self");
            return;
        }
        long amount;
        try {
            amount = Long.parseLong(amountText);
        } catch (NumberFormatException exception) {
            plugin.getMessages().send(from, "economy.pay-usage");
            return;
        }
        if (amount < payMin) {
            plugin.getMessages().send(from, "economy.pay-min", Map.of("min", payMin));
            return;
        }
        if (!has(from.getUniqueId(), amount)) {
            plugin.getMessages().send(from, "economy.not-enough", Map.of("cost", format(amount),
                    "have", format(balance(from.getUniqueId()))));
            return;
        }
        withdraw(from.getUniqueId(), amount);
        deposit(target.getUniqueId(), amount);
        plugin.getMessages().send(from, "economy.pay-sent", Map.of("player", target.getName(), "coins", format(amount)));
        Player online = target.getPlayer();
        if (online != null) {
            plugin.getMessages().send(online, "economy.pay-got", Map.of("player", from.getName(), "coins", format(amount)));
        }
    }

    // ---------------------------------------------------------------
    //  Продажа предметов
    // ---------------------------------------------------------------

    private boolean plain(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return item != null && !item.getType().isAir();
        }
        ItemMeta meta = item.getItemMeta();
        return !meta.hasDisplayName() && !meta.hasLore() && !meta.hasEnchants()
                && meta.getPersistentDataContainer().getKeys().isEmpty();
    }

    public boolean sellable(ItemStack item) {
        return plain(item) && sell.containsKey(item.getType());
    }

    private long priceFor(Player player, ItemStack item) {
        String day = LocalDate.now().toString();
        if (!day.equals(soldDay)) {
            soldDay = day;
            soldToday.clear();
        }
        double unit = sell.getOrDefault(item.getType(), 0.0);
        String key = player.getUniqueId() + ":" + item.getType();
        int already = soldToday.getOrDefault(key, 0);
        int amount = item.getAmount();
        int normal = Math.max(0, Math.min(amount, sellSoftCap - already));
        int over = amount - normal;
        soldToday.put(key, already + amount);
        return Math.round(unit * normal + unit * sellOverCapFactor * over);
    }

    public void openSell(Player player) {
        if (sell.isEmpty()) {
            plugin.getMessages().send(player, "economy.sell-none");
            return;
        }
        Inventory inventory = Bukkit.createInventory(new SellHolder(), 36,
                Hud.legacy("&8Продажа: положите предметы и закройте"));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onSellClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof SellHolder)
                || !(event.getPlayer() instanceof Player player)) {
            return;
        }
        long total = 0;
        int sold = 0;
        List<ItemStack> back = new ArrayList<>();
        for (ItemStack item : event.getInventory().getContents()) {
            if (item == null || item.getType().isAir()) {
                continue;
            }
            if (sellable(item)) {
                total += priceFor(player, item);
                sold += item.getAmount();
            } else {
                back.add(item);
            }
        }
        for (ItemStack item : back) {
            for (ItemStack rest : player.getInventory().addItem(item).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), rest);
            }
        }
        event.getInventory().clear();
        finishSale(player, total, sold, !back.isEmpty());
    }

    private void finishSale(Player player, long total, int sold, boolean returned) {
        if (sold == 0) {
            plugin.getMessages().send(player, "economy.sell-nothing");
            return;
        }
        give(player, total);
        plugin.getMessages().send(player, "economy.sold", Map.of("count", sold, "coins", format(total)));
        if (returned) {
            plugin.getMessages().send(player, "economy.sell-returned");
        }
    }

    /** /ag sell hand | all */
    public void sellQuick(Player player, boolean all) {
        long total = 0;
        int sold = 0;
        if (!all) {
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (sellable(hand)) {
                total = priceFor(player, hand);
                sold = hand.getAmount();
                player.getInventory().setItemInMainHand(null);
            }
        } else {
            ItemStack[] contents = player.getInventory().getStorageContents();
            for (int i = 0; i < contents.length; i++) {
                ItemStack item = contents[i];
                if (sellable(item)) {
                    total += priceFor(player, item);
                    sold += item.getAmount();
                    contents[i] = null;
                }
            }
            player.getInventory().setStorageContents(contents);
        }
        finishSale(player, total, sold, false);
    }

    public void prices(Player player) {
        List<String> parts = new ArrayList<>();
        sell.entrySet().stream().sorted(Map.Entry.comparingByKey())
                .forEach(e -> parts.add("&f" + e.getKey().name().toLowerCase(Locale.ROOT).replace('_', ' ')
                        + " &6" + (e.getValue() % 1 == 0 ? String.valueOf(e.getValue().longValue()) : String.valueOf(e.getValue()))));
        player.sendMessage(Hud.legacy("&6Цены скупки &8(за штуку):"));
        player.sendMessage(Hud.legacy(String.join("&8, ", parts)));
    }

    public static Component line(String text) {
        return Hud.legacy(text).decoration(TextDecoration.ITALIC, false);
    }
}
