package ru.adventurers.core.economy;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profession.PlayerProfessions;
import ru.adventurers.core.profession.Profession;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static ru.adventurers.core.economy.EconomyManager.line;

/**
 * Магазин гильдии (меню /ag shop). Категории и товары: shop.yml.
 * Товар: предмет (item), руна (rune+level) с ценой за пачку; можно требовать профессию и ранг.
 */
public class ShopManager implements Listener {

    private record Good(Material material, int amount, String name, String rune, int runeLevel,
                        long price, Profession profession, Rank minRank) {
    }

    private record Category(String id, String name, Material icon, String description,
                            Profession profession, List<Good> goods) {
    }

    private static final class Holder implements InventoryHolder {
        Category category;   // null = список категорий
        int page;
        final List<Category> categories = new ArrayList<>();
        final List<Good> shown = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final AdventurersCore plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();

    public ShopManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void init() {
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "shop.yml");
        if (!file.exists()) {
            plugin.saveResource("shop.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        categories.clear();
        ConfigurationSection root = cfg.getConfigurationSection("categories");
        if (root == null) {
            return;
        }
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) {
                continue;
            }
            Profession profession = Profession.fromInput(s.getString("profession", ""));
            Material icon = Material.matchMaterial(s.getString("icon", "CHEST"));
            List<Good> goods = new ArrayList<>();
            for (Map<?, ?> map : s.getMapList("goods")) {
                try {
                    Rank min = map.get("min-rank") == null ? null : Rank.fromInput(String.valueOf(map.get("min-rank")));
                    Profession req = map.get("profession") == null ? null
                            : Profession.fromInput(String.valueOf(map.get("profession")));
                    long price = map.get("price") instanceof Number n ? n.longValue() : 1;
                    if (map.get("rune") != null) {
                        goods.add(new Good(null, 1, null, String.valueOf(map.get("rune")),
                                map.get("level") instanceof Number n ? n.intValue() : 1, price, req, min));
                    } else {
                        Material material = Material.matchMaterial(String.valueOf(map.get("item")));
                        if (material == null) {
                            throw new IllegalArgumentException("item " + map.get("item"));
                        }
                        goods.add(new Good(material, map.get("amount") instanceof Number n ? n.intValue() : 1,
                                map.get("name") == null ? null : String.valueOf(map.get("name")), null, 0, price, req, min));
                    }
                } catch (RuntimeException exception) {
                    plugin.getLogger().warning("shop.yml " + id + ": " + exception.getMessage());
                }
            }
            categories.put(id, new Category(id, s.getString("name", id), icon == null ? Material.CHEST : icon,
                    s.getString("description", ""), profession, goods));
        }
    }

    // ---------------------------------------------------------------
    //  Меню
    // ---------------------------------------------------------------

    public void open(Player player) {
        Holder holder = new Holder();
        for (Category category : categories.values()) {
            holder.categories.add(category);
        }
        renderCategories(player, holder);
    }

    private boolean knows(Player player, Profession profession) {
        if (profession == null) {
            return true;
        }
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        return data != null && data.has(profession);
    }

    private void renderCategories(Player player, Holder holder) {
        holder.category = null;
        int rows = Math.max(2, Math.min(6, (holder.categories.size() + 8) / 9 + 1));
        Inventory inventory = Bukkit.createInventory(holder, rows * 9,
                Hud.legacy("&8Магазин гильдии"));
        int slot = 0;
        for (Category category : holder.categories) {
            ItemStack item = new ItemStack(category.icon);
            ItemMeta meta = item.getItemMeta();
            boolean ok = knows(player, category.profession);
            meta.displayName(line((ok ? "&6" : "&8") + category.name));
            List<Component> lore = new ArrayList<>();
            if (!category.description.isEmpty()) {
                lore.add(line("&7" + category.description));
            }
            if (!ok) {
                lore.add(line("&cНужна профессия: " + plugin.getProfessions().displayName(category.profession)));
            }
            lore.add(line("&7Товаров: &f" + category.goods.size()));
            lore.add(Component.empty());
            lore.add(line("&e▶ Нажми, чтобы открыть"));
            meta.lore(lore);
            item.setItemMeta(meta);
            inventory.setItem(slot++, item);
        }
        ItemStack wallet = new ItemStack(Material.GOLD_INGOT);
        ItemMeta meta = wallet.getItemMeta();
        meta.displayName(line("&6Кошелёк: " + plugin.getEconomy().format(plugin.getEconomy().balance(player.getUniqueId()))));
        meta.lore(List.of(line("&7Продать вещи: &f/ag sell"), line("&7Аукцион игроков: &f/ag ah")));
        wallet.setItemMeta(meta);
        inventory.setItem(rows * 9 - 5, wallet);
        player.openInventory(inventory);
    }

    private void renderCategory(Player player, Holder holder, Category category) {
        holder.category = category;
        Inventory inventory = Bukkit.createInventory(holder, 54, Hud.legacy("&8Магазин: &6" + category.name));
        holder.shown.clear();
        int from = holder.page * 45;
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        for (int i = from; i < Math.min(category.goods.size(), from + 45); i++) {
            Good good = category.goods.get(i);
            holder.shown.add(good);
            ItemStack item = stackOf(good);
            if (item == null) {
                item = new ItemStack(Material.BARRIER);
            }
            ItemMeta meta = item.getItemMeta();
            List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
            lore.add(Component.empty());
            lore.add(line("&7Цена за " + good.amount + " шт: " + plugin.getEconomy().format(good.price)));
            boolean allowed = true;
            if (good.minRank != null && (profile == null || !profile.getRank().isAtLeast(good.minRank))) {
                lore.add(line("&cНужен ранг " + good.minRank.getDisplayName()));
                allowed = false;
            }
            if (!knows(player, good.profession)) {
                lore.add(line("&cНужна профессия: " + plugin.getProfessions().displayName(good.profession)));
                allowed = false;
            }
            lore.add(line(allowed ? "&eЛКМ &7- купить &8| &eПКМ &7- ×8" : "&8Недоступно"));
            meta.lore(lore);
            item.setItemMeta(meta);
            inventory.setItem(i - from, item);
        }
        inventory.setItem(45, nav(Material.ARROW, "&7◀ Страница", holder.page > 0));
        inventory.setItem(53, nav(Material.ARROW, "&7Страница ▶", category.goods.size() > from + 45));
        inventory.setItem(48, nav(Material.BARRIER, "&7Назад к категориям", true));
        ItemStack wallet = new ItemStack(Material.GOLD_INGOT);
        ItemMeta meta = wallet.getItemMeta();
        meta.displayName(line("&6Кошелёк: " + plugin.getEconomy().format(plugin.getEconomy().balance(player.getUniqueId()))));
        wallet.setItemMeta(meta);
        inventory.setItem(50, wallet);
        player.openInventory(inventory);
    }

    private ItemStack nav(Material material, String name, boolean on) {
        ItemStack item = new ItemStack(on ? material : Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(on ? name : "&8·"));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack stackOf(Good good) {
        if (good.rune != null) {
            return plugin.getRunes() == null ? null : plugin.getRunes().create(good.rune, good.runeLevel);
        }
        ItemStack item = new ItemStack(good.material, Math.max(1, Math.min(64, good.amount)));
        if (good.name != null) {
            ItemMeta meta = item.getItemMeta();
            meta.displayName(line(good.name));
            item.setItemMeta(meta);
        }
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)
                || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        if (holder.category == null) {
            if (slot >= 0 && slot < holder.categories.size()) {
                Category category = holder.categories.get(slot);
                if (!knows(player, category.profession)) {
                    plugin.getMessages().send(player, "economy.shop-need-prof");
                    return;
                }
                holder.page = 0;
                renderCategory(player, holder, category);
            }
            return;
        }
        if (slot == 48) {
            renderCategories(player, holder);
        } else if (slot == 45 && holder.page > 0) {
            holder.page--;
            renderCategory(player, holder, holder.category);
        } else if (slot == 53 && event.getCurrentItem() != null && event.getCurrentItem().getType() == Material.ARROW) {
            holder.page++;
            renderCategory(player, holder, holder.category);
        } else if (slot >= 0 && slot < 45 && slot < holder.shown.size()) {
            buy(player, holder.shown.get(slot), event.getClick().isRightClick() ? 8 : 1);
            renderCategory(player, holder, holder.category);
        }
    }

    private void buy(Player player, Good good, int bundles) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        if (good.minRank != null && (profile == null || !profile.getRank().isAtLeast(good.minRank))) {
            plugin.getMessages().send(player, "economy.shop-rank", Map.of("rank", good.minRank.getDisplayName()));
            return;
        }
        if (!knows(player, good.profession)) {
            plugin.getMessages().send(player, "economy.shop-need-prof");
            return;
        }
        long cost = good.price * bundles;
        if (!plugin.getEconomy().has(player.getUniqueId(), cost)) {
            plugin.getMessages().send(player, "economy.not-enough", Map.of("cost", plugin.getEconomy().format(cost),
                    "have", plugin.getEconomy().format(plugin.getEconomy().balance(player.getUniqueId()))));
            return;
        }
        plugin.getEconomy().withdraw(player.getUniqueId(), cost);
        int given = 0;
        for (int i = 0; i < bundles; i++) {
            ItemStack stack = stackOf(good);
            if (stack == null) {
                continue;
            }
            int left = good.material == null ? 1 : good.amount;
            while (left > 0) {
                ItemStack part = stack.clone();
                part.setAmount(Math.min(left, part.getMaxStackSize()));
                left -= part.getAmount();
                for (ItemStack rest : player.getInventory().addItem(part).values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), rest);
                }
            }
            given++;
        }
        plugin.getMessages().send(player, "economy.bought", Map.of("count", given * (good.material == null ? 1 : good.amount),
                "coins", plugin.getEconomy().format(cost)));
    }
}
