package ru.adventurers.core.gear;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class GearListener implements Listener {

    private final GearManager gear;

    public GearListener(GearManager gear) {
        this.gear = gear;
    }

    // Удар оружием или инструментом
    @EventHandler(ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            if (!gear.canUse(player, player.getInventory().getItemInMainHand())) {
                event.setCancelled(true);
            }
        }
    }

    // Добыча блоков инструментом
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (!gear.canUse(player, player.getInventory().getItemInMainHand())) {
            event.setCancelled(true);
        }
    }

    // Правый клик: лук, арбалет, трезубец, надевание брони из руки.
    // Блокируем только использование предмета, а не двери и сундуки.
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getItem() == null) {
            return;
        }
        if (!gear.canUse(event.getPlayer(), event.getItem())) {
            event.setUseItemInHand(Event.Result.DENY);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        gear.forget(event.getPlayer().getUniqueId());
    }
}