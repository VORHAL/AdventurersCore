package ru.adventurers.core.gear;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.ProfileManager;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.survival.SurvivalManager;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Мастер Гильдии: выдаёт набор экипировки ранга. Один набор на ранг, повторно только админом.
 * NPC вызывает консольную команду: ag admin gear claim <ник>
 */
public class GuildGearService {

    private record ItemSpec(Material material, String name, List<String> lore,
                            Map<String, Integer> enchants, int amount) {
    }

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private final AdventurersCore plugin;
    private final GuildGearRepository repository;
    private final ProfileManager profiles;
    private final NamespacedKey gearKey;
    private final Map<Rank, List<ItemSpec>> kits = new EnumMap<>(Rank.class);

    public GuildGearService(AdventurersCore plugin, GuildGearRepository repository, ProfileManager profiles) {
        this.plugin = plugin;
        this.repository = repository;
        this.profiles = profiles;
        this.gearKey = SurvivalManager.rankGearKey(plugin);
    }

    public void init() throws SQLException {
        repository.createTable();
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "guildgear.yml");
        if (!file.exists()) {
            plugin.saveResource("guildgear.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        kits.clear();
        for (Rank rank : Rank.values()) {
            List<ItemSpec> specs = new ArrayList<>();
            for (Map<?, ?> raw : cfg.getMapList("kits." + rank.getDisplayName())) {
                ItemSpec spec = parse(raw, rank);
                if (spec != null) {
                    specs.add(spec);
                }
            }
            kits.put(rank, specs);
        }
    }

    private ItemSpec parse(Map<?, ?> raw, Rank rank) {
        Object materialValue = raw.get("material");
        Material material = materialValue == null ? null
                : Material.matchMaterial(String.valueOf(materialValue));
        if (material == null) {
            plugin.getLogger().warning("guildgear.yml, ранг " + rank.getDisplayName()
                    + ": неизвестный материал " + materialValue);
            return null;
        }
        Object nameValue = raw.get("name");
        String name = nameValue == null ? null : String.valueOf(nameValue);

        List<String> lore = new ArrayList<>();
        if (raw.get("lore") instanceof List<?> list) {
            for (Object line : list) {
                lore.add(String.valueOf(line));
            }
        }

        Map<String, Integer> enchants = new HashMap<>();
        if (raw.get("enchants") instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (entry.getValue() instanceof Number number) {
                    enchants.put(String.valueOf(entry.getKey()), number.intValue());
                }
            }
        }

        int amount = raw.get("amount") instanceof Number number ? Math.max(1, number.intValue()) : 1;
        return new ItemSpec(material, name, lore, enchants, amount);
    }

    private ItemStack build(ItemSpec spec, Rank rank) {
        ItemStack item = new ItemStack(spec.material(), spec.amount());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        if (spec.name() != null) {
            meta.displayName(LEGACY.deserialize(spec.name()).decoration(TextDecoration.ITALIC, false));
        }
        if (!spec.lore().isEmpty()) {
            List<Component> lines = new ArrayList<>();
            for (String line : spec.lore()) {
                lines.add(LEGACY.deserialize(line).decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(lines);
        }
        for (Map.Entry<String, Integer> entry : spec.enchants().entrySet()) {
            Enchantment enchantment = Registry.ENCHANTMENT.get(
                    NamespacedKey.minecraft(entry.getKey().toLowerCase(Locale.ROOT)));
            if (enchantment == null) {
                plugin.getLogger().warning("guildgear.yml: неизвестные чары " + entry.getKey());
                continue;
            }
            meta.addEnchant(enchantment, Math.max(1, entry.getValue()), true);
        }
        ru.adventurers.core.hud.PackItems.gear(meta, spec.material(), rank);
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
        meta.getPersistentDataContainer().set(gearKey, PersistentDataType.STRING, rank.name());
        item.setItemMeta(meta);
        return item;
    }

    /** Выдаёт набор прямо сейчас (основной поток). Лишнее падает под ноги. Возвращает число предметов. */
    public int give(Player player, Rank rank) {
        List<ItemSpec> specs = kits.getOrDefault(rank, List.of());
        int count = 0;
        for (ItemSpec spec : specs) {
            ItemStack item = build(spec, rank);
            Map<Integer, ItemStack> leftovers = player.getInventory().addItem(item);
            for (ItemStack extra : leftovers.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), extra);
            }
            count += item.getAmount();
        }
        return count;
    }

    public boolean hasKit(Rank rank) {
        return !kits.getOrDefault(rank, List.of()).isEmpty();
    }

    /** Мастер Гильдии: набор для текущего ранга игрока, один раз. feedback получает короткий итог. */
    public void claim(Player player, CommandSender feedback) {
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        if (profile == null) {
            plugin.getMessages().send(feedback, "commands.admin.profile-loading");
            return;
        }
        Rank rank = profile.getRank();
        Map<String, Object> placeholders = Map.of(
                "player", player.getName(),
                "rank", plugin.getMessages().rankName(rank));

        if (!hasKit(rank)) {
            plugin.getMessages().send(player, "gear.nothing", placeholders);
            return;
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            boolean first;
            try {
                first = repository.tryClaim(player.getUniqueId(), rank);
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not record gear claim for " + player.getName());
                exception.printStackTrace();
                Bukkit.getScheduler().runTask(plugin,
                        () -> plugin.getMessages().send(feedback, "gear.error"));
                return;
            }
            boolean granted = first;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!granted) {
                    plugin.getMessages().send(player, "gear.already", placeholders);
                    return;
                }
                if (!player.isOnline()) {
                    undo(player, rank);
                    return;
                }
                give(player, rank);
                plugin.getMessages().send(player, "gear.claimed", placeholders);
                if (feedback != player) {
                    plugin.getMessages().send(feedback, "gear.admin.claimed", placeholders);
                }
            });
        });
    }

    private void undo(Player player, Rank rank) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                repository.unclaim(player.getUniqueId(), rank);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });
    }

    /** Админ: забыть все получения наборов, чтобы выдать заново (для тестов). */
    public void reset(Player player, CommandSender feedback) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                repository.deleteAll(player.getUniqueId());
            } catch (SQLException exception) {
                exception.printStackTrace();
                Bukkit.getScheduler().runTask(plugin,
                        () -> plugin.getMessages().send(feedback, "gear.error"));
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> plugin.getMessages().send(
                    feedback, "gear.admin.reset", Map.of("player", player.getName())));
        });
    }
}
