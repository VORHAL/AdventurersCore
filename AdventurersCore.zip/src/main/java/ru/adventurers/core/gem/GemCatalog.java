package ru.adventurers.core.gem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;

import java.util.ArrayList;
import java.util.List;

/** Каталог самоцветов: список камней, по клику описание по уровням и места добычи. */
public class GemCatalog implements Listener {

    private static final int SIZE = 54;
    private static final int[] SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43};

    private final AdventurersCore plugin;

    public GemCatalog(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    private static final class Holder implements InventoryHolder {
        final List<String> ids = new ArrayList<>();
        int page;
        String detail;

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static Component text(String legacy) {
        return Hud.legacy(legacy).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack icon(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(text(name));
        List<Component> lines = new ArrayList<>();
        for (String line : lore) {
            lines.add(text(line));
        }
        meta.lore(lines);
        meta.addItemFlags(ItemFlag.values());
        item.setItemMeta(meta);
        return item;
    }

    private void frame(Inventory inventory) {
        ItemStack glass = icon(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < SIZE; i++) {
            inventory.setItem(i, glass);
        }
    }

    public void open(Player player, int page) {
        var gems = plugin.getGems();
        Holder holder = new Holder();
        holder.ids.addAll(gems.getTypes().keySet());
        int pages = Math.max(1, (holder.ids.size() + SLOTS.length - 1) / SLOTS.length);
        holder.page = Math.max(0, Math.min(page, pages - 1));
        Inventory inventory = Bukkit.createInventory(holder, SIZE, text("&8» &6&lСамоцветы"));
        frame(inventory);
        inventory.setItem(4, icon(Material.AMETHYST_SHARD, "&6Каталог самоцветов",
                List.of("&7Нажми на камень: бонусы по уровням", "&7и где его добыть.",
                        "&7Страница &f" + (holder.page + 1) + "&8/&f" + pages)));
        for (int i = 0; i < SLOTS.length; i++) {
            int index = holder.page * SLOTS.length + i;
            if (index >= holder.ids.size()) {
                inventory.setItem(SLOTS[i], null);
                continue;
            }
            var type = gems.type(holder.ids.get(index));
            List<String> lore = new ArrayList<>();
            lore.add(gems.describe(type, 1));
            if (!type.hint().isBlank()) {
                lore.add("&7Кому: " + type.hint());
            }
            lore.add("");
            lore.add("&e▶ Нажми: подробности");
            inventory.setItem(SLOTS[i], icon(type.material(), type.color() + "◆ " + type.name(), lore));
        }
        if (holder.page > 0) {
            inventory.setItem(45, icon(Material.ARROW, "&7◀ Назад", List.of()));
        }
        if (holder.page < pages - 1) {
            inventory.setItem(53, icon(Material.ARROW, "&7Дальше ▶", List.of()));
        }
        inventory.setItem(49, icon(Material.BARRIER, "&cЗакрыть", List.of()));
        inventory.setItem(48, icon(Material.SPECTRAL_ARROW, "&7К мастерской", List.of("&8Вернуться в меню ювелира.")));
        player.openInventory(inventory);
    }

    private void openDetail(Player player, String id, int page) {
        var gems = plugin.getGems();
        var type = gems.type(id);
        if (type == null) {
            return;
        }
        Holder holder = new Holder();
        holder.detail = id;
        holder.page = page;
        Inventory inventory = Bukkit.createInventory(holder, 45, text("&8» " + type.color() + "&l" + type.name()));
        ItemStack glass = icon(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 45; i++) {
            inventory.setItem(i, glass);
        }
        List<String> head = new ArrayList<>();
        if (!type.hint().isBlank()) {
            head.add("&7Кому подходит: " + type.hint());
        }
        head.add("&7Огранка и соединение: ювелир.");
        inventory.setItem(4, icon(type.material(), type.color() + "◆ " + type.name(), head));
        int max = gems.getMaxLevel();
        int[] levelSlots = {11, 12, 13, 14, 15, 16, 17, 18};
        for (int level = 1; level <= max && level <= levelSlots.length; level++) {
            inventory.setItem(levelSlots[level - 1],
                    icon(type.material(), type.color() + "Уровень " + level, List.of(gems.describe(type, level))));
        }
        List<String> sources = gems.sourcesOf(id);
        if (sources.isEmpty()) {
            sources = List.of("&8Только огранка и соединение.");
        }
        List<String> lore = new ArrayList<>(sources);
        inventory.setItem(31, icon(Material.MAP, "&6Где добыть", lore));
        inventory.setItem(39, icon(Material.ARROW, "&7◀ К списку", List.of()));
        inventory.setItem(41, icon(Material.BARRIER, "&cЗакрыть", List.of()));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)
                || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }
        int slot = event.getSlot();
        if (holder.detail != null) {
            if (slot == 39) {
                open(player, holder.page);
            } else if (slot == 41) {
                player.closeInventory();
            }
            return;
        }
        if (slot == 45 && holder.page > 0) {
            open(player, holder.page - 1);
        } else if (slot == 53) {
            open(player, holder.page + 1);
        } else if (slot == 49) {
            player.closeInventory();
        } else if (slot == 48) {
            plugin.openWorkshop(player);
        } else {
            for (int i = 0; i < SLOTS.length; i++) {
                if (SLOTS[i] == slot) {
                    int index = holder.page * SLOTS.length + i;
                    if (index < holder.ids.size()) {
                        openDetail(player, holder.ids.get(index), holder.page);
                    }
                    return;
                }
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        // ничего не храним
    }
}
