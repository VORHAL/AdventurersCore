package ru.adventurers.core.gem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profession.PlayerProfessions;
import ru.adventurers.core.profession.Profession;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.survival.SurvivalManager;

import java.io.File;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.UUID;

/**
 * Самоцветы: добыча, огранка и соединение ювелиром, гнёзда на ранговой экипировке,
 * бонусы к характеристикам и особые эффекты. Настройки: gems.yml. Только основной поток.
 */
public class GemManager {

    public enum Effect {
        LIFESTEAL, IGNITE, THORNS,
        REGEN, AURA_HEAL,
        BLOCK, REDUCE, RESIST, SURVIVOR,
        CRIT, EXECUTE,
        NIGHT_VISION, PROF_XP,
        HEAL_POWER
    }

    public record GemType(String id, String name, String color, Material material, Attribute attribute,
                          AttributeModifier.Operation operation, double value, Effect effect, String lore, String hint) {
    }

    public record Socketed(String type, int level) {
    }

    private record DropRule(String target, double chance, List<String> gems) {
    }

    private static final String MARK = "​";
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII"};

    private final AdventurersCore plugin;
    private final NamespacedKey typeKey;
    private final NamespacedKey levelKey;
    private final NamespacedKey rawKey;
    private final NamespacedKey socketsKey;
    private final Random random = new Random();

    private final Map<String, GemType> types = new LinkedHashMap<>();
    private final Map<Rank, Integer> slots = new EnumMap<>(Rank.class);
    private final List<DropRule> blockDrops = new ArrayList<>();
    private final List<DropRule> mobDrops = new ArrayList<>();
    private final Map<UUID, String> signatures = new HashMap<>();

    private int maxLevel = 5;
    private int combineAmount = 3;
    private double combineBase = 0.95;
    private double combinePenalty = 0.12;
    private double combineJeweler = 0.03;
    private double removeBreakChance = 0.25;
    private int cutXp = 20;
    private double upgradeChance = 0.06;
    private int igniteTicks = 60;
    private double critBonus = 0.5;
    private double blockReduction = 0.6;
    private double executeThreshold = 0.3;
    private long survivorCooldownMs = 120_000L;
    private boolean passivesEnabled = true;
    private final Map<Material, Integer> cutCost = new EnumMap<>(Material.class);
    private final Map<Material, Integer> combineCost = new EnumMap<>(Material.class);
    private BukkitTask task;

    public GemManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.typeKey = new NamespacedKey(plugin, "gem_type");
        this.levelKey = new NamespacedKey(plugin, "gem_level");
        this.rawKey = new NamespacedKey(plugin, "gem_raw");
        this.socketsKey = new NamespacedKey(plugin, "gem_sockets");
    }

    public void init() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 10L);
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            clearModifiers(player);
        }
        signatures.clear();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "gems.yml");
        if (!file.exists()) {
            plugin.saveResource("gems.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        maxLevel = Math.max(1, Math.min(8, cfg.getInt("max-level", 5)));
        combineAmount = Math.max(2, cfg.getInt("combine.amount", 3));
        combineBase = cfg.getDouble("combine.success-base", 0.95);
        combinePenalty = cfg.getDouble("combine.penalty-per-level", 0.12);
        combineJeweler = cfg.getDouble("combine.bonus-per-jeweler-level", 0.03);
        removeBreakChance = cfg.getDouble("unsocket.break-chance", 0.25);
        cutXp = Math.max(0, cfg.getInt("cut.profession-xp", 20));
        upgradeChance = cfg.getDouble("cut.upgrade-chance-per-jeweler-level", 0.06);
        igniteTicks = Math.max(20, cfg.getInt("ignite-ticks", 60));
        critBonus = cfg.getDouble("crit-bonus", 0.5);
        blockReduction = Math.max(0.0, Math.min(1.0, cfg.getDouble("block-reduction", 0.6)));
        executeThreshold = Math.max(0.05, Math.min(0.9, cfg.getDouble("execute-threshold", 0.3)));
        survivorCooldownMs = Math.max(0, cfg.getInt("survivor-cooldown-seconds", 120)) * 1000L;
        readCost(cfg.getConfigurationSection("cut.cost"), cutCost);
        readCost(cfg.getConfigurationSection("combine.cost-per-level"), combineCost);

        // Число гнёзд по рангу выдачи. Не убывает: если ранг пропущен, берётся значение предыдущего.
        slots.clear();
        int previous = 0;
        for (Rank rank : Rank.values()) {
            int value = previous;
            ConfigurationSection section = cfg.getConfigurationSection("slots");
            if (section != null) {
                for (String key : section.getKeys(false)) {
                    if (Rank.fromInput(key) == rank) {
                        value = section.getInt(key, previous);
                    }
                }
            }
            value = Math.max(previous, Math.max(0, value));
            slots.put(rank, value);
            previous = value;
        }

        types.clear();
        ConfigurationSection gems = cfg.getConfigurationSection("gems");
        if (gems != null) {
            for (String id : gems.getKeys(false)) {
                ConfigurationSection section = gems.getConfigurationSection(id);
                if (section == null) {
                    continue;
                }
                Material material = Material.matchMaterial(section.getString("material", "EMERALD"));
                if (material == null) {
                    plugin.getLogger().warning("gems.yml: неизвестный материал у самоцвета " + id);
                    material = Material.EMERALD;
                }
                Attribute attribute = null;
                String attributeName = section.getString("attribute");
                if (attributeName != null) {
                    attribute = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(attributeName.toLowerCase(Locale.ROOT)));
                    if (attribute == null) {
                        plugin.getLogger().warning("gems.yml: неизвестный атрибут " + attributeName + " (" + id + ")");
                    }
                }
                AttributeModifier.Operation operation = AttributeModifier.Operation.ADD_NUMBER;
                try {
                    operation = AttributeModifier.Operation.valueOf(
                            section.getString("operation", "ADD_NUMBER").toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException exception) {
                    plugin.getLogger().warning("gems.yml: неизвестная операция у " + id);
                }
                Effect effect = null;
                String effectName = section.getString("effect");
                if (effectName != null) {
                    try {
                        effect = Effect.valueOf(effectName.toUpperCase(Locale.ROOT));
                    } catch (IllegalArgumentException exception) {
                        plugin.getLogger().warning("gems.yml: неизвестный эффект " + effectName + " (" + id + ")");
                    }
                }
                types.put(id.toLowerCase(Locale.ROOT), new GemType(id.toLowerCase(Locale.ROOT),
                        section.getString("name", id), section.getString("color", "&f"), material,
                        attribute, operation, section.getDouble("value", 0.0), effect,
                        section.getString("lore", "&7Особый эффект"), section.getString("hint", "")));
            }
        }

        blockDrops.clear();
        mobDrops.clear();
        readDrops(cfg.getMapList("sources.blocks"), "material", blockDrops);
        readDrops(cfg.getMapList("sources.mobs"), "entity", mobDrops);

        readPassives();
        signatures.clear();
    }

    private void readCost(ConfigurationSection section, Map<Material, Integer> out) {
        out.clear();
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            Material material = Material.matchMaterial(key);
            if (material != null && section.getInt(key) > 0) {
                out.put(material, section.getInt(key));
            } else {
                plugin.getLogger().warning("gems.yml: неверная цена " + key);
            }
        }
    }

    private void readDrops(List<Map<?, ?>> list, String targetKey, List<DropRule> out) {
        for (Map<?, ?> raw : list) {
            Object target = raw.get(targetKey);
            Object chance = raw.get("chance");
            Object gems = raw.get("gems");
            if (target == null || !(chance instanceof Number number) || !(gems instanceof List<?> gemList)) {
                continue;
            }
            List<String> ids = new ArrayList<>();
            for (Object gem : gemList) {
                String id = String.valueOf(gem).toLowerCase(Locale.ROOT);
                if (types.containsKey(id)) {
                    ids.add(id);
                }
            }
            if (!ids.isEmpty()) {
                out.add(new DropRule(String.valueOf(target).toUpperCase(Locale.ROOT), number.doubleValue(), ids));
            }
        }
    }

    // ---------------------------------------------------------------
    //  Предметы
    // ---------------------------------------------------------------

    public Map<String, GemType> getTypes() {
        return types;
    }

    public GemType type(String id) {
        return id == null ? null : types.get(id.toLowerCase(Locale.ROOT));
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    private static String roman(int level) {
        return level >= 0 && level < ROMAN.length ? ROMAN[level] : String.valueOf(level);
    }

    private static String number(double value) {
        String text = String.format(Locale.ROOT, "%.2f", value);
        text = text.replaceAll("0+$", "");
        return text.endsWith(".") ? text.substring(0, text.length() - 1) : text;
    }

    /** Описание бонуса самоцвета на данном уровне (с цветами &). */
    public String describe(GemType type, int level) {
        double total = type.value() * level;
        String percent = number(total * 100.0);
        return type.lore().replace("{value}", number(total)).replace("{percent}", percent);
    }

    public ItemStack createGem(GemType type, int level, boolean raw) {
        ItemStack item = new ItemStack(type.material(), 1);
        ItemMeta meta = item.getItemMeta();
        String title = raw
                ? "&7Необработанный " + type.color() + type.name().toLowerCase(Locale.ROOT)
                : type.color() + "◆ " + type.name() + " " + roman(level);
        meta.displayName(Hud.legacy(title).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        if (raw) {
            lore.add(italicOff("&8Грубый камень. Его огранит ювелир."));
            lore.add(italicOff("&7Команда: &f/ag gem cut"));
        } else {
            lore.add(italicOff("&8Уровень: " + type.color() + roman(level) + "&8/&7" + roman(maxLevel)));
            lore.add(italicOff(describe(type, level)));
            if (!type.hint().isBlank()) {
                lore.add(italicOff("&8Подходит: " + type.hint()));
            }
            lore.add(Component.empty());
            lore.add(italicOff("&7Вставь в гнездо экипировки:"));
            lore.add(italicOff("&7экипировка в руке, камень в левой руке,"));
            lore.add(italicOff("&7команда &f/ag gem socket"));
        }
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        ru.adventurers.core.hud.PackItems.model(meta, raw ? "gem_raw" : "gem_" + type.id());
        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(typeKey, PersistentDataType.STRING, type.id());
        if (raw) {
            data.set(rawKey, PersistentDataType.BYTE, (byte) 1);
        } else {
            data.set(levelKey, PersistentDataType.INTEGER, level);
        }
        item.setItemMeta(meta);
        return item;
    }

    private static Component italicOff(String text) {
        return Hud.legacy(text).decoration(TextDecoration.ITALIC, false);
    }

    private PersistentDataContainer pdc(ItemStack item) {
        return item != null && item.getType() != Material.AIR && item.hasItemMeta()
                ? item.getItemMeta().getPersistentDataContainer() : null;
    }

    /** Тип самоцвета в предмете или null. */
    public GemType gemTypeOf(ItemStack item) {
        PersistentDataContainer data = pdc(item);
        return data == null ? null : type(data.get(typeKey, PersistentDataType.STRING));
    }

    public boolean isRaw(ItemStack item) {
        PersistentDataContainer data = pdc(item);
        return data != null && gemTypeOf(item) != null && data.has(rawKey, PersistentDataType.BYTE);
    }

    /** Уровень огранённого самоцвета, 0 если это не огранённый самоцвет. */
    public int levelOf(ItemStack item) {
        PersistentDataContainer data = pdc(item);
        if (data == null || gemTypeOf(item) == null || data.has(rawKey, PersistentDataType.BYTE)) {
            return 0;
        }
        Integer level = data.get(levelKey, PersistentDataType.INTEGER);
        return level == null ? 0 : level;
    }

    // ---------------------------------------------------------------
    //  Гнёзда на экипировке
    // ---------------------------------------------------------------

    /** Число гнёзд у предмета (по рангу выдачи). 0, если это не ранговая экипировка. */
    public int slotsOf(ItemStack item) {
        PersistentDataContainer data = pdc(item);
        if (data == null) {
            return 0;
        }
        String issued = data.get(SurvivalManager.rankGearKey(plugin), PersistentDataType.STRING);
        if (issued == null) {
            return 0;
        }
        try {
            return slots.getOrDefault(Rank.valueOf(issued), 0);
        } catch (IllegalArgumentException exception) {
            return 0;
        }
    }

    public List<Socketed> socketsOf(ItemStack item) {
        List<Socketed> result = new ArrayList<>();
        PersistentDataContainer data = pdc(item);
        String stored = data == null ? null : data.get(socketsKey, PersistentDataType.STRING);
        if (stored == null || stored.isBlank()) {
            return result;
        }
        for (String part : stored.split(",")) {
            String[] pieces = part.split(":");
            if (pieces.length == 2 && type(pieces[0]) != null) {
                try {
                    result.add(new Socketed(pieces[0], Integer.parseInt(pieces[1])));
                } catch (NumberFormatException ignored) {
                    // пропускаем испорченную запись
                }
            }
        }
        return result;
    }

    private void writeSockets(ItemStack item, List<Socketed> sockets) {
        ItemMeta meta = item.getItemMeta();
        StringBuilder text = new StringBuilder();
        for (Socketed socketed : sockets) {
            if (!text.isEmpty()) {
                text.append(',');
            }
            text.append(socketed.type()).append(':').append(socketed.level());
        }
        if (sockets.isEmpty()) {
            meta.getPersistentDataContainer().remove(socketsKey);
        } else {
            meta.getPersistentDataContainer().set(socketsKey, PersistentDataType.STRING, text.toString());
        }

        // Строки самоцветов в описании помечены невидимым символом: старые убираем, свежие дописываем.
        List<Component> lore = new ArrayList<>();
        List<Component> current = meta.lore();
        if (current != null) {
            for (Component line : current) {
                if (!PlainTextComponentSerializer.plainText().serialize(line).startsWith(MARK)) {
                    lore.add(line);
                }
            }
        }
        int total = slotsOf(item);
        if (total > 0) {
            StringBuilder icons = new StringBuilder(MARK + "&#8a8f98Гнёзда: ");
            for (int i = 0; i < total; i++) {
                if (i < sockets.size()) {
                    GemType gem = type(sockets.get(i).type());
                    icons.append(gem != null ? gem.color() : "&f").append("◆ ");
                } else {
                    icons.append("&8◇ ");
                }
            }
            lore.add(italicOff(icons.toString()));
            for (Socketed socketed : sockets) {
                GemType gem = type(socketed.type());
                if (gem != null) {
                    lore.add(italicOff(MARK + " " + gem.color() + "◆ " + gem.name() + " " + roman(socketed.level())
                            + " &8» " + describe(gem, socketed.level())));
                }
            }
        }
        meta.lore(lore);
        item.setItemMeta(meta);
    }

    // ---------------------------------------------------------------
    //  Действия ювелира
    // ---------------------------------------------------------------

    public int jewelerLevel(Player player) {
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        PlayerProfessions.Progress progress = data == null ? null : data.get(Profession.JEWELER);
        return progress == null ? 0 : progress.getLevel();
    }

    private boolean requireJeweler(Player player) {
        if (!plugin.getProfessions().has(player, Profession.JEWELER)) {
            say(player, "gems.need-jeweler");
            return false;
        }
        return true;
    }

    /** Огранка: необработанный самоцвет в руке. */
    public void cut(Player player) {
        if (!requireJeweler(player)) {
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        GemType type = gemTypeOf(hand);
        if (type == null || !isRaw(hand)) {
            say(player, "gems.cut-hand");
            return;
        }
        if (!hasCost(player, cutCost, 1)) {
            say(player, "gems.cost-missing", Map.of("cost", costText(cutCost, 1)));
            return;
        }
        takeCost(player, cutCost, 1);
        int jeweler = jewelerLevel(player);
        int level = 1;
        double chance = upgradeChance * jeweler;
        while (level < maxLevel && random.nextDouble() < chance) {
            level++;
            chance *= 0.5;
        }
        hand.setAmount(hand.getAmount() - 1);
        give(player, createGem(type, level, false));
        if (cutXp > 0) {
            plugin.getProfessions().addXp(player, Profession.JEWELER, cutXp);
        }
        say(player, "gems.cut-ok", Map.of(
                "gem", type.color() + type.name() + " " + roman(level)));
    }

    /** Сообщение в чат; если у игрока открыто меню (мастерская), ещё и над хотбаром, иначе его не видно. */
    private void say(Player player, String key) {
        say(player, key, Map.of());
    }

    private void say(Player player, String key, Map<String, ?> placeholders) {
        plugin.getMessages().send(player, key, placeholders);
        if (player.getOpenInventory().getType() == InventoryType.CRAFTING) {
            return;
        }
        String text = plugin.getMessages().text(key, "").replace("{prefix}", "");
        for (Map.Entry<String, ?> entry : placeholders.entrySet()) {
            text = text.replace("{" + entry.getKey() + "}", String.valueOf(entry.getValue()));
        }
        if (!text.isBlank()) {
            plugin.getSkillHud().flash(player, Hud.legacy(text));
        }
    }

    /** Соединение: несколько одинаковых огранённых самоцветов дают один уровнем выше. */
    public void combine(Player player) {
        if (!requireJeweler(player)) {
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        GemType type = gemTypeOf(hand);
        int level = levelOf(hand);
        if (type == null || level <= 0) {
            say(player, "gems.combine-hand");
            return;
        }
        if (level >= maxLevel) {
            say(player, "gems.combine-max");
            return;
        }
        int have = 0;
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack != null && type.equals(gemTypeOf(stack)) && levelOf(stack) == level) {
                have += stack.getAmount();
            }
        }
        if (have < combineAmount) {
            say(player, "gems.combine-few", Map.of(
                    "need", String.valueOf(combineAmount), "have", String.valueOf(have)));
            return;
        }
        if (!hasCost(player, combineCost, level + 1)) {
            say(player, "gems.cost-missing", Map.of("cost", costText(combineCost, level + 1)));
            return;
        }
        takeCost(player, combineCost, level + 1);
        // Заберём нужное число.
        int left = combineAmount;
        for (ItemStack stack : player.getInventory().getContents()) {
            if (left <= 0) {
                break;
            }
            if (stack != null && type.equals(gemTypeOf(stack)) && levelOf(stack) == level) {
                int take = Math.min(left, stack.getAmount());
                stack.setAmount(stack.getAmount() - take);
                left -= take;
            }
        }
        double success = Math.max(0.2, Math.min(1.0,
                combineBase - combinePenalty * (level - 1) + combineJeweler * jewelerLevel(player)));
        if (random.nextDouble() < success) {
            give(player, createGem(type, level + 1, false));
            say(player, "gems.combine-ok", Map.of(
                    "gem", type.color() + type.name() + " " + roman(level + 1)));
            if (cutXp > 0) {
                plugin.getProfessions().addXp(player, Profession.JEWELER, cutXp * level);
            }
        } else {
            // Неудача: один камень уцелел.
            give(player, createGem(type, level, false));
            say(player, "gems.combine-fail", Map.of(
                    "chance", String.valueOf(Math.round(success * 100))));
        }
    }

    /** Вставка: экипировка в основной руке, огранённый самоцвет в левой. */
    public void socket(Player player) {
        if (!requireJeweler(player)) {
            return;
        }
        ItemStack gear = player.getInventory().getItemInMainHand();
        ItemStack gem = player.getInventory().getItemInOffHand();
        GemType type = gemTypeOf(gem);
        int level = levelOf(gem);
        if (type == null || level <= 0) {
            say(player, "gems.socket-gem");
            return;
        }
        int total = slotsOf(gear);
        if (total <= 0) {
            say(player, "gems.socket-no-slots");
            return;
        }
        List<Socketed> sockets = socketsOf(gear);
        if (sockets.size() >= total) {
            say(player, "gems.socket-full", Map.of("slots", String.valueOf(total)));
            return;
        }
        sockets.add(new Socketed(type.id(), level));
        writeSockets(gear, sockets);
        gem.setAmount(gem.getAmount() - 1);
        signatures.remove(player.getUniqueId());
        say(player, "gems.socket-ok", Map.of(
                "gem", type.color() + type.name() + " " + roman(level),
                "used", String.valueOf(sockets.size()), "slots", String.valueOf(total)));
    }

    /** Извлечение самоцвета с номером index (с 1). Камень может разбиться. */
    public void unsocket(Player player, int index) {
        if (!requireJeweler(player)) {
            return;
        }
        ItemStack gear = player.getInventory().getItemInMainHand();
        List<Socketed> sockets = socketsOf(gear);
        if (sockets.isEmpty()) {
            say(player, "gems.unsocket-empty");
            return;
        }
        if (index < 1 || index > sockets.size()) {
            say(player, "gems.unsocket-usage");
            return;
        }
        Socketed removed = sockets.remove(index - 1);
        writeSockets(gear, sockets);
        signatures.remove(player.getUniqueId());
        GemType type = type(removed.type());
        if (type == null) {
            return;
        }
        String name = type.color() + type.name() + " " + roman(removed.level());
        if (random.nextDouble() < removeBreakChance) {
            say(player, "gems.unsocket-broken", Map.of("gem", name));
        } else {
            give(player, createGem(type, removed.level(), false));
            say(player, "gems.unsocket-ok", Map.of("gem", name));
        }
    }

    /** Показывает гнёзда предмета в руке. */
    public void info(Player player) {
        ItemStack gear = player.getInventory().getItemInMainHand();
        int total = slotsOf(gear);
        if (total <= 0) {
            say(player, "gems.info-none");
            return;
        }
        List<Socketed> sockets = socketsOf(gear);
        say(player, "gems.info-head", Map.of(
                "used", String.valueOf(sockets.size()), "slots", String.valueOf(total)));
        int number = 1;
        for (Socketed socketed : sockets) {
            GemType type = type(socketed.type());
            if (type != null) {
                say(player, "gems.info-line", Map.of(
                        "n", String.valueOf(number++),
                        "gem", type.color() + type.name() + " " + roman(socketed.level()),
                        "effect", describe(type, socketed.level())));
            }
        }
    }

    /** Список самоцветов и их свойств. */
    /** Где падает необработанный камень (для каталога). Строки с цветами &. */
    public List<String> sourcesOf(String gemId) {
        List<String> result = new ArrayList<>();
        for (DropRule rule : blockDrops) {
            if (rule.gems().contains(gemId)) {
                result.add("&7⛏ " + ruName(rule.target()) + " &8(" + percentText(rule.chance()) + ")");
            }
        }
        for (DropRule rule : mobDrops) {
            if (rule.gems().contains(gemId)) {
                result.add("&7☠ " + ruName(rule.target()) + " &8(" + percentText(rule.chance()) + ")");
            }
        }
        return result;
    }

    private static String percentText(double chance) {
        return number(chance * 100.0) + "%";
    }

    private static String ruName(String id) {
        return switch (id) {
            case "DIAMOND_ORE", "DEEPSLATE_DIAMOND_ORE" -> "алмазная руда";
            case "EMERALD_ORE", "DEEPSLATE_EMERALD_ORE" -> "изумрудная руда";
            case "LAPIS_ORE", "DEEPSLATE_LAPIS_ORE" -> "лазурит";
            case "GOLD_ORE", "DEEPSLATE_GOLD_ORE" -> "золотая руда";
            case "IRON_ORE", "DEEPSLATE_IRON_ORE" -> "железная руда";
            case "COPPER_ORE", "DEEPSLATE_COPPER_ORE" -> "медная руда";
            case "COAL_ORE", "DEEPSLATE_COAL_ORE" -> "угольная руда";
            case "ANCIENT_DEBRIS" -> "древние обломки";
            case "NETHER_QUARTZ_ORE" -> "кварцевая руда";
            case "WITHER_SKELETON" -> "скелет-иссушитель";
            case "BLAZE" -> "ифрит";
            case "ENDERMAN" -> "странник Края";
            case "WITCH" -> "ведьма";
            case "GUARDIAN" -> "страж";
            case "ELDER_GUARDIAN" -> "древний страж";
            case "WARDEN" -> "хранитель";
            case "ANY" -> "любой монстр";
            default -> id.toLowerCase(Locale.ROOT).replace('_', ' ');
        };
    }

    public void list(Player player) {
        say(player, "gems.list-head");
        for (GemType type : types.values()) {
            say(player, "gems.list-line", Map.of(
                    "gem", type.color() + "◆ " + type.name(),
                    "effect", describe(type, 1) + (type.hint().isBlank() ? "" : " &8(" + type.hint() + "&8)")));
        }
    }

    private boolean hasCost(Player player, Map<Material, Integer> cost, int factor) {
        for (Map.Entry<Material, Integer> entry : cost.entrySet()) {
            int have = 0;
            for (ItemStack stack : player.getInventory().getContents()) {
                if (stack != null && stack.getType() == entry.getKey()) {
                    have += stack.getAmount();
                }
            }
            if (have < entry.getValue() * factor) {
                return false;
            }
        }
        return true;
    }

    private void takeCost(Player player, Map<Material, Integer> cost, int factor) {
        for (Map.Entry<Material, Integer> entry : cost.entrySet()) {
            int left = entry.getValue() * factor;
            for (ItemStack stack : player.getInventory().getContents()) {
                if (left <= 0) {
                    break;
                }
                if (stack != null && stack.getType() == entry.getKey()) {
                    int take = Math.min(left, stack.getAmount());
                    stack.setAmount(stack.getAmount() - take);
                    left -= take;
                }
            }
        }
    }

    private String costText(Map<Material, Integer> cost, int factor) {
        StringBuilder text = new StringBuilder();
        for (Map.Entry<Material, Integer> entry : cost.entrySet()) {
            if (!text.isEmpty()) {
                text.append(", ");
            }
            text.append(entry.getValue() * factor).append(" × ")
                    .append(entry.getKey().name().toLowerCase(Locale.ROOT).replace('_', ' '));
        }
        return text.toString();
    }

    private void give(Player player, ItemStack item) {
        Map<Integer, ItemStack> left = player.getInventory().addItem(item);
        for (ItemStack extra : left.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
    }

    public boolean adminGive(Player target, String typeId, int level, boolean raw) {
        GemType type = type(typeId);
        if (type == null) {
            return false;
        }
        give(target, createGem(type, Math.max(1, Math.min(maxLevel, level)), raw));
        return true;
    }

    // ---------------------------------------------------------------
    //  Добыча
    // ---------------------------------------------------------------

    public void rollBlock(Player player, Material material, org.bukkit.Location where) {
        ItemStack gem = roll(blockDrops, material.name());
        if (gem != null && where.getWorld() != null) {
            where.getWorld().dropItemNaturally(where, gem);
        }
    }

    /** Самоцвет с убитого существа или null. */
    public ItemStack rollMob(String entityType) {
        ItemStack gem = roll(mobDrops, entityType);
        return gem;
    }

    private ItemStack roll(List<DropRule> rules, String target) {
        for (DropRule rule : rules) {
            if ((rule.target().equals(target) || rule.target().equals("ANY")) && random.nextDouble() < rule.chance()) {
                GemType type = types.get(rule.gems().get(random.nextInt(rule.gems().size())));
                if (type != null) {
                    return createGem(type, 1, true);
                }
            }
        }
        return null;
    }

    // ---------------------------------------------------------------
    //  Бонусы надетого
    // ---------------------------------------------------------------

    /**
     * Суммарные уровни самоцветов по типам: вставленные в надетую броню и оружие в руке
     * (с множителем силы камней) плюс уровни, выданные пассивками класса и профессий.
     */
    public Map<String, Double> equipped(Player player) {
        Map<String, Double> totals = new TreeMap<>();
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack piece : player.getInventory().getArmorContents()) {
            items.add(piece);
        }
        items.add(player.getInventory().getItemInMainHand());
        PassiveResult passives = passives(player);
        double factor = 1.0 + passives.gemPower();
        for (ItemStack item : items) {
            if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) {
                continue;
            }
            for (Socketed socketed : socketsOf(item)) {
                totals.merge(socketed.type(), socketed.level() * factor, Double::sum);
            }
        }
        for (Map.Entry<String, Double> grant : passives.grants().entrySet()) {
            totals.merge(grant.getKey(), grant.getValue(), Double::sum);
        }
        return totals;
    }

    /** Сила эффекта: сумма (уровень * value) всех камней с таким эффектом. */
    public double power(Player player, Effect effect) {
        double sum = 0.0;
        for (Map.Entry<String, Double> entry : equipped(player).entrySet()) {
            GemType type = types.get(entry.getKey());
            if (type != null && type.effect() == effect) {
                sum += entry.getValue() * type.value();
            }
        }
        return sum;
    }

    public int getIgniteTicks() {
        return igniteTicks;
    }

    public double getCritBonus() {
        return critBonus;
    }

    public double getBlockReduction() {
        return blockReduction;
    }

    public double getExecuteThreshold() {
        return executeThreshold;
    }

    public long getSurvivorCooldownMs() {
        return survivorCooldownMs;
    }

    // ---------------------------------------------------------------
    //  Пассивки класса и профессии (passives.yml)
    // ---------------------------------------------------------------

    private record PassiveEntry(String text, Map<String, Double> grants, double gemPower) {
    }

    public record PassiveResult(Map<String, Double> grants, double gemPower) {
    }

    private final Map<String, Map<String, PassiveEntry>> passiveTable = new HashMap<>();

    private void readPassives() {
        passiveTable.clear();
        File file = new File(plugin.getDataFolder(), "passives.yml");
        if (!file.exists()) {
            plugin.saveResource("passives.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        passivesEnabled = cfg.getBoolean("enabled", true);
        ConfigurationSection root = cfg.getConfigurationSection("passives");
        if (root == null) {
            return;
        }
        for (String classId : root.getKeys(false)) {
            ConfigurationSection byClass = root.getConfigurationSection(classId);
            if (byClass == null) {
                continue;
            }
            Map<String, PassiveEntry> byProfession = new HashMap<>();
            for (String professionId : byClass.getKeys(false)) {
                ConfigurationSection entry = byClass.getConfigurationSection(professionId);
                if (entry == null) {
                    continue;
                }
                Map<String, Double> grants = new HashMap<>();
                ConfigurationSection grantSection = entry.getConfigurationSection("grants");
                if (grantSection != null) {
                    for (String gem : grantSection.getKeys(false)) {
                        if (types.containsKey(gem.toLowerCase(Locale.ROOT))) {
                            grants.put(gem.toLowerCase(Locale.ROOT), grantSection.getDouble(gem));
                        } else {
                            plugin.getLogger().warning("passives.yml: нет самоцвета " + gem);
                        }
                    }
                }
                byProfession.put(professionId.toLowerCase(Locale.ROOT), new PassiveEntry(
                        entry.getString("text", ""), grants, entry.getDouble("gem-power", 0.0)));
            }
            passiveTable.put(classId.toLowerCase(Locale.ROOT), byProfession);
        }
    }

    /** Пассивки игрока: активный класс + известные профессии. Уровень профессии умножает награду. */
    public PassiveResult passives(Player player) {
        Map<String, Double> grants = new HashMap<>();
        double gemPower = 0.0;
        if (!passivesEnabled || plugin.getClasses() == null || plugin.getProfessions() == null) {
            return new PassiveResult(grants, 0.0);
        }
        var active = plugin.getClasses().activeClass(player.getUniqueId());
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        if (active == null || data == null) {
            return new PassiveResult(grants, 0.0);
        }
        Map<String, PassiveEntry> byProfession = passiveTable.get(active.getId());
        if (byProfession == null) {
            return new PassiveResult(grants, 0.0);
        }
        for (Profession profession : data.professions()) {
            PassiveEntry entry = byProfession.get(profession.getId());
            PlayerProfessions.Progress progress = data.get(profession);
            if (entry == null || progress == null) {
                continue;
            }
            int level = progress.getLevel();
            for (Map.Entry<String, Double> grant : entry.grants().entrySet()) {
                grants.merge(grant.getKey(), Math.floor(level * grant.getValue() * 100.0) / 100.0, Double::sum);
            }
            gemPower += entry.gemPower() * level;
        }
        return new PassiveResult(grants, gemPower);
    }

    /** Показывает игроку его пассивки. */
    public void showPassives(Player player) {
        var active = plugin.getClasses() == null ? null : plugin.getClasses().activeClass(player.getUniqueId());
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        if (active == null || data == null || data.count() == 0) {
            say(player, "gems.passive-none");
            return;
        }
        say(player, "gems.passive-head", Map.of(
                "class", plugin.getClasses().displayName(active)));
        Map<String, PassiveEntry> byProfession = passiveTable.getOrDefault(active.getId(), Map.of());
        for (Profession profession : data.professions()) {
            PassiveEntry entry = byProfession.get(profession.getId());
            PlayerProfessions.Progress progress = data.get(profession);
            if (entry == null || progress == null) {
                continue;
            }
            say(player, "gems.passive-line", Map.of(
                    "profession", plugin.getProfessions().displayName(profession),
                    "level", String.valueOf(progress.getLevel()),
                    "text", entry.text()));
        }
    }

    // ---------------------------------------------------------------
    //  Периодические эффекты и характеристики
    // ---------------------------------------------------------------

    private int tickCounter;

    private void tick() {
        tickCounter++;
        boolean aura = tickCounter % 10 == 0; // раз в 5 секунд (тик каждые 10 игровых тиков = 0.5 с)
        for (Player player : Bukkit.getOnlinePlayers()) {
            apply(player);
            if (power(player, Effect.NIGHT_VISION) > 0) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 260, 0, false, false, true));
            }
            if (aura) {
                double heal = power(player, Effect.AURA_HEAL);
                if (heal > 0 && !player.isDead()) {
                    for (Player target : plugin.getParties().shareTargets(player)) {
                        AttributeInstance max = target.getAttribute(Attribute.MAX_HEALTH);
                        double limit = max != null ? max.getValue() : 20.0;
                        if (!target.isDead() && target.getHealth() < limit) {
                            target.setHealth(Math.min(limit, target.getHealth() + heal));
                        }
                    }
                }
            }
        }
    }

    public void forget(UUID uuid) {
        signatures.remove(uuid);
    }

    private NamespacedKey modifierKey(GemType type) {
        return new NamespacedKey(plugin, "gem_" + type.id());
    }

    private void clearModifiers(Player player) {
        for (GemType type : types.values()) {
            if (type.attribute() == null) {
                continue;
            }
            AttributeInstance instance = player.getAttribute(type.attribute());
            if (instance == null) {
                continue;
            }
            NamespacedKey key = modifierKey(type);
            for (AttributeModifier modifier : new ArrayList<>(instance.getModifiers())) {
                if (modifier.getKey().equals(key)) {
                    instance.removeModifier(modifier);
                }
            }
        }
    }

    public void apply(Player player) {
        Map<String, Double> totals = equipped(player);
        StringBuilder signature = new StringBuilder();
        for (Map.Entry<String, Double> entry : totals.entrySet()) {
            signature.append(entry.getKey()).append('=').append(String.format(Locale.ROOT, "%.2f", entry.getValue())).append(';');
        }
        if (signature.toString().equals(signatures.get(player.getUniqueId()))) {
            return;
        }
        signatures.put(player.getUniqueId(), signature.toString());
        clearModifiers(player);
        for (Map.Entry<String, Double> entry : totals.entrySet()) {
            GemType type = types.get(entry.getKey());
            if (type == null || type.attribute() == null || entry.getValue() <= 0) {
                continue;
            }
            AttributeInstance instance = player.getAttribute(type.attribute());
            if (instance != null) {
                instance.addModifier(new AttributeModifier(modifierKey(type),
                        type.value() * entry.getValue(), type.operation()));
            }
        }
    }
}
