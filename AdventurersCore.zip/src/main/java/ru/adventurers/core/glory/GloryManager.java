package ru.adventurers.core.glory;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Слава: достижения (статистика игрока), титулы с пассивными бонусами и косметические эффекты
 * (удар, убийство, лечение, аура), которые открываются за достижения и ранг.
 * Настройки: glory.yml, тексты: messages.yml (glory.*). Данные игрока хранятся в его PDC.
 */
public class GloryManager implements Listener {

    public enum Kind {
        HIT("При ударе"), KILL("При убийстве"), HEAL("При лечении"), AURA("Аура");

        public final String title;

        Kind(String title) {
            this.title = title;
        }
    }

    record Title(String id, String name, String desc, String unlock, Map<String, Double> bonus) {
    }

    record Achievement(String id, String name, String desc, String stat, long target, long coins) {
    }

    record Effect(String id, String name, Kind kind, Particle particle, Color color, int count, double spread, String unlock) {
    }

    private static final class State {
        final Map<String, Long> stats = new HashMap<>();
        final Set<String> done = new HashSet<>();
        String title = "";
        final Map<Kind, String> fx = new EnumMap<>(Kind.class);
    }

    private enum View { MAIN, TITLES, ACH, FX }

    private static final class Menu implements InventoryHolder {
        final View view;
        final int page;
        final Map<Integer, String> ids = new HashMap<>();

        Menu(View view, int page) {
            this.view = view;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final TextDecoration NO_ITALIC = TextDecoration.ITALIC;

    private final AdventurersCore plugin;
    private final NamespacedKey statsKey;
    private final NamespacedKey doneKey;
    private final NamespacedKey titleKey;
    private final NamespacedKey fxKey;
    private final Map<UUID, State> states = new HashMap<>();
    private final Map<String, Title> titles = new LinkedHashMap<>();
    private final List<Achievement> achievements = new ArrayList<>();
    private final Map<String, Effect> effects = new LinkedHashMap<>();
    private final Set<String> bonusAttributes = new HashSet<>();
    private boolean enabled = true;
    private int auraTicks = 10;

    public GloryManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.statsKey = new NamespacedKey(plugin, "glory_stats");
        this.doneKey = new NamespacedKey(plugin, "glory_done");
        this.titleKey = new NamespacedKey(plugin, "glory_title");
        this.fxKey = new NamespacedKey(plugin, "glory_fx");
    }

    // ---------------------------------------------------------------
    //  Настройки
    // ---------------------------------------------------------------

    public void init() {
        reload();
        Bukkit.getScheduler().runTaskTimer(plugin, this::auraTick, 40L, 10L);
        for (Player player : Bukkit.getOnlinePlayers()) {
            applyBonus(player);
        }
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "glory.yml");
        if (!file.exists()) {
            plugin.saveResource("glory.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        titles.clear();
        achievements.clear();
        effects.clear();
        bonusAttributes.clear();
        ConfigurationSection ts = cfg.getConfigurationSection("titles");
        if (ts != null) {
            for (String key : ts.getKeys(false)) {
                ConfigurationSection t = ts.getConfigurationSection(key);
                if (t == null) {
                    continue;
                }
                Map<String, Double> bonus = new LinkedHashMap<>();
                ConfigurationSection b = t.getConfigurationSection("bonus");
                if (b != null) {
                    for (String attribute : b.getKeys(false)) {
                        bonus.put(attribute.toLowerCase(Locale.ROOT), b.getDouble(attribute));
                        bonusAttributes.add(attribute.toLowerCase(Locale.ROOT));
                    }
                }
                titles.put(key, new Title(key, t.getString("name", key), t.getString("desc", ""),
                        t.getString("unlock", "free"), bonus));
            }
        }
        for (Map<?, ?> map : cfg.getMapList("achievements")) {
            String id = String.valueOf(map.get("id"));
            achievements.add(new Achievement(id, String.valueOf(map.get("name")),
                    map.get("desc") == null ? "" : String.valueOf(map.get("desc")),
                    String.valueOf(map.get("stat")).toUpperCase(Locale.ROOT),
                    map.get("target") instanceof Number n ? n.longValue() : 1,
                    map.get("coins") instanceof Number n ? n.longValue() : 0));
        }
        ConfigurationSection es = cfg.getConfigurationSection("effects");
        if (es != null) {
            for (String key : es.getKeys(false)) {
                ConfigurationSection e = es.getConfigurationSection(key);
                if (e == null) {
                    continue;
                }
                Kind kind;
                Particle particle;
                try {
                    kind = Kind.valueOf(e.getString("kind", "HIT").toUpperCase(Locale.ROOT));
                    particle = Particle.valueOf(e.getString("particle", "END_ROD").toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException exception) {
                    plugin.getLogger().warning("glory.yml: bad effect " + key);
                    continue;
                }
                Color color = null;
                String hex = e.getString("color");
                if (hex != null && hex.matches("#[0-9a-fA-F]{6}")) {
                    color = Color.fromRGB(Integer.parseInt(hex.substring(1), 16));
                }
                effects.put(key, new Effect(key, e.getString("name", key), kind, particle, color,
                        Math.max(1, e.getInt("count", 6)), e.getDouble("spread", 0.3), e.getString("unlock", "free")));
            }
        }
        auraTicks = Math.max(5, cfg.getInt("aura-interval-ticks", 10));
    }

    public boolean isEnabled() {
        return enabled;
    }

    // ---------------------------------------------------------------
    //  Состояние игрока (PDC)
    // ---------------------------------------------------------------

    private State state(Player player) {
        return states.computeIfAbsent(player.getUniqueId(), id -> load(player));
    }

    private State load(Player player) {
        State state = new State();
        var pdc = player.getPersistentDataContainer();
        String stats = pdc.get(statsKey, PersistentDataType.STRING);
        if (stats != null && !stats.isEmpty()) {
            for (String part : stats.split(";")) {
                String[] kv = part.split("=");
                if (kv.length == 2) {
                    try {
                        state.stats.put(kv[0], Long.parseLong(kv[1]));
                    } catch (NumberFormatException ignored) {
                        // повреждённая запись пропускается
                    }
                }
            }
        }
        String done = pdc.get(doneKey, PersistentDataType.STRING);
        if (done != null && !done.isEmpty()) {
            state.done.addAll(List.of(done.split(",")));
        }
        state.title = pdc.getOrDefault(titleKey, PersistentDataType.STRING, "");
        String fx = pdc.get(fxKey, PersistentDataType.STRING);
        if (fx != null && !fx.isEmpty()) {
            for (String part : fx.split(";")) {
                String[] kv = part.split("=");
                if (kv.length == 2) {
                    try {
                        state.fx.put(Kind.valueOf(kv[0]), kv[1]);
                    } catch (IllegalArgumentException ignored) {
                        // старый тип эффекта
                    }
                }
            }
        }
        return state;
    }

    private void save(Player player, State state) {
        var pdc = player.getPersistentDataContainer();
        StringBuilder stats = new StringBuilder();
        state.stats.forEach((k, v) -> stats.append(stats.length() > 0 ? ";" : "").append(k).append('=').append(v));
        pdc.set(statsKey, PersistentDataType.STRING, stats.toString());
        pdc.set(doneKey, PersistentDataType.STRING, String.join(",", state.done));
        pdc.set(titleKey, PersistentDataType.STRING, state.title);
        StringBuilder fx = new StringBuilder();
        state.fx.forEach((k, v) -> fx.append(fx.length() > 0 ? ";" : "").append(k.name()).append('=').append(v));
        pdc.set(fxKey, PersistentDataType.STRING, fx.toString());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!enabled) {
            return;
        }
        Player player = event.getPlayer();
        states.remove(player.getUniqueId());
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                applyBonus(player);
                check(player, null);
            }
        }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        states.remove(event.getPlayer().getUniqueId());
    }

    // ---------------------------------------------------------------
    //  Статистика и достижения
    // ---------------------------------------------------------------

    public long stat(Player player, String stat) {
        if (stat.equals("RANK")) {
            PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
            return profile == null ? 0 : profile.getRank().ordinal() + 1;
        }
        return state(player).stats.getOrDefault(stat, 0L);
    }

    /** Увеличивает счётчик (KILLS, QUESTS, DUNGEONS, HEROICS, RAIDS, HEALED, DEPOSITED) и проверяет достижения. */
    public void add(Player player, String stat, long delta) {
        if (!enabled || delta <= 0) {
            return;
        }
        State state = state(player);
        state.stats.merge(stat, delta, Long::sum);
        save(player, state);
        check(player, stat);
    }

    public void setStat(Player player, String stat, long value) {
        State state = state(player);
        state.stats.put(stat.toUpperCase(Locale.ROOT), Math.max(0, value));
        save(player, state);
        check(player, stat.toUpperCase(Locale.ROOT));
    }

    /** Проверка достижений (stat = null: все). Вызывается и при повышении ранга. */
    public void check(Player player, String stat) {
        if (!enabled) {
            return;
        }
        State state = state(player);
        boolean changed = false;
        for (Achievement ach : achievements) {
            if (state.done.contains(ach.id()) || stat != null && !ach.stat().equals(stat) && !ach.stat().equals("RANK")) {
                continue;
            }
            if (stat(player, ach.stat()) >= ach.target()) {
                state.done.add(ach.id());
                changed = true;
                reward(player, ach);
            }
        }
        if (changed) {
            save(player, state);
            applyBonus(player);
        }
    }

    private void reward(Player player, Achievement ach) {
        if (ach.coins() > 0 && plugin.getEconomy() != null) {
            plugin.getEconomy().give(player, ach.coins());
        }
        List<String> unlocked = new ArrayList<>();
        titles.values().stream().filter(t -> t.unlock().equals("ach:" + ach.id()))
                .forEach(t -> unlocked.add("титул " + plain(t.name())));
        effects.values().stream().filter(e -> e.unlock().equals("ach:" + ach.id()))
                .forEach(e -> unlocked.add("эффект " + plain(e.name())));
        plugin.getMessages().send(player, "glory.achievement", Map.of("name", ach.name(), "desc", ach.desc(),
                "coins", ach.coins() > 0 && plugin.getEconomy() != null ? plugin.getEconomy().format(ach.coins()) : "-",
                "unlocked", unlocked.isEmpty() ? "-" : String.join(", ", unlocked)));
        player.sendActionBar(Hud.legacy("&6Достижение: &f" + ach.name()));
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.2f);
    }

    private String plain(String ampersand) {
        return plugin.getMessages().stripColors(ampersand);
    }

    // ---------------------------------------------------------------
    //  Титулы и бонусы
    // ---------------------------------------------------------------

    public boolean unlocked(Player player, String spec) {
        if (spec == null || spec.equals("free")) {
            return true;
        }
        if (spec.startsWith("rank:")) {
            Rank need = Rank.fromInput(spec.substring(5));
            PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
            return need != null && profile != null && profile.getRank().isAtLeast(need);
        }
        if (spec.startsWith("ach:")) {
            return state(player).done.contains(spec.substring(4));
        }
        return false;
    }

    /** Название активного титула (в формате с &), пусто если не выбран. */
    public String titleName(Player player) {
        if (!enabled) {
            return "";
        }
        Title title = titles.get(state(player).title);
        return title != null && unlocked(player, title.unlock()) ? title.name() : "";
    }

    public int doneCount(Player player) {
        return state(player).done.size();
    }

    public int totalCount() {
        return achievements.size();
    }

    private Attribute attribute(String name) {
        return Registry.ATTRIBUTE.get(NamespacedKey.minecraft(name));
    }

    /** Снимает старые и накладывает бонусы выбранного титула. */
    public void applyBonus(Player player) {
        for (String name : bonusAttributes) {
            Attribute attribute = attribute(name);
            AttributeInstance instance = attribute == null ? null : player.getAttribute(attribute);
            if (instance == null) {
                continue;
            }
            NamespacedKey key = new NamespacedKey(plugin, "glory_" + name);
            for (AttributeModifier modifier : new ArrayList<>(instance.getModifiers())) {
                if (modifier.getKey().equals(key)) {
                    instance.removeModifier(modifier);
                }
            }
        }
        if (!enabled) {
            return;
        }
        Title title = titles.get(state(player).title);
        if (title == null || !unlocked(player, title.unlock())) {
            return;
        }
        title.bonus().forEach((name, amount) -> {
            Attribute attribute = attribute(name);
            AttributeInstance instance = attribute == null ? null : player.getAttribute(attribute);
            if (instance != null && amount != 0) {
                instance.addTransientModifier(new AttributeModifier(new NamespacedKey(plugin, "glory_" + name),
                        amount, AttributeModifier.Operation.ADD_NUMBER));
            }
        });
    }

    private List<String> bonusLore(Title title) {
        List<String> lore = new ArrayList<>();
        title.bonus().forEach((name, amount) -> lore.add("&7" + bonusName(name) + ": &a+" + trim(amount)));
        if (lore.isEmpty()) {
            lore.add("&8Без бонусов");
        }
        return lore;
    }

    private static String trim(double value) {
        return value == Math.floor(value) ? String.valueOf((long) value)
                : String.format(Locale.ROOT, "%.3f", value).replaceAll("0+$", "");
    }

    private static String bonusName(String attribute) {
        return switch (attribute) {
            case "max_health" -> "Здоровье";
            case "attack_damage" -> "Урон";
            case "armor" -> "Броня";
            case "movement_speed" -> "Скорость";
            case "luck" -> "Удача";
            case "knockback_resistance" -> "Стойкость к отбрасыванию";
            case "armor_toughness" -> "Твёрдость брони";
            default -> attribute;
        };
    }

    // ---------------------------------------------------------------
    //  Эффекты
    // ---------------------------------------------------------------

    private Effect active(Player player, Kind kind) {
        if (!enabled) {
            return null;
        }
        Effect effect = effects.get(state(player).fx.get(kind));
        return effect != null && effect.kind() == kind && unlocked(player, effect.unlock()) ? effect : null;
    }

    private void play(Effect effect, Location at, int multiplier) {
        if (at.getWorld() == null) {
            return;
        }
        int count = effect.count() * multiplier;
        double spread = effect.spread();
        if (effect.particle() == Particle.DUST) {
            Particle.DustOptions options = new Particle.DustOptions(
                    effect.color() == null ? Color.WHITE : effect.color(), 1.2f);
            at.getWorld().spawnParticle(Particle.DUST, at, count, spread, spread, spread, 0, options);
        } else {
            at.getWorld().spawnParticle(effect.particle(), at, count, spread, spread, spread, 0.01);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && event.getEntity() instanceof LivingEntity target) {
            Effect effect = active(player, Kind.HIT);
            if (effect != null) {
                play(effect, target.getLocation().add(0, target.getHeight() * 0.6, 0), 1);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        Entity dead = event.getEntity();
        if (dead instanceof Player || dead instanceof org.bukkit.entity.ArmorStand) {
            return;
        }
        Player killer = dead.getKiller();
        if (killer == null) {
            return;
        }
        Effect effect = active(killer, Kind.KILL);
        if (effect != null) {
            play(effect, dead.getLocation().add(0, dead.getHeight() / 2, 0), 3);
        }
    }

    /** Вызывает лекарь после исцеления: эффект и счётчик HEALED. */
    public void onHeal(Player healer, Player target, double healed) {
        if (!enabled) {
            return;
        }
        Effect effect = active(healer, Kind.HEAL);
        if (effect != null) {
            play(effect, target.getLocation().add(0, 1.2, 0), 2);
        }
        if (healed >= 1) {
            add(healer, "HEALED", (long) healed);
        }
    }

    private void auraTick() {
        if (!enabled) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.isDead() || player.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
                continue;
            }
            Effect effect = active(player, Kind.AURA);
            if (effect != null) {
                double angle = (System.currentTimeMillis() / 150.0) % (Math.PI * 2);
                Location at = player.getLocation().add(Math.cos(angle) * 0.7, 0.2 + (Math.sin(angle * 2) + 1) * 0.5,
                        Math.sin(angle) * 0.7);
                play(effect, at, 1);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Меню
    // ---------------------------------------------------------------

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Hud.legacy(name).decoration(NO_ITALIC, false));
        List<Component> lines = new ArrayList<>();
        lore.forEach(line -> lines.add(Hud.legacy(line).decoration(NO_ITALIC, false)));
        meta.lore(lines);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        stack.setItemMeta(meta);
        return stack;
    }

    private void filler(Inventory inventory) {
        ItemStack pane = item(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, pane);
        }
    }

    public void open(Player player) {
        Menu menu = new Menu(View.MAIN, 0);
        Inventory inventory = Bukkit.createInventory(menu, 27, Hud.legacy("&8Слава"));
        filler(inventory);
        State state = state(player);
        String title = titleName(player);
        inventory.setItem(4, item(Material.NETHER_STAR, "&6Ваша слава", List.of(
                "&7Титул: " + (title.isEmpty() ? "&8не выбран" : title),
                "&7Достижений: &f" + state.done.size() + "&7/&f" + achievements.size(),
                "&7Убито существ: &f" + stat(player, "KILLS"),
                "&7Заданий сдано: &f" + stat(player, "QUESTS"),
                "&7Подземелий пройдено: &f" + stat(player, "DUNGEONS"))));
        inventory.setItem(11, item(Material.NAME_TAG, "&eТитулы", List.of("&7Титул виден в чате и даёт", "&7небольшой пассивный бонус.", "", "&eЛКМ &7- открыть")));
        inventory.setItem(13, item(Material.WRITABLE_BOOK, "&bДостижения", List.of("&7Прогресс и награды.", "", "&eЛКМ &7- открыть")));
        inventory.setItem(15, item(Material.FIREWORK_STAR, "&dЭффекты", List.of("&7Частицы при ударе, убийстве,", "&7лечении и аура вокруг вас.", "", "&eЛКМ &7- открыть")));
        player.openInventory(inventory);
    }

    private void openTitles(Player player) {
        Menu menu = new Menu(View.TITLES, 0);
        Inventory inventory = Bukkit.createInventory(menu, 54, Hud.legacy("&8Титулы"));
        filler(inventory);
        State state = state(player);
        int slot = 0;
        for (Title title : titles.values()) {
            if (slot >= 45) {
                break;
            }
            boolean open = unlocked(player, title.unlock());
            boolean current = title.id().equals(state.title);
            List<String> lore = new ArrayList<>();
            if (!title.desc().isEmpty()) {
                lore.add("&7" + title.desc());
            }
            lore.addAll(bonusLore(title));
            lore.add("");
            lore.add(current ? "&aВыбран. &8ЛКМ - снять" : open ? "&eЛКМ &7- выбрать" : "&cЗакрыт: " + unlockText(title.unlock()));
            inventory.setItem(slot, item(open ? (current ? Material.ENCHANTED_BOOK : Material.NAME_TAG) : Material.BARRIER,
                    open ? title.name() : "&8" + plain(title.name()), lore));
            menu.ids.put(slot, title.id());
            slot++;
        }
        inventory.setItem(45, item(Material.ARROW, "&7Назад", List.of()));
        player.openInventory(inventory);
    }

    private String unlockText(String spec) {
        if (spec.startsWith("rank:")) {
            return "ранг " + spec.substring(5);
        }
        if (spec.startsWith("ach:")) {
            String id = spec.substring(4);
            return achievements.stream().filter(a -> a.id().equals(id)).findFirst()
                    .map(a -> "достижение «" + a.name() + "»").orElse("достижение");
        }
        return "?";
    }

    private void openAchievements(Player player, int page) {
        Menu menu = new Menu(View.ACH, page);
        Inventory inventory = Bukkit.createInventory(menu, 54, Hud.legacy("&8Достижения (" + (page + 1) + ")"));
        filler(inventory);
        State state = state(player);
        int from = page * 45;
        for (int i = from; i < Math.min(achievements.size(), from + 45); i++) {
            Achievement ach = achievements.get(i);
            boolean done = state.done.contains(ach.id());
            long value = Math.min(stat(player, ach.stat()), ach.target());
            List<String> lore = new ArrayList<>();
            lore.add("&7" + ach.desc());
            int filled = (int) (value * 12 / ach.target());
            lore.add((done ? "&a" : "&e") + "▌".repeat(filled) + "&8" + "▌".repeat(12 - filled)
                    + " &f" + value + "&7/&f" + ach.target());
            if (ach.coins() > 0 && plugin.getEconomy() != null) {
                lore.add("&7Награда: " + plugin.getEconomy().format(ach.coins()));
            }
            final int index = i;
            titles.values().stream().filter(t -> t.unlock().equals("ach:" + ach.id()))
                    .forEach(t -> lore.add("&7Открывает титул: " + t.name()));
            effects.values().stream().filter(e -> e.unlock().equals("ach:" + ach.id()))
                    .forEach(e -> lore.add("&7Открывает эффект: " + e.name()));
            inventory.setItem(i - from, item(done ? Material.LIME_DYE : Material.GRAY_DYE,
                    (done ? "&a" : "&7") + ach.name(), lore));
        }
        inventory.setItem(45, item(Material.ARROW, "&7Назад", List.of()));
        if (page > 0) {
            inventory.setItem(48, item(Material.PAPER, "&7Предыдущая страница", List.of()));
        }
        if (from + 45 < achievements.size()) {
            inventory.setItem(50, item(Material.PAPER, "&7Следующая страница", List.of()));
        }
        player.openInventory(inventory);
    }

    private void openEffects(Player player) {
        Menu menu = new Menu(View.FX, 0);
        Inventory inventory = Bukkit.createInventory(menu, 54, Hud.legacy("&8Эффекты"));
        filler(inventory);
        State state = state(player);
        int slot = 0;
        for (Kind kind : Kind.values()) {
            for (Effect effect : effects.values()) {
                if (effect.kind() != kind || slot >= 45) {
                    continue;
                }
                boolean open = unlocked(player, effect.unlock());
                boolean current = effect.id().equals(state.fx.get(kind));
                inventory.setItem(slot, item(open ? (current ? Material.GLOWSTONE_DUST : Material.GUNPOWDER) : Material.BARRIER,
                        open ? effect.name() : "&8" + plain(effect.name()), List.of(
                                "&7Тип: &f" + kind.title,
                                "",
                                current ? "&aВключён. &8ЛКМ - выключить"
                                        : open ? "&eЛКМ &7- включить" : "&cЗакрыт: " + unlockText(effect.unlock()))));
                menu.ids.put(slot, effect.id());
                slot++;
            }
        }
        inventory.setItem(45, item(Material.ARROW, "&7Назад", List.of()));
        inventory.setItem(49, item(Material.BARRIER, "&cВыключить все эффекты", List.of("&eЛКМ")));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Menu menu) || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        State state = state(player);
        switch (menu.view) {
            case MAIN -> {
                if (slot == 11) {
                    openTitles(player);
                } else if (slot == 13) {
                    openAchievements(player, 0);
                } else if (slot == 15) {
                    openEffects(player);
                }
            }
            case TITLES -> {
                if (slot == 45) {
                    open(player);
                    return;
                }
                Title title = titles.get(menu.ids.get(slot));
                if (title == null) {
                    return;
                }
                if (!unlocked(player, title.unlock())) {
                    plugin.getMessages().send(player, "glory.locked");
                    return;
                }
                state.title = title.id().equals(state.title) ? "" : title.id();
                save(player, state);
                applyBonus(player);
                openTitles(player);
            }
            case ACH -> {
                if (slot == 45) {
                    open(player);
                } else if (slot == 48 && menu.page > 0) {
                    openAchievements(player, menu.page - 1);
                } else if (slot == 50 && (menu.page + 1) * 45 < achievements.size()) {
                    openAchievements(player, menu.page + 1);
                }
            }
            case FX -> {
                if (slot == 45) {
                    open(player);
                    return;
                }
                if (slot == 49) {
                    state.fx.clear();
                    save(player, state);
                    openEffects(player);
                    return;
                }
                Effect effect = effects.get(menu.ids.get(slot));
                if (effect == null) {
                    return;
                }
                if (!unlocked(player, effect.unlock())) {
                    plugin.getMessages().send(player, "glory.locked");
                    return;
                }
                if (effect.id().equals(state.fx.get(effect.kind()))) {
                    state.fx.remove(effect.kind());
                } else {
                    state.fx.put(effect.kind(), effect.id());
                }
                save(player, state);
                openEffects(player);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Админ: /ag admin glory ...
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        String action = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
        Player target = args.length > 3 ? Bukkit.getPlayerExact(args[3]) : null;
        switch (action) {
            case "stat" -> {
                if (target == null || args.length < 6) {
                    sender.sendMessage(Hud.legacy("&c/ag admin glory stat <ник> <СТАТ> <значение>  &7(KILLS, QUESTS, DUNGEONS, HEROICS, RAIDS, HEALED, DEPOSITED)"));
                    return;
                }
                try {
                    setStat(target, args[4], Long.parseLong(args[5]));
                    sender.sendMessage(Hud.legacy("&aГотово: &f" + args[4].toUpperCase(Locale.ROOT) + " = " + args[5]));
                } catch (NumberFormatException exception) {
                    sender.sendMessage(Hud.legacy("&cЧисло введено неверно."));
                }
            }
            case "reset" -> {
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin glory reset <ник>"));
                    return;
                }
                states.put(target.getUniqueId(), new State());
                save(target, states.get(target.getUniqueId()));
                applyBonus(target);
                sender.sendMessage(Hud.legacy("&aСлава игрока сброшена."));
            }
            case "info" -> {
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin glory info <ник>"));
                    return;
                }
                State state = state(target);
                sender.sendMessage(Hud.legacy("&6Слава &f" + target.getName() + "&7: достижений " + state.done.size() + "/"
                        + achievements.size() + ", титул " + (state.title.isEmpty() ? "-" : state.title)));
                state.stats.forEach((k, v) -> sender.sendMessage(Hud.legacy("&8» &7" + k + ": &f" + v)));
            }
            case "reload" -> {
                reload();
                sender.sendMessage(Hud.legacy("&aНастройки славы перечитаны."));
            }
            default -> sender.sendMessage(Hud.legacy("&7/ag admin glory stat <ник> <СТАТ> <знач>|reset <ник>|info <ник>|reload"));
        }
    }
}
