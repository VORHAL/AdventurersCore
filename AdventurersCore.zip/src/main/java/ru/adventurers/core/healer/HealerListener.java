package ru.adventurers.core.healer;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerExpChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

/** Управление жезлом Лекаря и защита настоящего опыта, пока на полоске показана мана. */
public class HealerListener implements Listener {

    private final HealerManager healer;

    public HealerListener(HealerManager healer) {
        this.healer = healer;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND || event.getAction() == Action.PHYSICAL) {
            return;
        }
        Player player = event.getPlayer();
        if (!healer.isStaff(player.getInventory().getItemInMainHand())) {
            return;
        }
        // Жезл не используется для блоков и предметов.
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        if (player.getGameMode() == GameMode.SPECTATOR) {
            return;
        }
        if (!healer.canUse(player)) {
            healer.warn(player);
            return;
        }
        switch (event.getAction()) {
            case RIGHT_CLICK_AIR, RIGHT_CLICK_BLOCK -> {
                if (player.isSneaking()) {
                    healer.pulse(player);
                } else {
                    healer.healTarget(player);
                }
            }
            case LEFT_CLICK_AIR, LEFT_CLICK_BLOCK -> healer.bolt(player);
            default -> {
            }
        }
    }

    // Подбор опыта: сначала возвращаем настоящий опыт, потом ваниль добавит полученный.
    @EventHandler(priority = EventPriority.LOWEST)
    public void onExp(PlayerExpChangeEvent event) {
        if (healer.inManaMode(event.getPlayer())) {
            healer.exitMode(event.getPlayer());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (healer.inManaMode(player)) {
            healer.exitMode(player);
            event.setDroppedExp(Math.min(player.getLevel() * 7, 100));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        healer.restoreAfterCrash(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onQuit(PlayerQuitEvent event) {
        healer.exitMode(event.getPlayer());
        healer.forget(event.getPlayer().getUniqueId());
    }
}
