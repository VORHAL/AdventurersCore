package ru.adventurers.core.healer;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.gem.GemManager;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.survival.SurvivalManager;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Лекарь: жезл (ПКМ лечит игрока, Shift+ПКМ импульс группе, ЛКМ магический снаряд с лечением союзника)
 * и мана на полоске опыта. Настройки: healer.yml. Только основной поток.
 */
public class HealerManager {

    private static final double[] DEFAULT_MANA = {40, 50, 60, 80, 100, 130, 160, 200};
    private static final double[] DEFAULT_HEAL = {3, 4, 5, 6, 8, 10, 12, 14};
    private static final double[] DEFAULT_BOLT = {2, 3, 4, 5, 6, 8, 10, 12};

    private final AdventurersCore plugin;
    private final NamespacedKey staffKey;
    private final NamespacedKey savedLevelKey;
    private final NamespacedKey savedExpKey;

    private final Map<UUID, Double> mana = new HashMap<>();
    private final Map<UUID, Long> healReady = new HashMap<>();
    private final Map<UUID, Long> pulseReady = new HashMap<>();
    private final Map<UUID, Long> boltReady = new HashMap<>();
    private final Map<UUID, Long> lastHint = new HashMap<>();
    private final Set<UUID> manaMode = new HashSet<>();

    private boolean enabled = true;
    private double universalFactor = 0.6;
    private double[] manaMax = DEFAULT_MANA;
    private double manaRegen = 2.0;
    private double manaRegenPerRank = 0.15;
    private double[] healAmount = DEFAULT_HEAL;
    private double healCost = 10;
    private long healCooldown = 3000;
    private double healRange = 12;
    private double selfFactor = 0.6;
    private double pulseCost = 30;
    private long pulseCooldown = 15000;
    private double pulseRadius = 10;
    private double pulseFactor = 0.7;
    private double[] boltDamage = DEFAULT_BOLT;
    private double boltCost = 4;
    private long boltCooldown = 800;
    private double boltRange = 14;
    private double lifelink = 1.0;
    private double lifelinkRadius = 10;
    private BukkitTask task;

    public HealerManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.staffKey = new NamespacedKey(plugin, "healer_staff");
        this.savedLevelKey = new NamespacedKey(plugin, "mana_saved_level");
        this.savedExpKey = new NamespacedKey(plugin, "mana_saved_exp");
    }

    public void init() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 5L);
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            exitMode(player);
        }
    }

    private static double[] list(List<?> raw, double[] fallback) {
        if (raw == null || raw.size() < 8) {
            return fallback;
        }
        double[] result = new double[8];
        for (int i = 0; i < 8; i++) {
            result[i] = raw.get(i) instanceof Number number ? number.doubleValue() : fallback[i];
        }
        return result;
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "healer.yml");
        if (!file.exists()) {
            plugin.saveResource("healer.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        universalFactor = cfg.getDouble("universal-factor", 0.6);
        manaMax = list(cfg.getList("mana.max"), DEFAULT_MANA);
        manaRegen = cfg.getDouble("mana.regen-per-second", 2.0);
        manaRegenPerRank = cfg.getDouble("mana.regen-per-rank", 0.15);
        healAmount = list(cfg.getList("heal.amount"), DEFAULT_HEAL);
        healCost = cfg.getDouble("heal.mana-cost", 10);
        healCooldown = (long) (cfg.getDouble("heal.cooldown-seconds", 3.0) * 1000);
        healRange = cfg.getDouble("heal.range", 12);
        selfFactor = cfg.getDouble("heal.self-factor", 0.6);
        pulseCost = cfg.getDouble("pulse.mana-cost", 30);
        pulseCooldown = (long) (cfg.getDouble("pulse.cooldown-seconds", 15.0) * 1000);
        pulseRadius = cfg.getDouble("pulse.radius", 10);
        pulseFactor = cfg.getDouble("pulse.factor", 0.7);
        boltDamage = list(cfg.getList("bolt.damage"), DEFAULT_BOLT);
        boltCost = cfg.getDouble("bolt.mana-cost", 4);
        boltCooldown = (long) (cfg.getDouble("bolt.cooldown-seconds", 0.8) * 1000);
        boltRange = cfg.getDouble("bolt.range", 14);
        lifelink = cfg.getDouble("bolt.lifelink", 1.0);
        lifelinkRadius = cfg.getDouble("bolt.lifelink-radius", 10);
    }

    // ---------------------------------------------------------------
    //  Вспомогательное
    // ---------------------------------------------------------------

    /** Подсказка тому, кому жезл не подчиняется. */
    public void warn(Player player) {
        bar(player, "healer.wrong-class", "&cЖезл подчиняется только Лекарю");
    }

    public boolean isEnabled() {
        return enabled;
    }

    /** Сколько миллисекунд осталось до готовности умения (heal, pulse, bolt); 0 если готово. */
    public long remaining(Player player, String skill) {
        Map<UUID, Long> map = switch (skill) {
            case "heal" -> healReady;
            case "pulse" -> pulseReady;
            default -> boltReady;
        };
        Long until = map.get(player.getUniqueId());
        return until == null ? 0 : Math.max(0, until - System.currentTimeMillis());
    }

    public long total(String skill) {
        return switch (skill) {
            case "heal" -> healCooldown;
            case "pulse" -> pulseCooldown;
            default -> boltCooldown;
        };
    }

    public boolean isStaff(ItemStack item) {
        return item != null && item.getType() != Material.AIR && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(staffKey, PersistentDataType.BYTE);
    }

    /** true, если активный класс игрока: Лекарь или Универсал. */
    public boolean canUse(Player player) {
        PlayerClass active = plugin.getClasses().activeClass(player.getUniqueId());
        return active == PlayerClass.HEALER || active == PlayerClass.UNIVERSAL;
    }

    private double factor(Player player) {
        return plugin.getClasses().activeClass(player.getUniqueId()) == PlayerClass.UNIVERSAL ? universalFactor : 1.0;
    }

    private int rankIndex(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? 0 : Math.min(7, profile.getRank().ordinal());
    }

    public double maxMana(Player player) {
        return manaMax[rankIndex(player)] * factor(player);
    }

    public double getMana(Player player) {
        return Math.min(maxMana(player), mana.getOrDefault(player.getUniqueId(), maxMana(player)));
    }

    private double rune(Player player, String stat) {
        return plugin.getRunes() == null ? 0 : plugin.getRunes().bonus(player, stat);
    }

    private long cd(Player player, long base) {
        return (long) (base * Math.max(0.3, 1.0 - rune(player, "heal_cooldown")));
    }

    private double healPower(Player player) {
        return 1.0 + plugin.getGems().power(player, GemManager.Effect.HEAL_POWER) + rune(player, "heal_power");
    }

    private void bar(Player player, String key, String fallback, Map<String, String> values) {
        String text = plugin.getMessages().text(key, fallback);
        for (Map.Entry<String, String> entry : values.entrySet()) {
            text = text.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        plugin.getSkillHud().flash(player, Hud.legacy(text));
    }

    private void bar(Player player, String key, String fallback) {
        bar(player, key, fallback, Map.of());
    }

    private boolean ready(Map<UUID, Long> map, Player player, long cooldown) {
        long now = System.currentTimeMillis();
        Long until = map.get(player.getUniqueId());
        return until == null || now >= until;
    }

    private void start(Map<UUID, Long> map, Player player, long cooldown) {
        map.put(player.getUniqueId(), System.currentTimeMillis() + cooldown);
    }

    private boolean spend(Player player, double rawCost) {
        double cost = rawCost * Math.max(0.4, 1.0 - rune(player, "mana_cost"));
        double current = getMana(player);
        if (current < cost) {
            long now = System.currentTimeMillis();
            Long last = lastHint.get(player.getUniqueId());
            if (last == null || now - last > 1000) {
                lastHint.put(player.getUniqueId(), now);
                bar(player, "healer.no-mana", "&cНе хватает маны");
            }
            return false;
        }
        mana.put(player.getUniqueId(), current - cost);
        return true;
    }

    private double maxHealth(LivingEntity entity) {
        AttributeInstance max = entity.getAttribute(Attribute.MAX_HEALTH);
        return max != null ? max.getValue() : 20.0;
    }

    private double heal(Player target, double amount) {
        double before = target.getHealth();
        target.setHealth(Math.min(maxHealth(target), before + amount));
        return target.getHealth() - before;
    }

    private static String fmt(double value) {
        return String.format(java.util.Locale.ROOT, "%.1f", value);
    }

    private void glory(Player healer, Player target, double healed) {
        if (plugin.getGlory() != null) {
            plugin.getGlory().onHeal(healer, target, healed);
        }
    }

    private void sparkle(Player target) {
        Location at = target.getLocation().add(0, 1.2, 0);
        target.getWorld().spawnParticle(Particle.HEART, at, 4, 0.3, 0.4, 0.3, 0);
        target.getWorld().playSound(at, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f, 1.4f);
    }

    // ---------------------------------------------------------------
    //  Мана и полоска опыта
    // ---------------------------------------------------------------

    private void tick() {
        if (!enabled) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!canUse(player)) {
                if (manaMode.contains(player.getUniqueId())) {
                    exitMode(player);
                }
                continue;
            }
            double max = maxMana(player);
            double regen = (manaRegen + manaRegenPerRank * rankIndex(player)) * 0.25 * (1.0 + rune(player, "mana_regen"));
            double current = Math.min(max, mana.getOrDefault(player.getUniqueId(), max) + regen);
            mana.put(player.getUniqueId(), current);

            if (isStaff(player.getInventory().getItemInMainHand())) {
                enterMode(player);
                player.setLevel((int) current);
                player.setExp((float) Math.max(0.0, Math.min(0.999, current / max)));
            } else if (manaMode.contains(player.getUniqueId())) {
                exitMode(player);
            }
        }
    }

    private void enterMode(Player player) {
        if (manaMode.add(player.getUniqueId())) {
            PersistentDataContainer data = player.getPersistentDataContainer();
            data.set(savedLevelKey, PersistentDataType.INTEGER, player.getLevel());
            data.set(savedExpKey, PersistentDataType.FLOAT, player.getExp());
        }
    }

    /** Возвращает настоящий опыт игрока. Безопасно вызывать сколько угодно раз. */
    public void exitMode(Player player) {
        PersistentDataContainer data = player.getPersistentDataContainer();
        Integer level = data.get(savedLevelKey, PersistentDataType.INTEGER);
        Float exp = data.get(savedExpKey, PersistentDataType.FLOAT);
        if (level != null && exp != null) {
            player.setLevel(level);
            player.setExp(exp);
        }
        data.remove(savedLevelKey);
        data.remove(savedExpKey);
        manaMode.remove(player.getUniqueId());
    }

    public boolean inManaMode(Player player) {
        return manaMode.contains(player.getUniqueId());
    }

    /** После сбоя сервера: если в данных игрока остался сохранённый опыт, возвращаем его. */
    public void restoreAfterCrash(Player player) {
        PersistentDataContainer data = player.getPersistentDataContainer();
        if (data.has(savedLevelKey, PersistentDataType.INTEGER) && !manaMode.contains(player.getUniqueId())) {
            exitMode(player);
        }
    }

    public void forget(UUID uuid) {
        mana.remove(uuid);
        healReady.remove(uuid);
        pulseReady.remove(uuid);
        boltReady.remove(uuid);
        lastHint.remove(uuid);
        manaMode.remove(uuid);
    }

    // ---------------------------------------------------------------
    //  Жезл
    // ---------------------------------------------------------------

    public void giveStaff(Player player) {
        if (!enabled || !canUse(player)) {
            plugin.getMessages().send(player, "healer.staff-denied");
            return;
        }
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        Rank rank = profile == null ? Rank.F : profile.getRank();
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isStaff(contents[i])) {
                player.getInventory().setItem(i, null);
            }
        }
        ItemStack staff = new ItemStack(Material.BLAZE_ROD, 1);
        ItemMeta meta = staff.getItemMeta();
        meta.displayName(Hud.legacy("<gradient:#6df5a0:#3ad6ff>&l✚ Жезл Лекаря</gradient> &8["
                + plugin.getMessages().rankName(rank) + "&8]").decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String line : new String[]{
                "&8Принадлежит Лекарю. Нельзя выбросить.", "",
                "&7ПКМ по игроку &8- &aисцелить",
                "&7Shift + ПКМ &8- &aимпульс группе вокруг",
                "&7ЛКМ &8- &bмагический снаряд &8(лечит раненого союзника)", "",
                "&8Мана видна на полоске опыта."}) {
            lore.add(Hud.legacy(line).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        ru.adventurers.core.hud.PackItems.model(meta, "staff");
        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(staffKey, PersistentDataType.BYTE, (byte) 1);
        data.set(SurvivalManager.rankGearKey(plugin), PersistentDataType.STRING, rank.name());
        staff.setItemMeta(meta);

        Map<Integer, ItemStack> left = player.getInventory().addItem(staff);
        for (ItemStack extra : left.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
        plugin.getMessages().send(player, "healer.staff-given");
    }

    // ---------------------------------------------------------------
    //  Умения
    // ---------------------------------------------------------------

    /** ПКМ: лечит игрока, на которого смотрит Лекарь, или самого себя. */
    public void healTarget(Player player) {
        if (!ready(healReady, player, healCooldown)) {
            return;
        }
        Location eye = player.getEyeLocation();
        RayTraceResult hit = player.getWorld().rayTrace(eye, eye.getDirection(), healRange,
                FluidCollisionMode.NEVER, true, 0.5,
                entity -> entity instanceof Player other && !other.equals(player)
                        && other.getGameMode() != GameMode.SPECTATOR);
        Player target = hit != null && hit.getHitEntity() instanceof Player found ? found : null;
        boolean self = target == null;
        if (self) {
            target = player;
        }
        if (target.getHealth() >= maxHealth(target)) {
            bar(player, "healer.full", "&7Здоровье уже полное");
            return;
        }
        if (!spend(player, healCost)) {
            return;
        }
        start(healReady, player, cd(player, healCooldown));
        double amount = healAmount[rankIndex(player)] * factor(player) * healPower(player) * (self ? selfFactor : 1.0);
        double healed = heal(target, amount);
        sparkle(target);
        glory(player, target, healed);
        if (self) {
            bar(player, "healer.healed-self", "&a+{amount} ❤ себе", Map.of("amount", fmt(healed)));
        } else {
            bar(player, "healer.healed-target", "&a+{amount} ❤ &f{player}",
                    Map.of("amount", fmt(healed), "player", target.getName()));
            bar(target, "healer.healed-you", "&a{player} исцелил тебя: +{amount} ❤",
                    Map.of("amount", fmt(healed), "player", player.getName()));
        }
    }

    /** Shift + ПКМ: лечит Лекаря и группу вокруг. */
    public void pulse(Player player) {
        if (!ready(pulseReady, player, pulseCooldown)) {
            bar(player, "healer.cooldown", "&7Импульс ещё не готов");
            return;
        }
        double radius = pulseRadius * (1.0 + rune(player, "pulse_radius"));
        List<Player> targets = new ArrayList<>();
        for (Player member : plugin.getParties().shareTargets(player)) {
            if (member.getWorld().equals(player.getWorld())
                    && member.getLocation().distanceSquared(player.getLocation()) <= radius * radius
                    && member.getHealth() < maxHealth(member)) {
                targets.add(member);
            }
        }
        if (targets.isEmpty()) {
            bar(player, "healer.nobody", "&7Никому не нужно лечение");
            return;
        }
        if (!spend(player, pulseCost)) {
            return;
        }
        start(pulseReady, player, cd(player, pulseCooldown));
        double amount = healAmount[rankIndex(player)] * factor(player) * healPower(player) * pulseFactor;
        for (Player member : targets) {
            double healed = heal(member, amount);
            sparkle(member);
            glory(player, member, healed);
            if (!member.equals(player)) {
                bar(member, "healer.healed-you", "&a{player} исцелил тебя: +{amount} ❤",
                        Map.of("amount", fmt(healed), "player", player.getName()));
            }
        }
        player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0, 1, 0),
                30, radius / 3, 0.6, radius / 3, 0);
        bar(player, "healer.pulse", "&a✚ Импульс: вылечено {count}", Map.of("count", String.valueOf(targets.size())));
    }

    /** ЛКМ: магический снаряд. Монстр получает урон, самый раненый союзник рядом лечится. */
    public void bolt(Player player) {
        if (!ready(boltReady, player, boltCooldown) || !spend(player, boltCost)) {
            return;
        }
        start(boltReady, player, boltCooldown);
        Location eye = player.getEyeLocation();
        Vector direction = eye.getDirection();
        RayTraceResult hit = player.getWorld().rayTrace(eye, direction, boltRange,
                FluidCollisionMode.NEVER, true, 0.3,
                entity -> entity instanceof LivingEntity && !(entity instanceof Player)
                        && !(entity instanceof ArmorStand));
        double length = hit != null ? hit.getHitPosition().distance(eye.toVector()) : boltRange;
        for (double d = 0.8; d < length; d += 0.7) {
            player.getWorld().spawnParticle(Particle.END_ROD, eye.clone().add(direction.clone().multiply(d)),
                    1, 0, 0, 0, 0);
        }
        player.getWorld().playSound(eye, Sound.ENTITY_EVOKER_CAST_SPELL, 0.6f, 1.6f);

        if (hit != null && hit.getHitEntity() instanceof LivingEntity victim) {
            double damage = boltDamage[rankIndex(player)] * factor(player);
            victim.damage(damage, player);
            victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 8, 0.3, 0.4, 0.3, 0.1);
            lifelink(player);
        }
    }

    private void lifelink(Player player) {
        Player weakest = null;
        double ratio = 1.0;
        for (Player member : plugin.getParties().shareTargets(player)) {
            if (member.getWorld().equals(player.getWorld())
                    && member.getLocation().distanceSquared(player.getLocation()) <= lifelinkRadius * lifelinkRadius) {
                double value = member.getHealth() / maxHealth(member);
                if (value < ratio) {
                    ratio = value;
                    weakest = member;
                }
            }
        }
        if (weakest == null) {
            return;
        }
        double amount = lifelink * (1.0 + rune(player, "bolt_lifelink")) * healPower(player) * factor(player);
        heal(weakest, amount);
        if (!weakest.equals(player)) {
            heal(player, amount / 2.0);
        }
        weakest.getWorld().spawnParticle(Particle.HEART, weakest.getLocation().add(0, 1.4, 0), 1, 0.2, 0.2, 0.2, 0);
    }
}
