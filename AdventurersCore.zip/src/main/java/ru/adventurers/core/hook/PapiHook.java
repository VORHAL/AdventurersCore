package ru.adventurers.core.hook;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profile.ProfileManager;

/**
 * Единственное место, которое знает про PlaceholderAPI.
 * Класс загружается только если PlaceholderAPI установлен.
 */
public final class PapiHook {

    private static AgExpansion expansion;

    private PapiHook() {
    }

    public static void register(AdventurersCore plugin,
                                ProfileManager profiles,
                                MessageManager messages) {
        expansion = new AgExpansion(plugin, profiles, messages);
        expansion.register();
    }

    public static void unregister() {
        if (expansion != null) {
            expansion.unregister();
            expansion = null;
        }
    }

    public static String apply(Player player, String text) {
        return PlaceholderAPI.setPlaceholders(player, text);
    }
}