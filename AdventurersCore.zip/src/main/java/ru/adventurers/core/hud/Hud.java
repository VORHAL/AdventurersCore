package ru.adventurers.core.hud;

import me.clip.placeholderapi.PlaceholderAPI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Общие вспомогательные методы для чата, TAB и панели: цвета &, HEX &#rrggbb и PlaceholderAPI. */
public final class Hud {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .useUnusualXRepeatedCharacterHexFormat()
            .build();

    /**
     * Команда вида /ag prof learn: слова из латинских строчных букв после "/".
     * Аргументы в <скобках>, [скобках] и с заглавными буквами в нажатие не попадают.
     */
    private static final Pattern COMMAND =
            Pattern.compile("(?<![\\p{L}\\p{N}/])/[a-z][a-z0-9_]*(?: [a-z][a-z0-9_+\\-]*)*");

    private static final Pattern GRADIENT = Pattern.compile(
            "<gradient:((?:#[0-9a-fA-F]{6})(?::#[0-9a-fA-F]{6})+)>(.*?)</gradient>", Pattern.DOTALL);

    private Hud() {
    }

    /** Подставляет плейсхолдеры (если PlaceholderAPI есть) и приводит § к &. Строка остаётся текстом. */
    public static String resolve(AdventurersCore plugin, Player player, String text) {
        String result = text == null ? "" : text;
        if (player != null && plugin.isPapiEnabled()) {
            result = PlaceholderAPI.setPlaceholders(player, result);
        }
        return result.replace('§', '&');
    }

    /**
     * Особые метки (работают в TAB, панели, MOTD и т. д.):
     *   {ico:rank|class|prof|coin|quest|group|online|ping|points|bank}  значок из пака (без пака: символ)
     *   {div}                       красивый разделитель (без пака: линия)
     *   {banner}                    официальный логотип крупно (занимает ~6 строк высоты; ниже оставьте пустые строки)
     *   {logo}                      пиксельный логотип CUBE ADVENTURERS (без пака: текст)
     *   {title}текст{/title}        красивый шрифт заголовков (без пака: обычный)
     * Значки и шрифт включаются в frames.yml: pack.glyphs: true (когда пак раздаётся всем).
     */
    private static final Pattern TOKEN = Pattern.compile(
            "\\{ico:([a-z_]+)\\}|\\{logo\\}|\\{banner\\}|\\{div\\}|\\{title\\}(.*?)\\{/title\\}", Pattern.DOTALL);
    private static final net.kyori.adventure.key.Key HUD_FONT = net.kyori.adventure.key.Key.key("adventurers", "hud");
    private static final net.kyori.adventure.key.Key TITLE_FONT = net.kyori.adventure.key.Key.key("adventurers", "title");
    private static final java.util.Map<String, int[]> ICONS = new java.util.LinkedHashMap<>();
    private static final java.util.Map<String, String> ICON_FALLBACK = new java.util.HashMap<>();

    static {
        String[] names = {"rank", "class", "prof", "coin", "quest", "group", "online", "ping", "points", "bank"};
        String[] fallback = {"✦", "⚔", "⚒", "⛁", "✎", "☻", "●", "⇅", "◆", "▣"};
        for (int i = 0; i < names.length; i++) {
            ICONS.put(names[i], new int[]{0xE030 + i});
            ICON_FALLBACK.put(names[i], fallback[i]);
        }
    }

    public static Component legacy(String text) {
        String source = text == null ? "" : text;
        if (!source.contains("{ico:") && !source.contains("{logo}") && !source.contains("{banner}") && !source.contains("{div}") && !source.contains("{title}")) {
            return LEGACY.deserialize(gradients(source));
        }
        Matcher matcher = TOKEN.matcher(source);
        Component result = Component.empty();
        int last = 0;
        boolean pack = PackItems.glyphsEnabled();
        while (matcher.find()) {
            if (matcher.start() > last) {
                result = result.append(LEGACY.deserialize(gradients(source.substring(last, matcher.start()))));
            }
            String token = matcher.group();
            if (token.startsWith("{ico:")) {
                String name = matcher.group(1);
                int[] code = ICONS.get(name);
                if (pack && code != null) {
                    result = result.append(Component.text(String.valueOf((char) code[0])).font(HUD_FONT)
                            .color(net.kyori.adventure.text.format.TextColor.color(0xffffff)));
                } else {
                    result = result.append(Component.text(ICON_FALLBACK.getOrDefault(name, "•"),
                            net.kyori.adventure.text.format.TextColor.color(0xff9a3c)));
                }
            } else if (token.equals("{div}")) {
                result = result.append(pack
                        ? Component.text(String.valueOf((char) 0xE041)).font(HUD_FONT).color(net.kyori.adventure.text.format.TextColor.color(0xffffff))
                        : LEGACY.deserialize(gradients("<gradient:#3a3a3a:#a637c9:#3a3a3a>━━━━━━━━━━━━━━━━</gradient>")));
            } else if (token.equals("{banner}")) {
                if (pack) {
                    result = result.append(Component.text(String.valueOf((char) 0xE042)).font(HUD_FONT)
                            .color(net.kyori.adventure.text.format.TextColor.color(0xffffff)));
                } else {
                    result = result.append(LEGACY.deserialize(gradients("<gradient:#a637c9:#e0b7df:#a637c9>&lCUBE ADVENTURERS</gradient>")));
                }
            } else if (token.equals("{logo}")) {
                if (pack) {
                    result = result.append(Component.text(String.valueOf((char) 0xE040)).font(HUD_FONT)
                            .color(net.kyori.adventure.text.format.TextColor.color(0xffffff)));
                } else {
                    result = result.append(LEGACY.deserialize(gradients("<gradient:#ff7a1a:#ffe278>&lCUBE ADVENTURERS</gradient>")));
                }
            } else {
                Component inner = LEGACY.deserialize(gradients(matcher.group(2)));
                result = result.append(pack ? inner.font(TITLE_FONT) : inner);
            }
            last = matcher.end();
        }
        if (last < source.length()) {
            result = result.append(LEGACY.deserialize(gradients(source.substring(last))));
        }
        return result;
    }

    /**
     * Градиент: <gradient:#ff9900:#ffee88>Текст</gradient> (два и больше цветов).
     * Перед текстом можно поставить &l (жирный), &o, &n, &m: они применятся ко всему тексту.
     * Раскрашивает каждую букву кодами &#rrggbb. Для цветов через MessageManager тоже подойдёт.
     */
    public static String gradients(String text) {
        if (text == null || !text.contains("<gradient:")) {
            return text;
        }
        Matcher matcher = GRADIENT.matcher(text);
        StringBuilder out = new StringBuilder();
        int last = 0;
        while (matcher.find()) {
            out.append(text, last, matcher.start());
            out.append(applyGradient(matcher.group(1).split(":"), matcher.group(2)));
            last = matcher.end();
        }
        out.append(text.substring(last));
        return out.toString();
    }

    private static String applyGradient(String[] stops, String body) {
        // Форматы в начале (&l, &o, &n, &m)
        StringBuilder formats = new StringBuilder();
        int start = 0;
        while (start + 1 < body.length() && body.charAt(start) == '&'
                && "lomnk".indexOf(Character.toLowerCase(body.charAt(start + 1))) >= 0) {
            formats.append(body, start, start + 2);
            start += 2;
        }
        // Видимые символы (остальные &-коды внутри градиента отбрасываем)
        List<Character> chars = new java.util.ArrayList<>();
        for (int i = start; i < body.length(); i++) {
            char c = body.charAt(i);
            if (c == '&' && i + 1 < body.length()
                    && "0123456789abcdefklmnorABCDEFKLMNOR".indexOf(body.charAt(i + 1)) >= 0) {
                i++;
                continue;
            }
            chars.add(c);
        }

        int[][] colors = new int[stops.length][3];
        for (int i = 0; i < stops.length; i++) {
            int value = Integer.parseInt(stops[i].substring(1), 16);
            colors[i] = new int[]{(value >> 16) & 255, (value >> 8) & 255, value & 255};
        }

        StringBuilder out = new StringBuilder();
        int n = chars.size();
        for (int i = 0; i < n; i++) {
            char c = chars.get(i);
            if (c == ' ') {
                out.append(' ');
                continue;
            }
            double t = n == 1 ? 0 : (double) i / (n - 1);
            double position = t * (colors.length - 1);
            int index = Math.min((int) Math.floor(position), colors.length - 2);
            double fraction = position - index;
            int red = (int) Math.round(colors[index][0] + (colors[index + 1][0] - colors[index][0]) * fraction);
            int green = (int) Math.round(colors[index][1] + (colors[index + 1][1] - colors[index][1]) * fraction);
            int blue = (int) Math.round(colors[index][2] + (colors[index + 1][2] - colors[index][2]) * fraction);
            out.append(String.format("&#%02x%02x%02x", red, green, blue)).append(formats).append(c);
        }
        return out.toString();
    }

    public static Component parse(AdventurersCore plugin, Player player, String text) {
        return legacy(resolve(plugin, player, text));
    }

    /**
     * Делает команды в тексте кликабельными: по ЛКМ команда вставляется в поле чата
     * (игроку остаётся нажать Enter). Применять только к сообщениям плагина, не к чату игроков.
     */
    public static Component clickable(AdventurersCore plugin, Component message) {
        Component hint = legacy(plugin.getMessages().text(
                "chat.click-hint", "&7Нажми, чтобы вставить команду"));
        return message.replaceText(TextReplacementConfig.builder()
                .match(COMMAND)
                .replacement((match, builder) -> builder
                        .clickEvent(ClickEvent.suggestCommand(match.group() + " "))
                        .hoverEvent(HoverEvent.showText(hint)))
                .build());
    }
}
