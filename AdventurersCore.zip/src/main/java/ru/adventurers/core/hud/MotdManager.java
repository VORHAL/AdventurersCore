package ru.adventurers.core.hud;

import com.destroystokyo.paper.event.server.PaperServerListPingEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.util.CachedServerIcon;
import ru.adventurers.core.AdventurersCore;

import java.io.File;

/** Название сервера в списке серверов (MOTD) и иконка. Настройки: motd.yml. */
public class MotdManager implements Listener {

    private final AdventurersCore plugin;
    private boolean enabled = true;
    private Component motd = Component.empty();
    private CachedServerIcon icon;
    private int maxPlayers = 0;

    public MotdManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void init() {
        reload();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "motd.yml");
        if (!file.exists()) {
            plugin.saveResource("motd.yml", false);
        }
        File iconFile = new File(plugin.getDataFolder(), "server-icon.png");
        if (!iconFile.exists()) {
            plugin.saveResource("server-icon.png", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        maxPlayers = cfg.getInt("max-players", 0);
        String first = cfg.getString("line1", "");
        String second = cfg.getString("line2", "");
        if (cfg.getBoolean("center", true)) {
            first = pad(first, cfg.getString("line1", ""));
            second = pad(second, cfg.getString("line2", ""));
        }
        motd = Hud.legacy(first).append(Component.newline()).append(Hud.legacy(second));
        icon = null;
        if (cfg.getBoolean("icon", true)) {
            try {
                icon = Bukkit.loadServerIcon(iconFile);
            } catch (Exception exception) {
                plugin.getLogger().warning("motd: bad server-icon.png (нужен 64x64): " + exception.getMessage());
            }
        }
    }

    /** Грубое центрирование пробелами по ширине обычного шрифта (список серверов ~ 270 пикселей). */
    private String pad(String text, String source) {
        String plain = source.replaceAll("<[^>]*>", "").replaceAll("&#[0-9a-fA-F]{6}", "").replaceAll("&[0-9a-fk-orA-FK-OR]", "");
        boolean bold = source.contains("&l");
        double width = 0;
        for (char c : plain.toCharArray()) {
            width += switch (c) {
                case ' ' -> 4;
                case 'i', '.', ',', ':', ';', '!', '\'', '|', 'l' -> 2.5;
                case 'f', 'k', 't', 'I', '[', ']', '«', '»', '"' -> 5;
                default -> 6;
            };
            if (bold && c != ' ') {
                width += 1;
            }
        }
        int spaces = (int) Math.max(0, (270 - width) / 2 / 4);
        return " ".repeat(spaces) + text;
    }

    @EventHandler
    public void onPing(PaperServerListPingEvent event) {
        if (!enabled) {
            return;
        }
        event.motd(motd);
        if (icon != null) {
            event.setServerIcon(icon);
        }
        if (maxPlayers > 0) {
            event.setMaxPlayers(maxPlayers);
        }
    }
}
