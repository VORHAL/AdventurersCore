package ru.adventurers.core.hud;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import ru.adventurers.core.profile.Rank;

import java.util.Locale;

/**
 * Свои модели предметов из ресурспака Adventurers (item_model) и вид брони на игроке.
 * Включается в frames.yml: pack.item-models: true (только когда пак уже раздаётся игрокам,
 * иначе у игроков без пака вместо предмета будет "пурпурная" заглушка).
 */
public final class PackItems {

    private static boolean enabled = false;
    private static boolean glyphs = false;

    private PackItems() {
    }

    public static void setEnabled(boolean value) {
        enabled = value;
    }

    public static void setGlyphs(boolean value) {
        glyphs = value;
    }

    /**
     * Значок ранга шрифтом пака для {badge} в чате и TAB. Пусто, если glyphs выключены.
     * Включайте только вместе с force: true для пака, иначе у игроков без пака будут квадраты.
     */
    public static net.kyori.adventure.text.Component badge(Rank rank) {
        if (!glyphs || rank == null) {
            return net.kyori.adventure.text.Component.empty();
        }
        return net.kyori.adventure.text.Component.text(String.valueOf((char) (0xE020 + rank.ordinal())))
                .font(net.kyori.adventure.key.Key.key("adventurers", "hud"))
                .color(net.kyori.adventure.text.format.TextColor.color(0xffffff));
    }

    public static boolean glyphsEnabled() {
        return glyphs;
    }

    public static boolean enabled() {
        return enabled;
    }

    private static NamespacedKey key(String path) {
        return NamespacedKey.fromString("adventurers:" + path);
    }

    private static String rank(Rank rank) {
        return rank.name().toLowerCase(Locale.ROOT);
    }

    /** Модель гильдейской вещи по рангу: броня (с видом на игроке) и мечи. Прочее не трогает. */
    public static void gear(ItemMeta meta, Material material, Rank rank) {
        if (!enabled || meta == null || rank == null) {
            return;
        }
        String name = material.name();
        String rk = rank(rank);
        EquipmentSlot slot = null;
        String piece = null;
        if (name.endsWith("_HELMET")) {
            slot = EquipmentSlot.HEAD;
            piece = "helmet";
        } else if (name.endsWith("_CHESTPLATE")) {
            slot = EquipmentSlot.CHEST;
            piece = "chestplate";
        } else if (name.endsWith("_LEGGINGS")) {
            slot = EquipmentSlot.LEGS;
            piece = "leggings";
        } else if (name.endsWith("_BOOTS")) {
            slot = EquipmentSlot.FEET;
            piece = "boots";
        } else if (name.endsWith("_SWORD")) {
            meta.setItemModel(key("sword_" + rk));
            return;
        }
        if (slot == null) {
            return;
        }
        meta.setItemModel(key("armor_" + rk + "_" + piece));
        EquippableComponent equippable = meta.getEquippable();
        equippable.setSlot(slot);
        equippable.setModel(key("rank_" + rk));
        meta.setEquippable(equippable);
    }

    /** Простая модель по имени: staff, shield_tank, gem_<id>, gem_raw. */
    public static void model(ItemMeta meta, String name) {
        if (enabled && meta != null) {
            meta.setItemModel(key(name));
        }
    }
}
