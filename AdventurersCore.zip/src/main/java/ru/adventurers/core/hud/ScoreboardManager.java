package ru.adventurers.core.hud;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Боковая панель с информацией. Игрок может скрыть её командой /ag sb (выбор запоминается). */
public class ScoreboardManager {

    private static final int MAX_LINES = 15;

    private static final class Board {
        final Scoreboard scoreboard;
        final Objective objective;
        final String[] lastLines = new String[MAX_LINES];
        String lastTitle;
        int lineCount;

        Board(Scoreboard scoreboard, Objective objective) {
            this.scoreboard = scoreboard;
            this.objective = objective;
        }
    }

    private final AdventurersCore plugin;
    private final NamespacedKey hiddenKey;
    private final Map<UUID, Board> boards = new HashMap<>();

    private boolean enabled;
    private boolean defaultVisible;
    private String title = "&6&lГИЛЬДИЯ";
    private List<String> lines = new ArrayList<>();
    private BukkitTask task;

    public ScoreboardManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.hiddenKey = new NamespacedKey(plugin, "sb_hidden");
    }

    public void init() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 20L, 20L);
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "scoreboard.yml");
        if (!file.exists()) {
            plugin.saveResource("scoreboard.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        defaultVisible = cfg.getBoolean("default-visible", true);
        title = cfg.getString("title", "&6&lГИЛЬДИЯ");
        lines = new ArrayList<>(cfg.getStringList("lines"));
        if (lines.size() > MAX_LINES) {
            plugin.getLogger().warning("scoreboard.yml: максимум " + MAX_LINES + " строк, лишние отброшены.");
            lines = new ArrayList<>(lines.subList(0, MAX_LINES));
        }
        // Пересоздаём панели: число строк могло измениться.
        clearAll();
        updateAll();
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        clearAll();
    }

    private void clearAll() {
        for (UUID uuid : new ArrayList<>(boards.keySet())) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
        }
        boards.clear();
    }

    public void remove(UUID uuid) {
        boards.remove(uuid);
    }

    // ---------------------------------------------------------------
    //  Показать / скрыть
    // ---------------------------------------------------------------

    public boolean isVisible(Player player) {
        Byte stored = player.getPersistentDataContainer().get(hiddenKey, PersistentDataType.BYTE);
        if (stored == null) {
            return defaultVisible;
        }
        return stored == 0;
    }

    /** Переключает панель. Возвращает true, если после переключения она видна. */
    public boolean toggle(Player player) {
        boolean visible = !isVisible(player);
        player.getPersistentDataContainer().set(hiddenKey, PersistentDataType.BYTE, (byte) (visible ? 0 : 1));
        update(player);
        return visible;
    }

    public boolean isEnabled() {
        return enabled;
    }

    // ---------------------------------------------------------------
    //  Обновление
    // ---------------------------------------------------------------

    private void updateAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            update(player);
        }
    }

    public void update(Player player) {
        UUID uuid = player.getUniqueId();
        if (!enabled || !isVisible(player) || lines.isEmpty()) {
            if (boards.remove(uuid) != null) {
                player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
            }
            return;
        }

        Board board = boards.get(uuid);
        if (board == null) {
            board = createBoard();
            boards.put(uuid, board);
            player.setScoreboard(board.scoreboard);
        }

        String renderedTitle = Hud.resolve(plugin, player, title);
        if (!renderedTitle.equals(board.lastTitle)) {
            board.objective.displayName(Hud.legacy(renderedTitle));
            board.lastTitle = renderedTitle;
        }

        for (int i = 0; i < lines.size(); i++) {
            String rendered = Hud.resolve(plugin, player, lines.get(i));
            if (rendered.equals(board.lastLines[i])) {
                continue;
            }
            board.lastLines[i] = rendered;
            Component text = rendered.isBlank() ? Component.text(" ") : Hud.legacy(rendered);
            board.objective.getScore("line" + i).customName(text);
        }
    }

    private Board createBoard() {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective = scoreboard.registerNewObjective("ag_side", Criteria.DUMMY, Component.text(" "));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.numberFormat(NumberFormat.blank()); // скрывает красные числа справа
        Board board = new Board(scoreboard, objective);
        board.lineCount = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            objective.getScore("line" + i).setScore(lines.size() - i);
        }
        return board;
    }
}
