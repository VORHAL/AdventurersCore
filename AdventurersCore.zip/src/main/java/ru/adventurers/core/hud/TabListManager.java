package ru.adventurers.core.hud;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.profile.PlayerProfile;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Список игроков (TAB): шапка, подвал, имена с рангом и сортировка по рангу. */
public class TabListManager {

    private final AdventurersCore plugin;

    private boolean enabled;
    private List<String> header = new ArrayList<>();
    private List<String> footer = new ArrayList<>();
    private String nameFormat = "&8[%ag_rank_colored%&8] &f{player}";
    private boolean sortByRank;
    private boolean reverseSort;
    private BukkitTask task;

    public TabListManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void init() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::updateAll, 40L, 40L);
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "tab.yml");
        if (!file.exists()) {
            plugin.saveResource("tab.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        header = new ArrayList<>(cfg.getStringList("header"));
        footer = new ArrayList<>(cfg.getStringList("footer"));
        nameFormat = cfg.getString("name-format", "&8[%ag_rank_colored%&8] &f{player}");
        sortByRank = cfg.getBoolean("sort-by-rank", true);
        reverseSort = cfg.getBoolean("reverse-sort", false);
        updateAll();
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendPlayerListHeaderAndFooter(Component.empty(), Component.empty());
            player.playerListName(null);
        }
    }

    private void updateAll() {
        if (!enabled) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            update(player);
        }
    }

    public void update(Player player) {
        if (!enabled) {
            return;
        }
        player.sendPlayerListHeaderAndFooter(join(player, header), join(player, footer));
        String classTag = plugin.getClasses() != null ? plugin.getClasses().tag(player.getUniqueId()) : "";
        var tabProfile = plugin.getProfileManager().getProfile(player.getUniqueId());
        player.playerListName(Hud.parse(plugin, player, nameFormat
                .replace("{class}", classTag)
                .replace("{player}", player.getName()))
                .replaceText(net.kyori.adventure.text.TextReplacementConfig.builder()
                        .matchLiteral("{badge}")
                        .replacement(PackItems.badge(tabProfile != null ? tabProfile.getRank() : null))
                        .build()));

        if (sortByRank) {
            PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
            int rank = profile != null ? profile.getRank().ordinal() : 0;
            player.setPlayerListOrder(reverseSort ? 100 - rank : rank);
        }
    }

    private Component join(Player player, List<String> source) {
        List<Component> parts = new ArrayList<>();
        for (String line : source) {
            parts.add(Hud.parse(plugin, player, line));
        }
        return Component.join(JoinConfiguration.newlines(), parts);
    }
}
