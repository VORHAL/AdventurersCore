package ru.adventurers.core.party;

import java.util.LinkedHashSet;
import java.util.UUID;

/** Группа или рейд. Хранится только в памяти: после рестарта сервера распадается. */
public class Party {

    public enum Type { GROUP, RAID }

    private final Type type;
    private UUID leader;
    private final LinkedHashSet<UUID> members = new LinkedHashSet<>();

    public Party(Type type, UUID leader) {
        this.type = type;
        this.leader = leader;
        this.members.add(leader);
    }

    public Type getType() {
        return type;
    }

    public UUID getLeader() {
        return leader;
    }

    public void setLeader(UUID leader) {
        this.leader = leader;
    }

    public LinkedHashSet<UUID> members() {
        return members;
    }

    public boolean has(UUID uuid) {
        return members.contains(uuid);
    }

    public int size() {
        return members.size();
    }
}
