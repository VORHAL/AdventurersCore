package ru.adventurers.core.pet;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Питомцы: спутник идёт за игроком, растёт от его успехов и даёт пассивные бонусы к атрибутам.
 * Вид питомца: настоящее маленькое существо (mode MOB) или модель из ресурспака (mode MODEL, ItemDisplay
 * с item_model). Настройки: pets.yml.
 */
public class PetManager implements Listener {

    record PetDef(String id, String name, String rarity, String mode, EntityType entity, boolean baby,
                  Material item, String model, double scale, long price, Rank minRank, String desc,
                  Map<String, Double> perLevel) {
    }

    private static final class Owned {
        int level = 1;
        long xp;
    }

    private static final class Data {
        final Map<String, Owned> pets = new LinkedHashMap<>();
        String active = "";
    }

    private static final class Menu implements InventoryHolder {
        final Map<Integer, String> ids = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final AdventurersCore plugin;
    private final NamespacedKey dataKey;
    private final NamespacedKey activeKey;
    private final NamespacedKey markKey;
    private final NamespacedKey eggKey;
    private final Map<String, PetDef> defs = new LinkedHashMap<>();
    private final Map<UUID, Data> cache = new HashMap<>();
    private final Map<UUID, Entity> spawned = new HashMap<>();
    private final java.util.Set<String> bonusAttributes = new java.util.HashSet<>();
    private boolean enabled = true;
    private int maxLevel = 10;
    private long xpPerLevel = 100;
    private long xpKill = 1;
    private long xpQuest = 8;
    private long xpDungeon = 25;
    private double followDistance = 3.5;
    private double teleportDistance = 16;
    private boolean hideInDungeons = true;
    private boolean autoSummon = true;

    public PetManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.dataKey = new NamespacedKey(plugin, "pets");
        this.activeKey = new NamespacedKey(plugin, "pet_active");
        this.markKey = new NamespacedKey(plugin, "pet_owner");
        this.eggKey = new NamespacedKey(plugin, "pet_egg");
    }

    // ---------------------------------------------------------------
    //  Настройки
    // ---------------------------------------------------------------

    public void init() {
        reload();
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity.getPersistentDataContainer().has(markKey, PersistentDataType.STRING)) {
                    entity.remove();
                }
            }
        }
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 40L, 5L);
        for (Player player : Bukkit.getOnlinePlayers()) {
            applyBonus(player);
        }
    }

    public void shutdown() {
        for (Entity entity : new ArrayList<>(spawned.values())) {
            entity.remove();
        }
        spawned.clear();
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "pets.yml");
        if (!file.exists()) {
            plugin.saveResource("pets.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        maxLevel = Math.max(1, cfg.getInt("max-level", 10));
        xpPerLevel = Math.max(1, cfg.getLong("xp-per-level", 100));
        xpKill = cfg.getLong("xp.kill", 1);
        xpQuest = cfg.getLong("xp.quest", 8);
        xpDungeon = cfg.getLong("xp.dungeon", 25);
        followDistance = cfg.getDouble("follow-distance", 3.5);
        teleportDistance = cfg.getDouble("teleport-distance", 16);
        hideInDungeons = cfg.getBoolean("hide-in-dungeons", true);
        autoSummon = cfg.getBoolean("auto-summon", true);
        defs.clear();
        bonusAttributes.clear();
        ConfigurationSection pets = cfg.getConfigurationSection("pets");
        if (pets == null) {
            return;
        }
        for (String key : pets.getKeys(false)) {
            ConfigurationSection p = pets.getConfigurationSection(key);
            if (p == null) {
                continue;
            }
            EntityType entity = EntityType.FOX;
            try {
                entity = EntityType.valueOf(p.getString("entity", "FOX").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("pets.yml: bad entity for " + key);
            }
            Material item = Material.matchMaterial(p.getString("item", "NETHER_STAR"));
            Rank min = Rank.fromInput(p.getString("rank", "F"));
            Map<String, Double> per = new LinkedHashMap<>();
            ConfigurationSection b = p.getConfigurationSection("per-level");
            if (b != null) {
                for (String attribute : b.getKeys(false)) {
                    per.put(attribute.toLowerCase(Locale.ROOT), b.getDouble(attribute));
                    bonusAttributes.add(attribute.toLowerCase(Locale.ROOT));
                }
            }
            defs.put(key, new PetDef(key, p.getString("name", key), p.getString("rarity", "&7Обычный"),
                    p.getString("mode", "MOB").toUpperCase(Locale.ROOT), entity, p.getBoolean("baby", true),
                    item == null ? Material.NETHER_STAR : item, p.getString("model", ""),
                    p.getDouble("scale", 0.6), p.getLong("price", 0), min == null ? Rank.F : min,
                    p.getString("desc", ""), per));
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    // ---------------------------------------------------------------
    //  Данные игрока (PDC)
    // ---------------------------------------------------------------

    private Data data(Player player) {
        return cache.computeIfAbsent(player.getUniqueId(), id -> {
            Data data = new Data();
            var pdc = player.getPersistentDataContainer();
            String raw = pdc.get(dataKey, PersistentDataType.STRING);
            if (raw != null && !raw.isEmpty()) {
                for (String part : raw.split(";")) {
                    String[] f = part.split(":");
                    if (f.length == 3) {
                        try {
                            Owned owned = new Owned();
                            owned.level = Integer.parseInt(f[1]);
                            owned.xp = Long.parseLong(f[2]);
                            data.pets.put(f[0], owned);
                        } catch (NumberFormatException ignored) {
                            // повреждённая запись
                        }
                    }
                }
            }
            data.active = pdc.getOrDefault(activeKey, PersistentDataType.STRING, "");
            return data;
        });
    }

    private void save(Player player) {
        Data data = data(player);
        StringBuilder out = new StringBuilder();
        data.pets.forEach((id, o) -> out.append(out.length() > 0 ? ";" : "")
                .append(id).append(':').append(o.level).append(':').append(o.xp));
        player.getPersistentDataContainer().set(dataKey, PersistentDataType.STRING, out.toString());
        player.getPersistentDataContainer().set(activeKey, PersistentDataType.STRING, data.active);
    }

    private Rank rankOf(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? Rank.F : profile.getRank();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        cache.remove(player.getUniqueId());
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                if (!autoSummon) {
                    data(player).active = "";
                }
                applyBonus(player);
            }
        }, 40L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        despawn(player.getUniqueId());
        cache.remove(player.getUniqueId());
    }

    // ---------------------------------------------------------------
    //  Выдача и прокачка
    // ---------------------------------------------------------------

    public boolean give(Player player, String id) {
        PetDef def = defs.get(id);
        if (def == null || data(player).pets.containsKey(id)) {
            return false;
        }
        data(player).pets.put(id, new Owned());
        save(player);
        plugin.getMessages().send(player, "pet.got", Map.of("name", def.name()));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
        return true;
    }

    /** Опыт активному питомцу. */
    public void addXp(Player player, long amount) {
        if (!enabled || amount <= 0) {
            return;
        }
        Data data = data(player);
        Owned owned = data.pets.get(data.active);
        PetDef def = defs.get(data.active);
        if (owned == null || def == null || owned.level >= maxLevel) {
            return;
        }
        owned.xp += amount;
        boolean up = false;
        while (owned.level < maxLevel && owned.xp >= xpPerLevel * owned.level) {
            owned.xp -= xpPerLevel * owned.level;
            owned.level++;
            up = true;
        }
        if (owned.level >= maxLevel) {
            owned.xp = 0;
        }
        if (up) {
            plugin.getMessages().send(player, "pet.level-up", Map.of("name", def.name(), "level", owned.level));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.8f);
            applyBonus(player);
        }
        save(player);
    }

    public void onKill(Player player) {
        addXp(player, xpKill);
    }

    public void onQuest(Player player) {
        addXp(player, xpQuest);
    }

    public void onDungeon(Player player) {
        addXp(player, xpDungeon);
    }

    // ---------------------------------------------------------------
    //  Бонусы
    // ---------------------------------------------------------------

    private Attribute attribute(String name) {
        return Registry.ATTRIBUTE.get(NamespacedKey.minecraft(name));
    }

    public void applyBonus(Player player) {
        for (String name : bonusAttributes) {
            Attribute attribute = attribute(name);
            AttributeInstance instance = attribute == null ? null : player.getAttribute(attribute);
            if (instance == null) {
                continue;
            }
            NamespacedKey key = new NamespacedKey(plugin, "pet_" + name);
            for (AttributeModifier modifier : new ArrayList<>(instance.getModifiers())) {
                if (modifier.getKey().equals(key)) {
                    instance.removeModifier(modifier);
                }
            }
        }
        if (!enabled) {
            return;
        }
        Data data = data(player);
        PetDef def = defs.get(data.active);
        Owned owned = data.pets.get(data.active);
        if (def == null || owned == null) {
            return;
        }
        def.perLevel().forEach((name, amount) -> {
            Attribute attribute = attribute(name);
            AttributeInstance instance = attribute == null ? null : player.getAttribute(attribute);
            if (instance != null && amount != 0) {
                instance.addTransientModifier(new AttributeModifier(new NamespacedKey(plugin, "pet_" + name),
                        amount * owned.level, AttributeModifier.Operation.ADD_NUMBER));
            }
        });
    }

    private static String bonusName(String attribute) {
        return switch (attribute) {
            case "max_health" -> "Здоровье";
            case "attack_damage" -> "Урон";
            case "armor" -> "Броня";
            case "movement_speed" -> "Скорость";
            case "luck" -> "Удача";
            case "knockback_resistance" -> "Стойкость к отбрасыванию";
            case "armor_toughness" -> "Твёрдость брони";
            default -> attribute;
        };
    }

    private static String trim(double value) {
        return String.format(Locale.ROOT, "%.3f", value).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    /** Для плейсхолдера %ag_pet%. */
    public String activeText(Player player) {
        Data data = data(player);
        PetDef def = defs.get(data.active);
        Owned owned = data.pets.get(data.active);
        return def == null || owned == null ? "" : def.name() + " &8[" + owned.level + "]";
    }

    // ---------------------------------------------------------------
    //  Вызов питомца и следование
    // ---------------------------------------------------------------

    private void despawn(UUID owner) {
        Entity entity = spawned.remove(owner);
        if (entity != null) {
            entity.remove();
        }
    }

    private boolean hidden(Player player) {
        if (player.isDead() || player.getGameMode() == org.bukkit.GameMode.SPECTATOR) {
            return true;
        }
        return hideInDungeons && plugin.getDungeons() != null && plugin.getDungeons().isInstanceWorld(player.getWorld());
    }

    private Location spot(Player player) {
        double yaw = Math.toRadians(player.getLocation().getYaw() + 135);
        return player.getLocation().add(-Math.sin(yaw) * 1.3, 0.0, Math.cos(yaw) * 1.3);
    }

    private Entity spawn(Player player, PetDef def, int level) {
        Location at = spot(player);
        World world = at.getWorld();
        Entity entity;
        if (def.mode().equals("MODEL")) {
            ItemDisplay display = world.spawn(at, ItemDisplay.class, d -> {
                ItemStack stack = new ItemStack(def.item());
                ItemMeta meta = stack.getItemMeta();
                if (!def.model().isEmpty()) {
                    NamespacedKey model = NamespacedKey.fromString(def.model());
                    if (model != null) {
                        meta.setItemModel(model);
                    }
                }
                stack.setItemMeta(meta);
                d.setItemStack(stack);
                d.setBillboard(Display.Billboard.FIXED);
                d.setTeleportDuration(4);
                d.setTransformation(new Transformation(new Vector3f(0, 0.4f, 0), new AxisAngle4f(),
                        new Vector3f((float) def.scale(), (float) def.scale(), (float) def.scale()), new AxisAngle4f()));
                d.setPersistent(false);
                d.getPersistentDataContainer().set(markKey, PersistentDataType.STRING, player.getUniqueId().toString());
            });
            entity = display;
        } else {
            Entity created = world.spawnEntity(at, def.entity());
            if (created instanceof Ageable ageable && def.baby()) {
                ageable.setBaby();
                ageable.setAgeLock(true);
            }
            if (created instanceof Mob mob) {
                mob.setRemoveWhenFarAway(false);
                mob.setCanPickupItems(false);
                mob.setTarget(null);
            }
            if (created instanceof LivingEntity living) {
                living.setCollidable(false);
            }
            created.setInvulnerable(true);
            created.setSilent(true);
            created.setPersistent(false);
            created.customName(Hud.legacy(def.name() + " &8[" + level + "]"));
            created.setCustomNameVisible(true);
            created.getPersistentDataContainer().set(markKey, PersistentDataType.STRING, player.getUniqueId().toString());
            entity = created;
        }
        spawned.put(player.getUniqueId(), entity);
        return entity;
    }

    private void tick() {
        if (!enabled) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            Data data = data(player);
            PetDef def = defs.get(data.active);
            Owned owned = data.pets.get(data.active);
            if (def == null || owned == null || hidden(player)) {
                despawn(player.getUniqueId());
                continue;
            }
            Entity entity = spawned.get(player.getUniqueId());
            if (entity == null || !entity.isValid() || !entity.getPersistentDataContainer().has(markKey, PersistentDataType.STRING)
                    || entity.getType() != (def.mode().equals("MODEL") ? EntityType.ITEM_DISPLAY : def.entity())) {
                despawn(player.getUniqueId());
                entity = spawn(player, def, owned.level);
            }
            double distSq = entity.getWorld().equals(player.getWorld())
                    ? entity.getLocation().distanceSquared(player.getLocation()) : Double.MAX_VALUE;
            if (def.mode().equals("MODEL")) {
                Location target = spot(player);
                target.add(0, 0.15 * Math.sin(System.currentTimeMillis() / 400.0), 0);
                target.setYaw(player.getLocation().getYaw());
                entity.teleport(target);
            } else if (distSq > teleportDistance * teleportDistance) {
                entity.teleport(spot(player));
            } else if (distSq > followDistance * followDistance && entity instanceof Mob mob) {
                mob.getPathfinder().moveTo(player.getLocation(), 1.3);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Защита питомца и яйцо
    // ---------------------------------------------------------------

    private boolean isPet(Entity entity) {
        return entity != null && entity.getPersistentDataContainer().has(markKey, PersistentDataType.STRING);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTarget(EntityTargetEvent event) {
        if (isPet(event.getEntity()) || isPet(event.getTarget())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (isPet(event.getDamager()) || isPet(event.getEntity())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteractPet(PlayerInteractEntityEvent event) {
        if (isPet(event.getRightClicked())) {
            event.setCancelled(true);
            if (event.getHand() == EquipmentSlot.HAND) {
                open(event.getPlayer());
            }
        }
    }

    public ItemStack egg(String id) {
        PetDef def = defs.get(id);
        if (def == null) {
            return null;
        }
        ItemStack stack = new ItemStack(Material.TURTLE_EGG);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Hud.legacy("&dЯйцо питомца: " + def.name()).decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Hud.legacy("&7Нажмите ПКМ, чтобы получить питомца.").decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(eggKey, PersistentDataType.STRING, id);
        stack.setItemMeta(meta);
        return stack;
    }

    @EventHandler(ignoreCancelled = false)
    public void onEgg(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND
                || event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack stack = event.getItem();
        if (stack == null || !stack.hasItemMeta()) {
            return;
        }
        String id = stack.getItemMeta().getPersistentDataContainer().get(eggKey, PersistentDataType.STRING);
        if (id == null) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!defs.containsKey(id)) {
            return;
        }
        if (data(player).pets.containsKey(id)) {
            plugin.getMessages().send(player, "pet.have");
            return;
        }
        stack.setAmount(stack.getAmount() - 1);
        give(player, id);
    }

    // ---------------------------------------------------------------
    //  Меню
    // ---------------------------------------------------------------

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Hud.legacy(name).decoration(TextDecoration.ITALIC, false));
        List<Component> lines = new ArrayList<>();
        lore.forEach(line -> lines.add(Hud.legacy(line).decoration(TextDecoration.ITALIC, false)));
        meta.lore(lines);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        stack.setItemMeta(meta);
        return stack;
    }

    public void open(Player player) {
        if (!enabled) {
            plugin.getMessages().send(player, "pet.disabled");
            return;
        }
        Menu menu = new Menu();
        Inventory inventory = Bukkit.createInventory(menu, 54, Hud.legacy("&8Питомцы"));
        ItemStack pane = item(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 54; i++) {
            inventory.setItem(i, pane);
        }
        Data data = data(player);
        inventory.setItem(4, item(Material.BONE, "&6Питомцы", List.of(
                "&7Питомец идёт за вами, растёт от убийств,",
                "&7заданий и подземелий и даёт бонусы.",
                "&7Максимальный уровень: &f" + maxLevel)));
        int slot = 10;
        for (PetDef def : defs.values()) {
            if (slot % 9 == 8) {
                slot += 2;
            }
            if (slot >= 44) {
                break;
            }
            Owned owned = data.pets.get(def.id());
            boolean active = def.id().equals(data.active);
            List<String> lore = new ArrayList<>();
            lore.add(def.rarity());
            if (!def.desc().isEmpty()) {
                lore.add("&7" + def.desc());
            }
            lore.add("");
            def.perLevel().forEach((name, amount) -> lore.add("&7" + bonusName(name) + ": &a+" + trim(amount) + " &8за уровень"));
            lore.add("");
            Material icon;
            if (owned != null) {
                long need = xpPerLevel * owned.level;
                int filled = owned.level >= maxLevel ? 12 : (int) (owned.xp * 12 / need);
                lore.add("&7Уровень: &f" + owned.level + "&7/&f" + maxLevel);
                lore.add("&e" + "▌".repeat(filled) + "&8" + "▌".repeat(12 - filled)
                        + (owned.level >= maxLevel ? " &aмакс." : " &f" + owned.xp + "&7/&f" + need));
                lore.add("");
                lore.add(active ? "&aС вами. &8ЛКМ - отпустить" : "&eЛКМ &7- позвать");
                icon = active ? Material.LIME_DYE : Material.EGG;
            } else if (def.price() > 0) {
                lore.add("&7Цена: " + (plugin.getEconomy() != null ? plugin.getEconomy().format(def.price()) : def.price()));
                if (!rankOf(player).isAtLeast(def.minRank())) {
                    lore.add("&cНужен ранг " + def.minRank().getDisplayName());
                } else {
                    lore.add("&eЛКМ &7- купить");
                }
                icon = Material.GRAY_DYE;
            } else {
                lore.add("&dОсобый питомец: &7выдаётся за достижения (яйцо).");
                icon = Material.BARRIER;
            }
            inventory.setItem(slot, item(icon, (active ? "&a" : owned != null ? "&f" : "&7") + def.name(), lore));
            menu.ids.put(slot, def.id());
            slot++;
        }
        inventory.setItem(49, item(Material.BARRIER, "&cОтпустить питомца", List.of("&7Спрятать текущего питомца.")));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Menu menu) || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        Data data = data(player);
        if (event.getSlot() == 49) {
            data.active = "";
            save(player);
            applyBonus(player);
            open(player);
            return;
        }
        PetDef def = defs.get(menu.ids.get(event.getSlot()));
        if (def == null) {
            return;
        }
        if (data.pets.containsKey(def.id())) {
            data.active = def.id().equals(data.active) ? "" : def.id();
            despawn(player.getUniqueId());
            save(player);
            applyBonus(player);
        } else if (def.price() > 0) {
            if (!rankOf(player).isAtLeast(def.minRank())) {
                plugin.getMessages().send(player, "pet.rank", Map.of("rank", def.minRank().getDisplayName()));
            } else if (plugin.getEconomy() == null || !plugin.getEconomy().withdraw(player.getUniqueId(), def.price())) {
                plugin.getMessages().send(player, "pet.poor", Map.of("price", plugin.getEconomy() != null
                        ? plugin.getEconomy().format(def.price()) : String.valueOf(def.price())));
            } else {
                give(player, def.id());
            }
        }
        open(player);
    }

    // ---------------------------------------------------------------
    //  Админ: /ag admin pet give <ник> <id> | egg <ник> <id> | list | reload
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        String action = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
        Player target = args.length > 3 ? Bukkit.getPlayerExact(args[3]) : null;
        String id = args.length > 4 ? args[4].toLowerCase(Locale.ROOT) : "";
        switch (action) {
            case "give" -> {
                if (target == null || !defs.containsKey(id)) {
                    sender.sendMessage(Hud.legacy("&c/ag admin pet give <ник> <id>"));
                } else {
                    sender.sendMessage(Hud.legacy(give(target, id) ? "&aПитомец выдан." : "&7Уже есть."));
                }
            }
            case "egg" -> {
                ItemStack egg = target == null ? null : egg(id);
                if (egg == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin pet egg <ник> <id>"));
                } else {
                    target.getInventory().addItem(egg).values().forEach(rest -> target.getWorld().dropItem(target.getLocation(), rest));
                    sender.sendMessage(Hud.legacy("&aЯйцо выдано."));
                }
            }
            case "take" -> {
                if (target == null || id.isEmpty()) {
                    sender.sendMessage(Hud.legacy("&c/ag admin pet take <ник> <id>"));
                } else {
                    Data data = data(target);
                    data.pets.remove(id);
                    if (data.active.equals(id)) {
                        data.active = "";
                    }
                    save(target);
                    applyBonus(target);
                    sender.sendMessage(Hud.legacy("&aУбрано."));
                }
            }
            case "list" -> defs.values().forEach(d -> sender.sendMessage(Hud.legacy("&8» &f" + d.id() + " &7" + d.name()
                    + " &8(" + d.mode() + ", цена " + d.price() + ")")));
            case "reload" -> {
                reload();
                sender.sendMessage(Hud.legacy("&aПитомцы перечитаны: " + defs.size()));
            }
            default -> sender.sendMessage(Hud.legacy("&7/ag admin pet give|egg|take <ник> <id>|list|reload"));
        }
    }

    public List<String> ids() {
        return new ArrayList<>(defs.keySet());
    }
}
