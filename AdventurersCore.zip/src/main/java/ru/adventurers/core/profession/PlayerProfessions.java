package ru.adventurers.core.profession;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Профессии одного игрока в памяти. Меняется только из основного потока сервера. */
public class PlayerProfessions {

    public static final class Progress {
        private int level = 1;
        private int xp = 0;

        public int getLevel() {
            return level;
        }

        public void setLevel(int level) {
            this.level = level;
        }

        public int getXp() {
            return xp;
        }

        public void setXp(int xp) {
            this.xp = xp;
        }
    }

    private final Map<Profession, Progress> map = new EnumMap<>(Profession.class);

    public boolean has(Profession profession) {
        return map.containsKey(profession);
    }

    /** Прогресс профессии или null, если игрок её не знает. */
    public Progress get(Profession profession) {
        return map.get(profession);
    }

    public Progress learn(Profession profession) {
        return map.computeIfAbsent(profession, key -> new Progress());
    }

    public boolean remove(Profession profession) {
        return map.remove(profession) != null;
    }

    public int count() {
        return map.size();
    }

    public Set<Profession> professions() {
        return Collections.unmodifiableSet(map.keySet());
    }

    /** Загрузка из базы. */
    public void put(Profession profession, int level, int xp) {
        Progress progress = new Progress();
        progress.setLevel(level);
        progress.setXp(xp);
        map.put(profession, progress);
    }

    /** Копия данных, которую можно спокойно отдать в другой поток для записи в базу. */
    public List<ProfessionRepository.Row> snapshot() {
        List<ProfessionRepository.Row> rows = new ArrayList<>(map.size());
        for (Map.Entry<Profession, Progress> entry : map.entrySet()) {
            rows.add(new ProfessionRepository.Row(
                    entry.getKey(),
                    entry.getValue().getLevel(),
                    entry.getValue().getXp()
            ));
        }
        return rows;
    }
}
