package ru.adventurers.core.profession;

import java.util.Locale;

public enum Profession {

    // Основные: создают предметы
    ARMORSMITH("armorsmith", true),
    WEAPONSMITH("weaponsmith", true),
    JEWELER("jeweler", true),
    RUNESMITH("runesmith", true),
    // Дополнительные: временные бафы и больше добычи
    HUNTER("hunter", false),
    MINER("miner", false),
    ALCHEMIST("alchemist", false),
    COOK("cook", false);

    private final String id;
    private final boolean main;

    Profession(String id, boolean main) {
        this.id = id;
        this.main = main;
    }

    /** true: основная профессия (ремесло), false: дополнительная. */
    public boolean isMain() {
        return main;
    }

    /** Короткий идентификатор: используется в командах, базе и плейсхолдерах. */
    public String getId() {
        return id;
    }

    /** Принимает "hunter" и "HUNTER" в любом регистре. Если не нашёл, вернёт null. */
    public static Profession fromInput(String value) {
        if (value == null) {
            return null;
        }
        String text = value.toLowerCase(Locale.ROOT);
        for (Profession profession : values()) {
            if (profession.id.equals(text) || profession.name().equalsIgnoreCase(text)) {
                return profession;
            }
        }
        return null;
    }
}
