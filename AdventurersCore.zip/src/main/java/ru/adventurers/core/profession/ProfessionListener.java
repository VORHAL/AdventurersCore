package ru.adventurers.core.profession;

import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.Material;

public class ProfessionListener implements Listener {

    private final ProfessionManager professions;

    public ProfessionListener(ProfessionManager professions) {
        this.professions = professions;
    }

    // Нельзя создать наковальню, печь и другие станции без нужной профессии.
    @EventHandler(ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        Material result = event.getRecipe().getResult().getType();
        if (professions.canHandleStation(player, result)) {
            return;
        }
        event.setCancelled(true);
        professions.warnStation(player, "professions.station-craft-denied", result);
    }

    // Необязательно (restrict-use в professions.yml): нельзя пользоваться чужой станцией.
    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (!professions.isRestrictUse()
                || event.getAction() != Action.RIGHT_CLICK_BLOCK
                || event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        Player player = event.getPlayer();
        if (professions.canHandleStation(player, block.getType())) {
            return;
        }
        event.setUseInteractedBlock(Event.Result.DENY);
        professions.warnStation(player, "professions.station-use-denied", block.getType());
    }

    // Охотник получает опыт за убийство мобов.
    @EventHandler(ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null
                || event.getEntity() instanceof Player
                || event.getEntity() instanceof ArmorStand) {
            return;
        }
        int xp = professions.getHunterKillXp();
        if (xp > 0) {
            professions.addXp(killer, Profession.HUNTER, xp);
        }
    }
}
