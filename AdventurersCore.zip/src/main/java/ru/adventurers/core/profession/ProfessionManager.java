package ru.adventurers.core.profession;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.ProfileManager;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ProfessionManager {

    public static final int MAX_LEVEL = 10;

    private static final long WARNING_COOLDOWN_MS = 2_000L;
    private static final long CAP_WARNING_COOLDOWN_MS = 60_000L;

    // Значения по умолчанию, если в professions.yml чего-то нет.
    private static final int[] DEFAULT_XP = {100, 250, 500, 900, 1400, 2200, 3200, 4600, 6500};
    // Порядок как в Rank: F, E, D, C, B, A, A+, S
    private static final int[] DEFAULT_CAPS = {2, 3, 4, 5, 7, 8, 9, 10};

    public enum LearnResult {
        OK, ALREADY_KNOWN, LIMIT_REACHED, MAIN_LIMIT, EXTRA_LIMIT, NO_COINS, NOT_LOADED
    }

    private final AdventurersCore plugin;
    private final ProfessionRepository repository;
    private final ProfileManager profiles;

    private final Map<UUID, PlayerProfessions> cache = new ConcurrentHashMap<>();
    private final Map<String, Long> lastWarning = new ConcurrentHashMap<>();

    private final Map<Rank, Integer> levelCaps = new EnumMap<>(Rank.class);
    private final Map<Material, Set<Profession>> stations = new EnumMap<>(Material.class);
    private int[] xpTable = DEFAULT_XP.clone();

    private int maxMain = 1;
    private int maxExtra = 2;
    private boolean allowSelfLearn = true;
    private boolean restrictUse = false;
    private int hunterKillXp = 5;
    private int autosaveMinutes = 5;

    private BukkitTask autosaveTask;

    public ProfessionManager(AdventurersCore plugin,
                             ProfessionRepository repository,
                             ProfileManager profiles) {
        this.plugin = plugin;
        this.repository = repository;
        this.profiles = profiles;
    }

    // ---------------------------------------------------------------
    //  Запуск, перезагрузка, остановка
    // ---------------------------------------------------------------

    public void init() throws SQLException {
        repository.createTable();
        reload();

        long ticks = Math.max(1, autosaveMinutes) * 60L * 20L;
        autosaveTask = Bukkit.getScheduler().runTaskTimer(plugin, this::autosave, ticks, ticks);
    }

    /** Перечитывает professions.yml. Интервал автосохранения применится только после рестарта. */
    public void reload() {
        File file = new File(plugin.getDataFolder(), "professions.yml");
        if (!file.exists()) {
            plugin.saveResource("professions.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        maxMain = Math.max(0, cfg.getInt("max-main", 1));
        maxExtra = Math.max(0, cfg.getInt("max-extra", 2));
        allowSelfLearn = cfg.getBoolean("allow-self-learn", true);
        autosaveMinutes = cfg.getInt("autosave-minutes", 5);
        restrictUse = cfg.getBoolean("restrict-use", false);
        hunterKillXp = Math.max(0, cfg.getInt("xp-sources.hunter-mob-kill", 5));

        levelCaps.clear();
        for (Rank rank : Rank.values()) {
            int fallback = DEFAULT_CAPS[rank.ordinal()];
            int cap = cfg.getInt("level-cap-by-rank." + rank.getDisplayName(), fallback);
            levelCaps.put(rank, Math.max(1, Math.min(MAX_LEVEL, cap)));
        }

        List<Integer> list = cfg.getIntegerList("xp-to-next");
        int[] table = new int[MAX_LEVEL - 1];
        for (int i = 0; i < table.length; i++) {
            int value = i < list.size() ? list.get(i) : DEFAULT_XP[i];
            table[i] = Math.max(1, value);
        }
        xpTable = table;

        stations.clear();
        ConfigurationSection section = cfg.getConfigurationSection("stations");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Material material = Material.matchMaterial(key);
                if (material == null) {
                    plugin.getLogger().warning("professions.yml: неизвестный материал " + key);
                    continue;
                }
                Set<Profession> allowed = EnumSet.noneOf(Profession.class);
                for (String name : section.getStringList(key)) {
                    Profession profession = Profession.fromInput(name);
                    if (profession == null) {
                        plugin.getLogger().warning(
                                "professions.yml: неизвестная профессия " + name + " у " + key);
                        continue;
                    }
                    allowed.add(profession);
                }
                if (!allowed.isEmpty()) {
                    stations.put(material, allowed);
                }
            }
        }
    }

    /** Вызывается из onDisable: останавливает автосохранение и записывает всех игроков. */
    public void shutdown() {
        if (autosaveTask != null) {
            autosaveTask.cancel();
            autosaveTask = null;
        }
        for (Map.Entry<UUID, PlayerProfessions> entry : cache.entrySet()) {
            saveRows(entry.getKey(), entry.getValue().snapshot());
        }
        cache.clear();
    }

    // ---------------------------------------------------------------
    //  Загрузка и сохранение игроков
    // ---------------------------------------------------------------

    public void load(Player player) {
        UUID uuid = player.getUniqueId();

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                PlayerProfessions data = repository.load(uuid);

                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (player.isOnline()) {
                        cache.put(uuid, data);
                    }
                });
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not load professions for " + player.getName());
                exception.printStackTrace();
            }
        });
    }

    public void unload(UUID uuid) {
        PlayerProfessions data = cache.remove(uuid);
        String prefix = uuid + ":";
        lastWarning.keySet().removeIf(key -> key.startsWith(prefix));

        if (data == null) {
            return;
        }
        List<ProfessionRepository.Row> rows = data.snapshot();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveRows(uuid, rows));
    }

    private void autosave() {
        Map<UUID, List<ProfessionRepository.Row>> batch = new HashMap<>();
        for (Map.Entry<UUID, PlayerProfessions> entry : cache.entrySet()) {
            batch.put(entry.getKey(), entry.getValue().snapshot());
        }
        if (batch.isEmpty()) {
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> batch.forEach(this::saveRows));
    }

    private void saveAsync(UUID uuid) {
        PlayerProfessions data = cache.get(uuid);
        if (data == null) {
            return;
        }
        List<ProfessionRepository.Row> rows = data.snapshot();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveRows(uuid, rows));
    }

    private void saveRows(UUID uuid, List<ProfessionRepository.Row> rows) {
        try {
            repository.save(uuid, rows);
        } catch (SQLException exception) {
            plugin.getLogger().severe("Could not save professions: " + uuid);
            exception.printStackTrace();
        }
    }

    // ---------------------------------------------------------------
    //  Доступ к данным
    // ---------------------------------------------------------------

    /** Профессии игрока или null, пока они ещё грузятся. */
    public PlayerProfessions get(UUID uuid) {
        return cache.get(uuid);
    }

    public boolean has(Player player, Profession profession) {
        PlayerProfessions data = cache.get(player.getUniqueId());
        return data != null && data.has(profession);
    }

    public int getMaxProfessions() {
        return maxMain + maxExtra;
    }

    public int getMaxMain() {
        return maxMain;
    }

    public int getMaxExtra() {
        return maxExtra;
    }

    public int count(PlayerProfessions data, boolean main) {
        int result = 0;
        for (Profession known : data.professions()) {
            if (known.isMain() == main) {
                result++;
            }
        }
        return result;
    }

    public boolean isSelfLearnAllowed() {
        return allowSelfLearn;
    }

    public boolean isRestrictUse() {
        return restrictUse;
    }

    public int getHunterKillXp() {
        return hunterKillXp;
    }

    /** Максимальный уровень профессии на ранге игрока. */
    public int levelCap(Player player) {
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        return levelCapFor(profile != null ? profile.getRank() : Rank.F);
    }

    public int levelCapFor(Rank rank) {
        return levelCaps.getOrDefault(rank, 1);
    }

    /** Сколько опыта нужно, чтобы перейти с этого уровня на следующий. -1, если уровень максимальный. */
    public int xpToNext(int level) {
        if (level >= MAX_LEVEL) {
            return -1;
        }
        int index = Math.max(0, Math.min(level - 1, xpTable.length - 1));
        return xpTable[index];
    }

    // ---------------------------------------------------------------
    //  Тексты
    // ---------------------------------------------------------------

    /** Название профессии с цветом из messages.yml (формат с "&"). */
    public String displayName(Profession profession) {
        return plugin.getMessages().text("professions.names." + profession.getId(), profession.getId());
    }

    public String description(Profession profession) {
        return plugin.getMessages().text("professions.descriptions." + profession.getId(), "");
    }

    // ---------------------------------------------------------------
    //  Изучение, забывание, уровни
    // ---------------------------------------------------------------

    public LearnResult learn(Player player, Profession profession) {
        PlayerProfessions data = cache.get(player.getUniqueId());
        if (data == null) {
            return LearnResult.NOT_LOADED;
        }
        if (data.has(profession)) {
            return LearnResult.ALREADY_KNOWN;
        }
        if (profession.isMain() && count(data, true) >= maxMain) {
            return LearnResult.MAIN_LIMIT;
        }
        if (!profession.isMain() && count(data, false) >= maxExtra) {
            return LearnResult.EXTRA_LIMIT;
        }
        if (plugin.getEconomy() != null
                && !plugin.getEconomy().charge(player, plugin.getEconomy().learnCost(profession.isMain()))) {
            return LearnResult.NO_COINS;
        }
        data.learn(profession);
        saveAsync(player.getUniqueId());
        return LearnResult.OK;
    }

    /** Для админа: игнорирует лимит профессий. Возвращает true, если профессия была новой. */
    public boolean adminLearn(Player player, Profession profession) {
        PlayerProfessions data = cache.get(player.getUniqueId());
        if (data == null || data.has(profession)) {
            return false;
        }
        data.learn(profession);
        saveAsync(player.getUniqueId());
        return true;
    }

    /** Забывание профессии. Строка в базе удаляется сразу. */
    public boolean forget(Player player, Profession profession) {
        UUID uuid = player.getUniqueId();
        PlayerProfessions data = cache.get(uuid);
        if (data == null || !data.remove(profession)) {
            return false;
        }
        try {
            repository.delete(uuid, profession);
        } catch (SQLException exception) {
            plugin.getLogger().severe("Could not delete profession for " + player.getName());
            exception.printStackTrace();
        }
        return true;
    }

    /**
     * Для админа: ставит уровень (и сразу изучает профессию, если её не было).
     * Без force уровень режется потолком ранга игрока.
     * Возвращает итоговый уровень или -1, если данные игрока не загружены.
     */
    public int setLevel(Player player, Profession profession, int level, boolean force) {
        PlayerProfessions data = cache.get(player.getUniqueId());
        if (data == null) {
            return -1;
        }
        PlayerProfessions.Progress progress = data.learn(profession);
        int limit = force ? MAX_LEVEL : Math.min(MAX_LEVEL, levelCap(player));
        int result = Math.max(1, Math.min(limit, level));
        progress.setLevel(result);
        progress.setXp(0);
        saveAsync(player.getUniqueId());
        return result;
    }

    /** Добавляет опыт. Возвращает false, если игрок не знает эту профессию. */
    public boolean addXp(Player player, Profession profession, int amount) {
        PlayerProfessions data = cache.get(player.getUniqueId());
        if (data == null || amount < 0) {
            return false;
        }
        PlayerProfessions.Progress progress = data.get(profession);
        if (progress == null) {
            return false;
        }
        if (amount > 0 && plugin.getGems() != null) {
            double bonus = plugin.getGems().power(player, ru.adventurers.core.gem.GemManager.Effect.PROF_XP);
            if (bonus > 0) {
                amount = (int) Math.round(amount * (1.0 + Math.min(1.0, bonus)));
            }
        }
        if (amount > 0 && plugin.getMentors() != null) {
            amount = (int) Math.round(amount * plugin.getMentors().xpMultiplier(player));
        }
        applyXp(player, profession, progress, amount);
        return true;
    }

    /** Вызывать после смены ранга: накопленный опыт, который ждал повышения, превращается в уровни. */
    public void refreshLevels(Player player) {
        PlayerProfessions data = cache.get(player.getUniqueId());
        if (data == null) {
            return;
        }
        for (Profession profession : new ArrayList<>(data.professions())) {
            PlayerProfessions.Progress progress = data.get(profession);
            if (progress != null) {
                applyXp(player, profession, progress, 0);
            }
        }
        saveAsync(player.getUniqueId());
    }

    private void applyXp(Player player, Profession profession,
                         PlayerProfessions.Progress progress, int amount) {
        int cap = levelCap(player);
        int levelBefore = progress.getLevel();
        int xpBefore = progress.getXp();

        progress.setXp(xpBefore + amount);

        while (progress.getLevel() < MAX_LEVEL && progress.getLevel() < cap) {
            int need = xpToNext(progress.getLevel());
            if (progress.getXp() < need) {
                break;
            }
            progress.setXp(progress.getXp() - need);
            progress.setLevel(progress.getLevel() + 1);
        }

        boolean waitingForRank = false;
        if (progress.getLevel() >= MAX_LEVEL) {
            progress.setXp(0);
        } else if (progress.getLevel() >= cap) {
            // Уровень упёрся в лимит ранга: опыт копится, но не выше порога следующего уровня.
            int limit = xpToNext(progress.getLevel()) - 1;
            if (progress.getXp() > limit) {
                progress.setXp(limit);
            }
            waitingForRank = amount > 0;
        }

        if (progress.getLevel() > levelBefore) {
            plugin.getMessages().send(player, "professions.level-up", Map.of(
                    "profession", displayName(profession),
                    "level", progress.getLevel()
            ));
        } else if (waitingForRank) {
            warn(player, "professions.xp-capped", CAP_WARNING_COOLDOWN_MS, Map.of(
                    "profession", displayName(profession),
                    "cap", cap
            ));
        }
    }

    // ---------------------------------------------------------------
    //  Станции (наковальня, печь и т.д.)
    // ---------------------------------------------------------------

    /** Можно ли игроку создавать или использовать этот блок. true, если ограничений нет. */
    /** Блок из списка станций (наковальня, печь...): такие предметы не выпадают при смерти. */
    public boolean isStation(Material material) {
        return stations.containsKey(material);
    }

    public boolean canHandleStation(Player player, Material material) {
        Set<Profession> allowed = stations.get(material);
        if (allowed == null) {
            return true;
        }
        if (player.hasPermission("ag.bypass.professions")) {
            return true;
        }
        PlayerProfessions data = cache.get(player.getUniqueId());
        if (data == null) {
            return false;
        }
        for (Profession profession : allowed) {
            if (data.has(profession)) {
                return true;
            }
        }
        return false;
    }

    /** Сообщает игроку, какая профессия нужна для станции. messageKey: ключ из messages.yml. */
    public void warnStation(Player player, String messageKey, Material material) {
        Set<Profession> allowed = stations.get(material);
        if (allowed == null) {
            return;
        }
        List<String> names = new ArrayList<>();
        for (Profession profession : allowed) {
            names.add(displayName(profession));
        }
        warn(player, messageKey, WARNING_COOLDOWN_MS, Map.of(
                "item", Component.translatable(material.translationKey()),
                "professions", String.join("&7, ", names)
        ));
    }

    private void warn(Player player, String key, long cooldownMs, Map<String, ?> placeholders) {
        String id = player.getUniqueId() + ":" + key;
        long now = System.currentTimeMillis();
        Long last = lastWarning.get(id);
        if (last != null && now - last < cooldownMs) {
            return;
        }
        lastWarning.put(id, now);
        plugin.getMessages().send(player, key, placeholders);
    }
}
