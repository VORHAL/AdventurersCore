package ru.adventurers.core.profession;

import ru.adventurers.core.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

/** Работа с таблицей player_professions. Все методы блокирующие: вызывать не из основного потока. */
public class ProfessionRepository {

    public record Row(Profession profession, int level, int xp) {
    }

    private final DatabaseManager database;

    public ProfessionRepository(DatabaseManager database) {
        this.database = database;
    }

    public void createTable() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS player_professions (
                    uuid CHAR(36) NOT NULL,
                    profession VARCHAR(32) NOT NULL,
                    prof_level TINYINT UNSIGNED NOT NULL DEFAULT 1,
                    prof_xp INT UNSIGNED NOT NULL DEFAULT 0,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (uuid, profession),
                    INDEX idx_player_professions_profession (profession)
                ) ENGINE=InnoDB
                  DEFAULT CHARSET=utf8mb4
                  COLLATE=utf8mb4_unicode_ci
                """;

        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }
    }

    public PlayerProfessions load(UUID uuid) throws SQLException {
        String sql = """
                SELECT profession, prof_level, prof_xp
                FROM player_professions
                WHERE uuid = ?
                """;

        PlayerProfessions data = new PlayerProfessions();

        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, uuid.toString());

            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    Profession profession = Profession.fromInput(result.getString("profession"));
                    if (profession == null) {
                        continue; // профессию убрали из плагина, строку просто пропускаем
                    }
                    data.put(profession, result.getInt("prof_level"), result.getInt("prof_xp"));
                }
            }
        }
        return data;
    }

    public void save(UUID uuid, List<Row> rows) throws SQLException {
        if (rows.isEmpty()) {
            return;
        }

        String sql = """
                INSERT INTO player_professions (uuid, profession, prof_level, prof_xp)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    prof_level = VALUES(prof_level),
                    prof_xp = VALUES(prof_xp)
                """;

        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            for (Row row : rows) {
                statement.setString(1, uuid.toString());
                statement.setString(2, row.profession().getId());
                statement.setInt(3, row.level());
                statement.setInt(4, row.xp());
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }

    public void delete(UUID uuid, Profession profession) throws SQLException {
        String sql = "DELETE FROM player_professions WHERE uuid = ? AND profession = ?";

        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, uuid.toString());
            statement.setString(2, profession.getId());
            statement.executeUpdate();
        }
    }
}
