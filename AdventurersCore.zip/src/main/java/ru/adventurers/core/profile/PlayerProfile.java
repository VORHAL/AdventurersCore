
package ru.adventurers.core.profile;

import java.util.UUID;

public class PlayerProfile {

    private final UUID uuid;
    private String username;
    private Rank rank;

    public PlayerProfile(UUID uuid, String username, Rank rank) {
        this.uuid = uuid;
        this.username = username;
        this.rank = rank;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Rank getRank() {
        return rank;
    }

    public void setRank(Rank rank) {
        this.rank = rank;
    }
}
