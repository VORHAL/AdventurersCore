package ru.adventurers.core.profile;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.DatabaseManager;
import ru.adventurers.core.message.MessageManager;

import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ProfileManager {

    private final AdventurersCore plugin;
    private final DatabaseManager database;

    private final Map<UUID, PlayerProfile> profiles =
            new ConcurrentHashMap<>();

    public ProfileManager(
            AdventurersCore plugin,
            DatabaseManager database
    ) {
        this.plugin = plugin;
        this.database = database;
    }

    public void loadProfile(Player player) {
        UUID uuid = player.getUniqueId();
        String username = player.getName();
        MessageManager messages = plugin.getMessages();

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                PlayerProfile profile =
                        database.loadOrCreateProfile(uuid, username);

                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) {
                        return;
                    }

                    profiles.put(uuid, profile);

                    messages.send(player, "profile.loaded", Map.of(
                            "player", profile.getUsername(),
                            "rank", messages.rankName(profile.getRank())
                    ));
                });

            } catch (SQLException exception) {
                plugin.getLogger().severe(
                        "Could not load profile for " + username
                );
                exception.printStackTrace();

                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (player.isOnline()) {
                        player.kick(messages.joined("profile.load-failed"));
                    }
                });
            }
        });
    }

    public void saveProfile(UUID uuid) {
        PlayerProfile profile = profiles.remove(uuid);

        if (profile == null) {
            return;
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                database.saveProfile(profile);
            } catch (SQLException exception) {
                plugin.getLogger().severe(
                        "Could not save profile: " + uuid
                );
                exception.printStackTrace();
            }
        });
    }

    public PlayerProfile getProfile(UUID uuid) {
        return profiles.get(uuid);
    }

    public void saveAllSync() {
        for (PlayerProfile profile : profiles.values()) {
            try {
                database.saveProfile(profile);
            } catch (SQLException exception) {
                plugin.getLogger().severe(
                        "Could not save profile: " + profile.getUuid()
                );
                exception.printStackTrace();
            }
        }

        profiles.clear();
    }

    /** Асинхронно сохраняет профиль, не удаляя его из памяти. */
    public void saveNow(PlayerProfile profile) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                database.saveProfile(profile);
            } catch (SQLException exception) {
                plugin.getLogger().severe(
                        "Could not save profile: " + profile.getUuid()
                );
                exception.printStackTrace();
            }
        });
    }
}