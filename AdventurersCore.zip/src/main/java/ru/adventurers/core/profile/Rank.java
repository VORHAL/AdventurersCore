package ru.adventurers.core.profile;

public enum Rank {
    F("F"),
    E("E"),
    D("D"),
    C("C"),
    B("B"),
    A("A"),
    A_PLUS("A+"),
    S("S");

    private final String displayName;

    Rank(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDatabaseName() {
        return displayName;
    }

    /** Следующий ранг или null, если ранг максимальный. */
    public Rank next() {
        Rank[] all = values();
        return ordinal() + 1 < all.length ? all[ordinal() + 1] : null;
    }

    /** Для проверок вида "ранг не ниже C". */
    public boolean isAtLeast(Rank other) {
        return this.ordinal() >= other.ordinal();
    }

    /** Из базы данных. Неизвестное значение превращается в F. */
    public static Rank fromDatabase(String value) {
        Rank rank = fromInput(value);
        return rank != null ? rank : F;
    }

    /** Из ввода игрока: принимает "A+" и "A_PLUS". Если не нашёл, вернёт null. */
    public static Rank fromInput(String value) {
        if (value == null) {
            return null;
        }
        for (Rank rank : values()) {
            if (rank.displayName.equalsIgnoreCase(value)
                    || rank.name().equalsIgnoreCase(value)) {
                return rank;
            }
        }
        return null;
    }
}
