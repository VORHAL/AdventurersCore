package ru.adventurers.core.quest;

import java.util.LinkedHashMap;
import java.util.Map;

/** Прогресс заданий игрока и очки гильдии. */
public class PlayerQuests {

    public enum State { ACTIVE, DONE, ABANDONED }

    public static final class Entry {
        public State state = State.ACTIVE;
        public int progress;
        public long acceptedDay;
        public long completedDay;

        Entry copy() {
            Entry copy = new Entry();
            copy.state = state;
            copy.progress = progress;
            copy.acceptedDay = acceptedDay;
            copy.completedDay = completedDay;
            return copy;
        }
    }

    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private int points;
    private int completed;

    public Map<String, Entry> entries() {
        return entries;
    }

    public Entry get(String questId) {
        return entries.get(questId);
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = Math.max(0, points);
    }

    /** Сколько заданий выполнено за всё время. */
    public int getCompleted() {
        return completed;
    }

    public void setCompleted(int completed) {
        this.completed = Math.max(0, completed);
    }

    public PlayerQuests copy() {
        PlayerQuests copy = new PlayerQuests();
        copy.points = points;
        copy.completed = completed;
        for (Map.Entry<String, Entry> entry : entries.entrySet()) {
            copy.entries.put(entry.getKey(), entry.getValue().copy());
        }
        return copy;
    }
}
