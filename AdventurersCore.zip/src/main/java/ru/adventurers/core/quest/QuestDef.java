package ru.adventurers.core.quest;

import ru.adventurers.core.profession.Profession;
import ru.adventurers.core.profile.Rank;

import java.util.List;
import java.util.Map;

/** Описание задания из quests.yml. */
public record QuestDef(
        String id,
        Rank minRank,
        Rank maxRank,
        String title,
        List<String> story,
        Type type,
        String target,
        int amount,
        int points,
        Map<Profession, Integer> professionXp,
        List<ItemReward> items,
        List<String> commands,
        boolean repeatable) {

    public enum Type { KILL, DELIVER }

    public record ItemReward(String material, int amount, String name) {
    }

    public boolean availableFor(Rank rank) {
        return rank.isAtLeast(minRank) && maxRank.isAtLeast(rank);
    }
}
