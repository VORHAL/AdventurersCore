package ru.adventurers.core.quest;

import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;

public class QuestListener implements Listener {

    private final QuestManager quests;
    private final ru.adventurers.core.party.PartyManager parties;

    public QuestListener(QuestManager quests, ru.adventurers.core.party.PartyManager parties) {
        this.quests = quests;
        this.parties = parties;
    }

    // Мобы из спавнеров, яиц, разведения и големы не дают прогресс заданий.
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        quests.getGuard().onSpawn(event.getEntity(), event.getSpawnReason());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        if (event.getEntity() instanceof Player || event.getEntity() instanceof ArmorStand) {
            return;
        }
        Player killer = event.getEntity().getKiller();
        if (killer != null && quests.getGuard().allow(killer, event.getEntity())) {
            // Убийство засчитывается всей группе, если участники рядом
            var glory = org.bukkit.plugin.java.JavaPlugin.getPlugin(ru.adventurers.core.AdventurersCore.class).getGlory();
            if (glory != null) {
                glory.add(killer, "KILLS", 1);
            }
            var pets = org.bukkit.plugin.java.JavaPlugin.getPlugin(ru.adventurers.core.AdventurersCore.class).getPets();
            if (pets != null) {
                pets.onKill(killer);
            }
            String type = event.getEntity().getType().name();
            var contracts = org.bukkit.plugin.java.JavaPlugin.getPlugin(ru.adventurers.core.AdventurersCore.class).getContracts();
            for (Player member : parties.shareTargets(killer)) {
                quests.onKill(member, type);
                if (contracts != null) {
                    contracts.progress(member, "KILL", type, 1);
                }
            }
        }
    }
}
