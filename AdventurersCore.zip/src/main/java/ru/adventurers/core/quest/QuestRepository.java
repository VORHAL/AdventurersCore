package ru.adventurers.core.quest;

import ru.adventurers.core.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;

/** Таблицы player_quests и player_guild_points. Методы блокирующие. */
public class QuestRepository {

    private final DatabaseManager database;

    public QuestRepository(DatabaseManager database) {
        this.database = database;
    }

    public void createTables() throws SQLException {
        String quests = """
                CREATE TABLE IF NOT EXISTS player_quests (
                    uuid CHAR(36) NOT NULL,
                    quest_id VARCHAR(64) NOT NULL,
                    state VARCHAR(12) NOT NULL,
                    progress INT UNSIGNED NOT NULL DEFAULT 0,
                    accepted_day INT NOT NULL DEFAULT 0,
                    completed_day INT NOT NULL DEFAULT 0,
                    PRIMARY KEY (uuid, quest_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        String points = """
                CREATE TABLE IF NOT EXISTS player_guild_points (
                    uuid CHAR(36) NOT NULL PRIMARY KEY,
                    points INT UNSIGNED NOT NULL DEFAULT 0
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        try (Connection connection = database.getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(quests)) {
                statement.executeUpdate();
            }
            try (PreparedStatement statement = connection.prepareStatement(points)) {
                statement.executeUpdate();
            }
            // Колонка добавлена позже: для старых таблиц докидываем
            try (PreparedStatement statement = connection.prepareStatement(
                    "ALTER TABLE player_guild_points ADD COLUMN IF NOT EXISTS "
                            + "completed INT UNSIGNED NOT NULL DEFAULT 0")) {
                statement.executeUpdate();
            }
        }
    }

    public PlayerQuests load(UUID uuid) throws SQLException {
        PlayerQuests data = new PlayerQuests();
        try (Connection connection = database.getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT quest_id, state, progress, accepted_day, completed_day FROM player_quests WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        PlayerQuests.Entry entry = new PlayerQuests.Entry();
                        entry.state = switch (String.valueOf(result.getString(2))) {
                            case "DONE" -> PlayerQuests.State.DONE;
                            case "ABANDONED" -> PlayerQuests.State.ABANDONED;
                            default -> PlayerQuests.State.ACTIVE;
                        };
                        entry.progress = result.getInt(3);
                        entry.acceptedDay = result.getLong(4);
                        entry.completedDay = result.getLong(5);
                        data.entries().put(result.getString(1), entry);
                    }
                }
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT points, completed FROM player_guild_points WHERE uuid = ?")) {
                statement.setString(1, uuid.toString());
                try (ResultSet result = statement.executeQuery()) {
                    if (result.next()) {
                        data.setPoints(result.getInt(1));
                        data.setCompleted(result.getInt(2));
                    }
                }
            }
        }
        return data;
    }

    public void save(UUID uuid, PlayerQuests data) throws SQLException {
        try (Connection connection = database.getConnection()) {
            if (!data.entries().isEmpty()) {
                String sql = """
                        INSERT INTO player_quests (uuid, quest_id, state, progress, accepted_day, completed_day)
                        VALUES (?, ?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE
                            state = VALUES(state), progress = VALUES(progress),
                            accepted_day = VALUES(accepted_day), completed_day = VALUES(completed_day)
                        """;
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    for (Map.Entry<String, PlayerQuests.Entry> entry : data.entries().entrySet()) {
                        statement.setString(1, uuid.toString());
                        statement.setString(2, entry.getKey());
                        statement.setString(3, entry.getValue().state.name());
                        statement.setInt(4, Math.max(0, entry.getValue().progress));
                        statement.setLong(5, entry.getValue().acceptedDay);
                        statement.setLong(6, entry.getValue().completedDay);
                        statement.addBatch();
                    }
                    statement.executeBatch();
                }
            }
            try (PreparedStatement statement = connection.prepareStatement("""
                    INSERT INTO player_guild_points (uuid, points, completed) VALUES (?, ?, ?)
                    ON DUPLICATE KEY UPDATE points = VALUES(points), completed = VALUES(completed)
                    """)) {
                statement.setString(1, uuid.toString());
                statement.setInt(2, data.getPoints());
                statement.setInt(3, data.getCompleted());
                statement.executeUpdate();
            }
        }
    }

    public void deleteQuests(UUID uuid) throws SQLException {
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "DELETE FROM player_quests WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            statement.executeUpdate();
        }
    }
}
