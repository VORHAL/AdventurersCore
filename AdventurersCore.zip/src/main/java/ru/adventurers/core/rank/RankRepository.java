package ru.adventurers.core.rank;

import ru.adventurers.core.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;

/** Таблица player_rank_since: когда игрок получил текущий ранг. Методы блокирующие. */
public class RankRepository {

    private final DatabaseManager database;

    public RankRepository(DatabaseManager database) {
        this.database = database;
    }

    public void createTable() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS player_rank_since (
                    uuid CHAR(36) NOT NULL PRIMARY KEY,
                    since TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }
    }

    /** Возвращает время получения ранга; если записи нет, создаёт её с текущим временем. */
    public Instant loadOrCreate(UUID uuid) throws SQLException {
        try (Connection connection = database.getConnection()) {
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT IGNORE INTO player_rank_since (uuid) VALUES (?)")) {
                insert.setString(1, uuid.toString());
                insert.executeUpdate();
            }
            try (PreparedStatement select = connection.prepareStatement(
                    "SELECT since FROM player_rank_since WHERE uuid = ?")) {
                select.setString(1, uuid.toString());
                try (ResultSet result = select.executeQuery()) {
                    if (result.next()) {
                        Timestamp timestamp = result.getTimestamp(1);
                        if (timestamp != null) {
                            return timestamp.toInstant();
                        }
                    }
                }
            }
        }
        return Instant.now();
    }

    public void save(UUID uuid, Instant since) throws SQLException {
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement("""
                     INSERT INTO player_rank_since (uuid, since) VALUES (?, ?)
                     ON DUPLICATE KEY UPDATE since = VALUES(since)
                     """)) {
            statement.setString(1, uuid.toString());
            statement.setTimestamp(2, Timestamp.from(since));
            statement.executeUpdate();
        }
    }
}
