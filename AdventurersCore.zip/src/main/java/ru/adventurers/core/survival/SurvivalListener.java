package ru.adventurers.core.survival;

import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.SmithItemEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Iterator;

public class SurvivalListener implements Listener {

    private final SurvivalManager survival;

    public SurvivalListener(SurvivalManager survival) {
        this.survival = survival;
    }

    // Броня, оружие и станции остаются у игрока, выпадают только материалы.
    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        if (event.getKeepInventory()) {
            return;
        }
        Iterator<ItemStack> iterator = event.getDrops().iterator();
        while (iterator.hasNext()) {
            ItemStack item = iterator.next();
            if (survival.shouldKeepOnDeath(item)) {
                event.getItemsToKeep().add(item);
                iterator.remove();
            }
        }
    }

    // Выданную экипировку нельзя выбросить (клавиша Q, перетаскивание за окно инвентаря).
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (survival.isDropLocked(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            survival.warnDrop(event.getPlayer());
        }
    }

    // Голод не тратится: разрешаем только рост сытости.
    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent event) {
        if (!survival.isHungerDisabled() || !(event.getEntity() instanceof Player player)) {
            return;
        }
        if (event.getFoodLevel() < player.getFoodLevel()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (survival.isHungerDisabled()) {
            event.getPlayer().setFoodLevel(20);
            event.getPlayer().setSaturation(20f);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        survival.forget(event.getPlayer().getUniqueId());
    }

    // Ванильное лечение от сытости отключено: лечим сами после выхода из боя.
    @EventHandler(ignoreCancelled = true)
    public void onRegain(EntityRegainHealthEvent event) {
        if (!survival.isCustomRegen() || !(event.getEntity() instanceof Player)) {
            return;
        }
        EntityRegainHealthEvent.RegainReason reason = event.getRegainReason();
        if (reason == EntityRegainHealthEvent.RegainReason.SATIATED
                || reason == EntityRegainHealthEvent.RegainReason.REGEN) {
            event.setCancelled(true);
        }
    }

    // Любой урон по игроку и любой урон от игрока считается боем.
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player victim) {
            survival.markCombat(victim.getUniqueId());
        }
        if (event instanceof EntityDamageByEntityEvent byEntity) {
            Entity damager = byEntity.getDamager();
            if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter) {
                damager = shooter;
            }
            if (damager instanceof Player attacker) {
                survival.markCombat(attacker.getUniqueId());
            }
        }
    }

    // Ранговая броня и оружие не ломаются.
    @EventHandler(ignoreCancelled = true)
    public void onItemDamage(PlayerItemDamageEvent event) {
        if (survival.isUnbreakable(event.getItem())) {
            event.setCancelled(true);
        }
    }

    // Экипировку нельзя создать из добытых материалов.
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (event.getRecipe() == null || !(event.getView().getPlayer() instanceof Player player)) {
            return;
        }
        Material result = event.getRecipe().getResult().getType();
        if (survival.isCraftBlocked(result) && !survival.canBypassCrafting(player)) {
            event.getInventory().setResult(null);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        Material result = event.getRecipe().getResult().getType();
        if (survival.isCraftBlocked(result) && !survival.canBypassCrafting(player)) {
            event.setCancelled(true);
            survival.warnCraft(player, result);
        }
    }

    @EventHandler
    public void onPrepareSmithing(PrepareSmithingEvent event) {
        ItemStack result = event.getResult();
        if (result == null || !(event.getView().getPlayer() instanceof Player player)) {
            return;
        }
        if (survival.isCraftBlocked(result.getType()) && !survival.canBypassCrafting(player)) {
            event.setResult(null);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSmith(SmithItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        ItemStack result = event.getCurrentItem();
        if (result != null && survival.isCraftBlocked(result.getType())
                && !survival.canBypassCrafting(player)) {
            event.setCancelled(true);
            survival.warnCraft(player, result.getType());
        }
    }
}
