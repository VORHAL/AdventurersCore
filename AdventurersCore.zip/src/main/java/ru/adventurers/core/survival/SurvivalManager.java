package ru.adventurers.core.survival;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.profession.ProfessionManager;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Правила выживания: смерть, голод, регенерация, прочность, запрет крафта экипировки. Только основной поток. */
public class SurvivalManager {

    /** Ключ метки «ранговый предмет» (PersistentDataContainer). */
    public static NamespacedKey rankGearKey(AdventurersCore plugin) {
        return new NamespacedKey(plugin, "rank_gear");
    }

    private static final long WARNING_COOLDOWN_MS = 5_000L;

    private final AdventurersCore plugin;
    private final ProfessionManager professions;
    private final NamespacedKey gearKey;

    private final Map<UUID, Long> lastCombat = new HashMap<>();
    private final Map<UUID, Long> lastWarning = new HashMap<>();

    private boolean keepGear;
    private boolean keepStations;
    private boolean hungerDisabled;
    private boolean customRegen;
    private boolean gearUnbreakable;
    private boolean blockGearCrafting;
    private boolean dropLock;
    private long combatDelayMs;
    private double regenPercent;
    private List<String> gearRules = new ArrayList<>();
    private List<String> craftRules = new ArrayList<>();
    private BukkitTask regenTask;

    public SurvivalManager(AdventurersCore plugin, ProfessionManager professions) {
        this.plugin = plugin;
        this.professions = professions;
        this.gearKey = rankGearKey(plugin);
    }

    public void init() {
        reload();
        regenTask = Bukkit.getScheduler().runTaskTimer(plugin, this::regenTick, 20L, 20L);
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "survival.yml");
        if (!file.exists()) {
            plugin.saveResource("survival.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        keepGear = cfg.getBoolean("death.keep-gear", true);
        keepStations = cfg.getBoolean("death.keep-stations", true);
        hungerDisabled = cfg.getBoolean("hunger.disabled", true);
        customRegen = cfg.getBoolean("regen.custom", true);
        combatDelayMs = Math.max(0, cfg.getInt("regen.out-of-combat-seconds", 8)) * 1000L;
        regenPercent = Math.max(0, cfg.getInt("regen.percent-per-second", 5));
        gearUnbreakable = cfg.getBoolean("durability.gear-unbreakable", true);
        blockGearCrafting = cfg.getBoolean("crafting.block-gear-crafting", true);
        gearRules = upper(cfg.getStringList("gear-items"));
        craftRules = upper(cfg.getStringList("craft-block"));
        dropLock = cfg.getBoolean("drop.lock-issued-gear", true);
    }

    public void shutdown() {
        if (regenTask != null) {
            regenTask.cancel();
            regenTask = null;
        }
        lastCombat.clear();
        lastWarning.clear();
    }

    private static List<String> upper(List<String> source) {
        List<String> result = new ArrayList<>();
        if (source != null) {
            for (String value : source) {
                if (value != null && !value.isBlank()) {
                    result.add(value.trim().toUpperCase(Locale.ROOT));
                }
            }
        }
        return result;
    }

    private static boolean matches(List<String> rules, Material material) {
        String name = material.name();
        for (String rule : rules) {
            if (rule.startsWith("_") ? name.endsWith(rule) : name.equals(rule)) {
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------
    //  Вопросы к правилам
    // ---------------------------------------------------------------

    public boolean isKeepGear() {
        return keepGear;
    }

    public boolean isHungerDisabled() {
        return hungerDisabled;
    }

    public boolean isCustomRegen() {
        return customRegen;
    }

    public boolean isBlockGearCrafting() {
        return blockGearCrafting;
    }

    public boolean isRankGear(ItemStack item) {
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(gearKey, PersistentDataType.STRING);
    }

    /** Выданную Гильдией экипировку (броню, оружие, инструмент) нельзя выбросить. */
    public boolean isDropLocked(ItemStack item) {
        return dropLock && isRankGear(item);
    }

    private long lastDropWarn(UUID uuid) {
        return lastWarning.getOrDefault(uuid, 0L);
    }

    public void warnDrop(Player player) {
        long now = System.currentTimeMillis();
        if (now - lastDropWarn(player.getUniqueId()) < WARNING_COOLDOWN_MS) {
            return;
        }
        lastWarning.put(player.getUniqueId(), now);
        plugin.getMessages().send(player, "survival.drop-denied");
    }

    /** Экипировка: по списку gear-items или по метке рангового предмета. */
    public boolean isGear(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            return false;
        }
        return matches(gearRules, item.getType()) || isRankGear(item);
    }

    /** Предмет не выпадает при смерти. */
    public boolean shouldKeepOnDeath(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            return false;
        }
        if (keepGear && isGear(item)) {
            return true;
        }
        return keepStations && professions.isStation(item.getType());
    }

    public boolean isUnbreakable(ItemStack item) {
        return gearUnbreakable && isGear(item);
    }

    public boolean isCraftBlocked(Material material) {
        return blockGearCrafting && matches(craftRules, material);
    }

    public boolean canBypassCrafting(Player player) {
        return player.hasPermission("ag.bypass.gearcraft");
    }

    public void warnCraft(Player player, Material material) {
        long now = System.currentTimeMillis();
        Long last = lastWarning.get(player.getUniqueId());
        if (last != null && now - last < WARNING_COOLDOWN_MS) {
            return;
        }
        lastWarning.put(player.getUniqueId(), now);
        plugin.getMessages().send(player, "survival.craft-gear-denied", Map.of(
                "item", Component.translatable(material.translationKey())));
    }

    // ---------------------------------------------------------------
    //  Бой и регенерация
    // ---------------------------------------------------------------

    public void markCombat(UUID uuid) {
        lastCombat.put(uuid, System.currentTimeMillis());
    }

    /** Игрок в бою: последний урон (нанесённый или полученный) был не раньше, чем out-of-combat-seconds назад. */
    public boolean isInCombat(UUID uuid) {
        Long last = lastCombat.get(uuid);
        return last != null && System.currentTimeMillis() - last < Math.max(combatDelayMs, 1000L);
    }

    public void forget(UUID uuid) {
        lastCombat.remove(uuid);
        lastWarning.remove(uuid);
    }

    private void regenTick() {
        if (!customRegen) {
            return;
        }
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.isDead()) {
                continue;
            }
            AttributeInstance maxAttribute = player.getAttribute(Attribute.MAX_HEALTH);
            if (maxAttribute == null) {
                continue;
            }
            double max = maxAttribute.getValue();
            double health = player.getHealth();
            if (health >= max) {
                continue;
            }
            Long last = lastCombat.get(player.getUniqueId());
            if (last != null && now - last < combatDelayMs) {
                continue;
            }
            double bonus = plugin.getGems() != null
                    ? plugin.getGems().power(player, ru.adventurers.core.gem.GemManager.Effect.REGEN) * 100.0 : 0.0;
            double percent = regenPercent + bonus;
            if (percent <= 0) {
                continue;
            }
            double heal = Math.max(0.5, max * percent / 100.0);
            player.setHealth(Math.min(max, health + heal));
        }
    }
}
