package ru.adventurers.core.tank;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;

import java.util.UUID;

/** Управление умениями Танка (с Shift и щитом в левой руке) и их действие в бою. */
public class TankListener implements Listener {

    private final TankManager tank;
    private final java.util.Map<UUID, Long> lastClick = new java.util.HashMap<>();

    public TankListener(TankManager tank) {
        this.tank = tank;
    }

    private boolean ready(Player player) {
        return tank.isEnabled() && player.isSneaking() && tank.canUse(player) && tank.hasShield(player);
    }

    // Shift + ПКМ в воздух: провокация. Shift + ЛКМ в воздух: рывок.
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.LEFT_CLICK_AIR) {
            return;
        }
        // Один клик порождает события для обеих рук: берём только первое.
        long now = System.currentTimeMillis();
        Long last = lastClick.get(event.getPlayer().getUniqueId());
        if (last != null && now - last < 150) {
            return;
        }
        Player player = event.getPlayer();
        if (!ready(player)) {
            return;
        }
        lastClick.put(player.getUniqueId(), now);
        if (action == Action.RIGHT_CLICK_AIR) {
            tank.taunt(player);
        } else {
            tank.dash(player);
        }
    }

    // Shift + F: стена щитов (обычная смена рук с Shift у Танка со щитом отключена).
    @EventHandler(priority = EventPriority.HIGH)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (ready(player)) {
            event.setCancelled(true);
            tank.wall(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHurt(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player) {
            double multiplier = tank.wallMultiplier(player);
            if (multiplier < 1.0) {
                event.setDamage(event.getDamage() * multiplier);
            }
        }
    }

    // Спровоцированные монстры не переключаются на других игроков.
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onTarget(EntityTargetLivingEntityEvent event) {
        UUID taunter = tank.taunter(event.getEntity().getUniqueId());
        if (taunter != null && (event.getTarget() == null || !event.getTarget().getUniqueId().equals(taunter))) {
            var player = org.bukkit.Bukkit.getPlayer(taunter);
            if (player != null && !player.isDead()) {
                event.setTarget(player);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        tank.forget(event.getPlayer().getUniqueId());
        lastClick.remove(event.getPlayer().getUniqueId());
    }
}
