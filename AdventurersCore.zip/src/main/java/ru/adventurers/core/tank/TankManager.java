package ru.adventurers.core.tank;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.survival.SurvivalManager;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Умения Танка при щите в левой руке: Провокация, Стена щитов, Рывок щитом.
 * Настройки: tank.yml. Только основной поток.
 */
public class TankManager {

    private record Taunt(UUID tank, long until) {
    }

    private record Wall(double reduction, long until) {
    }

    private static final double[] RANKS8 = {0, 0, 0, 0, 0, 0, 0, 0};

    private final AdventurersCore plugin;
    private final NamespacedKey shieldKey;
    private final Map<UUID, Taunt> taunts = new HashMap<>();
    private final Map<UUID, Wall> walls = new HashMap<>();
    private final Map<UUID, Long> tauntReady = new HashMap<>();
    private final Map<UUID, Long> wallReady = new HashMap<>();
    private final Map<UUID, Long> dashReady = new HashMap<>();
    private final Map<UUID, Long> lastHint = new HashMap<>();

    private boolean enabled = true;
    private double universalFactor = 0.6;
    private long tauntCooldown = 20000;
    private double[] tauntRadius = {6, 6, 7, 7, 8, 8, 9, 10};
    private double[] tauntDuration = {4, 4, 5, 5, 6, 6, 7, 8};
    private double[] tauntDamage = {1, 1, 2, 2, 3, 3, 4, 5};
    private long wallCooldown = 45000;
    private double[] wallDuration = {3, 3, 4, 4, 5, 5, 6, 6};
    private double[] wallReduction = {0.4, 0.4, 0.45, 0.5, 0.5, 0.55, 0.6, 0.65};
    private double wallShare = 0.4;
    private double wallRadius = 8;
    private long dashCooldown = 12000;
    private double dashSpeed = 1.3;
    private double[] dashDamage = {2, 2, 3, 3, 4, 5, 6, 7};
    private int stunTicks = 30;
    private BukkitTask task;

    public TankManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.shieldKey = new NamespacedKey(plugin, "tank_shield");
    }

    public void init() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 10L);
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        taunts.clear();
        walls.clear();
    }

    private static double[] list(List<?> raw, double[] fallback) {
        if (raw == null || raw.size() < 8) {
            return fallback;
        }
        double[] result = new double[8];
        for (int i = 0; i < 8; i++) {
            result[i] = raw.get(i) instanceof Number number ? number.doubleValue() : fallback[i];
        }
        return result;
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "tank.yml");
        if (!file.exists()) {
            plugin.saveResource("tank.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        universalFactor = cfg.getDouble("universal-factor", 0.6);
        tauntCooldown = (long) (cfg.getDouble("taunt.cooldown-seconds", 20) * 1000);
        tauntRadius = list(cfg.getList("taunt.radius"), tauntRadius);
        tauntDuration = list(cfg.getList("taunt.duration-seconds"), tauntDuration);
        tauntDamage = list(cfg.getList("taunt.damage"), tauntDamage);
        wallCooldown = (long) (cfg.getDouble("wall.cooldown-seconds", 45) * 1000);
        wallDuration = list(cfg.getList("wall.duration-seconds"), wallDuration);
        wallReduction = list(cfg.getList("wall.reduction"), wallReduction);
        wallShare = cfg.getDouble("wall.ally-share", 0.4);
        wallRadius = cfg.getDouble("wall.ally-radius", 8);
        dashCooldown = (long) (cfg.getDouble("dash.cooldown-seconds", 12) * 1000);
        dashSpeed = cfg.getDouble("dash.speed", 1.3);
        dashDamage = list(cfg.getList("dash.damage"), dashDamage);
        stunTicks = cfg.getInt("dash.stun-ticks", 30);
    }

    // ---------------------------------------------------------------
    //  Условия
    // ---------------------------------------------------------------

    public boolean isEnabled() {
        return enabled;
    }

    /** Сколько миллисекунд осталось до готовности умения (taunt, wall, dash); 0 если готово. */
    public long remaining(Player player, String skill) {
        Map<UUID, Long> map = switch (skill) {
            case "taunt" -> tauntReady;
            case "wall" -> wallReady;
            default -> dashReady;
        };
        Long until = map.get(player.getUniqueId());
        return until == null ? 0 : Math.max(0, until - System.currentTimeMillis());
    }

    /** Полная пауза умения в миллисекундах. */
    public long total(String skill) {
        return switch (skill) {
            case "taunt" -> tauntCooldown;
            case "wall" -> wallCooldown;
            default -> dashCooldown;
        };
    }

    private double rune(Player player, String stat) {
        return plugin.getRunes() == null ? 0 : plugin.getRunes().bonus(player, stat);
    }

    private long cd(Player player, long base, String stat) {
        return (long) (base * Math.max(0.3, 1.0 - rune(player, stat)));
    }

    public boolean canUse(Player player) {
        PlayerClass active = plugin.getClasses().activeClass(player.getUniqueId());
        return active == PlayerClass.TANK || active == PlayerClass.UNIVERSAL;
    }

    public boolean hasShield(Player player) {
        ItemStack off = player.getInventory().getItemInOffHand();
        return off != null && off.getType() == Material.SHIELD;
    }

    private double factor(Player player) {
        return plugin.getClasses().activeClass(player.getUniqueId()) == PlayerClass.UNIVERSAL ? universalFactor : 1.0;
    }

    private int rankIndex(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? 0 : Math.min(7, profile.getRank().ordinal());
    }

    private void bar(Player player, String key, String fallback, Map<String, String> values) {
        String text = plugin.getMessages().text(key, fallback);
        for (Map.Entry<String, String> entry : values.entrySet()) {
            text = text.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        plugin.getSkillHud().flash(player, Hud.legacy(text));
    }

    /** true, если умение готово. Иначе коротко сообщает, сколько осталось. */
    private boolean ready(Map<UUID, Long> map, Player player, String name) {
        long now = System.currentTimeMillis();
        Long until = map.get(player.getUniqueId());
        if (until != null && now < until) {
            Long last = lastHint.get(player.getUniqueId());
            if (last == null || now - last > 800) {
                lastHint.put(player.getUniqueId(), now);
                bar(player, "tank.cooldown", "&7{skill}: ещё {seconds} с",
                        Map.of("skill", name, "seconds", String.valueOf((until - now) / 1000 + 1)));
            }
            return false;
        }
        return true;
    }

    private void start(Map<UUID, Long> map, Player player, long cooldown) {
        map.put(player.getUniqueId(), System.currentTimeMillis() + cooldown);
    }

    // ---------------------------------------------------------------
    //  Провокация
    // ---------------------------------------------------------------

    public void taunt(Player player) {
        if (!ready(tauntReady, player, "Провокация")) {
            return;
        }
        int index = rankIndex(player);
        double radius = tauntRadius[index] * (1.0 + rune(player, "taunt_radius"));
        long until = System.currentTimeMillis() + (long) (tauntDuration[index] * factor(player) * (1.0 + rune(player, "taunt_duration")) * 1000);
        double damage = tauntDamage[index] * factor(player);
        int count = 0;
        for (var entity : player.getNearbyEntities(radius, radius, radius)) {
            if (entity instanceof Monster monster) {
                taunts.put(monster.getUniqueId(), new Taunt(player.getUniqueId(), until));
                monster.setTarget(player);
                monster.damage(damage, player);
                count++;
            }
        }
        if (count == 0) {
            bar(player, "tank.nobody", "&7Рядом нет врагов", Map.of());
            return;
        }
        start(tauntReady, player, tauntCooldown);
        Location at = player.getLocation();
        player.getWorld().playSound(at, Sound.ENTITY_RAVAGER_ROAR, 0.8f, 1.2f);
        player.getWorld().spawnParticle(Particle.ANGRY_VILLAGER, at.clone().add(0, 1.8, 0), 12, 0.6, 0.3, 0.6, 0);
        bar(player, "tank.taunt", "&9⛨ Провокация: враги &f{count}", Map.of("count", String.valueOf(count)));
    }

    /** Монстру, которого спровоцировали, нужен Танк: чужие цели отменяются. */
    public UUID taunter(UUID mob) {
        Taunt taunt = taunts.get(mob);
        if (taunt == null) {
            return null;
        }
        if (System.currentTimeMillis() > taunt.until()) {
            taunts.remove(mob);
            return null;
        }
        return taunt.tank();
    }

    // ---------------------------------------------------------------
    //  Стена щитов
    // ---------------------------------------------------------------

    public void wall(Player player) {
        if (!ready(wallReady, player, "Стена щитов")) {
            return;
        }
        start(wallReady, player, cd(player, wallCooldown, "wall_cooldown"));
        int index = rankIndex(player);
        double reduction = Math.min(0.85, (wallReduction[index] + rune(player, "wall_reduction")) * factor(player));
        long until = System.currentTimeMillis() + (long) (wallDuration[index] * factor(player) * 1000);
        walls.put(player.getUniqueId(), new Wall(reduction, until));
        int allies = 0;
        for (Player member : plugin.getParties().shareTargets(player)) {
            if (!member.equals(player) && member.getWorld().equals(player.getWorld())
                    && member.getLocation().distanceSquared(player.getLocation()) <= wallRadius * wallRadius) {
                walls.put(member.getUniqueId(), new Wall(reduction * wallShare, until));
                bar(member, "tank.wall-ally", "&9⛨ {player} прикрывает тебя щитом",
                        Map.of("player", player.getName()));
                allies++;
            }
        }
        Location at = player.getLocation();
        player.getWorld().playSound(at, Sound.ITEM_SHIELD_BLOCK, 1.0f, 0.7f);
        player.getWorld().spawnParticle(Particle.CRIT, at.clone().add(0, 1, 0), 30, 0.7, 0.8, 0.7, 0.2);
        bar(player, "tank.wall", "&9⛨ Стена щитов: -{percent}% урона, союзников {count}",
                Map.of("percent", String.valueOf(Math.round(reduction * 100)), "count", String.valueOf(allies)));
    }

    /** Множитель входящего урона (1.0 = защиты нет). */
    public double wallMultiplier(Player player) {
        Wall wall = walls.get(player.getUniqueId());
        if (wall == null) {
            return 1.0;
        }
        if (System.currentTimeMillis() > wall.until()) {
            walls.remove(player.getUniqueId());
            return 1.0;
        }
        return 1.0 - wall.reduction();
    }

    // ---------------------------------------------------------------
    //  Рывок щитом
    // ---------------------------------------------------------------

    public void dash(Player player) {
        if (!ready(dashReady, player, "Рывок щитом")) {
            return;
        }
        start(dashReady, player, cd(player, dashCooldown, "dash_cooldown"));
        double damage = dashDamage[rankIndex(player)] * factor(player) * (1.0 + rune(player, "dash_damage"));
        Vector direction = player.getLocation().getDirection().setY(0);
        if (direction.lengthSquared() < 0.0001) {
            direction = new Vector(0, 0, 1);
        }
        direction.normalize();
        Vector push = direction.clone().multiply(dashSpeed * (0.8 + 0.2 * factor(player))).setY(0.15);
        player.setVelocity(push);
        player.setFallDistance(0f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.8f);
        bar(player, "tank.dash", "&9⛨ Рывок щитом!", Map.of());

        Set<UUID> hit = new HashSet<>();
        Vector knock = direction.clone();
        int[] ticks = {0};
        Bukkit.getScheduler().runTaskTimer(plugin, runnable -> {
            if (!player.isOnline() || ticks[0]++ > 8) {
                runnable.cancel();
                return;
            }
            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation().add(0, 0.3, 0), 3, 0.2, 0.1, 0.2, 0.01);
            for (var entity : player.getNearbyEntities(1.6, 1.2, 1.6)) {
                if (entity instanceof LivingEntity living && !(entity instanceof Player)
                        && !(entity instanceof ArmorStand) && hit.add(entity.getUniqueId())) {
                    living.damage(damage, player);
                    living.setVelocity(knock.clone().multiply(0.9).setY(0.35));
                    living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
                            (int) (stunTicks * factor(player)), 4, false, true, true));
                }
            }
        }, 1L, 1L);
    }

    // ---------------------------------------------------------------
    //  Периодика и щит
    // ---------------------------------------------------------------

    private void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Taunt>> iterator = taunts.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Taunt> entry = iterator.next();
            Taunt taunt = entry.getValue();
            var entity = Bukkit.getEntity(entry.getKey());
            Player tank = Bukkit.getPlayer(taunt.tank());
            if (now > taunt.until() || !(entity instanceof Mob mob) || mob.isDead() || tank == null || tank.isDead()) {
                iterator.remove();
                continue;
            }
            if (!tank.equals(mob.getTarget())) {
                mob.setTarget(tank);
            }
        }
        walls.values().removeIf(wall -> now > wall.until());
    }

    public void forget(UUID uuid) {
        walls.remove(uuid);
        tauntReady.remove(uuid);
        wallReady.remove(uuid);
        dashReady.remove(uuid);
        lastHint.remove(uuid);
    }

    /** Выдаёт ранговый Щит Танка; прежний такой щит заменяется. */
    public void giveShield(Player player) {
        if (!enabled || !canUse(player)) {
            plugin.getMessages().send(player, "tank.shield-denied");
            return;
        }
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        Rank rank = profile == null ? Rank.F : profile.getRank();
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isTankShield(contents[i])) {
                player.getInventory().setItem(i, null);
            }
        }
        if (isTankShield(player.getInventory().getItemInOffHand())) {
            player.getInventory().setItemInOffHand(null);
        }
        ItemStack shield = new ItemStack(Material.SHIELD, 1);
        ItemMeta meta = shield.getItemMeta();
        meta.displayName(Hud.legacy("<gradient:#4f8cff:#7ad7ff>&l⛨ Щит Танка</gradient> &8["
                + plugin.getMessages().rankName(rank) + "&8]").decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String line : new String[]{
                "&8Принадлежит Танку. Нельзя выбросить.", "",
                "&7Держи в левой руке. С Shift:",
                "&7ПКМ в воздух &8- &9Провокация",
                "&7F (смена рук) &8- &9Стена щитов",
                "&7ЛКМ в воздух &8- &9Рывок щитом"}) {
            lore.add(Hud.legacy(line).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        meta.setUnbreakable(true);
        ru.adventurers.core.hud.PackItems.model(meta, "shield_tank");
        PersistentDataContainer data = meta.getPersistentDataContainer();
        data.set(shieldKey, PersistentDataType.BYTE, (byte) 1);
        data.set(SurvivalManager.rankGearKey(plugin), PersistentDataType.STRING, rank.name());
        shield.setItemMeta(meta);
        Map<Integer, ItemStack> left = player.getInventory().addItem(shield);
        for (ItemStack extra : left.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
        plugin.getMessages().send(player, "tank.shield-given");
    }

    public boolean isTankShield(ItemStack item) {
        return item != null && item.getType() != Material.AIR && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(shieldKey, PersistentDataType.BYTE);
    }
}
