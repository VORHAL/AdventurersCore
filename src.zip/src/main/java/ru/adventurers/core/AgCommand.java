package ru.adventurers.core;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.classes.ClassManager;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.classes.PlayerClasses;
import ru.adventurers.core.gear.GearManager;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.quest.QuestDef;
import ru.adventurers.core.quest.QuestManager;
import ru.adventurers.core.rank.RankManager;
import ru.adventurers.core.profession.PlayerProfessions;
import ru.adventurers.core.profession.Profession;
import ru.adventurers.core.profession.ProfessionManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.ProfileManager;
import ru.adventurers.core.profile.Rank;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AgCommand implements CommandExecutor, TabCompleter {

    private final AdventurersCore plugin;
    private final ProfileManager profiles;
    private final MessageManager messages;
    private final GearManager gear;
    private final ProfessionManager professions;

    // Имена меню DeluxeMenus (файлы plugins/DeluxeMenus/menus/<имя>.yml)
    private static final String MENU_MAIN = "ag_main";
    private static final String MENU_PROFESSIONS = "ag_professions";
    private static final String MENU_WORKSHOP = "ag_workshop";
    private static final String MENU_GUIDE = "ag_guide";
    private static final String MENU_CLASSES = "ag_classes";
    private static final String MENU_QUESTS = "ag_quests";
    private static final String MENU_RANK = "ag_rank";

    public AgCommand(AdventurersCore plugin, ProfileManager profiles,
                     MessageManager messages, GearManager gear,
                     ProfessionManager professions) {
        this.plugin = plugin;
        this.profiles = profiles;
        this.messages = messages;
        this.gear = gear;
        this.professions = professions;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command,
                             String label, String[] args) {

        if (args.length > 0 && args[0].equalsIgnoreCase("admin")) {
            return handleAdmin(sender, args);
        }

        if (!(sender instanceof Player player)) {
            messages.send(sender, "commands.only-players");
            return true;
        }

        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        if (profile == null) {
            messages.send(player, "profile.loading");
            return true;
        }

        // Пол обязателен до начала игры: пока не выбран, меню гильдии закрыто.
        // Исключение - сама команда /ag gender, иначе игрок не смог бы выбрать.
        boolean choosingGender = args.length > 0 && args[0].equalsIgnoreCase("gender");
        if (!choosingGender && plugin.getGender().needsChoice(player)) {
            messages.send(player, "gender.required");
            plugin.getGender().openMenu(player);
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("menu")) {
            if (!openMenu(player, MENU_MAIN)) {
                messages.send(player, "commands.card", Map.of(
                        "player", profile.getUsername(),
                        "rank", messages.rankName(profile.getRank())
                ));
            }
        } else if (args[0].equalsIgnoreCase("guide") || args[0].equalsIgnoreCase("help")) {
            if (!openMenu(player, MENU_GUIDE)) {
                messages.send(player, "commands.help");
            }
        } else if (args[0].equalsIgnoreCase("rank")) {
            if (args.length > 1 && args[1].equalsIgnoreCase("promote")) {
                selfPromote(player);
            } else if (!openMenu(player, MENU_RANK)) {
                showRank(player, profile);
            }
            // цепочка первых шагов (раздел 24): игрок нашёл главное меню
            if (plugin.getOnboarding() != null) {
                plugin.getOnboarding().complete(player, "menu-opened");
            }
        } else if (args[0].equalsIgnoreCase("sb") || args[0].equalsIgnoreCase("scoreboard")) {
            boolean visible = plugin.getScoreboard().toggle(player);
            messages.send(player, visible ? "scoreboard.shown" : "scoreboard.hidden");
        } else if (args[0].equalsIgnoreCase("group")) {
            plugin.getParties().handle(player, ru.adventurers.core.party.Party.Type.GROUP, args);
        } else if (args[0].equalsIgnoreCase("raid")) {
            plugin.getParties().handle(player, ru.adventurers.core.party.Party.Type.RAID, args);
        } else if (args[0].equalsIgnoreCase("quest") || args[0].equalsIgnoreCase("quests")) {
            handleQuest(player, args);
        } else if (args[0].equalsIgnoreCase("passive") || args[0].equalsIgnoreCase("passives")) {
            plugin.getGems().showPassives(player);
        } else if (args[0].equalsIgnoreCase("gem") || args[0].equalsIgnoreCase("gems")) {
            handleGem(player, args);
        } else if (args[0].equalsIgnoreCase("donate") || args[0].equalsIgnoreCase("shop")
                || args[0].equalsIgnoreCase("донат") || args[0].equalsIgnoreCase("магазин")) {
            plugin.getDonate().open(player);
        } else if (args[0].equalsIgnoreCase("event") || args[0].equalsIgnoreCase("events")
                || args[0].equalsIgnoreCase("ивент") || args[0].equalsIgnoreCase("испытание")) {
            handleEvent(player, args);
        } else if (args[0].equalsIgnoreCase("gender") || args[0].equalsIgnoreCase("пол")) {
            handleGender(player, args);
        } else if (args[0].equalsIgnoreCase("world") || args[0].equalsIgnoreCase("ascended")
                || args[0].equalsIgnoreCase("избранные")) {
            handleAscended(player, args);
        } else if (args[0].equalsIgnoreCase("start") || args[0].equalsIgnoreCase("старт")) {
            var onboarding = plugin.getOnboarding();
            messages.send(player, "onboarding.header");
            for (String line : onboarding.describe(player)) {
                player.sendMessage(Hud.legacy(line));
            }
        } else if (args[0].equalsIgnoreCase("skills") || args[0].equalsIgnoreCase("умения")) {
            var abilities = plugin.getAbilities();
            messages.send(player, "abilities.header");
            for (String line : abilities.describe(player)) {
                player.sendMessage(Hud.legacy(line));
            }
            messages.send(player, "abilities.footer");
        } else if (args[0].equalsIgnoreCase("class")) {
            handleClass(player, args);
        } else if (args[0].equalsIgnoreCase("shop")) {
            plugin.getShop().open(player);
        } else if (args[0].equalsIgnoreCase("sell")) {
            String mode = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
            switch (mode) {
                case "hand" -> plugin.getEconomy().sellQuick(player, false);
                case "all" -> plugin.getEconomy().sellQuick(player, true);
                case "prices" -> plugin.getEconomy().prices(player);
                default -> plugin.getEconomy().openSell(player);
            }
        } else if (args[0].equalsIgnoreCase("ah") || args[0].equalsIgnoreCase("auction")) {
            if (args.length > 2 && args[1].equalsIgnoreCase("sell")) {
                plugin.getAuction().sell(player, args[2]);
            } else {
                plugin.getAuction().open(player);
            }
        } else if (args[0].equalsIgnoreCase("trade")) {
            if (plugin.getTradeManager() == null) {
                player.sendMessage(Hud.legacy("&cОбмен сейчас недоступен."));
            } else {
                plugin.getTradeManager().handle(player, args);
            }
        } else if (args[0].equalsIgnoreCase("pay")) {
            if (args.length < 3) {
                messages.send(player, "economy.pay-usage");
            } else {
                plugin.getEconomy().pay(player, args[1], args[2]);
            }
        } else if (args[0].equalsIgnoreCase("coins") || args[0].equalsIgnoreCase("bal")
                || args[0].equalsIgnoreCase("balance") || args[0].equalsIgnoreCase("money")) {
            messages.send(player, "economy.balance", Map.of("coins",
                    plugin.getEconomy().format(plugin.getEconomy().balance(player.getUniqueId()))));
        } else if (args[0].equalsIgnoreCase("bank")) {
            plugin.getEconomy().bankCommand(player, args);
        } else if (args[0].equalsIgnoreCase("covenant") || args[0].equalsIgnoreCase("cov")
                || args[0].equalsIgnoreCase("clan") || args[0].equalsIgnoreCase("ковенант")) {
            plugin.getCovenants().command(player, args);
        } else if (args[0].equalsIgnoreCase("glory") || args[0].equalsIgnoreCase("title")
                || args[0].equalsIgnoreCase("titles") || args[0].equalsIgnoreCase("слава")) {
            if (plugin.getGlory().isEnabled()) {
                plugin.getGlory().open(player);
            } else {
                messages.send(player, "glory.disabled");
            }
        } else if (args[0].equalsIgnoreCase("contracts") || args[0].equalsIgnoreCase("contract")
                || args[0].equalsIgnoreCase("заказы")) {
            plugin.getContracts().open(player);
        } else if (args[0].equalsIgnoreCase("invasion") || args[0].equalsIgnoreCase("inv")
                || args[0].equalsIgnoreCase("вторжение")) {
            plugin.getInvasions().command(player, args);
        } else if (args[0].equalsIgnoreCase("mentor") || args[0].equalsIgnoreCase("наставник")) {
            plugin.getMentors().command(player, args);
        } else if (args[0].equalsIgnoreCase("pet") || args[0].equalsIgnoreCase("pets")
                || args[0].equalsIgnoreCase("питомец")) {
            plugin.getPets().open(player);
        } else if (args[0].equalsIgnoreCase("craft") || args[0].equalsIgnoreCase("recipes")) {
            plugin.getRecipes().open(player, args.length > 1 ? args[1] : null);
        } else if (args[0].equalsIgnoreCase("rune") || args[0].equalsIgnoreCase("runes")) {
            handleRune(player, args);
        } else if (args[0].equalsIgnoreCase("dungeon") || args[0].equalsIgnoreCase("dg")) {
            handleDungeon(player, args);
        } else if (args[0].equalsIgnoreCase("frames")) {
            boolean on = plugin.getPartyFrames().toggle(player);
            messages.send(player, on ? "frames.on" : "frames.off");
        } else if (args[0].equalsIgnoreCase("work") || args[0].equalsIgnoreCase("workshop")) {
            if (professions.get(player.getUniqueId()) == null) {
                messages.send(player, "profile.loading");
                return true;
            }
            plugin.openWorkshop(player, args.length > 1 ? Profession.fromInput(args[1]) : null);
        } else if (args[0].equalsIgnoreCase("prof") || args[0].equalsIgnoreCase("profession")) {
            handleProf(player, args);
        } else {
            messages.send(player, "commands.unknown");
        }
        return true;
    }

    // /ag gem [list|info|cut|combine|socket|unsocket <номер>]
    private void handleGem(Player player, String[] args) {
        var gems = plugin.getGems();
        String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "cut" -> gems.cut(player);
            case "combine" -> gems.combine(player);
            case "socket" -> gems.socket(player);
            case "unsocket" -> {
                Integer index = args.length > 2 ? parseInt(args, 2) : null;
                if (index == null) {
                    messages.send(player, "gems.unsocket-usage");
                } else {
                    gems.unsocket(player, index);
                }
            }
            case "info" -> gems.info(player);
            case "list" -> gems.list(player);
            case "catalog", "book" -> plugin.getGemCatalog().open(player, 0);
            default -> messages.send(player, "gems.usage");
        }
    }

    /** Открывает меню DeluxeMenus. Возвращает false, если DeluxeMenus не установлен. */
    private boolean openMenu(Player player, String menu) {
        if (!plugin.getServer().getPluginManager().isPluginEnabled("DeluxeMenus")) {
            return false;
        }
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "dm open " + menu + " " + player.getName());
    }

    private void showRank(Player player, PlayerProfile profile) {
        Rank current = profile.getRank();
        Rank next = current.next();

        messages.send(player, "commands.rank.current", Map.of("rank", messages.rankName(current)));
        if (next == null) {
            messages.send(player, "commands.rank.max");
            return;
        }
        messages.send(player, "commands.rank.next", Map.of("next_rank", messages.rankName(next)));
        messages.send(player, "ranks.requirements-header");
        for (RankManager.Status status : plugin.getRanks().check(player)) {
            if (status.id().endsWith("-days")) {
                // Подсказка о сроке накопления взноса (не отдельное условие).
                String base = status.id().substring(0, status.id().length() - "-days".length());
                messages.send(player, "ranks.fee-days", Map.of(
                        "name", messages.text("ranks.names." + base, base),
                        "days", status.needed()));
                continue;
            }
            messages.send(player, "ranks.requirement-line", Map.of(
                    "name", messages.text("ranks.names." + status.id(), status.id()),
                    "current", status.current(),
                    "needed", status.needed(),
                    "mark", status.ok() ? "&a✔" : "&c✘"));
        }
        messages.send(player, plugin.getRanks().isSelfPromote()
                ? "ranks.hint-self" : "ranks.hint-master");
    }

    // Режим тестов (self-promote в ranks.yml): игрок сам повышает ранг
    private void selfPromote(Player player) {
        if (!plugin.getRanks().isSelfPromote() && !player.hasPermission("ag.admin")) {
            messages.send(player, "ranks.master-only");
            return;
        }
        reportPromotion(player, player, plugin.getRanks().promote(player, false));
    }

    private void reportPromotion(CommandSender sender, Player target, RankManager.PromoteResult result) {
        Map<String, Object> placeholders = Map.of("player", target.getName());
        switch (result) {
            case OK -> {
                if (sender != target) {
                    messages.send(sender, "ranks.admin.promoted", placeholders);
                }
            }
            case MAX_RANK -> messages.send(sender, "ranks.max-rank", placeholders);
            case REQUIREMENTS -> messages.send(sender, "ranks.not-ready", placeholders);
            case NO_COINS -> { }
            case NOT_LOADED -> messages.send(sender, "commands.admin.profile-loading");
        }
    }

    // ---------------------------------------------------------------
    //  /ag quest
    // ---------------------------------------------------------------

    private void handleQuest(Player player, String[] args) {
        QuestManager quests = plugin.getQuests();
        if (quests.get(player.getUniqueId()) == null) {
            messages.send(player, "profile.loading");
            return;
        }
        if (args.length == 1) {
            if (!openMenu(player, MENU_QUESTS)) {
                listQuests(player, quests);
            }
            return;
        }
        String action = args[1].toLowerCase(Locale.ROOT);
        if (action.equals("list")) {
            listQuests(player, quests);
            return;
        }
        Integer slot = args.length > 2 ? parseInt(args, 2) : null;
        if (slot == null || !(action.equals("accept") || action.equals("turnin") || action.equals("abandon"))) {
            messages.send(player, "quests.usage");
            return;
        }
        QuestDef def = quests.slot(player, slot);
        Map<String, Object> placeholders = Map.of(
                "title", def != null ? def.title() : "",
                "limit", quests.getDailyLimit(),
                "max", quests.getMaxActive());

        switch (action) {
            case "accept" -> {
                switch (quests.accept(player, slot)) {
                    case OK -> messages.send(player, "quests.accepted", placeholders);
                    case NO_SLOT -> messages.send(player, "quests.no-slot");
                    case ALREADY_ACTIVE -> messages.send(player, "quests.already-active", placeholders);
                    case DONE_TODAY -> messages.send(player, "quests.done-today", placeholders);
                    case DAILY_LIMIT -> messages.send(player, "quests.daily-limit", placeholders);
                    case TOO_MANY_ACTIVE -> messages.send(player, "quests.too-many-active", placeholders);
                    case NOT_LOADED -> messages.send(player, "profile.loading");
                }
            }
            case "turnin" -> {
                switch (quests.turnIn(player, slot)) {
                    case OK -> messages.send(player, "quests.completed", placeholders);
                    case NO_SLOT -> messages.send(player, "quests.no-slot");
                    case NOT_ACTIVE -> messages.send(player, "quests.not-active", placeholders);
                    case NOT_READY -> messages.send(player, "quests.not-ready", placeholders);
                    case NOT_LOADED -> messages.send(player, "profile.loading");
                }
            }
            default -> messages.send(player, quests.abandon(player, slot)
                    ? "quests.abandoned" : "quests.not-active", placeholders);
        }
    }

    // Запасной вариант без DeluxeMenus: список в чате
    private void listQuests(Player player, QuestManager quests) {
        messages.send(player, "quests.list-header", Map.of(
                "left", quests.dailyLeft(player), "limit", quests.getDailyLimit()));
        int slot = 1;
        for (QuestDef def : quests.board(player)) {
            messages.send(player, "quests.list-entry", Map.of(
                    "slot", slot,
                    "title", def.title(),
                    "goal", quests.goalText(def),
                    "state", quests.state(player, slot)));
            slot++;
        }
    }

    // ---------------------------------------------------------------
    //  /ag class
    // ---------------------------------------------------------------

    private void handleClass(Player player, String[] args) {
        ClassManager classes = plugin.getClasses();
        PlayerClasses data = classes.get(player.getUniqueId());
        if (data == null) {
            messages.send(player, "profile.loading");
            return;
        }
        if (args.length == 1) {
            if (!openMenu(player, MENU_CLASSES)) {
                PlayerClass active = data.getActive();
                messages.send(player, "classes.current", Map.of(
                        "class", active != null ? classes.displayName(active) : "&8нет"));
            }
            return;
        }
        if (args[1].equalsIgnoreCase("shield")) {
            plugin.getTank().giveShield(player);
            return;
        }
        if (args[1].equalsIgnoreCase("staff")) {
            plugin.getHealer().giveStaff(player);
            return;
        }
        if (args.length < 3
                || !(args[1].equalsIgnoreCase("choose") || args[1].equalsIgnoreCase("switch"))) {
            messages.send(player, "classes.usage");
            return;
        }
        PlayerClass target = PlayerClass.fromInput(args[2]);
        if (target == null) {
            messages.send(player, "classes.unknown");
            return;
        }
        Map<String, Object> placeholders = Map.of(
                "class", classes.displayName(target),
                "rank", messages.rankName(classes.secondClassRank()));

        if (args[1].equalsIgnoreCase("choose")) {
            switch (classes.choose(player, target)) {
                case OK -> messages.send(player, "classes.chosen", placeholders);
                case ALREADY_OWNED -> messages.send(player, "classes.already-owned", placeholders);
                case NOT_CHOOSABLE -> messages.send(player, "classes.not-choosable", placeholders);
                case RANK_TOO_LOW -> messages.send(player, "classes.rank-too-low", placeholders);
                case LIMIT -> messages.send(player, "classes.limit", placeholders);
                case DISABLED -> messages.send(player, "classes.second-disabled", placeholders);
                case NO_COINS -> { }
                case NOT_LOADED -> messages.send(player, "profile.loading");
            }
        } else {
            switch (classes.switchTo(player, target)) {
                case OK -> messages.send(player, "classes.switched", placeholders);
                case ALREADY_ACTIVE -> messages.send(player, "classes.already-active", placeholders);
                case NOT_AVAILABLE -> messages.send(player, "classes.not-available", placeholders);
                case COOLDOWN -> messages.send(player, "classes.cooldown", placeholders);
                case IN_COMBAT -> messages.send(player, "classes.in-combat", placeholders);
                case NO_COINS -> { }
                case NOT_LOADED -> messages.send(player, "profile.loading");
            }
        }
    }

    // ---------------------------------------------------------------
    //  /ag world [join|info|top]
    // ---------------------------------------------------------------

    private void handleAscended(Player player, String[] args) {
        var ascended = plugin.getAscended();
        if (ascended == null || !ascended.isEnabled()) {
            messages.send(player, "ascended.disabled");
            return;
        }
        String mode = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "info";
        switch (mode) {
            case "join", "start", "войти" -> ascended.join(player);
            case "ladder", "ступени" -> {
                messages.send(player, "ascended.ladder-header");
                for (String line : ascended.ladder()) {
                    player.sendMessage(Hud.legacy(line));
                }
            }
            default -> {
                messages.send(player, "ascended.info", Map.of(
                        "have", String.valueOf(ascended.sRankCount()),
                        "required", String.valueOf(ascended.requiredSRank()),
                        "waves", "20"));
                if (!ascended.open()) {
                    player.sendMessage(Hud.legacy(ascended.gateHint()));
                }
            }
        }
    }

    // ---------------------------------------------------------------
    //  /ag event [join|top|list]
    // ---------------------------------------------------------------

    private void handleEvent(Player player, String[] args) {
        var events = plugin.getEvents();
        if (events == null || !events.isEnabled()) {
            messages.send(player, "events.disabled");
            return;
        }
        var type = events.current();
        if (args.length == 1) {
            events.open(player);
            return;
        }
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "join", "start", "войти" -> events.join(player, type);
            case "top", "топ" -> {
                messages.send(player, "events.top-header", Map.of("event", type.coloredName()));
                int place = 1;
                for (var row : events.top(type, 10)) {
                    messages.send(player, "events.top-line", Map.of(
                            "place", String.valueOf(place++),
                            "player", row.playerName(),
                            "stage", String.valueOf(row.bestStage()),
                            "time", ru.adventurers.core.event.EventRecord.time(row.bestMillis())));
                }
            }
            case "list", "ladder", "список" -> {
                messages.send(player, "events.list-header",
                        Map.of("week", String.valueOf(events.seasonWeek() + 1)));
                for (var each : ru.adventurers.core.event.EventType.values()) {
                    var config = events.config(each);
                    boolean now = each == type;
                    messages.send(player, now ? "events.list-current" : "events.list-line", Map.of(
                            "event", each.coloredName(),
                            "stages", String.valueOf(config == null ? 0 : config.stages()),
                            "desc", each.getDescription()));
                }
            }
            default -> events.open(player);
        }
    }

    // ---------------------------------------------------------------
    //  /ag gender [male|female]
    // ---------------------------------------------------------------

    private void handleGender(Player player, String[] args) {
        var genders = plugin.getGender();
        if (!genders.isEnabled()) {
            messages.send(player, "gender.disabled");
            return;
        }
        if (args.length == 1) {
            PlayerProfile profile = profiles.getProfile(player.getUniqueId());
            if (profile != null && profile.hasGender()) {
                messages.send(player, "gender.current", Map.of(
                        "gender", genders.apply(player, profile.getGender().getDisplayName())));
            }
            genders.openMenu(player);
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        if (sub.equals("menu") || sub.equals("choose")) {
            genders.openMenu(player);
            return;
        }
        if (sub.equals("reset") && player.hasPermission("ag.admin")) {
            var profile = profiles.getProfile(player.getUniqueId());
            if (profile != null) {
                profile.setGender(ru.adventurers.core.profile.Gender.UNSET);
                profiles.saveNow(profile);
            }
            messages.send(player, "gender.reset");
            genders.openMenu(player);
            return;
        }
        var gender = ru.adventurers.core.profile.Gender.parse(sub);
        if (gender == null) {
            messages.send(player, "gender.usage");
            return;
        }
        genders.setGender(player, gender);
    }

    // ---------------------------------------------------------------
    //  /ag prof
    // ---------------------------------------------------------------

    private void handleProf(Player player, String[] args) {
        if (professions.get(player.getUniqueId()) == null) {
            messages.send(player, "profile.loading");
            return;
        }

        if (args.length == 1) {
            // Есть профессия - открываем мастерскую, нет - выбор профессий.
            PlayerProfessions own = professions.get(player.getUniqueId());
            String menu = own != null && own.count() > 0 ? MENU_WORKSHOP : MENU_PROFESSIONS;
            if (!openMenu(player, menu)) {
                showProfessions(player);
            }
            return;
        }

        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "menu", "choose" -> {
                if (!openMenu(player, MENU_PROFESSIONS)) {
                    showProfessions(player);
                }
            }
            case "list" -> listProfessions(player);
            case "learn" -> learnProfession(player, args);
            default -> messages.send(player, "professions.usage");
        }
    }

    private void showProfessions(Player player) {
        PlayerProfessions data = professions.get(player.getUniqueId());
        if (data == null || data.count() == 0) {
            messages.send(player, "professions.none");
            return;
        }

        int cap = professions.levelCap(player);
        messages.send(player, "professions.header");

        for (Profession profession : data.professions()) {
            PlayerProfessions.Progress progress = data.get(profession);
            if (progress == null) {
                continue;
            }
            int need = professions.xpToNext(progress.getLevel());
            messages.send(player, "professions.entry", Map.of(
                    "profession", professions.displayName(profession),
                    "level", progress.getLevel(),
                    "cap", cap,
                    "xp", progress.getXp(),
                    "xp_next", need < 0 ? "-" : String.valueOf(need)
            ));
        }
    }

    private void listProfessions(Player player) {
        messages.send(player, "professions.list-header");
        for (Profession profession : Profession.values()) {
            messages.send(player, "professions.list-entry", Map.of(
                    "profession", professions.displayName(profession),
                    "id", profession.getId(),
                    "description", professions.description(profession)
            ));
        }
    }

    private void learnProfession(Player player, String[] args) {
        if (args.length < 3) {
            messages.send(player, "professions.usage");
            return;
        }
        Profession profession = Profession.fromInput(args[2]);
        if (profession == null) {
            messages.send(player, "professions.unknown");
            return;
        }
        if (!professions.isSelfLearnAllowed() && !player.hasPermission("ag.admin")) {
            messages.send(player, "professions.self-learn-disabled");
            return;
        }

        Map<String, Object> placeholders = Map.of(
                "profession", professions.displayName(profession),
                "max", professions.getMaxProfessions()
        );

        switch (professions.learn(player, profession)) {
            case OK -> messages.send(player, "professions.learned", placeholders);
            case ALREADY_KNOWN -> messages.send(player, "professions.already-known", placeholders);
            case LIMIT_REACHED -> messages.send(player, "professions.limit-reached", placeholders);
            case MAIN_LIMIT -> messages.send(player, "professions.main-limit", Map.of(
                    "profession", professions.displayName(profession), "max", professions.getMaxMain()));
            case NO_COINS -> { }
            case EXTRA_LIMIT -> messages.send(player, "professions.extra-limit", Map.of(
                    "profession", professions.displayName(profession), "max", professions.getMaxExtra()));
            case NOT_LOADED -> messages.send(player, "profile.loading");
        }
    }

    // ---------------------------------------------------------------
    //  /ag admin ...
    // ---------------------------------------------------------------

    private boolean handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("ag.admin")) {
            messages.send(sender, "commands.no-permission");
            return true;
        }

        if (args.length == 1 || (args.length >= 2 && args[1].equalsIgnoreCase("help"))) {
            messages.send(sender, "adminhelp");
            return true;
        }

        if (args.length >= 2) {
            switch (args[1].toLowerCase(Locale.ROOT)) {
                case "reload":
                    messages.reload();
                    gear.reload();
                    professions.reload();
                    plugin.getSurvival().reload();
                    plugin.getGuildGear().reload();
                    plugin.getClasses().reload();
                    plugin.getQuests().reload();
                    plugin.getGems().reload();
                    plugin.getHealer().reload();
                    plugin.getTank().reload();
                    plugin.getSkillHud().reload();
                    plugin.getWorldRules().reload();
                    plugin.getDungeons().reload();
                    plugin.getRunes().reload();
                    plugin.getWeapon().reload();
                    plugin.getEconomy().reload();
                    plugin.getShop().reload();
                    plugin.getAuction().reload();
                    plugin.getRecipes().reload();
                    plugin.getPartyFrames().reload();
                    plugin.getExtraEffects().reload();
                    plugin.getRanks().reload();
                    plugin.getParties().reload();
                    plugin.getCovenants().reload();
                    plugin.getGlory().reload();
                    plugin.getContracts().reload();
                    plugin.getInvasions().reload();
                    plugin.getMentors().reload();
                    plugin.getPets().reload();
                    plugin.getChat().reload();
                    plugin.getScoreboard().reload();
                    plugin.getTabList().reload();
                    plugin.getGender().reload();
                    plugin.getMotd().reload();
                    messages.send(sender, "commands.admin.reloaded");
                    return true;
                case "setrank":
                    return adminSetRank(sender, args);
                case "prof":
                    return adminProf(sender, args);
                case "info":
                    return adminInfo(sender, args);
                case "season":
                    return adminSeason(sender, args);
                case "gear":
                    return adminGear(sender, args);
                case "class":
                    return adminClass(sender, args);
                case "gender":
                    return adminGender(sender, args);
                case "event":
                    return adminEvent(sender, args);
                case "donate":
                    return adminDonate(sender, args);
                case "quest":
                    return adminQuest(sender, args);
                case "promote":
                    return adminPromote(sender, args);
                case "gem":
                    return adminGem(sender, args);
                case "resources":
                    return adminResources(sender, args);
                case "dungeon":
                    plugin.getDungeons().admin(sender, args);
                    return true;
                case "rune":
                    return adminRune(sender, args);
                case "coins":
                    return adminCoins(sender, args);
                case "covenant":
                    plugin.getCovenants().admin(sender, args);
                    return true;
                case "glory":
                    plugin.getGlory().admin(sender, args);
                    return true;
                case "contracts":
                    plugin.getContracts().admin(sender, args);
                    return true;
                case "invasion":
                    plugin.getInvasions().admin(sender, args);
                    return true;
                case "mentor":
                    plugin.getMentors().admin(sender, args);
                    return true;
                case "pet":
                    plugin.getPets().admin(sender, args);
                    return true;
                default:
                    break;
            }
        }

        messages.send(sender, "commands.admin.usage");
        return true;
    }

    // /ag admin setrank <ник> <ранг>
    private boolean adminSetRank(CommandSender sender, String[] args) {
        if (args.length != 4) {
            messages.send(sender, "commands.admin.usage");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }

        Rank rank = Rank.fromInput(args[3]);
        if (rank == null) {
            messages.send(sender, "commands.admin.unknown-rank");
            return true;
        }

        PlayerProfile profile = profiles.getProfile(target.getUniqueId());
        if (profile == null) {
            messages.send(sender, "commands.admin.profile-loading");
            return true;
        }

        profile.setRank(rank);
        profiles.saveNow(profile);
        professions.refreshLevels(target);
        plugin.getClasses().refresh(target);
        plugin.getRanks().resetSince(target);

        Map<String, Object> placeholders = Map.of(
                "player", target.getName(),
                "rank", messages.rankName(rank)
        );
        messages.send(sender, "commands.admin.rank-set", placeholders);
        messages.send(target, "commands.admin.rank-changed", placeholders);
        return true;
    }

    // /ag admin promote <ник> [force]  (его вызывает NPC "Мастер Гильдии" от консоли)
    private boolean adminPromote(CommandSender sender, String[] args) {
        if (args.length < 3) {
            messages.send(sender, "ranks.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        boolean force = args.length > 3 && args[3].equalsIgnoreCase("force");
        RankManager.PromoteResult result = plugin.getRanks().promote(target, force);
        reportPromotion(sender, target, result);
        if (result == RankManager.PromoteResult.REQUIREMENTS) {
            messages.send(target, "ranks.not-ready-player");
        }
        return true;
    }

    // /ag admin quest reset <ник> | points <ник> <число>
    private boolean adminQuest(CommandSender sender, String[] args) {
        if (args.length < 4) {
            messages.send(sender, "quests.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        QuestManager quests = plugin.getQuests();
        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "reset" -> messages.send(sender, quests.adminReset(target)
                    ? "quests.admin.reset" : "commands.admin.profile-loading",
                    Map.of("player", target.getName()));
            case "points" -> {
                Integer delta = parseInt(args, 4);
                if (delta == null) {
                    messages.send(sender, "quests.admin.usage");
                } else {
                    messages.send(sender, quests.adminAddPoints(target, delta)
                            ? "quests.admin.points" : "commands.admin.profile-loading",
                            Map.of("player", target.getName(), "points", delta));
                }
            }
            default -> messages.send(sender, "quests.admin.usage");
        }
        return true;
    }

    // /ag rune [info|clear]  (руна в руке: вставить)
    private void handleRune(Player player, String[] args) {
        String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "apply";
        if (action.equals("clear")) {
            messages.send(player, plugin.getRunes().clear(player) ? "rune.cleared" : "rune.nothing");
            return;
        }
        if (action.equals("info")) {
            List<String> list = plugin.getRunes().installed(player);
            messages.send(player, "rune.info", Map.of("slots", plugin.getRunes().slots(),
                    "list", list.isEmpty() ? "&8нет" : String.join("&7, ", list)));
            return;
        }
        switch (plugin.getRunes().apply(player)) {
            case OK -> messages.send(player, "rune.applied");
            case NOT_RUNE -> messages.send(player, "rune.not-rune");
            case NO_TARGET -> messages.send(player, "rune.no-target");
            case FULL -> messages.send(player, "rune.full", Map.of("slots", plugin.getRunes().slots()));
            case WEAKER -> messages.send(player, "rune.weaker");
        }
    }

    // /ag admin coins give|take|set|get <ник> [сумма]
    private boolean adminCoins(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(Hud.legacy("&7/ag admin coins give|take|set|get <ник> [сумма]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            sender.sendMessage(Hud.legacy("&cИгрок не в сети."));
            return true;
        }
        var economy = plugin.getEconomy();
        String action = args[2].toLowerCase(Locale.ROOT);
        long amount = 0;
        if (!action.equals("get")) {
            try {
                amount = Long.parseLong(args.length > 4 ? args[4] : "x");
            } catch (NumberFormatException exception) {
                sender.sendMessage(Hud.legacy("&cУкажите сумму числом."));
                return true;
            }
        }
        switch (action) {
            case "give" -> economy.deposit(target.getUniqueId(), amount);
            case "take" -> economy.withdraw(target.getUniqueId(), Math.min(amount, economy.balance(target.getUniqueId())));
            case "set" -> economy.set(target.getUniqueId(), amount);
            case "get" -> { }
            default -> {
                sender.sendMessage(Hud.legacy("&7/ag admin coins give|take|set|get <ник> [сумма]"));
                return true;
            }
        }
        sender.sendMessage(Hud.legacy("&6" + target.getName() + "&7: " + economy.format(economy.balance(target.getUniqueId()))));
        return true;
    }

    // /ag admin rune give <ник> <руна> [уровень]
    private boolean adminRune(CommandSender sender, String[] args) {
        if (args.length < 5 || !args[2].equalsIgnoreCase("give")) {
            sender.sendMessage(Hud.legacy("&7/ag admin rune give <ник> <руна> [уровень]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        int level = 1;
        if (args.length > 5) {
            try {
                level = Integer.parseInt(args[5]);
            } catch (NumberFormatException ignored) {
                level = 1;
            }
        }
        ItemStack rune = target == null ? null : plugin.getRunes().create(args[4], level);
        if (rune == null) {
            sender.sendMessage(Hud.legacy("&cИгрок или руна не найдены."));
            return true;
        }
        target.getInventory().addItem(rune).values()
                .forEach(rest -> target.getWorld().dropItemNaturally(target.getLocation(), rest));
        sender.sendMessage(Hud.legacy("&aРуна выдана: &f" + target.getName()));
        return true;
    }

    // /ag dungeon [list|enter <id> [heroic]|leave|reward]
    private void handleDungeon(Player player, String[] args) {
        String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "list";
        switch (action) {
            case "enter" -> {
                if (args.length > 2) {
                    boolean heroic = args.length > 3 && args[3].equalsIgnoreCase("heroic");
                    // /ag dungeon enter <id> [heroic] [модификатор] - раздел 26.5
                    String modifier = args.length > 4 ? args[4] : null;
                    plugin.getDungeons().enter(player, args[2], heroic, false, modifier);
                } else {
                    plugin.getDungeons().list(player);
                }
            }
            case "mod", "modifier", "мод" -> {
                // /ag dungeon mod <id> [heroic] - заход со случайным модификатором
                if (args.length < 3) {
                    messages.send(player, "dungeon.mod-usage");
                    break;
                }
                String modifier = args.length > 4 ? args[4] : plugin.getDungeons().randomModifierId();
                if (modifier == null) {
                    messages.send(player, "dungeon.no-modifiers");
                    break;
                }
                boolean heroic = args.length > 3 && args[3].equalsIgnoreCase("heroic");
                var entry = plugin.getDungeons().modifier(modifier);
                player.sendMessage(Hud.legacy("&7Модификатор захода: &f"
                        + (entry == null ? modifier : entry.name())));
                plugin.getDungeons().enter(player, args[2], heroic, false, modifier);
            }
            case "season", "сезон" -> plugin.getSeasonal().info(player);
            case "records", "рекорды" -> plugin.getDungeons().printRecords(player,
                    args.length > 2 ? args[2] : (args.length > 1 ? args[1] : ""));
            case "leave" -> plugin.getDungeons().leave(player);
            case "reward" -> plugin.getDungeons().openReward(player);
            default -> plugin.getDungeons().list(player);
        }
    }

    // /ag admin resources [reset [all]]
    private boolean adminResources(CommandSender sender, String[] args) {
        Player player = sender instanceof Player p ? p : null;
        boolean reset = args.length > 2 && args[2].equalsIgnoreCase("reset");
        boolean all = reset && args.length > 3 && args[3].equalsIgnoreCase("all");
        if (reset) {
            if (!all && player == null) {
                messages.send(sender, "world.usage");
                return true;
            }
            plugin.getWorldRules().reset(sender, all, player);
            return true;
        }
        if (player == null) {
            messages.send(sender, "world.usage");
            return true;
        }
        plugin.getWorldRules().info(player);
        return true;
    }

    // /ag admin gem give <ник> <самоцвет> [уровень] [raw]
    private boolean adminGem(CommandSender sender, String[] args) {
        if (args.length < 5 || !args[2].equalsIgnoreCase("give")) {
            messages.send(sender, "gems.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        boolean raw = args.length > 6 && args[6].equalsIgnoreCase("raw");
        Integer level = args.length > 5 ? parseInt(args, 5) : Integer.valueOf(1);
        if (level == null) {
            level = 1;
        }
        if (plugin.getGems().adminGive(target, args[4], level, raw)) {
            messages.send(sender, "gems.admin.given", Map.of("player", target.getName(), "gem", args[4]));
        } else {
            messages.send(sender, "gems.admin.unknown");
        }
        return true;
    }

    // /ag admin class set <ник> <класс> | reset <ник>
    // /ag admin gender <ник> <male|female|reset>
    private boolean adminGender(CommandSender sender, String[] args) {
        if (args.length < 4) {
            messages.send(sender, "gender.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        PlayerProfile profile = profiles.getProfile(target.getUniqueId());
        if (profile == null) {
            messages.send(sender, "commands.admin.profile-loading");
            return true;
        }
        ru.adventurers.core.profile.Gender gender;
        var parsed = args.length > 4 ? ru.adventurers.core.profile.Gender.parse(args[4]) : null;
        if (args.length > 4 && args[4].equalsIgnoreCase("reset")) {
            gender = ru.adventurers.core.profile.Gender.UNSET;
        } else {
            gender = parsed;
        }
        if (gender == null) {
            messages.send(sender, "gender.admin.usage");
            return true;
        }
        profile.setGender(gender);
        profiles.saveNow(profile);
        if (plugin.getGuildGear() != null) {
            plugin.getGuildGear().refreshModels(target);
        }
        plugin.getTabList().update(target);
        messages.send(sender, "gender.admin.set", Map.of(
                "player", target.getName(),
                "gender", plugin.getGender().apply(target, gender.getDisplayName())));
        return true;
    }

    // /ag admin event <reload|open|close|reset|list>
    private boolean adminEvent(CommandSender sender, String[] args) {
        var events = plugin.getEvents();
        if (events == null) {
            messages.send(sender, "events.disabled");
            return true;
        }
        if (args.length < 3) {
            messages.send(sender, "events.admin.usage");
            return true;
        }
        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                events.reload();
                messages.send(sender, "commands.admin.reloaded");
            }
            case "close" -> {
                events.closeWeek(events.current());
                messages.send(sender, "events.admin.closed",
                        Map.of("event", events.current().coloredName()));
            }
            case "open" -> {
                Player target = args.length > 3 ? Bukkit.getPlayerExact(args[3]) : null;
                if (target == null) {
                    messages.send(sender, "commands.admin.player-not-found");
                } else {
                    events.open(target);
                }
            }
            case "start" -> {
                Player target = args.length > 3 ? Bukkit.getPlayerExact(args[3]) : null;
                var parsed = args.length > 4
                        ? ru.adventurers.core.event.EventType.fromInput(args[4]) : events.current();
                if (target == null) {
                    messages.send(sender, "commands.admin.player-not-found");
                } else if (parsed == null) {
                    messages.send(sender, "events.admin.usage");
                } else {
                    events.join(target, parsed);
                }
            }
            default -> messages.send(sender, "events.admin.usage");
        }
        return true;
    }

    // /ag admin donate <give|take|check> <ник> [количество]
    private boolean adminDonate(CommandSender sender, String[] args) {
        var donate = plugin.getDonate();
        if (donate == null) {
            messages.send(sender, "donate.disabled");
            return true;
        }
        if (args.length < 4) {
            messages.send(sender, "donate.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        long amount = args.length > 4 ? Long.parseLong(args[4]) : 0;
        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "give" -> donate.giveGems(target, Math.max(1, amount));
            case "take" -> donate.setGems(target, donate.gems(target) - Math.max(1, amount));
            case "check" -> messages.send(sender, "donate.admin.check", Map.of(
                    "player", target.getName(), "gems", String.valueOf(donate.gems(target))));
            default -> messages.send(sender, "donate.admin.usage");
        }
        return true;
    }

    private boolean adminClass(CommandSender sender, String[] args) {
        if (args.length < 4) {
            messages.send(sender, "classes.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        ClassManager classes = plugin.getClasses();
        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "set" -> {
                PlayerClass playerClass = args.length > 4 ? PlayerClass.fromInput(args[4]) : null;
                if (playerClass == null) {
                    messages.send(sender, "classes.admin.usage");
                } else if (classes.adminSet(target, playerClass)) {
                    messages.send(sender, "classes.admin.set", Map.of(
                            "player", target.getName(), "class", classes.displayName(playerClass)));
                } else {
                    messages.send(sender, "commands.admin.profile-loading");
                }
            }
            case "reset" -> {
                if (classes.adminReset(target)) {
                    messages.send(sender, "classes.admin.reset", Map.of("player", target.getName()));
                } else {
                    messages.send(sender, "commands.admin.profile-loading");
                }
            }
            default -> messages.send(sender, "classes.admin.usage");
        }
        return true;
    }

    // /ag admin gear claim <ник> | give <ник> <ранг> | reset <ник>
    // NPC "Мастер Гильдии" вызывает от консоли: ag admin gear claim <ник>
    // /ag admin season <id|reset>
    private boolean adminSeason(CommandSender sender, String[] args) {
        if (args.length < 3) {
            messages.send(sender, "gear.admin.season-usage");
            return true;
        }
        if (args[2].equalsIgnoreCase("reset")) {
            plugin.getSeasonal().forceNone();
            messages.send(sender, "gear.admin.season-reset");
            return true;
        }
        if (!plugin.getSeasonal().force(args[2], sender)) {
            messages.send(sender, "gear.admin.season-unknown", java.util.Map.of("id", args[2]));
            return true;
        }
        messages.send(sender, "gear.admin.season-set", java.util.Map.of("id", args[2].toLowerCase(Locale.ROOT)));
        return true;
    }

    private boolean adminGear(CommandSender sender, String[] args) {
        if (args.length < 4) {
            messages.send(sender, "gear.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        switch (args[2].toLowerCase(Locale.ROOT)) {
            case "claim" -> plugin.getGuildGear().claim(target, sender);
            case "reset" -> plugin.getGuildGear().reset(target, sender);
            case "give" -> {
                Rank rank = args.length > 4 ? Rank.fromInput(args[4]) : null;
                if (rank == null) {
                    messages.send(sender, "gear.admin.usage");
                    break;
                }
                int count = plugin.getGuildGear().give(target, rank);
                messages.send(sender, "gear.admin.given", Map.of(
                        "player", target.getName(),
                        "rank", messages.rankName(rank),
                        "count", count));
            }
            case "curse" -> {
                // /ag admin gear curse <ник> <id|random> - наложить проклятие на вещь в руке
                if (plugin.getCurses() == null || !(target.getInventory().getItemInMainHand()
                        .getType().isItem())) {
                    messages.send(sender, "gear.admin.curse-usage");
                    break;
                }
                var stack = target.getInventory().getItemInMainHand();
                String wanted = args.length > 4 ? args[4] : "random";
                if (wanted.equalsIgnoreCase("remove")) {
                    String removed = plugin.getCurses().remove(stack);
                    messages.send(sender, "gear.admin.curse-removed", java.util.Map.of(
                            "player", target.getName(),
                            "curse", removed == null ? "-" : removed));
                    break;
                }
                var curse = wanted.equalsIgnoreCase("random")
                        ? plugin.getCurses().curses().values().stream().findAny().orElse(null)
                        : plugin.getCurses().curses().get(wanted.toLowerCase(Locale.ROOT));
                if (curse == null) {
                    messages.send(sender, "gear.admin.curse-unknown", java.util.Map.of("curse", wanted));
                    break;
                }
                plugin.getCurses().apply(stack, curse);
                messages.send(sender, "gear.admin.curse-applied", java.util.Map.of(
                        "player", target.getName(), "curse", curse.name()));
            }
            default -> messages.send(sender, "gear.admin.usage");
        }
        return true;
    }

    // /ag admin info <ник>  (UUID и технические данные видит только администрация)
    private boolean adminInfo(CommandSender sender, String[] args) {
        if (args.length != 3) {
            messages.send(sender, "commands.admin.usage");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }
        PlayerProfile profile = profiles.getProfile(target.getUniqueId());
        PlayerProfessions data = professions.get(target.getUniqueId());
        if (profile == null || data == null) {
            messages.send(sender, "commands.admin.profile-loading");
            return true;
        }

        messages.send(sender, "commands.admin.info-header", Map.of("player", target.getName()));
        messages.send(sender, "commands.admin.info-line", Map.of(
                "label", "UUID", "value", profile.getUuid().toString()));
        messages.send(sender, "commands.admin.info-line", Map.of(
                "label", "Ранг", "value", messages.rankName(profile.getRank())));
        List<String> parts = new ArrayList<>();
        for (Profession profession : data.professions()) {
            PlayerProfessions.Progress progress = data.get(profession);
            if (progress != null) {
                parts.add(professions.displayName(profession) + " &f"
                        + progress.getLevel() + " &8(" + progress.getXp() + " xp)");
            }
        }
        messages.send(sender, "commands.admin.info-line", Map.of(
                "label", "Профессии",
                "value", parts.isEmpty() ? "&8нет" : String.join("&7, ", parts)));
        return true;
    }

    // /ag admin prof <learn|forget|set|addxp> <ник> <профессия> [число]
    private boolean adminProf(CommandSender sender, String[] args) {
        if (args.length < 5) {
            messages.send(sender, "professions.admin.usage");
            return true;
        }

        String action = args[2].toLowerCase(Locale.ROOT);

        Player target = Bukkit.getPlayerExact(args[3]);
        if (target == null) {
            messages.send(sender, "commands.admin.player-not-found");
            return true;
        }

        Profession profession = Profession.fromInput(args[4]);
        if (profession == null) {
            messages.send(sender, "professions.unknown");
            return true;
        }

        if (professions.get(target.getUniqueId()) == null) {
            messages.send(sender, "commands.admin.profile-loading");
            return true;
        }

        String professionName = professions.displayName(profession);
        Map<String, Object> placeholders = Map.of(
                "player", target.getName(),
                "profession", professionName
        );

        switch (action) {
            case "learn":
                professions.adminLearn(target, profession);
                messages.send(sender, "professions.admin.learned", placeholders);
                break;

            case "forget":
                if (professions.forget(target, profession)) {
                    messages.send(sender, "professions.admin.forgotten", placeholders);
                } else {
                    messages.send(sender, "professions.admin.not-known", placeholders);
                }
                break;

            case "set": {
                Integer level = parseInt(args, 5);
                if (level == null || level < 1 || level > ProfessionManager.MAX_LEVEL) {
                    messages.send(sender, "professions.admin.usage");
                    break;
                }
                boolean force = args.length > 6 && args[6].equalsIgnoreCase("force");
                int result = professions.setLevel(target, profession, level, force);
                if (result < 0) {
                    messages.send(sender, "commands.admin.profile-loading");
                    break;
                }
                Map<String, Object> levelPlaceholders = Map.of(
                        "player", target.getName(),
                        "profession", professionName,
                        "level", result,
                        "cap", professions.levelCap(target)
                );
                messages.send(sender, "professions.admin.level-set", levelPlaceholders);
                if (result < level) {
                    messages.send(sender, "professions.admin.level-capped", levelPlaceholders);
                }
                break;
            }

            case "addxp": {
                Integer xp = parseInt(args, 5);
                if (xp == null || xp < 1) {
                    messages.send(sender, "professions.admin.usage");
                    break;
                }
                if (professions.addXp(target, profession, xp)) {
                    messages.send(sender, "professions.admin.xp-added", Map.of(
                            "player", target.getName(),
                            "profession", professionName,
                            "xp", xp
                    ));
                } else {
                    messages.send(sender, "professions.admin.not-known", placeholders);
                }
                break;
            }

            default:
                messages.send(sender, "professions.admin.usage");
                break;
        }
        return true;
    }

    private Integer parseInt(String[] args, int index) {
        if (args.length <= index) {
            return null;
        }
        try {
            return Integer.parseInt(args[index]);
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    // ---------------------------------------------------------------
    //  Подсказки по Tab
    // ---------------------------------------------------------------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command,
                                      String alias, String[] args) {
        List<String> result = new ArrayList<>();
        boolean admin = sender.hasPermission("ag.admin");

        if (args.length == 1) {
            result.add("menu");
            result.add("rank");
            result.add("prof");
            result.add("work");
            result.add("frames");
            result.add("dungeon");
            result.add("bank");
            result.add("covenant");
            result.add("glory");
            result.add("contracts");
            result.add("invasion");
            result.add("mentor");
            result.add("pet");
            result.add("craft");
            result.add("workshop");
            result.add("rune");
            result.add("shop");
            result.add("sell");
            result.add("ah");
            result.add("pay");
            result.add("trade");
            result.add("coins");
            result.add("class");
            result.add("skills");
            result.add("world");
            result.add("start");
            result.add("gender");
            result.add("season");
            result.add("event");
            result.add("donate");
            result.add("quest");
            result.add("gem");
            result.add("passive");
            result.add("group");
            result.add("raid");
            result.add("sb");
            result.add("guide");
            if (admin) {
                result.add("admin");
            }
        } else if (args[0].equalsIgnoreCase("trade")) {
            if (args.length == 2) {
                result.addAll(List.of("accept", "decline", "cancel", "coins"));
                addOnlinePlayers(result);
            }
        } else if (args[0].equalsIgnoreCase("group") || args[0].equalsIgnoreCase("raid")) {
            if (args.length == 2) {
                for (String sub : new String[]{"create", "invite", "accept", "decline", "leave",
                        "kick", "promote", "disband", "list", "check"}) {
                    result.add(sub);
                }
            } else if (args.length == 3 && (args[1].equalsIgnoreCase("invite")
                    || args[1].equalsIgnoreCase("kick") || args[1].equalsIgnoreCase("promote"))) {
                addOnlinePlayers(result);
            }
        } else if (args[0].equalsIgnoreCase("rank")) {
            if (args.length == 2) {
                result.add("promote");
            }
        } else if (args[0].equalsIgnoreCase("quest") || args[0].equalsIgnoreCase("quests")) {
            if (args.length == 2) {
                result.add("list");
                result.add("accept");
                result.add("turnin");
                result.add("abandon");
            } else if (args.length == 3) {
                for (int i = 1; i <= QuestManager.OFFERS_PER_DAY + plugin.getQuests().getMaxActive(); i++) {
                    result.add(String.valueOf(i));
                }
            }
        } else if (args[0].equalsIgnoreCase("gem")) {
            if (args.length == 2) {
                for (String sub : new String[]{"list", "info", "cut", "combine", "socket", "unsocket"}) {
                    result.add(sub);
                }
            }
        } else if (args[0].equalsIgnoreCase("class")) {
            if (args.length == 2) {
                result.add("choose");
                result.add("switch");
                result.add("staff");
                result.add("shield");
            } else if (args.length == 3) {
                for (PlayerClass playerClass : PlayerClass.values()) {
                    result.add(playerClass.getId());
                }
            }
        } else if (args[0].equalsIgnoreCase("prof") || args[0].equalsIgnoreCase("profession")) {
            if (args.length == 2) {
                result.add("list");
                result.add("learn");
            } else if (args.length == 3 && args[1].equalsIgnoreCase("learn")) {
                addProfessionIds(result);
            }
        } else if (admin && args[0].equalsIgnoreCase("admin")) {
            if (args.length == 2) {
                result.add("setrank");
                result.add("prof");
                result.add("info");
                result.add("gear");
                result.add("class");
                result.add("skills");
                result.add("world");
                result.add("start");
                result.add("gender");
            result.add("season");
                result.add("event");
                result.add("donate");
                result.add("quest");
                result.add("promote");
                result.add("gem");
                result.add("resources");
                result.add("dungeon");
                result.add("rune");
                result.add("coins");
                result.add("covenant");
                result.add("glory");
                result.add("contracts");
                result.add("invasion");
                result.add("mentor");
                result.add("pet");
                result.add("help");
                result.add("reload");
            } else if (args[1].equalsIgnoreCase("setrank")) {
                if (args.length == 3) {
                    addOnlinePlayers(result);
                } else if (args.length == 4) {
                    for (Rank rank : Rank.values()) {
                        result.add(rank.getDisplayName());
                    }
                }
            } else if (args[1].equalsIgnoreCase("promote")) {
                if (args.length == 3) {
                    addOnlinePlayers(result);
                } else if (args.length == 4) {
                    result.add("force");
                }
            } else if (args[1].equalsIgnoreCase("quest")) {
                if (args.length == 3) {
                    result.add("reset");
                    result.add("points");
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                }
            } else if (args[1].equalsIgnoreCase("dungeon")) {
                if (args.length == 3) {
                    result.addAll(List.of("enter", "mod", "records", "leave", "reward", "list"));
                } else if (args.length == 4 && (args[2].equalsIgnoreCase("mod")
                        || args[2].equalsIgnoreCase("enter"))) {
                    result.add("heroic");
                } else if (args.length >= 5 && args[2].equalsIgnoreCase("mod")) {
                    result.addAll(plugin.getDungeons().modifiers().keySet());
                } else if (args.length == 4 && args[2].equalsIgnoreCase("records")) {
                    plugin.getDungeons().ids().forEach(result::add);
                }
            } else if (args[1].equalsIgnoreCase("donate")) {
                if (args.length == 3) {
                    result.addAll(List.of("give", "take", "check"));
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                }
            } else if (args[1].equalsIgnoreCase("event")) {
                if (args.length == 3) {
                    result.addAll(List.of("reload", "open", "close", "start"));
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                } else if (args.length == 5) {
                    for (ru.adventurers.core.event.EventType type : ru.adventurers.core.event.EventType.values()) {
                        result.add(type.getId());
                    }
                }
            } else if (args[1].equalsIgnoreCase("gender")) {
                if (args.length == 3) {
                    addOnlinePlayers(result);
                } else if (args.length == 4) {
                    result.addAll(List.of("male", "female", "reset"));
                }
            } else if (args[1].equalsIgnoreCase("class")) {
                if (args.length == 3) {
                    result.add("set");
                    result.add("reset");
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                } else if (args.length == 5 && args[2].equalsIgnoreCase("set")) {
                    for (PlayerClass playerClass : PlayerClass.values()) {
                        result.add(playerClass.getId());
                    }
                }
            } else if (args[1].equalsIgnoreCase("gear")) {
                if (args.length == 3) {
                    result.add("claim");
                    result.add("give");
                    result.add("reset");
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                } else if (args.length == 5 && args[2].equalsIgnoreCase("give")) {
                    for (Rank rank : Rank.values()) {
                        result.add(rank.getDisplayName());
                    }
                }
            } else if (args[1].equalsIgnoreCase("coins")) {
                if (args.length == 3) {
                    result.addAll(List.of("give", "take", "set", "get"));
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                }
            } else if (args[1].equalsIgnoreCase("rune")) {
                if (args.length == 3) {
                    result.add("give");
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                } else if (args.length == 5) {
                    plugin.getRunes().all().forEach(r -> result.add(r.id()));
                }
            } else if (args[1].equalsIgnoreCase("dungeon")) {
                if (args.length == 3) {
                    result.addAll(List.of("status", "reload", "close", "test", "rel", "buildtest", "reset", "pass", "locks"));
                } else if (args.length == 4 && List.of("reset", "pass", "locks").contains(args[2].toLowerCase(Locale.ROOT))) {
                    addOnlinePlayers(result);
                } else if (args.length == 4 && List.of("test", "rel", "buildtest").contains(args[2].toLowerCase(Locale.ROOT))) {
                    plugin.getDungeons().definitions().forEach(d -> result.add(d.id));
                } else if (args.length == 5 && args[2].equalsIgnoreCase("test")) {
                    result.add("heroic");
                }
            } else if (args[1].equalsIgnoreCase("pet")) {
                if (args.length == 3) {
                    result.addAll(List.of("give", "egg", "take", "list", "reload"));
                } else if (args.length == 5) {
                    result.addAll(plugin.getPets().ids());
                }
            } else if (args[1].equalsIgnoreCase("mentor")) {
                if (args.length == 3) {
                    result.addAll(List.of("list", "clear", "reload"));
                }
            } else if (args[1].equalsIgnoreCase("invasion")) {
                if (args.length == 3) {
                    result.addAll(List.of("spawn", "list", "clear", "reload"));
                } else if (args.length == 4 && args[2].equalsIgnoreCase("spawn")) {
                    result.addAll(List.of("F", "E", "D", "C", "B", "A", "A+", "S"));
                } else if (args.length == 5 && args[2].equalsIgnoreCase("spawn")) {
                    result.add("here");
                }
            } else if (args[1].equalsIgnoreCase("contracts")) {
                if (args.length == 3) {
                    result.addAll(List.of("reset", "reload"));
                }
            } else if (args[1].equalsIgnoreCase("glory")) {
                if (args.length == 3) {
                    result.addAll(List.of("stat", "reset", "info", "reload"));
                } else if (args.length == 5 && args[2].equalsIgnoreCase("stat")) {
                    result.addAll(List.of("KILLS", "QUESTS", "DUNGEONS", "HEROICS", "RAIDS", "HEALED"));
                }
            } else if (args[1].equalsIgnoreCase("covenant")) {
                if (args.length == 3) {
                    result.addAll(List.of("list", "info", "disband", "unclaim", "setbank", "reload"));
                } else if (args.length == 4) {
                    plugin.getCovenants().all().forEach(c -> result.add(c.name.replace(' ', '_')));
                }
            } else if (args[1].equalsIgnoreCase("resources")) {
                if (args.length == 3) {
                    result.add("reset");
                } else if (args.length == 4 && args[2].equalsIgnoreCase("reset")) {
                    result.add("all");
                }
            } else if (args[1].equalsIgnoreCase("gem")) {
                if (args.length == 3) {
                    result.add("give");
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                } else if (args.length == 5) {
                    result.addAll(plugin.getGems().getTypes().keySet());
                } else if (args.length == 7) {
                    result.add("raw");
                }
            } else if (args[1].equalsIgnoreCase("info")) {
                if (args.length == 3) {
                    addOnlinePlayers(result);
                }
            } else if (args[1].equalsIgnoreCase("prof")) {
                if (args.length == 3) {
                    result.add("learn");
                    result.add("forget");
                    result.add("set");
                    result.add("addxp");
                } else if (args.length == 4) {
                    addOnlinePlayers(result);
                } else if (args.length == 5) {
                    addProfessionIds(result);
                } else if (args.length == 7 && args[2].equalsIgnoreCase("set")) {
                    result.add("force");
                }
            }
        }

        String typed = args[args.length - 1].toLowerCase(Locale.ROOT);
        result.removeIf(option -> !option.toLowerCase(Locale.ROOT).startsWith(typed));
        return result;
    }

    private void addOnlinePlayers(List<String> result) {
        Bukkit.getOnlinePlayers().forEach(player -> result.add(player.getName()));
    }

    private void addProfessionIds(List<String> result) {
        for (Profession profession : Profession.values()) {
            result.add(profession.getId());
        }
    }
}
