package ru.adventurers.core;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import ru.adventurers.core.profile.Gender;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

public class DatabaseManager {

    private final AdventurersCore plugin;
    private HikariDataSource dataSource;

    public DatabaseManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    /** Значение-заглушка из шаблона конфига: подключение с ним невозможно. */
    private static final String PLACEHOLDER = "CHANGE_ME";

    /**
     * Читает строку подключения. Пароль можно задать в конфиге либо через переменную
     * окружения {@code ADVENTURERS_DB_PASSWORD}, чтобы не хранить секрет в файле.
     */
    private String credential(String key, String env) {
        String value = plugin.getConfig().getString("database." + key);
        if (env != null) {
            String fromEnv = System.getenv(env);
            if (fromEnv != null && !fromEnv.isBlank()) {
                value = fromEnv;
            }
        }
        if (value == null || value.isBlank() || PLACEHOLDER.equals(value)) {
            return null;
        }
        return value;
    }

    private String require(String key, String env) throws SQLException {
        String value = credential(key, env);
        if (value == null) {
            throw new SQLException("Не задан database." + key
                    + " (укажите в config.yml или через переменную окружения " + env + ")");
        }
        return value;
    }

    public void connect() throws SQLException {
        String host = credential("host", null);
        if (host == null) {
            host = "127.0.0.1";
        }
        int port = plugin.getConfig().getInt("database.port", 3306);
        String database = require("name", "ADVENTURERS_DB_NAME");
        String username = require("username", "ADVENTURERS_DB_USER");
        String password = require("password", "ADVENTURERS_DB_PASSWORD");

        HikariConfig config = new HikariConfig();

        config.setJdbcUrl(
                "jdbc:mariadb://" + host + ":" + port + "/" + database
        );

        config.setUsername(username);
        config.setPassword(password);
        config.setMaximumPoolSize(
                plugin.getConfig().getInt("database.pool-size", 5)
        );

        config.setPoolName("AdventurersCore-Pool");
        config.setDriverClassName("org.mariadb.jdbc.Driver");
        dataSource = new HikariDataSource(config);

        createTables();

        plugin.getLogger().info("MariaDB connection established!");
    }

    private void createTables() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS players (
                    uuid CHAR(36) NOT NULL,
                    username VARCHAR(16) NOT NULL,
                    rank_name VARCHAR(10) NOT NULL DEFAULT 'F',
                    -- Пол персонажа: unset (не выбран), male, female. Только внешность.
                    gender VARCHAR(8) NOT NULL DEFAULT 'unset',
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (uuid),
                    INDEX idx_players_rank (rank_name)
                ) ENGINE=InnoDB
                  DEFAULT CHARSET=utf8mb4
                  COLLATE=utf8mb4_unicode_ci
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }

        ensureGenderColumn();
    }

    /**
     * Обновление уже существующей базы: у таблицы players, созданной до выбора пола,
     * колонки gender нет. CREATE TABLE IF NOT EXISTS её не добавит, поэтому добавляем сами.
     * Ошибка «колонка уже есть» (1060) - нормальный случай, остальные пишем в лог.
     */
    private void ensureGenderColumn() {
        String sql = "ALTER TABLE players ADD COLUMN gender VARCHAR(8) NOT NULL DEFAULT 'unset'";
        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
            plugin.getLogger().info("players: добавлена колонка gender");
        } catch (SQLException exception) {
            int code = exception.getErrorCode();
            if (code != 1060 && code != 1091) { // 1060 duplicate column, 1091 can't drop
                plugin.getLogger().warning("players: не удалось добавить gender (" + exception.getMessage() + ")");
            }
        }
    }

    public PlayerProfile loadOrCreateProfile(UUID uuid, String username)
            throws SQLException {

        String insertSql = """
                INSERT INTO players (uuid, username, rank_name)
                VALUES (?, ?, 'F')
                ON DUPLICATE KEY UPDATE username = VALUES(username)
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(insertSql)) {

            statement.setString(1, uuid.toString());
            statement.setString(2, username);
            statement.executeUpdate();
        }

        String selectSql = """
                SELECT rank_name, gender
                FROM players
                WHERE uuid = ?
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(selectSql)) {

            statement.setString(1, uuid.toString());

            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    Rank rank = Rank.fromDatabase(
                            result.getString("rank_name")
                    );
                    Gender gender;
                    try {
                        gender = Gender.fromInput(result.getString("gender"));
                    } catch (SQLException missing) {
                        // база без колонки gender (старая версия): считаем, что пол не выбран
                        gender = Gender.UNSET;
                    }

                    return new PlayerProfile(uuid, username, rank, gender);
                }
            }
        }

        throw new SQLException("Could not load player profile: " + uuid);
    }

    public void saveProfile(PlayerProfile profile) throws SQLException {
        String sql = """
                UPDATE players
                SET username = ?, rank_name = ?, gender = ?
                WHERE uuid = ?
                """;

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, profile.getUsername());
            statement.setString(2, profile.getRank().getDatabaseName());
            statement.setString(3, profile.getGender().getId());
            statement.setString(4, profile.getUuid().toString());

            statement.executeUpdate();
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
