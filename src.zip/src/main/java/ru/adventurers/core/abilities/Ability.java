package ru.adventurers.core.abilities;

/**
 * Умение игрока: открывается по рангу (раздел 22 отчёта).
 *
 * @param classId   класс, которому принадлежит умение (tank/healer/fighter/archer)
 * @param id        идентификатор умения внутри класса (taunt, wall, sweep...)
 * @param name      название для игрока («Провокация»)
 * @param unlock    ранг, с которого умение доступно
 * @param icon      глиф пака для HUD (может быть пустым - тогда HUD пишет название)
 * @param ultimate  ультимейт: сильнее обычного умения и с длинным кулдауном
 */
public record Ability(String classId, String id, String name, String unlock, String icon,
                      boolean ultimate) {

    /** Ключ для конфигов и сохранений: «tank.taunt». */
    public String key() {
        return classId + "." + id;
    }
}
