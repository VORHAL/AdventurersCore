package ru.adventurers.core.abilities;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.combat.WeaponSkills;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.tank.TankManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Способности по рангу (раздел 22 отчёта).
 *
 * <p>Было: все умения класса доступны с первого дня. Стало: F - 1 умение, E/D - 2,
 * C - 3 (весь базовый набор), с B - плюс ультимейт. Сила каждого умения не меняется,
 * меняется только количество доступных кнопок.
 *
 * <p>Зачем: раньше ранг давал только цифры, и первые десять уровней не ощущались -
 * игрок сразу видел весь арсенал. Теперь каждый ранг даёт новую кнопку, а ультимейт
 * становится целью, к которой идут.
 *
 * <p>Почему это не pay2win и не ломает баланс:
 * <ul>
 *   <li>ранг растёт только от игры (задания, подземелья, боссы), купить его нельзя;</li>
 *   <li>умение с рангом не становится сильнее, только открывается - сила задана
 *       в tank.yml / healer.yml / weapon.yml и растёт по рангам уже там;</li>
 *   <li>счёт по рангам монотонный: F+ 1, E 2, D 2, C 3, B+ 4 - ни один ранг не теряет умение.</li>
 * </ul>
 */
public class AbilityManager {

    private final AdventurersCore plugin;
    private final MessageManager messages;

    private boolean enabled = true;
    /** Наборы умений по классам: порядок в файле = порядок открытия. */
    private final Map<String, List<Ability>> byClass = new LinkedHashMap<>();
    private final Map<String, Ability> byKey = new LinkedHashMap<>();
    /** Ультимейты: класс -> (id -> настройки). */
    private final Map<String, Map<String, YamlConfiguration>> ultimates = new LinkedHashMap<>();
    private YamlConfiguration cfg = new YamlConfiguration();
    /** Последнее показанное игроку «это ещё не открыто» - чтобы не спамить в HUD. */
    private final Map<UUID, Long> lastHint = new HashMap<>();

    public AbilityManager(AdventurersCore plugin, MessageManager messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    public void reload() {
        cfg = plugin.getFiles().load("abilities.yml");
        enabled = cfg.getBoolean("enabled", true);
        byClass.clear();
        byKey.clear();
        ultimates.clear();
        ConfigurationSection abilities = cfg.getConfigurationSection("abilities");
        if (abilities == null) {
            plugin.getLogger().warning("abilities.yml: нет раздела abilities, умения не ограничены по рангу");
            return;
        }
        for (String classId : abilities.getKeys(false)) {
            ConfigurationSection node = abilities.getConfigurationSection(classId);
            if (node == null) {
                continue;
            }
            List<Ability> list = new ArrayList<>();
            for (String id : node.getKeys(false)) {
                ConfigurationSection ability = node.getConfigurationSection(id);
                if (ability == null) {
                    continue;
                }
                Rank unlock = Rank.fromInput(ability.getString("unlock-rank", "F"));
                if (unlock == null) {
                    unlock = Rank.F;
                }
                // ультимейт по определению тот, что открывается с B и выше
                boolean ultimate = unlock.ordinal() >= Rank.B.ordinal();
                Ability entry = new Ability(classId, id,
                        ability.getString("name", id), unlock.name(),
                        ability.getString("icon", ""), ultimate);
                list.add(entry);
                byKey.put(entry.key(), entry);
            }
            byClass.put(classId, list);
        }
        ConfigurationSection ultimateNode = cfg.getConfigurationSection("ultimates");
        if (ultimateNode != null) {
            for (String classId : ultimateNode.getKeys(false)) {
                ConfigurationSection node = ultimateNode.getConfigurationSection(classId);
                if (node == null) {
                    continue;
                }
                Map<String, YamlConfiguration> map = new LinkedHashMap<>();
                for (String id : node.getKeys(false)) {
                    ConfigurationSection section = node.getConfigurationSection(id);
                    if (section != null) {
                        map.put(id, copyOf(section));
                    }
                }
                ultimates.put(classId, map);
            }
        }
        plugin.getLogger().info("Умения по рангам: " + byKey.size() + " умений в "
                + byClass.size() + " наборах");
    }

    /** Перенос секции ультимейта в отдельный конфиг (для удобного чтения в коде). */
    private static YamlConfiguration copyOf(ConfigurationSection section) {
        YamlConfiguration copy = new YamlConfiguration();
        for (String key : section.getKeys(true)) {
            copy.set(key, section.get(key));
        }
        return copy;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public List<Ability> abilities(String classId) {
        return byClass.getOrDefault(classId.toLowerCase(Locale.ROOT), List.of());
    }

    public Ability ability(String classId, String id) {
        return byKey.get(classId.toLowerCase(Locale.ROOT) + "." + id);
    }

    // ---------------------------------------------------------------
    //  Что открыто
    // ---------------------------------------------------------------

    /**
     * Сколько умений открыто на ранге: F - 1, E/D - 2, C - 3, B и выше - все.
     * Число берётся из abilities.yml (поле unlock-rank), а не задаётся здесь:
     * так администратор может сдвинуть порог, не трогая код.
     */
    public int unlockedCount(Rank rank) {
        int count = 0;
        for (Ability ability : abilitiesOf(null)) {
            if (rankAtLeast(rank, Rank.fromInput(ability.unlock()))) {
                count++;
            }
        }
        return count;
    }

    private List<Ability> abilitiesOf(String classId) {
        if (classId != null) {
            return abilities(classId);
        }
        // без класса - берём самый длинный набор: он показывает общий принцип
        List<Ability> longest = List.of();
        for (List<Ability> list : byClass.values()) {
            if (list.size() > longest.size()) {
                longest = list;
            }
        }
        return longest;
    }

    public static boolean rankAtLeast(Rank current, Rank required) {
        if (current == null) {
            return false;
        }
        if (required == null) {
            return true;
        }
        return current.ordinal() >= required.ordinal();
    }

    public Rank rank(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? Rank.F : profile.getRank();
    }

    /** Открыто ли умение у игрока. Класс не проверяется - только ранг. */
    public boolean unlocked(Player player, String classId, String id) {
        if (!enabled) {
            return true;
        }
        Ability ability = ability(classId, id);
        if (ability == null) {
            // умение не описано в abilities.yml: не блокируем игру из-за опечатки в конфиге
            return true;
        }
        return rankAtLeast(rank(player), Rank.fromInput(ability.unlock()));
    }

    /** Открытые умения игрока (в порядке открытия). */
    public List<Ability> unlocked(Player player) {
        Rank playerRank = rank(player);
        String classId = activeClassId(player);
        List<Ability> result = new ArrayList<>();
        for (Ability ability : abilities(classId)) {
            if (rankAtLeast(playerRank, Rank.fromInput(ability.unlock()))) {
                result.add(ability);
            }
        }
        return result;
    }

    /** Заблокированные умения: HUD покажет их серыми с подписью «с ранга C». */
    public List<Ability> locked(Player player) {
        Rank playerRank = rank(player);
        List<Ability> result = new ArrayList<>();
        for (Ability ability : abilities(activeClassId(player))) {
            if (!rankAtLeast(playerRank, Rank.fromInput(ability.unlock()))) {
                result.add(ability);
            }
        }
        return result;
    }

    public String activeClassId(Player player) {
        PlayerClass active = plugin.getClasses().activeClass(player.getUniqueId());
        return switch (active) {
            case TANK -> "tank";
            case HEALER -> "healer";
            case FIGHTER -> "fighter";
            case UNIVERSAL -> "universal";
        };
    }

    /**
     * Класс для набора умений: Универсал играет набором Бойца и Танка слабее
     * (так уже устроены tank.yml и weapon.yml - universal-factor 0.6),
     * поэтому ему показываем набор Бойца, а проверки внутри классов идут отдельно.
     */
    public String skillSetFor(Player player) {
        String active = activeClassId(player);
        return active.equals("universal") ? "fighter" : active;
    }

    // ---------------------------------------------------------------
    //  Проверки перед нажатием кнопки
    // ---------------------------------------------------------------

    /**
     * Можно ли нажать умение. Если нет - коротко пишет в HUD, с какого ранга оно
     * откроется (раз в 2 секунды, чтобы не спамить при зажатой кнопке).
     */
    public boolean allow(Player player, String classId, String id) {
        if (!enabled) {
            return true;
        }
        if (unlocked(player, classId, id)) {
            return true;
        }
        Ability ability = ability(classId, id);
        if (ability == null) {
            return true;
        }
        long now = System.currentTimeMillis();
        Long last = lastHint.get(player.getUniqueId());
        if (last == null || now - last > 2000) {
            lastHint.put(player.getUniqueId(), now);
            String text = cfg.getString("hints.locked",
                    "&7{ability} откроется с ранга &f{rank}");
            text = text.replace("{ability}", ability.name()).replace("{rank}", ability.unlock());
            if (plugin.getSkillHud() != null) {
                plugin.getSkillHud().flash(player, Hud.legacy(text));
            } else {
                messages.send(player, "abilities.locked", Map.of(
                        "ability", ability.name(), "rank", ability.unlock()));
            }
        }
        return false;
    }

    /** Проверка перед вызовом умения танка. */
    public boolean allowTank(Player player, String id) {
        return allow(player, "tank", id);
    }

    /** Проверка перед вызовом умения лекаря. */
    public boolean allowHealer(Player player, String id) {
        return allow(player, "healer", id);
    }

    /** Проверка перед вызовом умения бойца или стрелка (у Бойца два набора). */
    public boolean allowWeapon(Player player, String id) {
        return allow(player, "fighter", id) && allow(player, "archer", id);
    }

    // ---------------------------------------------------------------
    //  Ультимейты
    // ---------------------------------------------------------------

    /** Открыт ли ультимейт класса (с ранга B). */
    public boolean ultimateUnlocked(Player player, String classId) {
        for (Ability ability : abilities(classId)) {
            if (ability.ultimate()) {
                return rankAtLeast(rank(player), Rank.fromInput(ability.unlock()));
            }
        }
        return false;
    }

    /** Настройки ультимейта: читаются кодом класса (танк/лекарь/боец/стрелок). */
    public YamlConfiguration ultimate(String classId, String id) {
        return ultimates.getOrDefault(classId.toLowerCase(Locale.ROOT), Map.of())
                .getOrDefault(id.toLowerCase(Locale.ROOT), new YamlConfiguration());
    }

    /**
     * Значение по рангу из списка в конфиге ультимейта:
     * [6, 7, 8, 9, 10] на рангах B..S. Ниже B ультимейт недоступен, поэтому
     * список начинается с B - индекс = ordinal(rank) - ordinal(B).
     */
    public double ultimateValue(Player player, String classId, String id, String path, double fallback) {
        YamlConfiguration config = ultimate(classId, id);
        List<Double> values = config.getDoubleList(path);
        if (values.isEmpty()) {
            return fallback;
        }
        int index = Math.max(0, Math.min(values.size() - 1,
                rank(player).ordinal() - Rank.B.ordinal()));
        return values.get(index);
    }

    // ---------------------------------------------------------------
    //  Сообщение для игрока
    // ---------------------------------------------------------------

    /** Текст «что открыто, что нет» для /ag skills. */
    public List<String> describe(Player player) {
        List<String> lines = new ArrayList<>();
        String classId = skillSetFor(player);
        Rank playerRank = rank(player);
        lines.add("&8Набор: &f" + classId + "&8, ранг &f" + playerRank.name());
        for (Ability ability : abilities(classId)) {
            boolean open = rankAtLeast(playerRank, Rank.fromInput(ability.unlock()));
            String prefix = open ? "&a✔ " : "&8✖ ";
            String name = open ? "&f" + ability.name()
                    : "&7" + ability.name() + " &8(с ранга " + ability.unlock() + ")";
            String mark = ability.ultimate() ? " &6[ультимейт]" : "";
            lines.add(prefix + name + mark);
        }
        return lines;
    }

    public void forget(UUID uuid) {
        lastHint.remove(uuid);
    }

    /** Сколько умений открывается на каждом ранге: для отчёта и теста. */
    public Map<Rank, Integer> ladder() {
        Map<Rank, Integer> ladder = new LinkedHashMap<>();
        Set<Rank> ranks = new LinkedHashSet<>(List.of(Rank.values()));
        for (Rank rank : ranks) {
            ladder.put(rank, unlockedCount(rank));
        }
        return ladder;
    }
}
