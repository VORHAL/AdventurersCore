package ru.adventurers.core.ascended;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * S-ранг: Мир Избранных и бесконечные волны (раздел 23 отчёта).
 *
 * <p>Проблема, которую это решает: S-ранг был тупиком. Все подземелья пройдены,
 * ранг максимальный, следующей цели нет - и именно эти игроки уходят первыми,
 * хотя они и есть ядро сервера.
 *
 * <p>Решение: отдельный мир, который открывается, когда на сервере наберётся
 * пять игроков с S-рангом. Внутри - волны самых сложных мобов, боссы каждые
 * пять волн, рекорды и осколки на косметику.
 *
 * <p>Почему это не ломает баланс и не превращается в pay2win:
 * <ul>
 *   <li>вход только с S-ранга, а ранг нельзя купить;</li>
 *   <li>награда - осколки, которые меняются только на косметику и титулы;
 *       монет за волны нет, поэтому экономика раздела 15 не меняется;</li>
 *   <li>PvP в мире выключен, заходов в сутки пять;</li>
 *   <li>мир открывается не «первому дошедшему», а серверу: один S-игрок там
 *       не выживет, и контент выглядел бы сломанным.</li>
 * </ul>
 */
public class AscendedManager {

    private final AdventurersCore plugin;
    private final MessageManager messages;

    private boolean enabled = true;
    private String worldName = "adventurers_ascended";
    private int platformRadius = 60;
    private int height = 140;
    private int requiredSRank = 5;
    private boolean announce = true;

    private int baseMobs = 2;
    private double mobsGrowth = 0.5;
    private int maxMobs = 12;
    /** Суммарное здоровье волны: здоровье одного моба = сумма / число мобов. */
    private double baseHp = 300;
    private double hpGrowth = 1.14;
    private double baseDamage = 6;
    private double damageGrowth = 1.12;
    private int bossEvery = 5;
    private double bossHpMultiplier = 3.0;
    private double bossDamageMultiplier = 1.5;
    private int pauseSeconds = 20;
    private int wavesPerRun = 20;
    private int runsPerDay = 5;
    private int topSize = 10;
    private int groupSize = 5;

    private int shardsBase = 1;
    private double shardsGrowth = 0.3;
    private int shardsBoss = 2;

    private final List<Mob> mobs = new ArrayList<>();
    private final List<Mob> bosses = new ArrayList<>();

    /** Забег в мире Избранных: одна команда, волны общие. */
    private final Map<UUID, Run> runs = new ConcurrentHashMap<>();
    /** Последний заход игрока: пауза между забегами. */
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    /** Сколько заходов сделано за сутки (ключ - UTC-день + игрок). */
    private final Map<String, Integer> runsToday = new ConcurrentHashMap<>();

    private String dayKey() {
        return java.time.LocalDate.now(java.time.ZoneOffset.UTC).toString();
    }

    private int runsToday(UUID uuid) {
        return runsToday.getOrDefault(dayKey() + ":" + uuid, 0);
    }
    private BukkitTask ticker;
    private int tick;

    /** Порог мобов: с какой волны появляется тип. */
    private record Mob(int from, EntityType type) {
    }

    /** Забег: игроки, номер волны, живые мобы, время до конца паузы. */
    public static final class Run {
        final java.util.Set<UUID> members = java.util.concurrent.ConcurrentHashMap.newKeySet();
        final java.util.Set<UUID> alive = java.util.concurrent.ConcurrentHashMap.newKeySet();
        int wave = 0;
        int bestWave = 0;
        long nextWaveAt = 0;
        boolean finished;
        Player owner;

        Run(Player owner) {
            this.owner = owner;
            members.add(owner.getUniqueId());
        }
    }

    public AscendedManager(AdventurersCore plugin, MessageManager messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    public void init() {
        reload();
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public void shutdown() {
        if (ticker != null) {
            ticker.cancel();
        }
        runs.clear();
    }

    public void reload() {
        YamlConfiguration cfg = plugin.getFiles().load("ascended.yml");
        enabled = cfg.getBoolean("enabled", true);
        worldName = cfg.getString("world.name", worldName);
        platformRadius = cfg.getInt("world.platform-radius", platformRadius);
        height = cfg.getInt("world.height", height);
        requiredSRank = Math.max(1, cfg.getInt("gate.required-s-rank", requiredSRank));
        announce = cfg.getBoolean("gate.announce", announce);

        ConfigurationSection waves = cfg.getConfigurationSection("waves");
        if (waves != null) {
            baseMobs = waves.getInt("base-mobs", baseMobs);
            mobsGrowth = waves.getDouble("mobs-growth", mobsGrowth);
            maxMobs = waves.getInt("max-mobs-per-wave", maxMobs);
            baseHp = waves.getDouble("base-hp", baseHp);
            hpGrowth = waves.getDouble("hp-growth", hpGrowth);
            baseDamage = waves.getDouble("base-damage", baseDamage);
            damageGrowth = waves.getDouble("damage-growth", damageGrowth);
            bossEvery = Math.max(0, waves.getInt("boss-every", bossEvery));
            bossHpMultiplier = waves.getDouble("boss-hp-multiplier", bossHpMultiplier);
            bossDamageMultiplier = waves.getDouble("boss-damage-multiplier", bossDamageMultiplier);
            pauseSeconds = Math.max(3, waves.getInt("pause-seconds", pauseSeconds));
            wavesPerRun = Math.max(1, waves.getInt("waves-per-run", wavesPerRun));
            mobs.clear();
            bosses.clear();
            for (Map<?, ?> row : waves.getMapList("mobs")) {
                EntityType type = parse(String.valueOf(row.get("type")));
                if (type != null) {
                    mobs.add(new Mob(number(row.get("from"), 1), type));
                }
            }
            for (Map<?, ?> row : waves.getMapList("bosses")) {
                EntityType type = parse(String.valueOf(row.get("type")));
                if (type != null) {
                    bosses.add(new Mob(number(row.get("from"), 1), type));
                }
            }
        }
        shardsBase = cfg.getInt("rewards.shards-base", shardsBase);
        shardsGrowth = cfg.getDouble("rewards.shards-growth", shardsGrowth);
        shardsBoss = cfg.getInt("rewards.shards-boss", shardsBoss);
        runsPerDay = Math.max(1, cfg.getInt("limits.runs-per-day", runsPerDay));
        groupSize = Math.max(1, cfg.getInt("limits.group-size", groupSize));
        topSize = Math.max(1, cfg.getInt("records.top-size", topSize));
    }

    private static EntityType parse(String name) {
        try {
            return EntityType.valueOf(name.trim().toUpperCase(java.util.Locale.ROOT));
        } catch (Exception exception) {
            return null;
        }
    }

    private static int number(Object value, int fallback) {
        return value instanceof Number number ? number.intValue() : fallback;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String worldName() {
        return worldName;
    }

    public int requiredSRank() {
        return requiredSRank;
    }

    // ---------------------------------------------------------------
    //  Открытие мира: 5 игроков с S-рангом
    // ---------------------------------------------------------------

    /** Сколько игроков на сервере имеют S-ранг. */
    public int sRankCount() {
        int count = 0;
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isS(player)) {
                count++;
            }
        }
        return count;
    }

    private boolean isS(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile != null && profile.getRank().isAtLeast(Rank.S);
    }

    /** Открыт ли мир: порог по числу S-игроков достигнут. */
    public boolean open() {
        return enabled && sRankCount() >= requiredSRank;
    }

    /** Текст о состоянии ворот: нужен и в /ag world, и в HUD. */
    public String gateHint() {
        YamlConfiguration cfg = plugin.getFiles().load("ascended.yml");
        String text = cfg.getString("gate.hint-locked",
                "&7Мир Избранных откроется, когда S-ранг будет у &f{required} &7игроков.");
        return text.replace("{required}", String.valueOf(requiredSRank))
                .replace("{have}", String.valueOf(sRankCount()));
    }

    // ---------------------------------------------------------------
    //  Мир и арена
    // ---------------------------------------------------------------

    /** Мир Избранных: строится один раз (площадка), дальше живёт сам. */
    public World world() {
        World world = Bukkit.getWorld(worldName);
        if (world != null) {
            return world;
        }
        WorldCreator creator = new WorldCreator(worldName);
        creator.generator(new org.bukkit.generator.ChunkGenerator() {
            @Override
            public boolean shouldGenerateNoise() {
                return false;
            }

            @Override
            public boolean shouldGenerateSurface() {
                return false;
            }

            @Override
            public boolean shouldGenerateCaves() {
                return false;
            }

            @Override
            public boolean shouldGenerateStructures() {
                return false;
            }
        });
        world = creator.createWorld();
        if (world != null) {
            world.setAutoSave(false);
            world.setPVP(false);
            world.setStorm(false);
            world.setTime(18000);
            world.setDifficulty(org.bukkit.Difficulty.HARD);
            world.setGameRule(org.bukkit.GameRule.DO_MOB_SPAWNING, false);
            world.setGameRule(org.bukkit.GameRule.KEEP_INVENTORY, true);
            buildArena(world);
        }
        return world;
    }

    /** Площадка Избранных: тёмный камень, кольцо обсидиана, четыре колонны. */
    private void buildArena(World world) {
        int r = platformRadius;
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                double distance = Math.sqrt(x * x + z * z);
                if (distance > r) {
                    continue;
                }
                world.getBlockAt(x, height, z).setType(Material.POLISHED_DEEPSLATE, false);
                if (distance > r - 3) {
                    world.getBlockAt(x, height + 1, z).setType(Material.CRYING_OBSIDIAN, false);
                }
            }
        }
        for (int i = 0; i < 4; i++) {
            double angle = Math.PI / 2 * i + Math.PI / 4;
            int x = (int) Math.round(Math.cos(angle) * (r - 8));
            int z = (int) Math.round(Math.sin(angle) * (r - 8));
            for (int y = 1; y <= 10; y++) {
                world.getBlockAt(x, height + y, z).setType(Material.POLISHED_BLACKSTONE, false);
            }
            world.getBlockAt(x, height + 11, z).setType(Material.SOUL_LANTERN, false);
        }
    }

    public Location spawn() {
        World world = world();
        return world == null ? null : new Location(world, 0.5, height + 1, 0.5, 0f, 0f);
    }

    // ---------------------------------------------------------------
    //  Заход
    // ---------------------------------------------------------------

    /** Вход в мир Избранных: проверка ранга, ворот и лимита заходов. */
    public void join(Player player) {
        if (!enabled) {
            messages.send(player, "ascended.disabled");
            return;
        }
        if (!isS(player)) {
            messages.send(player, "ascended.rank-only");
            return;
        }
        if (!open()) {
            messages.send(player, "ascended.gate-locked", Map.of(
                    "required", String.valueOf(requiredSRank),
                    "have", String.valueOf(sRankCount())));
            return;
        }
        if (inRun(player)) {
            messages.send(player, "ascended.already");
            return;
        }
        if (runsToday(player.getUniqueId()) >= runsPerDay) {
            messages.send(player, "ascended.daily-limit", Map.of("limit", String.valueOf(runsPerDay)));
            return;
        }
        Long cooldown = cooldowns.get(player.getUniqueId());
        if (cooldown != null && cooldown > System.currentTimeMillis()) {
            messages.send(player, "ascended.cooldown", Map.of(
                    "seconds", String.valueOf((cooldown - System.currentTimeMillis()) / 1000 + 1)));
            return;
        }
        Location spawn = spawn();
        if (spawn == null) {
            messages.send(player, "ascended.world-error");
            return;
        }
        if (player.getWorld() != spawn.getWorld()) {
            player.teleport(spawn);
        }
        Run run = currentRun();
        if (run == null) {
            run = new Run(player);
            runs.put(player.getUniqueId(), run);
            runsToday.merge(dayKey() + ":" + player.getUniqueId(), 1, Integer::sum);
            startNextWave(run);
        } else {
            if (run.members.size() >= groupSize) {
                messages.send(player, "ascended.group-full", Map.of("size", String.valueOf(groupSize)));
                return;
            }
            run.members.add(player.getUniqueId());
            runs.put(player.getUniqueId(), run);
        }
        messages.send(player, "ascended.joined", Map.of(
                "wave", String.valueOf(run.wave),
                "waves", String.valueOf(wavesPerRun)));
    }

    /** Объявление об открытии мира: вызывается из тика, когда порог впервые достигнут. */
    private boolean announced = false;

    private void checkGate() {
        if (!enabled || announced) {
            return;
        }
        if (!open()) {
            return;
        }
        announced = true;
        if (announce) {
            Bukkit.getOnlinePlayers().forEach(viewer -> messages.send(viewer, "ascended.gate-open",
                    Map.of("count", String.valueOf(requiredSRank))));
        }
    }

    private Run currentRun() {
        for (Run run : runs.values()) {
            if (!run.finished) {
                return run;
            }
        }
        return null;
    }

    public boolean inRun(Player player) {
        Run run = runs.get(player.getUniqueId());
        return run != null && !run.finished;
    }

    // ---------------------------------------------------------------
    //  Волны
    // ---------------------------------------------------------------

    private void startNextWave(Run run) {
        run.wave++;
        run.bestWave = Math.max(run.bestWave, run.wave);
        World world = world();
        if (world == null) {
            return;
        }
        boolean boss = bossEvery > 0 && run.wave % bossEvery == 0;
        int count = mobCount(run.wave);
        // суммарное здоровье волны делится между мобами: волна из 12 мобов не становится
        // 12 боссами, а босс на пятой волне получает всё здоровье волны целиком
        double totalHp = baseHp * Math.pow(hpGrowth, run.wave - 1) * (boss ? bossHpMultiplier : 1.0);
        double hp = totalHp / count;
        double damage = baseDamage * Math.pow(damageGrowth, run.wave - 1) * (boss ? bossDamageMultiplier : 1.0);
        List<EntityType> types = new ArrayList<>();
        for (Mob mob : mobs) {
            if (mob.from() <= run.wave) {
                types.add(mob.type());
            }
        }
        if (types.isEmpty()) {
            types.add(EntityType.ZOMBIE);
        }
        if (boss) {
            EntityType bossType = bossType(run.wave);
            spawnMob(world, bossType, run, totalHp * 0.6, damage * bossDamageMultiplier);
        }
        for (int i = 0; i < Math.max(1, count); i++) {
            spawnMob(world, types.get(ThreadLocalRandom.current().nextInt(types.size())), run, hp, damage);
        }
        run.nextWaveAt = System.currentTimeMillis() + pauseSeconds * 1000L;
        for (UUID member : run.members) {
            Player online = Bukkit.getPlayer(member);
            if (online != null && online.isOnline()) {
                messages.send(online, boss ? "ascended.wave-boss" : "ascended.wave",
                        Map.of("wave", String.valueOf(run.wave),
                                "waves", String.valueOf(wavesPerRun),
                                "mobs", String.valueOf(count)));
            }
        }
    }

    /** Сколько мобов на волне: +0.5 за волну, но не больше предела. */
    private int mobCount(int wave) {
        return Math.max(1, Math.min(maxMobs, baseMobs + (int) Math.floor((wave - 1) * mobsGrowth)));
    }

    private EntityType bossType(int wave) {
        EntityType chosen = bosses.isEmpty() ? EntityType.RAVAGER : bosses.get(0).type();
        for (Mob boss : bosses) {
            if (boss.from() <= wave) {
                chosen = boss.type();
            }
        }
        return chosen;
    }

    private void spawnMob(World world, EntityType type, Run run, double hp, double damage) {
        double angle = ThreadLocalRandom.current().nextDouble() * Math.PI * 2;
        double radius = platformRadius - 12;
        Location location = new Location(world, Math.cos(angle) * radius, height + 1, Math.sin(angle) * radius);
        if (!world.isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4)) {
            world.loadChunk(location.getBlockX() >> 4, location.getBlockZ() >> 4);
        }
        var entity = world.spawnEntity(location, type);
        if (!(entity instanceof LivingEntity living)) {
            return;
        }
        var maxHealth = living.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(hp);
            living.setHealth(Math.min(hp, maxHealth.getValue()));
        }
        var attack = living.getAttribute(Attribute.ATTACK_DAMAGE);
        if (attack != null) {
            attack.setBaseValue(damage);
        }
        living.setPersistent(false);
        run.alive.add(living.getUniqueId());
        living.setRemoveWhenFarAway(false);
    }

    private void tick() {
        checkGate();
        if (!enabled) {
            return;
        }
        tick++;
        long now = System.currentTimeMillis();
        for (Run run : new ArrayList<>(runs.values())) {
            if (run.finished) {
                continue;
            }
            boolean anyOnline = run.members.stream().map(Bukkit::getPlayer)
                    .anyMatch(player -> player != null && player.isOnline()
                            && player.getWorld() == world());
            if (!anyOnline) {
                finish(run, false);
                continue;
            }
            run.alive.removeIf(uuid -> {
                var entity = Bukkit.getEntity(uuid);
                return entity == null || entity.isDead();
            });
            if (run.alive.isEmpty() && run.wave > 0) {
                if (run.wave >= wavesPerRun) {
                    finish(run, true);
                    continue;
                }
                if (now < run.nextWaveAt) {
                    continue;
                }
                startNextWave(run);
            }
        }
    }

    /** Конец забега: осколки, рекорд, сообщение. */
    private void finish(Run run, boolean victory) {
        if (run.finished) {
            return;
        }
        run.finished = true;
        int shards = shardsBase + (int) Math.round((run.bestWave - 1) * shardsGrowth)
                + run.bestWave / Math.max(1, bossEvery) * shardsBoss;
        for (UUID member : run.members) {
            runs.remove(member);
            Player player = Bukkit.getPlayer(member);
            if (player == null || !player.isOnline()) {
                continue;
            }
            plugin.getDonate().giveShards(player, shards);
            messages.send(player, victory ? "ascended.victory" : "ascended.over", Map.of(
                    "wave", String.valueOf(run.bestWave),
                    "shards", String.valueOf(shards)));
        }
        // пауза между заходами: один забег вместо бесконечного фарма волн
        cooldowns.put(run.owner.getUniqueId(), System.currentTimeMillis() + 60_000L);
    }

    public void forget(UUID uuid) {
        Run run = runs.remove(uuid);
        if (run != null && run.members.isEmpty()) {
            run.finished = true;
        }
    }

    /** Линия для HUD: «Волна 7/20, мобов 5». */
    public String statusLine(Player player) {
        Run run = runs.get(player.getUniqueId());
        if (run == null || run.finished) {
            return "";
        }
        return "&5Избранные: &fволна " + run.wave + "&7/&f" + wavesPerRun
                + " &8| живых мобов: &f" + run.alive.size();
    }

    /** Таблица для отчёта и /ag world info: волна, мобы, HP, урон. */
    public List<String> ladder() {
        List<String> lines = new ArrayList<>();
        for (int wave = 1; wave <= wavesPerRun; wave++) {
            boolean boss = bossEvery > 0 && wave % bossEvery == 0;
            int count = mobCount(wave);
            double totalHp = baseHp * Math.pow(hpGrowth, wave - 1) * (boss ? bossHpMultiplier : 1.0);
            double damage = baseDamage * Math.pow(damageGrowth, wave - 1) * (boss ? bossDamageMultiplier : 1.0);
            String shards = String.valueOf(shardsBase + (int) (wave - 1) * shardsGrowth
                    + (boss ? shardsBoss : 0));
            lines.add(String.format("&8волна &f%2d&8: &7мобов &f%d&7 (HP %s каждый), урон &f%.0f"
                            + "&7, осколков &f%s%s",
                    wave, boss ? count + 1 : count, boss ? "босс " + Math.round(totalHp * 0.6) + " / "
                            : Math.round(totalHp / count) + "", damage, shards,
                    boss ? " &c[босс]" : ""));
        }
        return lines;
    }

    /** Сколько записей показывать в /ag world top. */
    public int topSize() {
        return topSize;
    }

    /** Название и ключ титула недели: читаются из ascended.yml, объявляются при закрытии. */
    public String weeklyTitle() {
        return plugin.getFiles().load("ascended.yml").getString("records.weekly-title", "");
    }

    public String weeklyUnlock() {
        return plugin.getFiles().load("ascended.yml").getString("records.weekly-unlock", "");
    }

    public Map<String, String> info() {
        Map<String, String> info = new LinkedHashMap<>();
        info.put("s-rank", String.valueOf(sRankCount()));
        info.put("required", String.valueOf(requiredSRank));
        info.put("open", open() ? "да" : "нет");
        info.put("waves", String.valueOf(wavesPerRun));
        return info;
    }
}
