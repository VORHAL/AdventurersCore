package ru.adventurers.core.board;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.BlockFace;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Доски в мире: деревянная рамка с пробковой поверхностью и приколотыми листками, над ней надпись.
 * ПКМ по доске открывает меню: заданий, контрактов или вторжений. Ставится админом на стену здания:
 * /ag admin board add quests|contracts|invasions. Доски хранятся в boards.yml, сами фигуры
 * (display-сущности) не сохраняются в мире и создаются при загрузке чанка.
 */
public class BoardManager implements Listener {

    private record Board(String id, String type, String world, double x, double y, double z, float yaw) {
    }

    private final AdventurersCore plugin;
    private final File file;
    private final NamespacedKey markKey;
    private final Map<String, Board> boards = new LinkedHashMap<>();
    private final Map<String, List<UUID>> spawned = new HashMap<>();
    private final Map<UUID, String> clickMap = new HashMap<>();
    private final Map<UUID, Long> cooldown = new HashMap<>();
    private int counter;

    public BoardManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "boards.yml");
        this.markKey = new NamespacedKey(plugin, "board_part");
    }

    // ---------------------------------------------------------------
    //  Хранение
    // ---------------------------------------------------------------

    public void init() {
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        var section = cfg.getConfigurationSection("boards");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                var b = section.getConfigurationSection(id);
                if (b != null) {
                    boards.put(id, new Board(id, b.getString("type", "quests"), b.getString("world", "world"),
                            b.getDouble("x"), b.getDouble("y"), b.getDouble("z"), (float) b.getDouble("yaw")));
                    counter = Math.max(counter, id.hashCode() & 0xff);
                }
            }
        }
        // «осиротевшие» фигуры после аварийного выключения
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity.getPersistentDataContainer().has(markKey, PersistentDataType.BYTE)) {
                    entity.remove();
                }
            }
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> boards.values().forEach(this::spawn), 20L);
        Bukkit.getScheduler().runTaskTimer(plugin, this::hint, 40L, 20L);
    }

    public void shutdown() {
        new ArrayList<>(spawned.keySet()).forEach(this::despawn);
    }

    private void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Board b : boards.values()) {
            String path = "boards." + b.id();
            cfg.set(path + ".type", b.type());
            cfg.set(path + ".world", b.world());
            cfg.set(path + ".x", b.x());
            cfg.set(path + ".y", b.y());
            cfg.set(path + ".z", b.z());
            cfg.set(path + ".yaw", b.yaw());
        }
        try {
            cfg.save(file);
        } catch (IOException exception) {
            plugin.getLogger().warning("boards.yml: " + exception.getMessage());
        }
    }

    // ---------------------------------------------------------------
    //  Фигуры
    // ---------------------------------------------------------------

    private static String title(String type) {
        return switch (type) {
            case "contracts" -> "&6&lДОСКА КОНТРАКТОВ";
            case "invasions" -> "&5&lВТОРЖЕНИЯ";
            default -> "&6&lДОСКА ЗАДАНИЙ";
        };
    }

    private static String subtitle(String type) {
        return switch (type) {
            case "contracts" -> "&7Недельные, месячные и редкие";
            case "invasions" -> "&7Порталы и карта мира";
            default -> "&7Задания гильдии на сегодня";
        };
    }

    private <T extends Entity> T mark(T entity, String boardId) {
        entity.setPersistent(false);
        entity.getPersistentDataContainer().set(markKey, PersistentDataType.BYTE, (byte) 1);
        spawned.computeIfAbsent(boardId, k -> new ArrayList<>()).add(entity.getUniqueId());
        return entity;
    }

    private static Transformation tf(float tx, float ty, float tz, float sx, float sy, float sz, float rollDeg) {
        return new Transformation(new Vector3f(tx, ty, tz),
                new AxisAngle4f((float) Math.toRadians(rollDeg), 0, 0, 1), new Vector3f(sx, sy, sz), new AxisAngle4f());
    }

    private void spawn(Board board) {
        World world = Bukkit.getWorld(board.world());
        if (world == null) {
            return;
        }
        Location center = new Location(world, board.x(), board.y(), board.z(), board.yaw(), 0f);
        if (!world.isChunkLoaded(center.getBlockX() >> 4, center.getBlockZ() >> 4)) {
            return;
        }
        despawn(board.id());
        String id = board.id();

        // рамка и «пробка»
        world.spawn(center, BlockDisplay.class, d -> {
            mark(d, id);
            d.setBlock(Material.DARK_OAK_PLANKS.createBlockData());
            d.setTransformation(tf(-1.2f, -0.85f, -0.08f, 2.4f, 1.7f, 0.14f, 0));
        });
        world.spawn(center, BlockDisplay.class, d -> {
            mark(d, id);
            d.setBlock(Material.BROWN_TERRACOTTA.createBlockData());
            d.setTransformation(tf(-1.1f, -0.75f, -0.06f, 2.2f, 1.5f, 0.15f, 0));
        });
        // листки
        float[][] notes = {{-0.75f, 0.3f, -7}, {-0.15f, 0.38f, 5}, {0.5f, 0.28f, -4}, {0.9f, 0.34f, 8},
                {-0.55f, -0.3f, 6}, {0.1f, -0.36f, -6}, {0.7f, -0.28f, 3}};
        for (float[] n : notes) {
            world.spawn(center, ItemDisplay.class, d -> {
                mark(d, id);
                d.setItemStack(new ItemStack(Material.PAPER));
                d.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
                d.setTransformation(tf(n[0], n[1], 0.095f, 0.5f, 0.5f, 0.02f, n[2]));
            });
        }
        // надпись над доской
        world.spawn(center, TextDisplay.class, d -> {
            mark(d, id);
            d.text(Hud.legacy(title(board.type())).appendNewline().append(Hud.legacy(subtitle(board.type()))));
            d.setBillboard(Display.Billboard.FIXED);
            d.setBackgroundColor(org.bukkit.Color.fromARGB(0, 0, 0, 0));
            d.setShadowed(true);
            d.setTransformation(tf(0, 1.15f, 0.1f, 1.0f, 1.0f, 1.0f, 0));
        });
        // область клика
        Location low = center.clone().add(0, -0.85, 0);
        Interaction hit = world.spawn(low, Interaction.class, d -> {
            mark(d, id);
            d.setInteractionWidth(2.4f);
            d.setInteractionHeight(1.7f);
            d.setResponsive(true);
        });
        clickMap.put(hit.getUniqueId(), id);
    }

    private void despawn(String boardId) {
        List<UUID> list = spawned.remove(boardId);
        if (list == null) {
            return;
        }
        for (UUID uuid : list) {
            Entity entity = Bukkit.getEntity(uuid);
            if (entity != null) {
                entity.remove();
            }
            clickMap.remove(uuid);
        }
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        if (boards.isEmpty()) {
            return;
        }
        String worldName = event.getWorld().getName();
        int cx = event.getChunk().getX();
        int cz = event.getChunk().getZ();
        for (Board board : boards.values()) {
            if (board.world().equals(worldName) && ((int) Math.floor(board.x())) >> 4 == cx
                    && ((int) Math.floor(board.z())) >> 4 == cz) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> spawn(board), 5L);
            }
        }
    }

    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent event) {
        String worldName = event.getWorld().getName();
        int cx = event.getChunk().getX();
        int cz = event.getChunk().getZ();
        for (Board board : boards.values()) {
            if (board.world().equals(worldName) && ((int) Math.floor(board.x())) >> 4 == cx
                    && ((int) Math.floor(board.z())) >> 4 == cz) {
                despawn(board.id());
            }
        }
    }

    // ---------------------------------------------------------------
    //  Взаимодействие
    // ---------------------------------------------------------------

    private void use(Player player, String boardId) {
        Board board = boards.get(boardId);
        if (board == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - cooldown.getOrDefault(player.getUniqueId(), 0L) < 500) {
            return;
        }
        cooldown.put(player.getUniqueId(), now);
        player.playSound(player.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1f);
        switch (board.type()) {
            case "contracts" -> plugin.getContracts().open(player);
            case "invasions" -> plugin.getInvasions().command(player, new String[]{"invasion"});
            default -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "dm open ag_quests " + player.getName());
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent event) {
        String id = clickMap.get(event.getRightClicked().getUniqueId());
        if (id != null) {
            event.setCancelled(true);
            if (event.getHand() == EquipmentSlot.HAND) {
                use(event.getPlayer(), id);
            }
        }
    }

    @EventHandler
    public void onAttack(EntityDamageByEntityEvent event) {
        String id = clickMap.get(event.getEntity().getUniqueId());
        if (id != null) {
            event.setCancelled(true);
            if (event.getDamager() instanceof Player player) {
                use(player, id);
            }
        }
    }

    /** Подсказка рядом с доской. */
    private void hint() {
        if (boards.isEmpty()) {
            return;
        }
        for (Board board : boards.values()) {
            World world = Bukkit.getWorld(board.world());
            if (world == null) {
                continue;
            }
            Location at = new Location(world, board.x(), board.y(), board.z());
            for (Player player : world.getPlayers()) {
                if (player.getLocation().distanceSquared(at) <= 16) {
                    player.sendActionBar(Hud.legacy("&7Нажмите &eПКМ &7по доске: &f"
                            + plugin.getMessages().stripColors(title(board.type()))));
                }
            }
        }
    }

    // ---------------------------------------------------------------
    //  Админ: /ag admin board add <тип> | remove | list | reload
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        String action = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
        switch (action) {
            case "add" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Hud.legacy("&cТолько в игре."));
                    return;
                }
                String type = args.length > 3 ? args[3].toLowerCase(Locale.ROOT) : "quests";
                if (!List.of("quests", "contracts", "invasions").contains(type)) {
                    sender.sendMessage(Hud.legacy("&c/ag admin board add quests|contracts|invasions &7(смотрите на стену)"));
                    return;
                }
                RayTraceResult hit = player.rayTraceBlocks(6);
                if (hit == null || hit.getHitBlock() == null || hit.getHitBlockFace() == null) {
                    sender.sendMessage(Hud.legacy("&cПосмотрите на стену (до 6 блоков)."));
                    return;
                }
                BlockFace face = hit.getHitBlockFace();
                if (face == BlockFace.UP || face == BlockFace.DOWN) {
                    sender.sendMessage(Hud.legacy("&cДоска вешается на вертикальную стену."));
                    return;
                }
                double nx = face.getModX();
                double nz = face.getModZ();
                Location block = hit.getHitBlock().getLocation().add(0.5, 0.5, 0.5);
                float yaw = (float) Math.toDegrees(Math.atan2(-nx, nz));
                String id = type.charAt(0) + Long.toString(System.currentTimeMillis() % 100000, 36) + (++counter);
                Board board = new Board(id, type, block.getWorld().getName(), block.getX() + nx * 0.56,
                        block.getY() + 0.4, block.getZ() + nz * 0.56, yaw);
                boards.put(id, board);
                save();
                spawn(board);
                sender.sendMessage(Hud.legacy("&aДоска поставлена: &f" + id + " &7(" + type + ")"));
            }
            case "remove" -> {
                if (!(sender instanceof Player player)) {
                    return;
                }
                Board nearest = null;
                double best = 36;
                for (Board board : boards.values()) {
                    World world = Bukkit.getWorld(board.world());
                    if (world == null || !world.equals(player.getWorld())) {
                        continue;
                    }
                    double d = player.getLocation().distanceSquared(new Location(world, board.x(), board.y(), board.z()));
                    if (d < best) {
                        best = d;
                        nearest = board;
                    }
                }
                if (nearest == null) {
                    sender.sendMessage(Hud.legacy("&cРядом (6 блоков) досок нет."));
                    return;
                }
                despawn(nearest.id());
                boards.remove(nearest.id());
                save();
                sender.sendMessage(Hud.legacy("&aДоска удалена: &f" + nearest.id()));
            }
            case "list" -> {
                sender.sendMessage(Hud.legacy("&6Доски: &f" + boards.size()));
                boards.values().forEach(b -> sender.sendMessage(Hud.legacy("&8» &f" + b.id() + " &7" + b.type() + " "
                        + b.world() + " " + (int) b.x() + ", " + (int) b.y() + ", " + (int) b.z())));
            }
            case "reload" -> {
                shutdown();
                boards.clear();
                init();
                sender.sendMessage(Hud.legacy("&aДоски перезагружены."));
            }
            default -> sender.sendMessage(Hud.legacy("&7/ag admin board add quests|contracts|invasions | remove | list | reload"));
        }
    }
}
