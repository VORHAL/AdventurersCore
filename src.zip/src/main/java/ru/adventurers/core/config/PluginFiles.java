package ru.adventurers.core.config;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Раскладка конфигов по папкам (раздел 21 отчёта).
 *
 * <p>Проблема: до этого раздела в папке плагина лежало 39 yml вперемешку - сообщения,
 * подземелья, броня, экономика, испытания. Администратор не понимал, что можно трогать,
 * а что сломает игру, и случайно правил не тот файл.
 *
 * <p>Решение: файлы раскладываются по семи папкам по смыслу, а код обращается к ним
 * через {@link #file(String)} - поэтому перенос не зависит от того, помнит ли каждый
 * менеджер новый путь. Раскладка описана одной таблицей {@link #LAYOUT}, старые файлы
 * переносятся автоматически при первом запуске (содержимое не меняется, данные не теряются).
 *
 * <pre>
 * plugins/AdventurersCore/
 *   config.yml              - главные настройки
 *   messages.yml            - сообщения (остаётся в корне: его правят чаще всего)
 *   content/                - контент игры: классы, ранги, профессии, руны, питомцы, слава
 *   combat/                 - бой и способности: танк, лекарь, умения, оружие, эффекты
 *   economy/                - деньги и торговля: экономика, магазин, аукцион, контракты, вторжения
 *   dungeons/               - подземелья и их добыча
 *   world/                  - миры, правила миров, HUD, TAB, скорборд, MOTD, чат
 *   events/                 - испытания, донат, сезоны
 *   data/                   - служебные файлы (не для правки): кэши, данные наставников
 * </pre>
 */
public final class PluginFiles {

    /** Куда переехал каждый файл: имя в корне -> папка. */
    private static final Map<String, String> LAYOUT = new LinkedHashMap<>();

    static {
        for (String name : List.of("classes.yml", "ranks.yml", "professions.yml", "runes.yml",
                "pets.yml", "glory.yml", "quests.yml", "passives.yml", "gems.yml", "mentor.yml",
                "covenants.yml", "recipes.yml", "gender.yml")) {
            LAYOUT.put(name, "content");
        }
        for (String name : List.of("tank.yml", "healer.yml", "skillhud.yml", "weapon.yml",
                "gear.yml", "guildgear.yml", "abilities.yml", "cursed.yml")) {
            LAYOUT.put(name, "combat");
        }
        for (String name : List.of("economy.yml", "shop.yml", "contracts.yml", "invasions.yml")) {
            LAYOUT.put(name, "economy");
        }
        for (String name : List.of("dungeons.yml", "dungeon-loot.yml")) {
            LAYOUT.put(name, "dungeons");
        }
        for (String name : List.of("world.yml", "world-data.yml", "survival.yml", "tab.yml",
                "scoreboard.yml", "motd.yml", "frames.yml", "party.yml", "chat.yml", "seasonal.yml",
                "server-icon.png")) {
            LAYOUT.put(name, "world");
        }
        for (String name : List.of("events.yml", "donate.yml", "ascended.yml", "onboarding.yml")) {
            LAYOUT.put(name, "events");
        }
        // служебные файлы лежат в data/, даже если плагин создаёт их сам при первом запуске
        LAYOUT.put("mentors-data.yml", "data");
        LAYOUT.put("invasions-data.yml", "data");
    }

    /** Файлы, которые остаются в корне папки плагина. */
    private static final List<String> ROOT = List.of("config.yml", "messages.yml");

    private static final List<String> FOLDERS = List.of(
            "content", "combat", "economy", "dungeons", "world", "events", "data");

    private final JavaPlugin plugin;
    private final List<String> moved = new ArrayList<>();

    public PluginFiles(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /** Папка, в которой лежит файл (пустая строка - корень). */
    public static String folderOf(String name) {
        return LAYOUT.getOrDefault(name, "");
    }

    /**
     * Полный путь к файлу конфига с учётом раскладки.
     *
     * <p>Если имя не описано в раскладке (папка схем подземелий, вложенный путь вида
     * dungeons/test.yml, картинка сервера), путь остаётся прежним: такие файлы - это уже
     * структура данных, а не настройки, и переносить их нельзя.
     */
    public File file(String name) {
        if (!LAYOUT.containsKey(name)) {
            return new File(plugin.getDataFolder(), name);
        }
        return new File(new File(plugin.getDataFolder(), LAYOUT.get(name)), name);
    }

    /**
     * Раскладка при запуске: создаёт папки и переносит старые файлы из корня.
     * Возвращает список перенесённых файлов (для сообщения в лог).
     */
    public List<String> migrate() {
        moved.clear();
        File dataFolder = plugin.getDataFolder();
        if (!dataFolder.exists() && !dataFolder.mkdirs()) {
            return moved;
        }
        for (String folder : FOLDERS) {
            File dir = new File(dataFolder, folder);
            if (!dir.exists() && !dir.mkdirs()) {
                plugin.getLogger().warning("Не удалось создать папку конфигов " + folder);
            }
        }
        // переносим старые файлы только если в новой папке файла ещё нет:
        // иначе можно затереть правки администратора
        for (Map.Entry<String, String> entry : LAYOUT.entrySet()) {
            File from = new File(dataFolder, entry.getKey());
            File to = new File(new File(dataFolder, entry.getValue()), entry.getKey());
            if (!from.isFile() || to.exists()) {
                continue;
            }
            if (from.renameTo(to)) {
                moved.add(entry.getKey() + " -> " + entry.getValue() + "/");
            } else {
                // если перенос не удался (файл занят, права), копируем и оставляем оригинал
                try {
                    Files.copy(from.toPath(), to.toPath());
                    moved.add(entry.getKey() + " -> " + entry.getValue() + "/ (копия)");
                } catch (IOException exception) {
                    plugin.getLogger().warning("Не удалось перенести " + entry.getKey()
                            + ": " + exception.getMessage());
                }
            }
        }
        writeReadme(dataFolder);
        return moved;
    }

    public List<String> moved() {
        return moved;
    }

    /** Короткая записка для администратора: что где лежит. */
    private void writeReadme(File dataFolder) {
        File readme = new File(dataFolder, "ГДЕ_ЧТО_ЛЕЖИТ.txt");
        if (readme.exists()) {
            return;
        }
        List<String> lines = new ArrayList<>();
        lines.add("AdventurersCore: где что лежит");
        lines.add("");
        lines.add("В корне:");
        lines.add("  config.yml    - главные настройки (БД, язык, включение модулей)");
        lines.add("  messages.yml  - ВСЕ сообщения игрокам, по разделам");
        lines.add("");
        lines.add("content/  - контент игры: классы, ранги, профессии, руны, питомцы, слава,");
        lines.add("            задания, пассивки, самоцветы, наставники, ковенанты, рецепты, пол");
        lines.add("combat/   - бой и способности: танк, лекарь, HUD умений, оружие, экипировка");
        lines.add("economy/  - деньги и торговля: экономика, магазин, аукцион, контракты, вторжения");
        lines.add("dungeons/ - подземелья: описание, добыча, свои схемы");
        lines.add("world/    - миры и интерфейс: правила миров, выживание, TAB, скорборд, MOTD, чат");
        lines.add("events/   - еженедельные испытания (events.yml) и донат (donate.yml)");
        lines.add("data/     - служебные данные, руками не править");
        lines.add("");
        lines.add("Правила:");
        lines.add("  1. messages.yml правьте через /ag admin reload - плагин проверит ключи.");
        lines.add("  2. В content/ и combat/ числа связаны, см. AUDIT_AND_BALANCE_2026-11-24.md.");
        lines.add("  3. В events/ можно менять награды, но рост наград ограничен балансом.");
        lines.add("  4. Файлы в data/ плагин перезаписывает сам.");
        try (var writer = Files.newBufferedWriter(readme.toPath(), StandardCharsets.UTF_8)) {
            for (String line : lines) {
                writer.write(line);
                writer.write(System.lineSeparator());
            }
        } catch (IOException exception) {
            plugin.getLogger().warning("Не удалось записать ГДЕ_ЧТО_ЛЕЖИТ.txt: "
                    + exception.getMessage());
        }
    }

    /**
     * Кладёт ресурс из jar в нужную папку (замена plugin.saveResource(name, false)).
     * Вложенные ресурсы (dungeons/test.yml) отдаёт самому плагину - он умеет их раскладывать.
     */
    public File save(String resource) {
        File target = file(resource);
        if (!LAYOUT.containsKey(resource) && resource.contains("/")) {
            // вложенный ресурс (схема подземелья) - раскладывает сам плагин
            if (!target.isFile()) {
                plugin.saveResource(resource, false);
            }
            return target;
        }
        if (target.isFile()) {
            return target;
        }
        File parent = target.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            plugin.getLogger().warning("Не удалось создать папку для " + resource);
        }
        try (InputStream in = plugin.getResource(resource)) {
            if (in == null) {
                return target;
            }
            Files.copy(in, target.toPath());
        } catch (IOException exception) {
            plugin.getLogger().warning("Не удалось сохранить " + resource + ": "
                    + exception.getMessage());
        }
        return target;
    }

    /** Чтение yml с учётом раскладки (при отсутствии - сначала кладём из jar). */
    public YamlConfiguration load(String name) {
        File target = file(name);
        if (!target.isFile()) {
            save(name);
        }
        return YamlConfiguration.loadConfiguration(target);
    }

    /** Стандартные значения из jar: чтобы у старых конфигов не терялись новые ключи. */
    public YamlConfiguration defaults(String resource) {
        try (InputStream in = plugin.getResource(resource)) {
            if (in == null) {
                return new YamlConfiguration();
            }
            return YamlConfiguration.loadConfiguration(
                    new InputStreamReader(in, StandardCharsets.UTF_8));
        } catch (IOException exception) {
            return new YamlConfiguration();
        }
    }

    public static boolean isRoot(String name) {
        return ROOT.contains(name);
    }

    /** Все известные файлы конфигов (для проверок и тестов). */
    public static List<String> layout() {
        List<String> all = new ArrayList<>(ROOT);
        all.addAll(LAYOUT.keySet());
        all.sort(String::compareTo);
        return all;
    }

    /** Текстовая схема раскладки: печатается в лог при запуске и в /ag admin files. */
    public static String describe() {
        StringBuilder builder = new StringBuilder();
        builder.append("корень/").append(System.lineSeparator());
        for (String name : ROOT) {
            builder.append("  ").append(name).append(System.lineSeparator());
        }
        for (String folder : FOLDERS) {
            builder.append(folder).append('/').append(System.lineSeparator());
            LAYOUT.forEach((name, where) -> {
                if (where.equals(folder)) {
                    builder.append("  ").append(name).append(System.lineSeparator());
                }
            });
        }
        return builder.toString();
    }
}
