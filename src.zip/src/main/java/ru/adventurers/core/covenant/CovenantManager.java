package ru.adventurers.core.covenant;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.DatabaseManager;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * Ковенанты (кланы): создание, роли, казна, участок земли пяти размеров с защитой, чат-канал.
 * Настройки: covenants.yml, тексты: messages.yml (covenant.*). Данные в БД (ag_covenant, ag_covenant_member).
 * Все операции в основном потоке, запись в БД идёт отдельным потоком по очереди.
 */
public class CovenantManager implements Listener {

    public record Size(String id, String name, int side, long price, int level) {
    }

    private record Invite(int covenant, long expires, String from) {
    }

    private enum View { MAIN, MEMBERS, TERRITORY }

    private static final class Menu implements InventoryHolder {
        final View view;
        final int covenant;
        final Map<Integer, UUID> heads = new HashMap<>();
        final Map<Integer, String> sizes = new HashMap<>();

        Menu(View view, int covenant) {
            this.view = view;
            this.covenant = covenant;
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private static final TextDecoration NO_ITALIC = TextDecoration.ITALIC;

    private final AdventurersCore plugin;
    private final DatabaseManager database;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private final Map<Integer, Covenant> covenants = new LinkedHashMap<>();
    private final Map<UUID, Covenant> byPlayer = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();
    private final Map<UUID, Integer> standingIn = new HashMap<>();
    private final Map<UUID, Long> disbandAsk = new HashMap<>();
    private boolean ready;
    private final CovenantBank bank;
    private final CovenantWeekly weekly;
    private final CovenantBanner banner;
    /** Пороги уровней: вклады в казну (по возрастанию) и лимит участников на этом уровне. */
    private final List<long[]> levels = new ArrayList<>();

    private boolean enabled = true;
    private long createCost = 6000;
    private Rank createRank = Rank.E;
    private int nameMin = 3;
    private int nameMax = 16;
    private int maxMembers = 25;
    private long inviteMs = 60_000L;
    private List<String> claimWorlds = new ArrayList<>();
    private int spawnDistance = 300;
    private int gap = 16;
    private double refund = 0.5;
    private final List<Size> sizes = new ArrayList<>();
    private Pattern namePattern = Pattern.compile("^[\\p{L}\\p{N} _'\\-]+$");

    public CovenantManager(AdventurersCore plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
        this.bank = new CovenantBank(plugin, this);
        this.weekly = new CovenantWeekly(plugin, this);
        this.banner = new CovenantBanner(plugin, this);
    }

    public CovenantWeekly getWeekly() {
        return weekly;
    }

    public CovenantBanner getBanner() {
        return banner;
    }

    /** Меняет казну (может быть отрицательным) и сохраняет. */
    void addBank(Covenant cov, long delta) {
        cov.bank = Math.max(0, cov.bank + delta);
        saveBank(cov);
    }

    void saveWeekly(Covenant cov) {
        io("UPDATE ag_covenant SET week_score=?, goal_progress=?, goal_done=?, week_id=? WHERE id=?",
                cov.weekScore, cov.goalProgress, cov.goalDone ? 1 : 0, cov.weekId, cov.id);
    }

    void broadcastTo(Covenant cov, String key, Object... kv) {
        broadcast(cov, key, kv);
    }

    public CovenantBank getBank() {
        return bank;
    }

    Covenant byId(int id) {
        return covenants.get(id);
    }

    /** Уровень ковенанта по сумме вкладов в казну (1 и выше). */
    public int level(Covenant cov) {
        int level = 1;
        for (int i = 0; i < levels.size(); i++) {
            if (cov.contributed >= levels.get(i)[0]) {
                level = i + 1;
            }
        }
        return level;
    }

    public int maxMembers(Covenant cov) {
        int level = Math.min(level(cov), levels.size());
        return levels.isEmpty() ? maxMembers : (int) levels.get(level - 1)[1];
    }

    // ---------------------------------------------------------------
    //  Запуск
    // ---------------------------------------------------------------

    public void init() {
        reload();
        try (Connection connection = database.getConnection()) {
            try (Statement statement = connection.createStatement()) {
                statement.executeUpdate("""
                        CREATE TABLE IF NOT EXISTS ag_covenant (
                            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            name VARCHAR(32) NOT NULL,
                            leader CHAR(36) NOT NULL,
                            bank BIGINT NOT NULL DEFAULT 0,
                            created BIGINT NOT NULL,
                            t_world VARCHAR(64) NULL,
                            t_x INT NOT NULL DEFAULT 0,
                            t_z INT NOT NULL DEFAULT 0,
                            t_half INT NOT NULL DEFAULT 0,
                            t_size VARCHAR(32) NULL,
                            UNIQUE KEY uq_cov_name (name)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                        """);
                statement.executeUpdate("""
                        CREATE TABLE IF NOT EXISTS ag_covenant_member (
                            uuid CHAR(36) NOT NULL PRIMARY KEY,
                            covenant INT NOT NULL,
                            role VARCHAR(12) NOT NULL,
                            name VARCHAR(32) NOT NULL,
                            joined BIGINT NOT NULL,
                            KEY ix_cov_member (covenant)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                        """);
                // обновление с v27: новые столбцы и таблицы банка
                statement.executeUpdate("ALTER TABLE ag_covenant_member ADD COLUMN IF NOT EXISTS contrib BIGINT NOT NULL DEFAULT 0");
                statement.executeUpdate("ALTER TABLE ag_covenant ADD COLUMN IF NOT EXISTS motd VARCHAR(200) NOT NULL DEFAULT ''");
                statement.executeUpdate("ALTER TABLE ag_covenant ADD COLUMN IF NOT EXISTS contributed BIGINT NOT NULL DEFAULT 0");
                statement.executeUpdate("ALTER TABLE ag_covenant ADD COLUMN IF NOT EXISTS tabs_open INT NOT NULL DEFAULT 1");
                statement.executeUpdate("ALTER TABLE ag_covenant ADD COLUMN IF NOT EXISTS week_score BIGINT NOT NULL DEFAULT 0");
                statement.executeUpdate("ALTER TABLE ag_covenant ADD COLUMN IF NOT EXISTS goal_progress BIGINT NOT NULL DEFAULT 0");
                statement.executeUpdate("ALTER TABLE ag_covenant ADD COLUMN IF NOT EXISTS goal_done TINYINT NOT NULL DEFAULT 0");
                statement.executeUpdate("ALTER TABLE ag_covenant ADD COLUMN IF NOT EXISTS week_id INT NOT NULL DEFAULT 0");
                statement.executeUpdate("""
                        CREATE TABLE IF NOT EXISTS ag_covenant_item (
                            covenant INT NOT NULL,
                            tab INT NOT NULL,
                            slot INT NOT NULL,
                            data MEDIUMBLOB NOT NULL,
                            PRIMARY KEY (covenant, tab, slot)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                        """);
                statement.executeUpdate("""
                        CREATE TABLE IF NOT EXISTS ag_covenant_log (
                            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                            covenant INT NOT NULL,
                            ts BIGINT NOT NULL,
                            text VARCHAR(240) NOT NULL,
                            KEY ix_cov_log (covenant, id)
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                        """);
                statement.executeUpdate("DELETE FROM ag_covenant_log WHERE ts < " + (System.currentTimeMillis() - 30L * 86_400_000L));
            }
            try (Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery("SELECT * FROM ag_covenant")) {
                while (rs.next()) {
                    Covenant cov = new Covenant(rs.getInt("id"), rs.getString("name"),
                            UUID.fromString(rs.getString("leader")), rs.getLong("bank"), rs.getLong("created"));
                    cov.world = rs.getString("t_world");
                    cov.cx = rs.getInt("t_x");
                    cov.cz = rs.getInt("t_z");
                    cov.half = rs.getInt("t_half");
                    cov.sizeId = rs.getString("t_size");
                    cov.motd = rs.getString("motd") == null ? "" : rs.getString("motd");
                    cov.contributed = rs.getLong("contributed");
                    cov.tabsOpen = Math.max(1, rs.getInt("tabs_open"));
                    cov.weekScore = rs.getLong("week_score");
                    cov.goalProgress = rs.getLong("goal_progress");
                    cov.goalDone = rs.getInt("goal_done") != 0;
                    cov.weekId = rs.getInt("week_id");
                    covenants.put(cov.id, cov);
                }
            }
            try (Statement statement = connection.createStatement();
                 ResultSet rs = statement.executeQuery("SELECT * FROM ag_covenant_member ORDER BY joined")) {
                while (rs.next()) {
                    Covenant cov = covenants.get(rs.getInt("covenant"));
                    if (cov == null) {
                        continue;
                    }
                    UUID uuid = UUID.fromString(rs.getString("uuid"));
                    Covenant.Role role;
                    try {
                        role = Covenant.Role.valueOf(rs.getString("role"));
                    } catch (IllegalArgumentException exception) {
                        role = Covenant.Role.MEMBER;
                    }
                    Covenant.Member loaded = new Covenant.Member(rs.getString("name"), role, rs.getLong("joined"));
                    loaded.contrib = rs.getLong("contrib");
                    cov.members.put(uuid, loaded);
                    byPlayer.put(uuid, cov);
                }
            }
            bank.load(connection, covenants);
            banner.load(connection);
            ready = true;
            weekly.init();
            banner.start();
        } catch (SQLException exception) {
            plugin.getLogger().severe("Covenants: database error, system disabled: " + exception.getMessage());
        }
    }

    public void shutdown() {
        bank.syncAll(covenants.values());
        io.shutdown();
        try {
            io.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
    }

    public void reload() {
        File file = plugin.getFiles().file("covenants.yml");
        if (!file.exists()) {
            plugin.getFiles().save("covenants.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        createCost = Math.max(0, cfg.getLong("create.cost", 6000));
        Rank rank = Rank.fromInput(cfg.getString("create.min-rank", "E"));
        createRank = rank == null ? Rank.E : rank;
        nameMin = Math.max(2, cfg.getInt("name.min", 3));
        nameMax = Math.max(nameMin, Math.min(32, cfg.getInt("name.max", 16)));
        maxMembers = Math.max(2, cfg.getInt("max-members", 25));
        inviteMs = Math.max(10, cfg.getInt("invite-seconds", 60)) * 1000L;
        claimWorlds = new ArrayList<>(cfg.getStringList("territory.worlds"));
        spawnDistance = Math.max(0, cfg.getInt("territory.min-spawn-distance", 300));
        gap = Math.max(0, cfg.getInt("territory.gap-between", 16));
        refund = Math.max(0, Math.min(1, cfg.getDouble("territory.refund", 0.5)));
        sizes.clear();
        ConfigurationSection section = cfg.getConfigurationSection("territory.sizes");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(key);
                if (s != null) {
                    sizes.add(new Size(key.toLowerCase(Locale.ROOT), s.getString("name", key),
                            Math.max(8, s.getInt("side", 32)), Math.max(0, s.getLong("price", 10000)),
                            Math.max(1, s.getInt("level", 1))));
                }
            }
        }
        sizes.sort(java.util.Comparator.comparingInt(Size::side));
        levels.clear();
        for (Object entry : cfg.getMapList("levels")) {
            if (entry instanceof Map<?, ?> map) {
                long contrib = map.get("contributed") instanceof Number n ? n.longValue() : 0;
                long members = map.get("members") instanceof Number n ? n.longValue() : maxMembers;
                levels.add(new long[]{contrib, members});
            }
        }
        if (levels.isEmpty()) {
            levels.add(new long[]{0, maxMembers});
        }
        levels.sort(java.util.Comparator.comparingLong(a -> a[0]));
        bank.reload(cfg.getConfigurationSection("bank"));
        weekly.reload(cfg.getConfigurationSection("weekly"));
        banner.reload(cfg.getConfigurationSection("banner"));
    }

    public boolean isEnabled() {
        return enabled && ready;
    }

    // ---------------------------------------------------------------
    //  Доступ для других систем (чат, плейсхолдеры)
    // ---------------------------------------------------------------

    public Covenant of(UUID uuid) {
        return byPlayer.get(uuid);
    }

    public boolean sameCovenant(UUID a, UUID b) {
        Covenant cov = byPlayer.get(a);
        return cov != null && cov == byPlayer.get(b);
    }

    public Covenant at(Location location) {
        for (Covenant cov : covenants.values()) {
            if (cov.contains(location)) {
                return cov;
            }
        }
        return null;
    }

    public java.util.Collection<Covenant> all() {
        return covenants.values();
    }

    // ---------------------------------------------------------------
    //  Вспомогательное
    // ---------------------------------------------------------------

    void io(String sql, Object... params) {
        if (io.isShutdown()) {
            return;
        }
        io.submit(() -> {
            try (Connection connection = database.getConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                for (int i = 0; i < params.length; i++) {
                    statement.setObject(i + 1, params[i]);
                }
                statement.executeUpdate();
            } catch (SQLException exception) {
                plugin.getLogger().warning("Covenants: " + exception.getMessage());
            }
        });
    }

    void say(CommandSender to, String key, Object... kv) {
        Map<String, Object> map = new HashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            map.put(String.valueOf(kv[i]), kv[i + 1]);
        }
        plugin.getMessages().send(to, "covenant." + key, map);
    }

    private void broadcast(Covenant cov, String key, Object... kv) {
        for (UUID uuid : cov.members.keySet()) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                say(player, key, kv);
            }
        }
    }

    String money(long amount) {
        return plugin.getEconomy().format(amount);
    }

    private Covenant find(String name) {
        for (Covenant cov : covenants.values()) {
            if (cov.name.equalsIgnoreCase(name)) {
                return cov;
            }
        }
        return null;
    }

    private UUID memberByName(Covenant cov, String name) {
        for (Map.Entry<UUID, Covenant.Member> entry : cov.members.entrySet()) {
            if (entry.getValue().name.equalsIgnoreCase(name)) {
                return entry.getKey();
            }
        }
        return null;
    }

    void saveMember(UUID uuid, Covenant cov, Covenant.Member member) {
        io("REPLACE INTO ag_covenant_member (uuid, covenant, role, name, joined, contrib) VALUES (?,?,?,?,?,?)",
                uuid.toString(), cov.id, member.role.name(), member.name, member.joined, member.contrib);
    }

    private void saveBank(Covenant cov) {
        io("UPDATE ag_covenant SET bank=? WHERE id=?", cov.bank, cov.id);
    }

    private void saveTerritory(Covenant cov) {
        io("UPDATE ag_covenant SET t_world=?, t_x=?, t_z=?, t_half=?, t_size=? WHERE id=?",
                cov.world, cov.cx, cov.cz, cov.half, cov.sizeId, cov.id);
    }

    private Size size(String id) {
        for (Size s : sizes) {
            if (s.id().equalsIgnoreCase(id)) {
                return s;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------
    //  Команда /ag covenant ...
    // ---------------------------------------------------------------

    public void command(Player player, String[] args) {
        if (!isEnabled()) {
            say(player, "disabled");
            return;
        }
        String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        Covenant own = byPlayer.get(player.getUniqueId());
        switch (action) {
            case "", "menu" -> {
                if (own == null) {
                    say(player, "help-none", "cost", money(createCost), "rank", createRank.getDisplayName());
                } else {
                    openMain(player, own);
                }
            }
            case "create" -> create(player, join(args, 2));
            case "accept" -> accept(player);
            case "deny" -> {
                invites.remove(player.getUniqueId());
                say(player, "invite-denied");
            }
            case "list" -> list(player);
            case "top" -> weekly.printTop(player);
            case "info" -> {
                Covenant target = args.length > 2 ? find(join(args, 2)) : own;
                if (target == null) {
                    say(player, args.length > 2 ? "unknown" : "not-in");
                } else {
                    info(player, target);
                }
            }
            default -> {
                if (own == null) {
                    say(player, "not-in");
                    return;
                }
                member(player, own, action, args);
            }
        }
    }

    private static String join(String[] args, int from) {
        return args.length <= from ? "" : String.join(" ", java.util.Arrays.copyOfRange(args, from, args.length)).trim();
    }

    private void member(Player player, Covenant own, String action, String[] args) {
        UUID id = player.getUniqueId();
        switch (action) {
            case "invite" -> invite(player, own, args.length > 2 ? args[2] : "");
            case "leave" -> leave(player, own);
            case "kick" -> kick(player, own, args.length > 2 ? args[2] : "");
            case "promote", "demote" -> setRole(player, own, args.length > 2 ? args[2] : "", action.equals("promote"));
            case "leader" -> transfer(player, own, args.length > 2 ? args[2] : "");
            case "disband" -> disband(player, own, args.length > 2 && args[2].equalsIgnoreCase("confirm"));
            case "members" -> openMembers(player, own);
            case "bank" -> {
                if (args.length > 2 && args[2].equalsIgnoreCase("buy")) {
                    bank.buyTab(player, own);
                } else {
                    bank.openHub(player, own);
                }
            }
            case "banner" -> banner.give(player, own);
            case "goal" -> say(player, "goal-line", "goal", weekly.goalText(own));
            case "log" -> bank.printLog(player, own, 15);
            case "motd" -> motd(player, own, join(args, 2));
            case "deposit" -> deposit(player, own, args.length > 2 ? args[2] : "");
            case "withdraw" -> withdraw(player, own, args.length > 2 ? args[2] : "");
            case "territory", "land", "terr" -> territory(player, own, args);
            default -> {
                if (own.members.containsKey(id)) {
                    say(player, "usage");
                }
            }
        }
    }

    private void create(Player player, String name) {
        UUID id = player.getUniqueId();
        if (byPlayer.containsKey(id)) {
            say(player, "already-in");
            return;
        }
        PlayerProfile profile = plugin.getProfileManager().getProfile(id);
        if (profile == null || !profile.getRank().isAtLeast(createRank)) {
            say(player, "create-rank", "rank", createRank.getDisplayName());
            return;
        }
        if (name.length() < nameMin || name.length() > nameMax || !namePattern.matcher(name).matches()) {
            say(player, "name-bad", "min", nameMin, "max", nameMax);
            return;
        }
        if (find(name) != null) {
            say(player, "name-taken");
            return;
        }
        if (!plugin.getEconomy().has(id, createCost)) {
            say(player, "create-poor", "cost", money(createCost));
            return;
        }
        long now = System.currentTimeMillis();
        int newId;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO ag_covenant (name, leader, bank, created) VALUES (?,?,0,?)",
                     Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, name);
            statement.setString(2, id.toString());
            statement.setLong(3, now);
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new SQLException("no key");
                }
                newId = keys.getInt(1);
            }
        } catch (SQLException exception) {
            plugin.getLogger().warning("Covenants: create failed: " + exception.getMessage());
            say(player, "name-taken");
            return;
        }
        plugin.getEconomy().withdraw(id, createCost);
        Covenant cov = new Covenant(newId, name, id, 0, now);
        Covenant.Member member = new Covenant.Member(player.getName(), Covenant.Role.LEADER, now);
        cov.members.put(id, member);
        covenants.put(cov.id, cov);
        byPlayer.put(id, cov);
        saveMember(id, cov, member);
        say(player, "created", "name", name, "cost", money(createCost));
        Bukkit.broadcast(Hud.legacy(plugin.getMessages().text("covenant.created-global",
                "{prefix}&7Основан ковенант &f{name}&7 под началом &f{leader}&7.")
                .replace("{prefix}", plugin.getMessages().text("prefix", ""))
                .replace("{name}", name).replace("{leader}", player.getName())));
    }

    private void invite(Player player, Covenant cov, String targetName) {
        if (!cov.atLeast(player.getUniqueId(), Covenant.Role.OFFICER)) {
            say(player, "need-officer");
            return;
        }
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            say(player, "player-offline");
            return;
        }
        if (byPlayer.containsKey(target.getUniqueId())) {
            say(player, "target-in", "player", target.getName());
            return;
        }
        if (cov.members.size() >= maxMembers(cov)) {
            say(player, "full", "max", maxMembers(cov));
            return;
        }
        invites.put(target.getUniqueId(), new Invite(cov.id, System.currentTimeMillis() + inviteMs, player.getName()));
        say(player, "invite-sent", "player", target.getName());
        say(target, "invite-got", "name", cov.name, "from", player.getName(), "seconds", inviteMs / 1000);
    }

    private void accept(Player player) {
        UUID id = player.getUniqueId();
        Invite invite = invites.remove(id);
        if (invite == null || invite.expires() < System.currentTimeMillis()) {
            say(player, "invite-none");
            return;
        }
        Covenant cov = covenants.get(invite.covenant());
        if (cov == null) {
            say(player, "invite-none");
            return;
        }
        if (byPlayer.containsKey(id)) {
            say(player, "already-in");
            return;
        }
        if (cov.members.size() >= maxMembers(cov)) {
            say(player, "full", "max", maxMembers(cov));
            return;
        }
        Covenant.Member member = new Covenant.Member(player.getName(), Covenant.Role.MEMBER, System.currentTimeMillis());
        cov.members.put(id, member);
        byPlayer.put(id, cov);
        saveMember(id, cov, member);
        bank.log(cov, player.getName() + " вступил в ковенант");
        broadcast(cov, "joined", "player", player.getName());
        motdTo(player, cov);
    }

    private void leave(Player player, Covenant cov) {
        UUID id = player.getUniqueId();
        if (cov.leader.equals(id)) {
            say(player, cov.members.size() == 1 ? "leader-alone" : "leader-cant-leave");
            return;
        }
        remove(cov, id);
        bank.log(cov, player.getName() + " покинул ковенант");
        say(player, "left-self", "name", cov.name);
        broadcast(cov, "left", "player", player.getName());
    }

    private void remove(Covenant cov, UUID uuid) {
        cov.members.remove(uuid);
        byPlayer.remove(uuid);
        io("DELETE FROM ag_covenant_member WHERE uuid=?", uuid.toString());
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) {
            standingIn.remove(uuid);
            bank.closeFor(online);
            if (plugin.getChat() != null
                    && plugin.getChat().speaking(online) == ru.adventurers.core.chat.ChatChannel.COVENANT) {
                plugin.getChat().setSpeaking(online, ru.adventurers.core.chat.ChatChannel.GLOBAL);
            }
        }
    }

    private void kick(Player player, Covenant cov, String targetName) {
        UUID target = memberByName(cov, targetName);
        if (target == null) {
            say(player, "no-member");
            return;
        }
        Covenant.Role mine = cov.role(player.getUniqueId());
        Covenant.Role theirs = cov.role(target);
        if (mine == Covenant.Role.MEMBER || theirs.ordinal() <= mine.ordinal()) {
            say(player, "cant-kick");
            return;
        }
        String name = cov.members.get(target).name;
        remove(cov, target);
        bank.log(cov, name + " исключён (" + player.getName() + ")");
        broadcast(cov, "kicked", "player", name, "by", player.getName());
        Player online = Bukkit.getPlayer(target);
        if (online != null) {
            say(online, "kicked-you", "name", cov.name);
        }
    }

    private void setRole(Player player, Covenant cov, String targetName, boolean up) {
        if (!cov.leader.equals(player.getUniqueId())) {
            say(player, "need-leader");
            return;
        }
        UUID target = memberByName(cov, targetName);
        if (target == null || target.equals(cov.leader)) {
            say(player, "no-member");
            return;
        }
        Covenant.Member member = cov.members.get(target);
        member.role = up ? Covenant.Role.OFFICER : Covenant.Role.MEMBER;
        saveMember(target, cov, member);
        broadcast(cov, up ? "promoted" : "demoted", "player", member.name);
    }

    private void transfer(Player player, Covenant cov, String targetName) {
        if (!cov.leader.equals(player.getUniqueId())) {
            say(player, "need-leader");
            return;
        }
        UUID target = memberByName(cov, targetName);
        if (target == null || target.equals(cov.leader)) {
            say(player, "no-member");
            return;
        }
        Covenant.Member old = cov.members.get(cov.leader);
        old.role = Covenant.Role.OFFICER;
        saveMember(cov.leader, cov, old);
        Covenant.Member fresh = cov.members.get(target);
        fresh.role = Covenant.Role.LEADER;
        cov.leader = target;
        saveMember(target, cov, fresh);
        io("UPDATE ag_covenant SET leader=? WHERE id=?", target.toString(), cov.id);
        broadcast(cov, "new-leader", "player", fresh.name);
    }

    private void disband(Player player, Covenant cov, boolean confirmed) {
        UUID id = player.getUniqueId();
        if (!cov.leader.equals(id)) {
            say(player, "need-leader");
            return;
        }
        Long asked = disbandAsk.get(id);
        if (!confirmed || asked == null || System.currentTimeMillis() - asked > 30_000L) {
            disbandAsk.put(id, System.currentTimeMillis());
            say(player, "disband-ask");
            return;
        }
        if (bank.hasItems(cov)) {
            say(player, "disband-items");
            return;
        }
        disbandAsk.remove(id);
        dissolve(cov, true);
    }

    /** Распускает ковенант; казна уходит главе. */
    private void dissolve(Covenant cov, boolean payLeader) {
        broadcast(cov, "disbanded", "name", cov.name);
        if (payLeader && cov.bank > 0) {
            plugin.getEconomy().deposit(cov.leader, cov.bank);
        }
        for (UUID uuid : new ArrayList<>(cov.members.keySet())) {
            remove(cov, uuid);
        }
        covenants.remove(cov.id);
        bank.deleteAll(cov.id);
        banner.clear(cov.id);
        io("DELETE FROM ag_covenant WHERE id=?", cov.id);
        io("DELETE FROM ag_covenant_member WHERE covenant=?", cov.id);
    }

    private long amount(Player player, String text, long max) {
        if (text.equalsIgnoreCase("all")) {
            return max;
        }
        try {
            return Long.parseLong(text.replace(" ", ""));
        } catch (NumberFormatException exception) {
            return -1;
        }
    }

    private void deposit(Player player, Covenant cov, String text) {
        long have = plugin.getEconomy().balance(player.getUniqueId());
        long value = amount(player, text, have);
        if (value <= 0) {
            say(player, "amount-bad");
            return;
        }
        depositMoney(player, cov, value);
    }

    /** Кладёт монеты в казну: учитывается вклад игрока и растёт уровень ковенанта. */
    void depositMoney(Player player, Covenant cov, long value) {
        long have = plugin.getEconomy().balance(player.getUniqueId());
        if (value <= 0 || value > have || !plugin.getEconomy().withdraw(player.getUniqueId(), value)) {
            say(player, "poor", "have", money(have));
            return;
        }
        int before = level(cov);
        cov.bank += value;
        cov.contributed += value;
        Covenant.Member member = cov.members.get(player.getUniqueId());
        if (member != null) {
            member.contrib += value;
            saveMember(player.getUniqueId(), cov, member);
        }
        io("UPDATE ag_covenant SET bank=?, contributed=? WHERE id=?", cov.bank, cov.contributed, cov.id);
        bank.log(cov, player.getName() + " внёс в казну " + plain(value));
        broadcast(cov, "deposited", "player", player.getName(), "coins", money(value), "bank", money(cov.bank));
        weekly.deposited(cov, value);
        if (plugin.getGlory() != null) {
            plugin.getGlory().add(player, "DEPOSITED", value);
        }
        if (level(cov) > before) {
            broadcast(cov, "level-up", "level", level(cov), "max", maxMembers(cov));
            bank.log(cov, "Ковенант достиг уровня " + level(cov));
        }
    }

    private String plain(long value) {
        return plugin.getEconomy().plain(value);
    }

    private void withdraw(Player player, Covenant cov, String text) {
        if (!cov.leader.equals(player.getUniqueId())) {
            say(player, "need-leader");
            return;
        }
        long value = amount(player, text, cov.bank);
        if (value <= 0) {
            say(player, "amount-bad");
            return;
        }
        if (value > cov.bank) {
            say(player, "bank-poor", "bank", money(cov.bank));
            return;
        }
        cov.bank -= value;
        saveBank(cov);
        plugin.getEconomy().give(player, value);
        bank.log(cov, player.getName() + " забрал из казны " + plain(value));
        broadcast(cov, "withdrawn", "player", player.getName(), "coins", money(value), "bank", money(cov.bank));
    }

    private void motd(Player player, Covenant cov, String text) {
        if (!cov.atLeast(player.getUniqueId(), Covenant.Role.OFFICER)) {
            say(player, "need-officer");
            return;
        }
        if (text.length() > 120) {
            text = text.substring(0, 120);
        }
        cov.motd = text;
        io("UPDATE ag_covenant SET motd=? WHERE id=?", cov.motd, cov.id);
        say(player, text.isBlank() ? "motd-cleared" : "motd-set");
    }

    private void motdTo(Player player, Covenant cov) {
        if (!cov.motd.isBlank()) {
            say(player, "motd-show", "name", cov.name, "motd", cov.motd);
        }
    }

    private void list(Player player) {
        if (covenants.isEmpty()) {
            say(player, "list-empty");
            return;
        }
        say(player, "list-header", "count", covenants.size());
        List<Covenant> sorted = new ArrayList<>(covenants.values());
        sorted.sort((a, b) -> Integer.compare(b.members.size(), a.members.size()));
        int shown = 0;
        for (Covenant cov : sorted) {
            if (shown++ >= 15) {
                break;
            }
            String leader = cov.members.containsKey(cov.leader) ? cov.members.get(cov.leader).name : "?";
            say(player, "list-line", "name", cov.name, "members", cov.members.size(), "leader", leader,
                    "land", cov.hasTerritory() ? size(cov.sizeId) != null ? size(cov.sizeId).name() : cov.sizeId : "-");
        }
    }

    private void info(CommandSender to, Covenant cov) {
        say(to, "info-header", "name", cov.name);
        say(to, "info-leader", "leader", cov.members.get(cov.leader) == null ? "?" : cov.members.get(cov.leader).name);
        say(to, "info-level", "level", level(cov), "contributed", money(cov.contributed));
        say(to, "info-members", "count", cov.members.size(), "max", maxMembers(cov));
        if (!cov.motd.isBlank()) {
            say(to, "info-motd", "motd", cov.motd);
        }
        say(to, "info-bank", "bank", money(cov.bank));
        Size s = cov.hasTerritory() ? size(cov.sizeId) : null;
        say(to, "info-land", "land", cov.hasTerritory()
                ? (s != null ? s.name() : cov.sizeId) + " &8(" + cov.half * 2 + "×" + cov.half * 2 + ", " + cov.world
                + " " + cov.cx + " " + cov.cz + ")" : "нет");
    }

    // ---------------------------------------------------------------
    //  Участок
    // ---------------------------------------------------------------

    private void territory(Player player, Covenant cov, String[] args) {
        String sub = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "info";
        switch (sub) {
            case "buy", "upgrade" -> claim(player, cov, args.length > 3 ? args[3] : "");
            case "abandon" -> abandon(player, cov);
            case "show" -> show(player, cov);
            case "menu" -> openTerritory(player, cov);
            default -> {
                if (!cov.hasTerritory()) {
                    say(player, "land-none");
                } else {
                    info(player, cov);
                }
                for (Size s : sizes) {
                    say(player, "land-size", "id", s.id(), "name", s.name(), "side", s.side(), "price", money(s.price()));
                }
            }
        }
    }

    /** Покупка или расширение участка вокруг игрока; оплата из казны ковенанта. */
    private void claim(Player player, Covenant cov, String sizeId) {
        if (!cov.leader.equals(player.getUniqueId())) {
            say(player, "need-leader");
            return;
        }
        Size size = size(sizeId);
        if (size == null) {
            say(player, "land-size-unknown");
            return;
        }
        if (level(cov) < size.level()) {
            say(player, "land-level", "level", size.level());
            return;
        }
        World world = player.getWorld();
        if (!claimWorlds.isEmpty() && claimWorlds.stream().noneMatch(w -> w.equalsIgnoreCase(world.getName()))) {
            say(player, "land-world");
            return;
        }
        if (plugin.getDungeons().isInstanceWorld(world)) {
            say(player, "land-world");
            return;
        }
        boolean upgrade = cov.hasTerritory();
        int half = size.side() / 2;
        int cx;
        int cz;
        long cost;
        if (upgrade) {
            Size current = size(cov.sizeId);
            if (half <= cov.half) {
                say(player, "land-not-bigger");
                return;
            }
            cx = cov.cx;
            cz = cov.cz;
            long paid = current == null ? 0 : current.price();
            cost = Math.max(0, size.price() - (long) (paid * refund));
        } else {
            cx = player.getLocation().getBlockX();
            cz = player.getLocation().getBlockZ();
            cost = size.price();
        }
        Location spawn = world.getSpawnLocation();
        if (Math.max(Math.abs(cx - spawn.getBlockX()), Math.abs(cz - spawn.getBlockZ())) - half < spawnDistance) {
            say(player, "land-spawn", "distance", spawnDistance);
            return;
        }
        for (Covenant other : covenants.values()) {
            if (other != cov && other.overlaps(world.getName(), cx, cz, half, gap)) {
                say(player, "land-overlap", "name", other.name, "gap", gap);
                return;
            }
        }
        if (cov.bank < cost) {
            say(player, "land-poor", "cost", money(cost), "bank", money(cov.bank));
            return;
        }
        cov.bank -= cost;
        saveBank(cov);
        cov.world = world.getName();
        cov.cx = cx;
        cov.cz = cz;
        cov.half = half;
        cov.sizeId = size.id();
        saveTerritory(cov);
        bank.log(cov, "Земли: " + size.name() + " (" + plain(cost) + ")");
        broadcast(cov, upgrade ? "land-upgraded" : "land-bought", "size", size.name(), "side", size.side(),
                "cost", money(cost), "x", cx, "z", cz);
        show(player, cov);
    }

    private void abandon(Player player, Covenant cov) {
        if (!cov.leader.equals(player.getUniqueId())) {
            say(player, "need-leader");
            return;
        }
        if (!cov.hasTerritory()) {
            say(player, "land-none");
            return;
        }
        Size current = size(cov.sizeId);
        long back = current == null ? 0 : (long) (current.price() * refund);
        cov.bank += back;
        saveBank(cov);
        cov.world = null;
        cov.half = 0;
        cov.sizeId = null;
        saveTerritory(cov);
        banner.clear(cov.id);
        broadcast(cov, "land-abandoned", "refund", money(back));
    }

    /** Показывает границы участка частицами на несколько секунд. */
    private void show(Player player, Covenant cov) {
        if (!cov.hasTerritory() || !player.getWorld().getName().equals(cov.world)) {
            say(player, "land-far");
            return;
        }
        say(player, "land-shown");
        int[] ticks = {0};
        Bukkit.getScheduler().runTaskTimer(plugin, task -> {
            if (!player.isOnline() || ticks[0]++ >= 12 || !cov.hasTerritory()) {
                task.cancel();
                return;
            }
            double y = player.getLocation().getY() + 1;
            int minX = cov.cx - cov.half;
            int maxX = cov.cx + cov.half;
            int minZ = cov.cz - cov.half;
            int maxZ = cov.cz + cov.half;
            Location base = player.getLocation();
            for (int i = 0; i <= cov.half * 2; i += 2) {
                edge(player, minX + i, y, minZ, base);
                edge(player, minX + i, y, maxZ, base);
                edge(player, minX, y, minZ + i, base);
                edge(player, maxX, y, minZ + i, base);
            }
        }, 0L, 10L);
    }

    private void edge(Player player, double x, double y, double z, Location base) {
        if (Math.abs(x - base.getX()) < 40 && Math.abs(z - base.getZ()) < 40) {
            player.spawnParticle(Particle.END_ROD, x + 0.5, y, z + 0.5, 1, 0, 0.6, 0, 0);
        }
    }

    // ---------------------------------------------------------------
    //  Защита участка
    // ---------------------------------------------------------------

    private boolean denied(Player player, Location location) {
        if (!isEnabled() || player.hasPermission("ag.bypass.covenant")) {
            return false;
        }
        Covenant cov = at(location);
        if (cov == null) {
            return false;
        }
        Covenant mine = byPlayer.get(player.getUniqueId());
        return mine != cov;
    }

    private void warn(Player player, Location location) {
        Covenant cov = at(location);
        player.sendActionBar(Hud.legacy(plugin.getMessages().text("covenant.protected",
                "&cЗемли ковенанта &f{name}&c: здесь нельзя.").replace("{name}", cov == null ? "" : cov.name)));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (denied(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
            warn(event.getPlayer(), event.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (denied(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
            warn(event.getPlayer(), event.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent event) {
        if (denied(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
            warn(event.getPlayer(), event.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (denied(event.getPlayer(), event.getBlock().getLocation())) {
            event.setCancelled(true);
            warn(event.getPlayer(), event.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Block block = event.getClickedBlock();
        if (block == null || (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.PHYSICAL)) {
            return;
        }
        Material type = block.getType();
        boolean guarded = block.getState() instanceof org.bukkit.block.Container
                || Tag.DOORS.isTagged(type) || Tag.TRAPDOORS.isTagged(type) || Tag.FENCE_GATES.isTagged(type)
                || Tag.BUTTONS.isTagged(type) || Tag.BEDS.isTagged(type) || Tag.ANVIL.isTagged(type)
                || type == Material.LEVER || type == Material.FARMLAND || type == Material.CRAFTING_TABLE
                || type == Material.FURNACE || type == Material.BLAST_FURNACE || type == Material.SMOKER
                || type == Material.ENCHANTING_TABLE || type == Material.BREWING_STAND
                || type == Material.ITEM_FRAME || type == Material.CAKE;
        if (guarded && denied(event.getPlayer(), block.getLocation())) {
            event.setCancelled(true);
            warn(event.getPlayer(), block.getLocation());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent event) {
        if (isEnabled()) {
            event.blockList().removeIf(block -> at(block.getLocation()) != null);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        if (isEnabled()) {
            event.blockList().removeIf(block -> at(block.getLocation()) != null);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!isEnabled() || event.getTo() == null) {
            return;
        }
        Location from = event.getFrom();
        Location to = event.getTo();
        if (from.getBlockX() >> 4 == to.getBlockX() >> 4 && from.getBlockZ() >> 4 == to.getBlockZ() >> 4
                && from.getWorld() == to.getWorld()) {
            return;
        }
        Player player = event.getPlayer();
        Covenant cov = at(to);
        Integer last = standingIn.get(player.getUniqueId());
        int now = cov == null ? -1 : cov.id;
        if (last != null && last == now || last == null && now == -1) {
            return;
        }
        if (now == -1) {
            standingIn.remove(player.getUniqueId());
            Covenant old = covenants.get(last);
            if (old != null) {
                player.sendActionBar(Hud.legacy(plugin.getMessages().text("covenant.leave-land",
                        "&8Вы покинули земли &7{name}").replace("{name}", old.name)));
            }
        } else {
            standingIn.put(player.getUniqueId(), now);
            player.sendActionBar(Hud.legacy(plugin.getMessages().text("covenant.enter-land",
                    "&6Земли ковенанта &f{name}").replace("{name}", cov.name)));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Covenant cov = byPlayer.get(event.getPlayer().getUniqueId());
        if (cov != null) {
            motdTo(event.getPlayer(), cov);
            Covenant.Member member = cov.members.get(event.getPlayer().getUniqueId());
            if (member != null && !member.name.equals(event.getPlayer().getName())) {
                member.name = event.getPlayer().getName();
                saveMember(event.getPlayer().getUniqueId(), cov, member);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        standingIn.remove(event.getPlayer().getUniqueId());
        invites.remove(event.getPlayer().getUniqueId());
        disbandAsk.remove(event.getPlayer().getUniqueId());
    }

    // ---------------------------------------------------------------
    //  Меню
    // ---------------------------------------------------------------

    ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Hud.legacy(name).decoration(NO_ITALIC, false));
        List<Component> lines = new ArrayList<>();
        for (String line : lore) {
            lines.add(Hud.legacy(line).decoration(NO_ITALIC, false));
        }
        meta.lore(lines);
        stack.setItemMeta(meta);
        return stack;
    }

    void filler(Inventory inventory) {
        ItemStack pane = item(Material.BLACK_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, pane);
        }
    }

    public void openMain(Player player, Covenant cov) {
        Menu holder = new Menu(View.MAIN, cov.id);
        Inventory inventory = Bukkit.createInventory(holder, 36, Hud.legacy("&8Ковенант: " + cov.name));
        filler(inventory);
        Covenant.Role role = cov.role(player.getUniqueId());
        Size s = cov.hasTerritory() ? size(cov.sizeId) : null;
        inventory.setItem(4, item(Material.WHITE_BANNER, "&6&l" + cov.name, List.of(
                "&7Ваша роль: " + role.color + role.title,
                "&7Уровень: &f" + level(cov) + " &8(вклады: " + money(cov.contributed) + "&8)",
                "&7Участников: &f" + cov.members.size() + "&7/&f" + maxMembers(cov),
                "&7Казна: " + money(cov.bank),
                "&7Земли: &f" + (cov.hasTerritory() ? (s != null ? s.name() : cov.sizeId) : "нет"))));
        inventory.setItem(10, item(Material.PLAYER_HEAD, "&eУчастники", List.of("&7Состав и роли ковенанта.", "", "&eЛКМ &7- открыть")));
        inventory.setItem(12, item(Material.GRASS_BLOCK, "&aЗемли ковенанта", List.of(
                "&7Участок под защитой, пять размеров.", "&7Покупает глава из казны.", "", "&eЛКМ &7- открыть")));
        inventory.setItem(14, item(Material.CHEST, "&6Банк ковенанта", List.of(
                "&7Казна: " + money(cov.bank),
                "&7Вкладки с предметами, журнал,", "&7пополнение казны.", "", "&eЛКМ &7- открыть")));
        inventory.setItem(20, item(Material.GOLDEN_HELMET, "&6Рейтинг недели", List.of(
                "&7Очки этой недели: &f" + cov.weekScore,
                "&7За подземелья, задания и вклады.", "&7Топ-3 получают награду в казну.", "", "&eЛКМ &7- показать рейтинг")));
        List<String> goalLore = new ArrayList<>(weekly.goalLore(cov));
        inventory.setItem(24, item(Material.BOOK, "&bЦель недели", goalLore));
        inventory.setItem(26, item(Material.WHITE_BANNER, "&dЗнамя ковенанта", List.of(
                "&7Ставится на своих землях, рядом бафф.", "&7Поставлено: &f" + banner.count(cov),
                "&8Купить (офицер): /ag covenant banner", "", "&eЛКМ &7- купить знамя")));
        inventory.setItem(22, item(Material.OAK_SIGN, "&fСообщение дня", List.of(
                cov.motd.isBlank() ? "&8Не задано." : "&7" + cov.motd, "",
                "&8Задать (офицер): /ag covenant motd <текст>")));
        inventory.setItem(16, item(Material.WRITABLE_BOOK, "&bЧат ковенанта", List.of(
                "&7Сообщение: &f/c <текст>", "&7Переключить: &f/ch covenant")));
        inventory.setItem(31, item(Material.BARRIER, "&cПокинуть ковенант", List.of(
                role == Covenant.Role.LEADER ? "&8Глава сначала передаёт власть: /ag covenant leader <ник>" : "&7Shift+ЛКМ - выйти")));
        player.openInventory(inventory);
    }

    private void openMembers(Player player, Covenant cov) {
        Menu holder = new Menu(View.MEMBERS, cov.id);
        Inventory inventory = Bukkit.createInventory(holder, 54, Hud.legacy("&8Участники: " + cov.name));
        filler(inventory);
        Covenant.Role mine = cov.role(player.getUniqueId());
        int slot = 0;
        List<Map.Entry<UUID, Covenant.Member>> sorted = new ArrayList<>(cov.members.entrySet());
        sorted.sort(java.util.Comparator.comparingInt(e -> e.getValue().role.ordinal()));
        for (Map.Entry<UUID, Covenant.Member> entry : sorted) {
            if (slot >= 45) {
                break;
            }
            Covenant.Member m = entry.getValue();
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(entry.getKey()));
            meta.displayName(Hud.legacy(m.role.color + m.name).decoration(NO_ITALIC, false));
            List<String> lore = new ArrayList<>();
            lore.add("&7Роль: " + m.role.color + m.role.title);
            lore.add(Bukkit.getPlayer(entry.getKey()) != null ? "&aв сети" : "&8не в сети");
            lore.add("&7Вклад в казну: &f" + plain(m.contrib));
            if (mine == Covenant.Role.LEADER && m.role != Covenant.Role.LEADER) {
                lore.add("");
                lore.add("&eЛКМ &7- повысить   &eПКМ &7- понизить");
            }
            if (mine != Covenant.Role.MEMBER && m.role.ordinal() > mine.ordinal()) {
                lore.add("&cShift+ПКМ &7- исключить");
            }
            List<Component> lines = new ArrayList<>();
            lore.forEach(l -> lines.add(Hud.legacy(l).decoration(NO_ITALIC, false)));
            meta.lore(lines);
            head.setItemMeta(meta);
            inventory.setItem(slot, head);
            holder.heads.put(slot, entry.getKey());
            slot++;
        }
        inventory.setItem(49, item(Material.ARROW, "&7Назад", List.of()));
        player.openInventory(inventory);
    }

    private void openTerritory(Player player, Covenant cov) {
        Menu holder = new Menu(View.TERRITORY, cov.id);
        Inventory inventory = Bukkit.createInventory(holder, 36, Hud.legacy("&8Земли: " + cov.name));
        filler(inventory);
        boolean leader = cov.leader.equals(player.getUniqueId());
        Size current = cov.hasTerritory() ? size(cov.sizeId) : null;
        int slot = 10;
        Material[] icons = {Material.OAK_FENCE, Material.OAK_LOG, Material.STONE_BRICKS, Material.DEEPSLATE_BRICKS, Material.CRYING_OBSIDIAN};
        int i = 0;
        for (Size s : sizes) {
            if (slot > 16) {
                break;
            }
            boolean owned = current != null && current.id().equals(s.id());
            boolean smaller = cov.hasTerritory() && s.side() / 2 <= cov.half;
            long cost = cov.hasTerritory() && !smaller ? Math.max(0, s.price() - (long) ((current == null ? 0 : current.price()) * refund)) : s.price();
            List<String> lore = new ArrayList<>();
            lore.add("&7Сторона: &f" + s.side() + "&7 блоков (&f" + s.side() + "×" + s.side() + "&7)");
            lore.add("&7Цена: " + money(cost) + (cov.hasTerritory() && !smaller ? " &8(доплата)" : ""));
            lore.add("");
            lore.add(owned ? "&aУ вас этот размер" : smaller ? "&8Меньше текущего"
                    : leader ? "&eЛКМ &7- " + (cov.hasTerritory() ? "расширить" : "купить здесь, где стоите") : "&8Покупает глава");
            inventory.setItem(slot, item(icons[Math.min(i, icons.length - 1)], "&6" + s.name(), lore));
            holder.sizes.put(slot, s.id());
            slot += 1 + (slot == 12 ? 0 : 0);
            i++;
        }
        inventory.setItem(22, item(Material.SPYGLASS, "&bПоказать границы", List.of("&7Частицы на несколько секунд.", "", "&eЛКМ")));
        inventory.setItem(31, item(Material.ARROW, "&7Назад", List.of()));
        if (cov.hasTerritory()) {
            inventory.setItem(26, item(Material.TNT, "&cОтказаться от земель", List.of(
                    "&7Возврат из казны: " + (int) (refund * 100) + "% цены.", "&7Shift+ЛКМ - отказаться")));
        }
        inventory.setItem(4, item(Material.MAP, "&6Земли ковенанта", List.of(
                cov.hasTerritory() ? "&7Центр: &f" + cov.cx + " " + cov.cz + " &8(" + cov.world + ")" : "&7Участка пока нет.",
                "&7Казна: " + money(cov.bank),
                "&8Встаньте в центр будущего участка и выберите размер.")));
        player.openInventory(inventory);
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Menu menu) || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        Covenant cov = covenants.get(menu.covenant);
        if (cov == null || !cov.members.containsKey(player.getUniqueId())) {
            player.closeInventory();
            return;
        }
        int slot = event.getSlot();
        boolean shift = event.isShiftClick();
        switch (menu.view) {
            case MAIN -> {
                if (slot == 10) {
                    openMembers(player, cov);
                } else if (slot == 12) {
                    openTerritory(player, cov);
                } else if (slot == 14) {
                    bank.openHub(player, cov);
                } else if (slot == 20) {
                    player.closeInventory();
                    weekly.printTop(player);
                } else if (slot == 26) {
                    player.closeInventory();
                    banner.give(player, cov);
                } else if (slot == 31 && shift) {
                    player.closeInventory();
                    leave(player, cov);
                }
            }
            case MEMBERS -> {
                if (slot == 49) {
                    openMain(player, cov);
                    return;
                }
                UUID target = menu.heads.get(slot);
                Covenant.Member m = target == null ? null : cov.members.get(target);
                if (m == null) {
                    return;
                }
                if (shift && event.isRightClick()) {
                    kick(player, cov, m.name);
                } else if (event.isLeftClick()) {
                    setRole(player, cov, m.name, true);
                } else if (event.isRightClick()) {
                    setRole(player, cov, m.name, false);
                }
                if (covenants.containsKey(cov.id) && cov.members.containsKey(player.getUniqueId())) {
                    openMembers(player, cov);
                }
            }
            case TERRITORY -> {
                if (slot == 31) {
                    openMain(player, cov);
                } else if (slot == 22) {
                    player.closeInventory();
                    show(player, cov);
                } else if (slot == 26 && shift) {
                    abandon(player, cov);
                    openTerritory(player, cov);
                } else if (menu.sizes.containsKey(slot)) {
                    player.closeInventory();
                    claim(player, cov, menu.sizes.get(slot));
                }
            }
        }
    }

    // ---------------------------------------------------------------
    //  Админ: /ag admin covenant ...
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        String action = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "list";
        switch (action) {
            case "reload" -> {
                reload();
                sender.sendMessage(Hud.legacy("&aНастройки ковенантов перечитаны."));
            }
            case "list" -> {
                sender.sendMessage(Hud.legacy("&6Ковенантов: &f" + covenants.size()));
                for (Covenant cov : covenants.values()) {
                    sender.sendMessage(Hud.legacy("&8» &f" + cov.name + " &7(" + cov.members.size() + " уч., казна "
                            + cov.bank + ", земли " + (cov.hasTerritory() ? cov.sizeId : "нет") + ")"));
                }
            }
            case "info", "disband", "unclaim", "setbank" -> {
                Covenant cov = args.length > 3 ? find(args[3].replace('_', ' ')) : null;
                if (cov == null) {
                    sender.sendMessage(Hud.legacy("&cУкажите ковенант (пробелы заменяйте на _): /ag admin covenant "
                            + action + " <название>"));
                    return;
                }
                switch (action) {
                    case "info" -> info(sender, cov);
                    case "disband" -> {
                        dissolve(cov, true);
                        sender.sendMessage(Hud.legacy("&aКовенант распущен, казна отдана главе."));
                    }
                    case "unclaim" -> {
                        cov.world = null;
                        cov.half = 0;
                        cov.sizeId = null;
                        saveTerritory(cov);
                        banner.clear(cov.id);
                        sender.sendMessage(Hud.legacy("&aЗемли сняты."));
                    }
                    default -> {
                        try {
                            cov.bank = Math.max(0, Long.parseLong(args.length > 4 ? args[4] : ""));
                            saveBank(cov);
                            sender.sendMessage(Hud.legacy("&aКазна: &f" + cov.bank));
                        } catch (NumberFormatException exception) {
                            sender.sendMessage(Hud.legacy("&c/ag admin covenant setbank <название> <сумма>"));
                        }
                    }
                }
            }
            default -> sender.sendMessage(Hud.legacy("&7/ag admin covenant list|info <имя>|disband <имя>|unclaim <имя>|setbank <имя> <сумма>|reload"));
        }
    }
}
