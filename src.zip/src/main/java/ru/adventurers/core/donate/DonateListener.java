package ru.adventurers.core.donate;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;

/** Клики в донат-магазине и приветственные самоцветы новому игроку. */
public class DonateListener implements Listener {

    private final DonateManager donate;

    public DonateListener(DonateManager donate) {
        this.donate = donate;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (!donate.isMenu(event.getInventory())) {
            return;
        }
        event.setCancelled(true);
        donate.click(player, event.getInventory(), event.getRawSlot());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        donate.welcome(event.getPlayer());
    }
}
