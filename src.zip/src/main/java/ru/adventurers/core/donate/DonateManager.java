package ru.adventurers.core.donate;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.message.MessageManager;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Донат-магазин: косметика, удобство и ускорители - без pay2win (раздел 20 отчёта).
 *
 * <p>Валюта - самоцветы (donate.yml), они покупаются у вас в магазине и начисляются
 * командой /ag admin donate give. Самоцветы НЕ конвертируются в монеты и не покупают
 * ранг, очки гильдии, ступени испытаний и характеристики: это и есть защита от pay2win.
 *
 * <p>Что можно купить:
 * <ul>
 *   <li>косметику (титулы, следы, ауры, питомцы-украшения) - видно другим, силы не даёт;</li>
 *   <li>удобство (доп. гнездо камня, камень возврата, второй набор способностей) -
 *       то же самое можно получить бесплатно, но медленнее;</li>
 *   <li>ускорители (boost) - ограничены по времени, не больше +50% и только на опыт,
 *       монеты со скупки и добычу, никогда на урон, здоровье и защиту.</li>
 * </ul>
 */
public class DonateManager {

    private final AdventurersCore plugin;
    private final MessageManager messages;
    private final NamespacedKey gemsKey;
    private final NamespacedKey sessionKey;
    /** Осколки Избранных (S-ранг, раздел 23): отдельная валюта, только на косметику. */
    private final NamespacedKey shardsKey;

    private boolean enabled = true;
    private String currencyName = "Самоцветы";
    private String symbol = "❖";
    private long welcome = 15;
    /** Правила из donate.yml: применяются при загрузке, а не только проверяются тестом. */
    private long maxCoinsPerPurchase = 0;
    private int maxPowerPercent = 50;
    private boolean serverWideOnly = true;
    /** Доступ на сервер не продаётся: если кто-то включит true, плагин это заблокирует. */
    private boolean serverAccessForSale = false;

    /** Товар магазина. */
    public record Offer(String id, Kind kind, String name, List<String> lore, Material icon, long price,
                        int percent, int minutes, int limit, int stack) {
    }

    /** Виды товаров: подпись используется в меню. */
    public enum Kind {
        BOOST("Ускоритель"), TITLE("Титул"), TRAIL("След"), AURA("Аура"), PET("Питомец"),
        COMFORT("Удобство"), PASS("Сезонный пропуск");

        private final String label;

        Kind(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }
    }

    /** Купленные товары на игрока: id -> количество. */
    private final Map<UUID, Map<String, Integer>> owned = new HashMap<>();
    /**
     * Активные СЕРВЕРНЫЕ бусты: id товара -> до какого времени. Общие для всех игроков:
     * покупатель платит за окно, но эффект получают все, включая тех, кто не платил.
     * Так ускоритель остаётся приятной мелочью для сервера, а не «плюсом к силе за деньги».
     */
    private final Map<String, Long> serverBoosts = new LinkedHashMap<>();

    private final List<Offer> offers = new ArrayList<>();
    private final Map<String, Offer> byId = new LinkedHashMap<>();

    public DonateManager(AdventurersCore plugin, MessageManager messages) {
        this.plugin = plugin;
        this.messages = messages;
        this.gemsKey = new NamespacedKey(plugin, "donate_gems");
        this.sessionKey = new NamespacedKey(plugin, "donate_welcome");
        this.shardsKey = new NamespacedKey(plugin, "ascended_shards");
    }

    public void reload() {
        File file = plugin.getFiles().file("donate.yml");
        if (!file.exists()) {
            plugin.getFiles().save("donate.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        currencyName = cfg.getString("currency.name", currencyName);
        symbol = cfg.getString("currency.symbol", symbol);
        welcome = cfg.getLong("currency.welcome", welcome);
        maxCoinsPerPurchase = cfg.getLong("rules.max-coins-per-purchase", 0);
        maxPowerPercent = cfg.getInt("rules.max-power-percent", 50);
        serverWideOnly = cfg.getBoolean("rules.boosts-must-be-server-wide", true);
        serverAccessForSale = cfg.getBoolean("rules.server-access-for-sale", false);
        if (serverAccessForSale) {
            plugin.getLogger().warning("donate.yml: server-access-for-sale: true - доступ на сервер "
                    + "не продаётся по правилам плагина, значение проигнорировано");
            serverAccessForSale = false;
        }

        offers.clear();
        byId.clear();
        ConfigurationSection boostsSection = cfg.getConfigurationSection("server-boosts");
        if (boostsSection != null) {
            for (String id : boostsSection.getKeys(false)) {
                ConfigurationSection s = boostsSection.getConfigurationSection(id);
                if (s == null) {
                    continue;
                }
                add(new Offer("boost." + id, Kind.BOOST, s.getString("name", id),
                        List.of(s.getString("desc", "")), material(s.getString("icon"), Material.SUGAR),
                        s.getLong("price", 50), s.getInt("percent", 0),
                        s.getInt("minutes", 180), 0, 1));
            }
        }
        ConfigurationSection cosmetics = cfg.getConfigurationSection("cosmetics");
        if (cosmetics != null) {
            read(cosmetics, "titles", Kind.TITLE, Material.NAME_TAG, "cosmetic.title.");
            read(cosmetics, "trails", Kind.TRAIL, Material.BLAZE_POWDER, "cosmetic.trail.");
            read(cosmetics, "auras", Kind.AURA, Material.AMETHYST_SHARD, "cosmetic.aura.");
            read(cosmetics, "pet_skins", Kind.PET, Material.NETHER_STAR, "cosmetic.pet.");
        }
        ConfigurationSection comfort = cfg.getConfigurationSection("comfort");
        if (comfort != null) {
            for (String id : comfort.getKeys(false)) {
                ConfigurationSection s = comfort.getConfigurationSection(id);
                if (s == null) {
                    continue;
                }
                add(new Offer("comfort." + id, Kind.COMFORT, s.getString("name", id),
                        List.of(s.getString("desc", "")), material(s.getString("icon"), Material.CHEST),
                        s.getLong("price", 100), 0, 0, Math.max(1, s.getInt("limit", 1)),
                        Math.max(1, s.getInt("stack", 1))));
            }
        }
        ConfigurationSection pass = cfg.getConfigurationSection("season-pass");
        if (pass != null && pass.getBoolean("enabled", true)) {
            add(new Offer("pass.season", Kind.PASS, pass.getString("name", "Сезонный пропуск"),
                    List.of("&7Косметическая ветка наград сезона",
                            "&7(30 шагов, без силы и без доступа)"),
                    Material.PAPER, pass.getLong("price", 350), 0, 0, 1, 1));
        }
    }

    private void read(ConfigurationSection parent, String section, Kind kind, Material fallback, String idPrefix) {
        ConfigurationSection node = parent.getConfigurationSection(section);
        if (node == null) {
            return;
        }
        for (String id : node.getKeys(false)) {
            ConfigurationSection s = node.getConfigurationSection(id);
            if (s == null) {
                continue;
            }
            add(new Offer(idPrefix + id, kind, s.getString("name", id),
                    List.of(s.getString("desc", "")), material(s.getString("icon"), fallback),
                    s.getLong("price", 100), 0, 0, 1, 1));
        }
    }

    private void add(Offer offer) {
        offers.add(offer);
        byId.put(offer.id(), offer);
    }

    private static Material material(String name, Material fallback) {
        Material mat = name == null ? null : Material.matchMaterial(name.trim().toUpperCase(Locale.ROOT));
        return mat == null ? fallback : mat;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public long maxCoinsPerPurchase() {
        return maxCoinsPerPurchase;
    }

    public int maxPowerPercent() {
        return maxPowerPercent;
    }

    public boolean serverAccessForSale() {
        return serverAccessForSale;
    }

    /** Платные ускорители обязаны действовать на всех: иначе это преимущество за деньги. */
    public boolean serverWideOnly() {
        return serverWideOnly;
    }

    public List<Offer> offers() {
        return offers;
    }

    public Offer offer(String id) {
        return byId.get(id);
    }

    // ---------------------------------------------------------------
    //  Кошелёк самоцветов
    // ---------------------------------------------------------------

    public long gems(Player player) {
        Long value = player.getPersistentDataContainer().get(gemsKey, PersistentDataType.LONG);
        return value == null ? 0 : value;
    }

    public void setGems(Player player, long amount) {
        player.getPersistentDataContainer().set(gemsKey, PersistentDataType.LONG, Math.max(0, amount));
    }

    public void giveGems(Player player, long amount) {
        setGems(player, gems(player) + amount);
        messages.send(player, "donate.gems-get", Map.of(
                "gems", String.valueOf(amount), "total", String.valueOf(gems(player))));
    }

    /** Осколки Избранных: ими платят только за косметику Мира Избранных. */
    public long shards(Player player) {
        Long value = player.getPersistentDataContainer().get(shardsKey, PersistentDataType.LONG);
        return value == null ? 0 : value;
    }

    public void giveShards(Player player, long amount) {
        long total = Math.max(0, shards(player) + amount);
        player.getPersistentDataContainer().set(shardsKey, PersistentDataType.LONG, total);
        messages.send(player, "ascended.shards-get", Map.of(
                "shards", String.valueOf(amount), "total", String.valueOf(total)));
    }

    /** Новому игроку - приветственные самоцветы, чтобы он увидел, как работает косметика. */
    public void welcome(Player player) {
        if (!enabled || welcome <= 0) {
            return;
        }
        if (player.getPersistentDataContainer().has(sessionKey, PersistentDataType.BYTE)) {
            return;
        }
        player.getPersistentDataContainer().set(sessionKey, PersistentDataType.BYTE, (byte) 1);
        giveGems(player, welcome);
    }

    // ---------------------------------------------------------------
    //  Покупки
    // ---------------------------------------------------------------

    /** Купить: списывает самоцветы и выдаёт товар. Возвращает ключ ошибки или null. */
    public String buy(Player player, Offer offer) {
        if (!enabled || offer == null) {
            return "donate.disabled";
        }
        long price = offer.price();
        if (gems(player) < price) {
            return "donate.no-gems";
        }
        int have = ownedCount(player, offer.id());
        if (offer.limit() > 0 && have >= offer.limit()) {
            return "donate.limit";
        }
        setGems(player, gems(player) - price);
        switch (offer.kind()) {
            case BOOST -> {
                long until = System.currentTimeMillis() + offer.minutes() * 60_000L;
                serverBoosts.merge(offer.id(), until, Math::max);
                // окно общее: объявляем всем, кто онлайн - это и есть «втягивание игроков»
                Bukkit.getOnlinePlayers().forEach(viewer -> messages.send(viewer, "donate.server-boost",
                        Map.of("name", offer.name(), "player", player.getName(),
                                "minutes", String.valueOf(offer.minutes()))));
            }
            case TITLE -> {
                // титул становится доступен в /ag glory: unlock other:donate-title-<id>
                if (plugin.getGlory() != null) {
                    plugin.getGlory().registerUnlock("donate-title-" + shortId(offer),
                            p -> ownedCount(p, offer.id()) > 0);
                }
                markOwned(player, offer.id(), 1);
                messages.send(player, "donate.title-on", Map.of("name", offer.name()));
            }
            default -> {
                markOwned(player, offer.id(), 1);
                messages.send(player, "donate.cosmetic-on", Map.of("name", offer.name()));
            }
        }
        return null;
    }

    private static String shortId(Offer offer) {
        String id = offer.id();
        int dot = id.lastIndexOf('.');
        return dot < 0 ? id : id.substring(dot + 1);
    }

    private void markOwned(Player player, String id, int amount) {
        owned.computeIfAbsent(player.getUniqueId(), key -> new LinkedHashMap<>())
                .merge(id, amount, Integer::sum);
    }

    public int ownedCount(Player player, String id) {
        return ownedCount(player.getUniqueId(), id);
    }

    public int ownedCount(UUID uuid, String id) {
        return owned.getOrDefault(uuid, Map.of()).getOrDefault(id, 0);
    }

    // ---------------------------------------------------------------
    //  Бусты: что они дают
    // ---------------------------------------------------------------

    /**
     * Множитель серверного буста на нужный канал, например "QUEST_POINTS" или "SELL_COINS".
     * Не зависит от игрока: окно либо идёт на сервере, либо нет - все в равных условиях.
     * Просроченные окна вычищаются сами.
     *
     * <p>Каналы силы (урон, здоровье, защита, скорость) здесь ОТСУТСТВУЮТ намеренно:
     * даже если кто-то допишет в donate.yml буст на урон, метод его не применит.
     */
    public double boost(String channel) {
        if (!enabled || !allowedChannel(channel)) {
            return 1.0;
        }
        long now = System.currentTimeMillis();
        double factor = 1.0;
        for (Map.Entry<String, Long> entry : new ArrayList<>(serverBoosts.entrySet())) {
            if (entry.getValue() < now) {
                serverBoosts.remove(entry.getKey());
                continue;
            }
            Offer offer = byId.get(entry.getKey());
            if (offer != null) {
                // окна одного канала не складываются: берём лучшее, иначе 4 покупки = x3
                factor = Math.max(factor, 1.0 + offer.percent() / 100.0);
            }
        }
        return factor;
    }

    /** Активные серверные окна: подпись для HUD и меню. */
    public List<String> activeBoosts() {
        long now = System.currentTimeMillis();
        List<String> active = new ArrayList<>();
        for (Map.Entry<String, Long> entry : serverBoosts.entrySet()) {
            if (entry.getValue() <= now) {
                continue;
            }
            Offer offer = byId.get(entry.getKey());
            if (offer != null) {
                active.add(offer.name() + " &7(" + ((entry.getValue() - now) / 60_000L + 1) + " мин)");
            }
        }
        return active;
    }

    /** Разрешённые каналы для донат-бустов. Только они влияют на множители. */
    public static boolean allowedChannel(String channel) {
        return switch (channel) {
            case "QUEST_POINTS", "SELL_COINS", "GATHER", "INVASION_COST" -> true;
            default -> false;
        };
    }

    /** Сколько минут осталось у серверного окна (0 - не активно). */
    public int minutesLeft(Offer offer) {
        Long until = serverBoosts.get(offer.id());
        if (until == null) {
            return 0;
        }
        long left = until - System.currentTimeMillis();
        return left <= 0 ? 0 : (int) (left / 60_000L) + 1;
    }

    // ---------------------------------------------------------------
    //  Меню магазина
    // ---------------------------------------------------------------

    /** Держатель инвентаря: по нему плагин понимает, что открыт донат-магазин. */
    public static final class Menu implements InventoryHolder {
        private final Map<Integer, String> offers = new HashMap<>();
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    public boolean isMenu(Inventory inventory) {
        return inventory != null && inventory.getHolder() instanceof Menu;
    }

    public void open(Player player) {
        if (!enabled) {
            messages.send(player, "donate.disabled");
            return;
        }
        Menu holder = new Menu();
        Inventory inventory = Bukkit.createInventory(holder, 54,
                Hud.legacy("&8Донат: &6" + currencyName + " " + symbol + " " + gems(player)));
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.displayName(Component.empty());
            filler.setItemMeta(fillerMeta);
        }
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
        int slot = 0;
        for (Offer offer : offers) {
            if (slot >= 45) {
                break;
            }
            ItemStack item = new ItemStack(offer.icon());
            ItemMeta meta = item.getItemMeta();
            if (meta == null) {
                continue;
            }
            meta.displayName(Hud.legacy(offer.name() + " &8[" + offer.kind().label() + "]"));
            List<Component> lore = new ArrayList<>();
            for (String line : offer.lore()) {
                if (line != null && !line.isBlank()) {
                    lore.add(Hud.legacy(line));
                }
            }
            lore.add(Component.empty());
            lore.add(Hud.legacy("&fЦена: &6" + offer.price() + " " + symbol));
            int have = ownedCount(player, offer.id());
            if (offer.kind() == Kind.BOOST && minutesLeft(offer) > 0) {
                lore.add(Hud.legacy("&aИдёт на сервере: &f" + minutesLeft(offer) + " мин"));
            } else if (offer.kind() == Kind.COMFORT && offer.limit() > 1) {
                lore.add(Hud.legacy("&7Куплено: &f" + have + "&7/&f" + offer.limit()));
            } else if (have > 0) {
                lore.add(Hud.legacy("&aКуплено"));
            }
            lore.add(Hud.legacy(gems(player) >= offer.price() ? "&eНажми, чтобы купить"
                    : "&cНе хватает " + (offer.price() - gems(player)) + " " + symbol));
            meta.lore(lore);
            item.setItemMeta(meta);
            inventory.setItem(slot, item);
            holder.offers.put(slot, offer.id());
            slot++;
        }
        // подпись правил: магазин сам напоминает, что силы тут нет
        ItemStack note = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta noteMeta = note.getItemMeta();
        if (noteMeta != null) {
            noteMeta.displayName(Hud.legacy("&7Что здесь НЕ продаётся"));
            noteMeta.lore(List.of(
                    Hud.legacy("&7Характеристики, урон, броня, скорость"),
                    Hud.legacy("&7Ранги, очки гильдии, ступени испытаний"),
                    Hud.legacy("&7Монеты за настоящие деньги"),
                    Component.empty(),
                    Hud.legacy("&8Это проверяется автоматически: DonateConfigTest")));
            note.setItemMeta(noteMeta);
        }
        inventory.setItem(49, note);
        player.openInventory(inventory);
    }

    public void click(Player player, Inventory inventory, int slot) {
        if (!isMenu(inventory)) {
            return;
        }
        Menu menu = (Menu) inventory.getHolder();
        String id = menu.offers.get(slot);
        if (id == null) {
            return;
        }
        Offer offer = byId.get(id);
        String error = buy(player, offer);
        if (error != null) {
            messages.send(player, error);
        } else {
            messages.send(player, "donate.bought", Map.of(
                    "name", offer.name(), "price", String.valueOf(offer.price()),
                    "gems", String.valueOf(gems(player))));
        }
        open(player);
    }
}
