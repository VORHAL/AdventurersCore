package ru.adventurers.core.dungeon;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.classes.PlayerClass;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;

/** Описание подземелья из dungeons/<id>.yml. Все координаты внутри файла считаются от нижнего угла шаблона. */
public final class DungeonDef {

    public record Region(int[] from, int[] to, Material material) {
    }

    public record PhaseDef(double atHealth, String say, Map<EntityType, Integer> summon, String effect) {
    }

    /**
     * Зона телеграфа (раздел 26.1): босс заранее подсвечивает область, через
     * telegraph-seconds наносит урон только внутри неё. Кто отошёл - жив.
     *
     * @param shape      CIRCLE, LINE или CONE
     * @param radius     радиус круга / длина линии / длина конуса
     * @param angle      угол конуса в градусах (для CONE)
     * @param damage     урон в единицах здоровья (2 = 1 сердце)
     * @param telegraph  сколько секунд висит подсветка до удара
     * @param atHealth   при каком проценте здоровья босса включается (0.0-1.0)
     * @param everySeconds как часто повторяется (0 - один раз за фазу)
     */
    public record ZoneDef(String shape, double radius, double angle, double damage,
                          double telegraph, double atHealth, double everySeconds) {
        public boolean cone() {
            return "CONE".equalsIgnoreCase(shape);
        }

        public boolean line() {
            return "LINE".equalsIgnoreCase(shape);
        }
    }

    /**
     * Модификатор захода (раздел 26.5): риск в обмен на награду.
     * Каждый модификатор обязан давать и минус, и плюс - иначе это просто подарок.
     *
     * @param id        идентификатор в dungeons.yml
     * @param name      название для игрока
     * @param mobHealth множитель здоровья мобов
     * @param mobDamage множитель урона мобов
     * @param playerDamage множитель урона игроков
     * @param playerTaken  множитель получаемого игроками урона
     * @param timeFactor   множитель лимита времени
     * @param lootBonus    сколько дополнительных рулонов добычи
     * @param coinsFactor  множитель монет
     * @param healFactor   множитель лечения (1.0 - как обычно)
     */
    public record ModifierDef(String id, String name, double mobHealth, double mobDamage,
                              double playerDamage, double playerTaken, double timeFactor,
                              int lootBonus, double coinsFactor, double healFactor) {
    }

    public record BossDef(EntityType type, String name, double health, double damage, double[] at,
                          List<PhaseDef> phases, List<ZoneDef> zones, double enrageMinutes) {
    }

    public record WaveDef(Map<EntityType, Integer> mobs, double[] at, double spread, String say) {
    }

    public record RoomDef(String id, String type, String name, double[] trigger, double radius,
                          List<Region> seal, List<Region> unlock, List<WaveDef> waves, BossDef boss) {
        public boolean isBoss() {
            return "boss".equalsIgnoreCase(type);
        }
    }

    public record Loot(String item, String gem, String rune, int min, int max, int level, double chance,
                       double weight, Set<PlayerClass> classes, String customId, String rarity, String name,
                       List<String> lore, Rank requiredRank, Map<String, Integer> enchants, String model) {
    }

    /** Героический режим: поля из секции heroic: (всё необязательно, остальное берётся из обычного). */
    public record Heroic(boolean enabled, Rank minRank, int lives, int timeLimitMinutes,
                         double mobHealth, double mobDamage, int points, long coins, List<Loot> loot) {
    }

    public final String id;
    public final String name;
    public final Rank minRank;
    /** Верхняя граница ранга (null = без ограничения): подземелья F, E, D... и пары F+E, E+D... */
    public final Rank maxRank;
    /** Ранг таблицы наград; по умолчанию равен min-rank, чтобы состав группы не менял дроп. */
    public final Rank lootRank;
    /** Рейдовое подземелье: заходит рейд (10 игроков, 2 танка, 2 лекаря, 6 бойцов). */
    public final boolean raid;
    /** Через сколько дней после прохождения можно зайти снова (обычный / героический режим). */
    public final int lockoutDays;
    public final int heroicLockoutDays;
    public final int minPlayers;
    public final int maxPlayers;
    public final int needTanks;
    public final int needHealers;
    public final int lives;
    public final int timeLimitMinutes;
    public final double mobHealth;
    public final double mobDamage;
    public final String templateWorld;
    public final int[] pos1;
    public final int[] pos2;
    public final double[] spawn;
    public final List<RoomDef> rooms = new ArrayList<>();
    public final int points;
    public final long coins;
    public final List<Loot> loot = new ArrayList<>();
    public final Heroic heroic;
    public final String description;
    public final String icon;
    /**
     * Блоки темы для черновой постройки (buildtest): пол, стены, потолок, свет и акцент
     * площадки босса. Пустая строка - берётся значение по умолчанию (серый камень).
     * Тема есть в yml каждого подземелья: без неё все девять карт выглядят одинаково.
     */
    public final String themeFloor;
    public final String themeWall;
    public final String themeCeiling;
    public final String themeLight;
    public final String themeAccent;

    public DungeonDef(String id, YamlConfiguration cfg) {
        this.id = id;
        this.name = cfg.getString("name", id);
        Rank rank = Rank.fromInput(cfg.getString("min-rank", "F"));
        this.minRank = rank == null ? Rank.values()[0] : rank;
        Rank top = cfg.contains("max-rank") ? Rank.fromInput(cfg.getString("max-rank", "")) : null;
        this.maxRank = top;
        Rank parsedLootRank = Rank.fromInput(cfg.getString("loot-rank", this.minRank.getDatabaseName()));
        this.lootRank = parsedLootRank == null ? this.minRank : parsedLootRank;
        this.raid = "raid".equalsIgnoreCase(cfg.getString("type", "group"));
        this.lockoutDays = Math.max(0, cfg.getInt("lockout-days", raid ? 7 : 2));
        this.heroicLockoutDays = Math.max(0, cfg.getInt("heroic.lockout-days", raid ? 7 : 3));
        this.minPlayers = Math.max(1, cfg.getInt("players.min", 3));
        this.maxPlayers = Math.max(minPlayers, cfg.getInt("players.max", 5));
        this.needTanks = Math.max(0, cfg.getInt("require.tanks", 1));
        this.needHealers = Math.max(0, cfg.getInt("require.healers", 1));
        this.lives = Math.max(1, cfg.getInt("lives", 3));
        this.timeLimitMinutes = cfg.getInt("time-limit-minutes", 40);
        this.mobHealth = cfg.getDouble("mob-health", 1.0);
        this.mobDamage = cfg.getDouble("mob-damage", 1.0);
        this.templateWorld = cfg.getString("template.world", "dungeon_templates");
        this.pos1 = ints(cfg.getList("template.pos1"), 3);
        this.pos2 = ints(cfg.getList("template.pos2"), 3);
        this.spawn = doubles(cfg.getList("spawn"), 3);
        this.points = cfg.getInt("rewards.points", 0);
        this.coins = cfg.getLong("rewards.coins", 0);
        loot.addAll(loot(cfg.getMapList("rewards.loot")));
        this.description = cfg.getString("description", "");
        this.icon = cfg.getString("icon", "IRON_DOOR");
        this.themeFloor = cfg.getString("theme.floor", "POLISHED_DEEPSLATE");
        this.themeWall = cfg.getString("theme.wall", "STONE_BRICKS");
        this.themeCeiling = cfg.getString("theme.ceiling", "STONE_BRICKS");
        this.themeLight = cfg.getString("theme.light", "LANTERN");
        this.themeAccent = cfg.getString("theme.accent", "CHISELED_STONE_BRICKS");
        ConfigurationSection hs = cfg.getConfigurationSection("heroic");
        if (hs == null || !hs.getBoolean("enabled", true)) {
            this.heroic = new Heroic(false, minRank, lives, timeLimitMinutes, mobHealth, mobDamage, points, coins, loot);
        } else {
            Rank hr = Rank.fromInput(hs.getString("min-rank", minRank.getDatabaseName()));
            List<Loot> all = new ArrayList<>(hs.contains("rewards.loot") ? loot(hs.getMapList("rewards.loot")) : loot);
            all.addAll(loot(hs.getMapList("rewards.extra-loot")));
            this.heroic = new Heroic(true, hr == null ? minRank : hr, Math.max(1, hs.getInt("lives", lives)),
                    hs.getInt("time-limit-minutes", timeLimitMinutes), hs.getDouble("mob-health", mobHealth * 1.8),
                    hs.getDouble("mob-damage", mobDamage * 1.5), hs.getInt("rewards.points", points * 2),
                    hs.getLong("rewards.coins", coins * 2), all);
        }
        ConfigurationSection rs = cfg.getConfigurationSection("rooms");
        if (rs != null) {
            for (String key : rs.getKeys(false)) {
                ConfigurationSection r = rs.getConfigurationSection(key);
                if (r != null) {
                    rooms.add(parseRoom(key, r));
                }
            }
        }
    }

    /** Подходит ли ранг игрока под диапазон подземелья (нижняя граница задаётся отдельно для режима). */
    public boolean rankInRange(Rank rank, Rank min) {
        return rank.isAtLeast(min) && (maxRank == null || maxRank.isAtLeast(rank));
    }

    /** Текст диапазона для меню: «F», «F – E» или «A+ и выше». */
    public String rankText() {
        if (maxRank == null) {
            return minRank.getDisplayName() + "+";
        }
        return maxRank == minRank ? minRank.getDisplayName()
                : minRank.getDisplayName() + " – " + maxRank.getDisplayName();
    }

    private static List<Loot> loot(List<Map<?, ?>> list) {
        List<Loot> result = new ArrayList<>();
        for (Map<?, ?> map : list) {
            String item = map.get("item") == null ? null : String.valueOf(map.get("item"));
            String gem = map.get("gem") == null ? null : String.valueOf(map.get("gem"));
            String rune = map.get("rune") == null ? null : String.valueOf(map.get("rune"));
            int min = num(map.get("min"), 1);
            int max = Math.max(min, num(map.get("max"), min));
            int level = num(map.get("level"), 1);
            double chance = map.get("chance") instanceof Number n ? n.doubleValue() : 1.0;
            double weight = map.get("weight") instanceof Number n ? Math.max(0.0, n.doubleValue()) : 1.0;
            Set<PlayerClass> allowedClasses = new HashSet<>();
            Object rawClasses = map.get("classes") != null ? map.get("classes") : map.get("need-classes");
            if (rawClasses instanceof List<?> classValues) {
                for (Object value : classValues) {
                    PlayerClass playerClass = PlayerClass.fromInput(String.valueOf(value));
                    if (playerClass != null) {
                        allowedClasses.add(playerClass);
                    }
                }
            } else if (rawClasses != null) {
                PlayerClass playerClass = PlayerClass.fromInput(String.valueOf(rawClasses));
                if (playerClass != null) {
                    allowedClasses.add(playerClass);
                }
            }
            String customId = map.get("custom-id") == null ? null : String.valueOf(map.get("custom-id"));
            String rarity = map.get("rarity") == null ? null : String.valueOf(map.get("rarity"));
            String name = map.get("name") == null ? null : String.valueOf(map.get("name"));
            List<String> lore = new ArrayList<>();
            if (map.get("lore") instanceof List<?> lines) {
                for (Object line : lines) {
                    lore.add(String.valueOf(line));
                }
            }
            Rank requiredRank = map.get("required-rank") == null
                    ? null : Rank.fromInput(String.valueOf(map.get("required-rank")));
            Map<String, Integer> enchants = new LinkedHashMap<>();
            if (map.get("enchants") instanceof Map<?, ?> rawEnchants) {
                for (Map.Entry<?, ?> entry : rawEnchants.entrySet()) {
                    if (entry.getValue() instanceof Number number) {
                        enchants.put(String.valueOf(entry.getKey()), number.intValue());
                    }
                }
            }
            // модель: своя у именного дропа с босса, иначе арт ранга (PackItems.gear)
            String model = map.get("model") == null ? null : String.valueOf(map.get("model"));
            result.add(new Loot(item, gem, rune, min, max, level, chance, weight, Set.copyOf(allowedClasses),
                    customId, rarity, name, List.copyOf(lore), requiredRank, Map.copyOf(enchants), model));
        }
        return result;
    }

    private static RoomDef parseRoom(String id, ConfigurationSection r) {
        List<WaveDef> waves = new ArrayList<>();
        for (Map<?, ?> map : r.getMapList("waves")) {
            waves.add(new WaveDef(mobs(map.get("mobs")), doubles((List<?>) map.get("at"), 3),
                    map.get("spread") instanceof Number n ? n.doubleValue() : 4.0,
                    map.get("say") == null ? null : String.valueOf(map.get("say"))));
        }
        BossDef boss = null;
        ConfigurationSection b = r.getConfigurationSection("boss");
        if (b != null) {
            List<PhaseDef> phases = new ArrayList<>();
            for (Map<?, ?> map : b.getMapList("phases")) {
                phases.add(new PhaseDef(map.get("at-health") instanceof Number n ? n.doubleValue() : 0.5,
                        map.get("say") == null ? null : String.valueOf(map.get("say")),
                        mobs(map.get("summon")),
                        map.get("effect") == null ? null : String.valueOf(map.get("effect"))));
            }
            List<ZoneDef> zones = new ArrayList<>();
            for (Map<?, ?> map : b.getMapList("zones")) {
                zones.add(new ZoneDef(
                        map.get("shape") == null ? "CIRCLE" : String.valueOf(map.get("shape")),
                        map.get("radius") instanceof Number radius ? radius.doubleValue() : 4.0,
                        map.get("angle") instanceof Number angle ? angle.doubleValue() : 90.0,
                        map.get("damage") instanceof Number damage ? damage.doubleValue() : 4.0,
                        map.get("telegraph") instanceof Number telegraph ? telegraph.doubleValue() : 1.2,
                        percent(map.get("at-health")),
                        map.get("every-seconds") instanceof Number every ? every.doubleValue() : 0.0));
            }
            EntityType type = entity(b.getString("type", "ZOMBIE"));
            boss = new BossDef(type == null ? EntityType.ZOMBIE : type, b.getString("name", "Босс"),
                    b.getDouble("health", 200), b.getDouble("damage", 0),
                    doubles(b.getList("at"), 3), phases, zones, b.getDouble("enrage-minutes", 0));
        }
        return new RoomDef(id, r.getString("type", "waves"), r.getString("name", id),
                doubles(r.getList("trigger"), 3), r.getDouble("radius", 8),
                regions(r.getMapList("seal")), regions(r.getMapList("unlock")), waves, boss);
    }

    /** Модификаторы захода из dungeons.yml: раздел modifiers. */
    public static Map<String, ModifierDef> parseModifiers(ConfigurationSection section) {
        Map<String, ModifierDef> result = new LinkedHashMap<>();
        if (section == null) {
            return result;
        }
        for (String id : section.getKeys(false)) {
            ConfigurationSection m = section.getConfigurationSection(id);
            if (m == null) {
                continue;
            }
            result.put(id, new ModifierDef(id, m.getString("name", id),
                    m.getDouble("mob-health", 1.0), m.getDouble("mob-damage", 1.0),
                    m.getDouble("player-damage", 1.0), m.getDouble("player-taken", 1.0),
                    m.getDouble("time-factor", 1.0), m.getInt("loot-bonus", 0),
                    m.getDouble("coins-factor", 1.0), m.getDouble("heal-factor", 1.0)));
        }
        return result;
    }

    private static List<Region> regions(List<Map<?, ?>> list) {
        List<Region> result = new ArrayList<>();
        for (Map<?, ?> map : list) {
            Material material = map.get("material") == null ? Material.IRON_BARS
                    : Material.matchMaterial(String.valueOf(map.get("material")));
            result.add(new Region(ints((List<?>) map.get("from"), 3), ints((List<?>) map.get("to"), 3),
                    material == null ? Material.IRON_BARS : material));
        }
        return result;
    }

    private static Map<EntityType, Integer> mobs(Object raw) {
        Map<EntityType, Integer> result = new LinkedHashMap<>();
        if (raw instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                EntityType type = entity(String.valueOf(entry.getKey()));
                if (type != null) {
                    result.put(type, num(entry.getValue(), 1));
                }
            }
        }
        return result;
    }

    private static EntityType entity(String name) {
        try {
            return EntityType.valueOf(name.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    private static int num(Object value, int fallback) {
        return value instanceof Number n ? n.intValue() : fallback;
    }

    private static int[] ints(List<?> list, int size) {
        int[] result = new int[size];
        if (list != null) {
            for (int i = 0; i < size && i < list.size(); i++) {
                result[i] = list.get(i) instanceof Number n ? n.intValue() : 0;
            }
        }
        return result;
    }

    /**
     * Порог зоны: принимаем и проценты (100/66/33), и доли (1.0/0.66/0.33).
     * Раньше значение больше 1 трактовалось как «до конца боя», и зона
     * с at-health: 80 не срабатывала никогда.
     */
    private static double percent(Object value) {
        if (!(value instanceof Number number)) {
            return 1.0;
        }
        double raw = number.doubleValue();
        if (raw <= 0) {
            return 0;
        }
        double fraction = raw > 1 ? raw / 100.0 : raw;
        return Math.min(1.0, fraction);
    }

    private static double[] doubles(List<?> list, int size) {
        double[] result = new double[size];
        if (list != null) {
            for (int i = 0; i < size && i < list.size(); i++) {
                result[i] = list.get(i) instanceof Number n ? n.doubleValue() : 0;
            }
        }
        return result;
    }
}
