package ru.adventurers.core.dungeon;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareGrindstoneEvent;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.hud.PackItems;
import ru.adventurers.core.gem.GemManager;
import ru.adventurers.core.party.Party;
import ru.adventurers.core.party.PartyManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.nio.file.Path;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Подземелья: у каждой группы своя копия карты в отдельном мире, комнаты с волнами,
 * мини-боссы и финальный босс, жизни, награда. Настройки: dungeons.yml и dungeons/&lt;id&gt;.yml.
 * Все методы вызываются из основного потока.
 */
public class DungeonManager implements Listener {

    /** Пустой мир без генерации. */
    private static final class VoidGenerator extends ChunkGenerator {
        @Override
        public Location getFixedSpawnLocation(World world, Random random) {
            return new Location(world, 0.5, 100, 0.5);
        }
    }

    private enum State { LOADING, RUNNING, COMPLETE, CLOSING }

    private final class Instance {
        final int slot;
        final DungeonDef def;
        final Location origin;          // нижний угол копии
        final Set<UUID> members = new HashSet<>();
        final Map<UUID, Integer> lives = new HashMap<>();
        final Set<UUID> mobs = new HashSet<>();
        final Set<Integer> phasesDone = new HashSet<>();
        final long created = System.currentTimeMillis();
        State state = State.LOADING;
        int room = 0;
        int wave = -1;                  // -1: комната ещё не начата
        UUID boss;
        double bossMax;
        BossBar bar;
        Location checkpoint;
        long closeAt;
        boolean admin;
        boolean heroic;
        /** Модификатор захода (раздел 26.5): null - обычный заход. */
        DungeonDef.ModifierDef modifier;
        /** Ступени ярости босса: 0 - не злится, растёт каждые 30 с после порога. */
        int enrageStacks;
        long bossStartedAt;
        /** Когда босс последний раз кастовал (чтобы не спамить касты). */
        long lastCastAt;
        /** Зоны, которые уже отработали в текущей фазе (ключ - индекс зоны). */
        final Set<Integer> zonesDone = new HashSet<>();
        /** Активный каст босса: сбивается умениями танка и бойца. */
        DungeonMechanics.Cast cast;
        /** Итоги забега (раздел 26.4): урон, лечение, смерти, сбитые касты. */
        final Map<UUID, Double> dealt = new LinkedHashMap<>();
        final Map<UUID, Double> taken = new LinkedHashMap<>();
        final Map<UUID, Double> healed = new LinkedHashMap<>();
        final Map<UUID, Integer> deaths = new LinkedHashMap<>();
        final Map<UUID, Integer> interrupts = new LinkedHashMap<>();
        String invasion;                // метка вторжения (null: обычное подземелье)
        long copyIndex;
        BukkitTask copyTask;

        Instance(int slot, DungeonDef def, Location origin) {
            this.slot = slot;
            this.def = def;
            this.origin = origin;
        }

        int lives() {
            return heroic ? def.heroic.lives() : def.lives;
        }

        double mobHealth() {
            double base = heroic ? def.heroic.mobHealth() : def.mobHealth;
            return modifier == null ? base : base * modifier.mobHealth();
        }

        double mobDamage() {
            double base = heroic ? def.heroic.mobDamage() : def.mobDamage;
            return modifier == null ? base : base * modifier.mobDamage();
        }

        int timeLimit() {
            int base = heroic ? def.heroic.timeLimitMinutes() : def.timeLimitMinutes;
            return modifier == null ? base : (int) Math.max(1, base * modifier.timeFactor());
        }

        /** Урон, который наносят игроки: модификатор «стеклянная пушка» его поднимает. */
        double playerDamage() {
            return modifier == null ? 1.0 : modifier.playerDamage();
        }

        /** Урон, который получают игроки: второй множитель того же модификатора. */
        double playerTaken() {
            return modifier == null ? 1.0 : modifier.playerTaken();
        }

        /** Лечение внутри забега: модификатор «без лекаря» его режет. */
        double playerHeal() {
            return modifier == null ? 1.0 : modifier.healFactor();
        }

        /** Дополнительные рулоны добычи от модификатора. */
        int extraRolls() {
            return modifier == null ? 0 : modifier.lootBonus();
        }

        Location abs(double[] rel) {
            return origin.clone().add(rel[0], rel[1], rel[2]);
        }
    }

    private enum LootChoice { NEED, GREED, PASS }

    private static final class LootDrop {
        final ItemStack item;
        final Set<ru.adventurers.core.classes.PlayerClass> allowedClasses;
        final Rank requiredRank;
        final Map<UUID, LootChoice> choices = new HashMap<>();
        boolean resolved;
        int rollGeneration;

        LootDrop(ItemStack item, Set<ru.adventurers.core.classes.PlayerClass> allowedClasses, Rank requiredRank) {
            this.item = item.clone();
            this.allowedClasses = Set.copyOf(allowedClasses);
            this.requiredRank = requiredRank;
        }
    }

    private static final class LootSession {
        final Set<UUID> members;
        final List<LootDrop> drops;
        final String dungeonName;
        boolean closed;

        LootSession(Set<UUID> members, List<LootDrop> drops, String dungeonName) {
            this.members = new HashSet<>(members);
            this.drops = new ArrayList<>(drops);
            this.dungeonName = dungeonName;
        }

        boolean complete() {
            return drops.stream().allMatch(drop -> drop.resolved);
        }
    }

    private record LootChoiceView(LootSession session, LootDrop drop, UUID playerId) { }

    private final AdventurersCore plugin;
    private final NamespacedKey mobKey;
    /** Телеграфы, ярость и прерывание каста (раздел 27). */
    private final DungeonMechanics mechanics;
    /** Модификаторы заходов из dungeons.yml (раздел 26.5). */
    private final Map<String, DungeonDef.ModifierDef> modifiers = new LinkedHashMap<>();
    /** Замер боя (/ag admin dungeon probe): когда начали, кто игрок, какой ранг. */
    private final Map<UUID, CombatProbe> probes = new HashMap<>();
    /** Копится на игрока по боям: сколько бьёт и сколько получает. Живёт в памяти до рестарта. */
    private final Map<UUID, CombatStats> combatStats = new LinkedHashMap<>();
    private final NamespacedKey runsKey;
    private final NamespacedKey customLootIdKey;
    private final NamespacedKey customLootRarityKey;
    private final NamespacedKey customLootClassesKey;
    private final NamespacedKey customLootRankKey;
    private final NamespacedKey dungeonLootOwnerKey;
    private final Random random = new Random();

    private final Map<String, DungeonDef> defs = new LinkedHashMap<>();
    private YamlConfiguration lootConfig = new YamlConfiguration();
    private final Map<Integer, Instance> instances = new HashMap<>();
    private final Map<UUID, Instance> byPlayer = new HashMap<>();
    private final Map<UUID, Location> returnTo = new HashMap<>();
    private final Map<UUID, LootSession> lootByPlayer = new HashMap<>();
    private final Map<Inventory, LootSession> lootMenus = new IdentityHashMap<>();
    private final Map<Inventory, LootChoiceView> lootChoiceMenus = new IdentityHashMap<>();
    private BukkitTask task;

    private boolean enabled = true;
    private String hubWorld = "";
    private String instanceWorldName = "dungeon_instances";
    private int spacing = 512;
    private int maxInstances = 4;
    private int copyPerTick = 12000;
    private int dailyLimit = 1;
    private boolean soloNeedsPass = true;
    private boolean showAllInMenu = false;
    private final NamespacedKey passKey;
    private int closeDelaySeconds = 120;
    private int groupLootRollSeconds = 30;
    private boolean heroicNeedsNormal = true;
    private double healthPerExtra = 0.35;
    private double damagePerExtra = 0.10;

    public DungeonManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.mobKey = new NamespacedKey(plugin, "dungeon_mob");
        this.mechanics = new DungeonMechanics(plugin);
        this.runsKey = new NamespacedKey(plugin, "dungeon_runs");
        this.customLootIdKey = new NamespacedKey(plugin, "custom_loot_id");
        this.customLootRarityKey = new NamespacedKey(plugin, "custom_loot_rarity");
        this.customLootClassesKey = new NamespacedKey(plugin, "custom_loot_classes");
        this.customLootRankKey = new NamespacedKey(plugin, "custom_loot_rank");
        this.dungeonLootOwnerKey = new NamespacedKey(plugin, "dungeon_loot_owner");
        this.passKey = new NamespacedKey(plugin, "dungeon_solo_pass");
    }

    // ---------------------------------------------------------------
    //  Запуск и настройки
    // ---------------------------------------------------------------

    public void init() {
        reload();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 10L);
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
        }
        for (Instance instance : new ArrayList<>(instances.values())) {
            close(instance, false);
        }
    }

    public void reload() {
        File file = plugin.getFiles().file("dungeons.yml");
        if (!file.exists()) {
            plugin.getFiles().save("dungeons.yml");
        }
        File dir = plugin.getFiles().file("dungeons");
        if (!dir.exists()) {
            plugin.saveResource("dungeons/test.yml", false);
        }
        // Шаблоны подземелий докладываем, только если файла нет - правки админа не трогаем.
        for (String builtin : new String[]{"crypt_d.yml", "raid_crimson_c.yml", "archive_e.yml", "mines_d.yml",
                "cathedral_c.yml", "forge_b.yml", "spire_a.yml", "abyss_ap.yml", "throne_s.yml"}) {
            if (!new File(dir, builtin).exists()) {
                plugin.saveResource("dungeons/" + builtin, false);
            }
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        File lootFile = plugin.getFiles().file("dungeon-loot.yml");
        if (!lootFile.exists()) {
            plugin.getFiles().save("dungeon-loot.yml");
        }
        lootConfig = YamlConfiguration.loadConfiguration(lootFile);
        // модификаторы заходов (раздел 26.5): риск в обмен на награду
        modifiers.clear();
        modifiers.putAll(DungeonDef.parseModifiers(cfg.getConfigurationSection("modifiers")));
        enabled = cfg.getBoolean("enabled", true);
        hubWorld = cfg.getString("hub-world", "");
        instanceWorldName = cfg.getString("instance-world", "dungeon_instances");
        spacing = Math.max(128, cfg.getInt("instance-spacing", 512));
        maxInstances = Math.max(1, cfg.getInt("max-instances", 4));
        copyPerTick = Math.max(1000, cfg.getInt("copy-blocks-per-tick", 12000));
        dailyLimit = cfg.getInt("daily-limit", 1);
        soloNeedsPass = cfg.getBoolean("solo.requires-pass", true);
        showAllInMenu = cfg.getBoolean("menu.show-all-ranks", false);
        closeDelaySeconds = Math.max(10, cfg.getInt("close-delay-seconds", 120));
        groupLootRollSeconds = Math.max(5, cfg.getInt("group-loot.roll-seconds", 30));
        heroicNeedsNormal = cfg.getBoolean("heroic-requires-normal-clear", true);
        healthPerExtra = cfg.getDouble("scaling.health-per-extra-player", 0.35);
        damagePerExtra = cfg.getDouble("scaling.damage-per-extra-player", 0.10);

        defs.clear();
        File[] files = dir.listFiles((d, name) -> name.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                String id = f.getName().substring(0, f.getName().length() - 4).toLowerCase(Locale.ROOT);
                try {
                    defs.put(id, new DungeonDef(id, YamlConfiguration.loadConfiguration(f)));
                } catch (RuntimeException exception) {
                    plugin.getLogger().warning("Dungeon " + id + ": " + exception.getMessage());
                }
            }
        }
    }

    public java.util.Collection<DungeonDef> definitions() {
        return defs.values();
    }

    private World voidWorld(String name) {
        World world = Bukkit.getWorld(name);
        if (world == null) {
            WorldCreator creator = new WorldCreator(name);
            creator.generator(new VoidGenerator());
            world = creator.createWorld();
        }
        if (world != null) {
            world.setAutoSave(false);
            world.setPVP(false);
            world.setTime(6000);
            world.setSpawnLocation(0, 100, 0);
        }
        return world;
    }

    private void say(Player player, String key, Map<String, ?> placeholders) {
        plugin.getMessages().send(player, key, placeholders);
    }

    private void sayAll(Instance instance, String key, Map<String, ?> placeholders) {
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                say(player, key, placeholders);
            }
        }
    }

    private void titleAll(Instance instance, String title, String subtitle) {
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                player.showTitle(Title.title(Hud.legacy(title), Hud.legacy(subtitle)));
            }
        }
    }

    // ---------------------------------------------------------------
    //  Суточный лимит и прохождения
    // ---------------------------------------------------------------

    private int runsToday(Player player) {
        String value = player.getPersistentDataContainer().get(runsKey, PersistentDataType.STRING);
        if (value == null) {
            return 0;
        }
        String[] parts = value.split("\\|");
        if (parts.length != 2 || !parts[0].equals(LocalDate.now().toString())) {
            return 0;
        }
        try {
            return Integer.parseInt(parts[1]);
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private void addRun(Player player) {
        player.getPersistentDataContainer().set(runsKey, PersistentDataType.STRING,
                LocalDate.now() + "|" + (runsToday(player) + 1));
    }

    // ---------------------------------------------------------------
    //  Блокировка после прохождения и пропуска для соло
    // ---------------------------------------------------------------

    private NamespacedKey lockKey(DungeonDef def, boolean heroic) {
        return new NamespacedKey(plugin, "dungeon_lock_" + def.id + (heroic ? "_h" : "_n"));
    }

    /** Сколько дней осталось до повторного захода (0 = можно). Блокировка ставится при победе. */
    public int lockDaysLeft(Player player, DungeonDef def, boolean heroic) {
        Long day = player.getPersistentDataContainer().get(lockKey(def, heroic), PersistentDataType.LONG);
        if (day == null) {
            return 0;
        }
        int days = heroic ? def.heroicLockoutDays : def.lockoutDays;
        long left = day + days - LocalDate.now().toEpochDay();
        return (int) Math.max(0, left);
    }

    private void setLock(Player player, DungeonDef def, boolean heroic) {
        player.getPersistentDataContainer().set(lockKey(def, heroic), PersistentDataType.LONG,
                LocalDate.now().toEpochDay());
    }

    /** Сбросить блокировки игрока (id = null: все подземелья). Возвращает число сброшенных. */
    public int resetLocks(Player player, String id) {
        int count = 0;
        for (DungeonDef def : defs.values()) {
            if (id != null && !def.id.equalsIgnoreCase(id)) {
                continue;
            }
            for (boolean heroic : new boolean[]{false, true}) {
                if (player.getPersistentDataContainer().has(lockKey(def, heroic), PersistentDataType.LONG)) {
                    player.getPersistentDataContainer().remove(lockKey(def, heroic));
                    count++;
                }
            }
        }
        if (id == null) {
            player.getPersistentDataContainer().remove(runsKey);
        }
        return count;
    }

    public int soloPasses(Player player) {
        Integer value = player.getPersistentDataContainer().get(passKey, PersistentDataType.INTEGER);
        return value == null ? 0 : value;
    }

    /** Выдать пропуски на одиночный вход (вызывается заданием гильдии или админом). */
    public void grantSoloPass(Player player, int amount) {
        player.getPersistentDataContainer().set(passKey, PersistentDataType.INTEGER,
                Math.max(0, soloPasses(player) + amount));
    }

    // ---------------------------------------------------------------
    //  Вход
    // ---------------------------------------------------------------

    private String modeName(Instance instance) {
        return instance.def.name + (instance.heroic ? " &c[Героический]" : "");
    }

    private NamespacedKey clearKey(DungeonDef def) {
        return new NamespacedKey(plugin, "dungeon_clear_" + def.id);
    }

    private boolean cleared(Player player, DungeonDef def) {
        return player.getPersistentDataContainer().has(clearKey(def), PersistentDataType.BYTE);
    }

    /** Меню выбора: ЛКМ по предмету - обычное, ПКМ - героическое. */
    private static final class MenuHolder implements org.bukkit.inventory.InventoryHolder {
        final List<DungeonDef> shown = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    public void list(Player player) {
        if (defs.isEmpty()) {
            say(player, "dungeon.none", Map.of());
            return;
        }
        if (!hubWorld.isEmpty() && !player.getWorld().getName().equalsIgnoreCase(hubWorld)
                && !player.hasPermission("ag.admin")) {
            say(player, "dungeon.only-hub", Map.of());
            return;
        }
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        boolean admin = player.hasPermission("ag.admin");
        List<DungeonDef> visible = new ArrayList<>();
        for (DungeonDef def : defs.values()) {
            boolean fits = profile != null && def.rankInRange(profile.getRank(), def.minRank);
            boolean heroicFits = def.heroic.enabled() && profile != null
                    && def.rankInRange(profile.getRank(), def.heroic.minRank());
            // игроку показываем то, что подходит его рангу (и рейды при ранге от минимального)
            if (showAllInMenu || admin || fits || heroicFits) {
                visible.add(def);
            }
        }
        visible.sort(java.util.Comparator.comparing((DungeonDef d) -> d.raid)
                .thenComparingInt(d -> d.minRank.ordinal())
                .thenComparingInt(d -> d.maxRank == null ? 99 : d.maxRank.ordinal())
                .thenComparing(d -> d.id));
        MenuHolder holder = new MenuHolder();
        int rows = Math.max(2, Math.min(6, (visible.size() + 8) / 9 + 1));
        Inventory inventory = Bukkit.createInventory(holder, rows * 9, Hud.legacy("&8Подземелья"));
        var noItalic = net.kyori.adventure.text.format.TextDecoration.ITALIC;
        int slot = 0;
        for (DungeonDef def : visible) {
            if (slot >= rows * 9 - 9) {
                break;
            }
            holder.shown.add(def);
            Material icon = Material.matchMaterial(def.icon);
            ItemStack item = new ItemStack(icon == null ? Material.IRON_DOOR : icon);
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Hud.legacy((def.raid ? "&5[Рейд] " : "") + def.name).decoration(noItalic, false));
            List<Component> lore = new ArrayList<>();
            if (!def.description.isEmpty()) {
                lore.add(Hud.legacy("&7" + def.description));
                lore.add(Component.empty());
            }
            boolean okNormal = profile != null && def.rankInRange(profile.getRank(), def.minRank);
            int lockN = lockDaysLeft(player, def, false);
            lore.add(Hud.legacy("&8Ранги: &f" + def.rankText()));
            lore.add(Hud.legacy("&8Обычный: " + (okNormal ? "&a" : "&c") + "доступен"
                    + "&7, жизней &f" + def.lives + "&7, " + (def.raid ? "рейд" : "игроков &f" + def.minPlayers + "-" + def.maxPlayers)));
            lore.add(Hud.legacy("&7  награда: &6" + def.points + " очков"
                    + (lockN > 0 ? "  &cдоступно через " + lockN + " дн." : "")));
            if (def.heroic.enabled()) {
                boolean okHeroic = profile != null && def.rankInRange(profile.getRank(), def.heroic.minRank());
                boolean open = !heroicNeedsNormal || cleared(player, def);
                int lockH = lockDaysLeft(player, def, true);
                lore.add(Hud.legacy("&8Героический: " + (okHeroic && open ? "&a" : "&c") + "ранг от "
                        + def.heroic.minRank().getDisplayName() + "&7, мобы сильнее, награда &6"
                        + def.heroic.points() + " очков&7 + руны"
                        + (open ? "" : " &8(сначала пройдите обычный)")
                        + (lockH > 0 ? " &cчерез " + lockH + " дн." : "")));
            }
            if (def.raid) {
                PartyManager parties = plugin.getParties();
                lore.add(Hud.legacy("&7Состав: &f" + parties.maxSize(Party.Type.RAID) + " &7игроков: танков &f"
                        + parties.need("tank") + "&7, лекарей &f" + parties.need("healer")
                        + "&7, бойцов &f" + parties.need("fighter")));
                lore.add(Hud.legacy("&7Вход через рейд: &f/ag raid"));
            } else {
                lore.add(Hud.legacy("&7Состав: танков &f" + def.needTanks + "&7, лекарей &f" + def.needHealers));
                if (soloNeedsPass) {
                    lore.add(Hud.legacy("&8Один можно только по пропуску гильдии (у вас: &f" + soloPasses(player) + "&8)"));
                }
            }
            lore.add(Component.empty());
            lore.add(Hud.legacy("&eЛКМ &7- обычный" + (def.heroic.enabled() ? "   &cПКМ &7- героический" : "")));
            lore.replaceAll(c -> c.decoration(noItalic, false));
            meta.lore(lore);
            item.setItemMeta(meta);
            inventory.setItem(slot++, item);
        }
        player.openInventory(inventory);
    }

    @EventHandler
    public void onMenuClick(org.bukkit.event.inventory.InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof MenuHolder holder)
                || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        if (slot < 0 || slot >= holder.shown.size()) {
            return;
        }
        boolean heroic = event.getClick().isRightClick();
        DungeonDef def = holder.shown.get(slot);
        player.closeInventory();
        enter(player, def.id, heroic, false);
    }

    /** Вход с модификатором (раздел 26.5): риск в обмен на добычу. */
    /** Случайный модификатор для захода «на удачу» (пустой список - без модификатора). */
    public String randomModifierId() {
        if (modifiers.isEmpty()) {
            return null;
        }
        List<String> ids = new ArrayList<>(modifiers.keySet());
        return ids.get(random.nextInt(ids.size()));
    }

    public void enter(Player leader, String id, boolean heroic, boolean adminTest, String modifierId) {
        DungeonDef.ModifierDef modifier = modifierId == null ? null : modifiers.get(modifierId.toLowerCase(Locale.ROOT));
        if (modifierId != null && modifier == null) {
            say(leader, "dungeon.unknown-modifier", Map.of("mod", modifierId));
            return;
        }
        // модификатор запоминается на игрока до конца входа: инстанс создаётся ниже,
        // в общем коде, поэтому передаём его через карту «ожидающих»
        pendingModifier.put(leader.getUniqueId(), modifier);
        try {
            enter(leader, id, heroic, adminTest);
        } finally {
            pendingModifier.remove(leader.getUniqueId());
        }
    }

    /** Модификатор, который надо применить к создаваемому инстансу. */
    private final Map<UUID, DungeonDef.ModifierDef> pendingModifier = new HashMap<>();

    public void enter(Player leader, String id, boolean heroic, boolean adminTest) {
        // цепочка первых шагов (раздел 24): засчитываем вход, когда подземелье реально началось
        if (plugin.getOnboarding() != null) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (plugin.getOnboarding() != null
                        && byPlayer.containsKey(leader.getUniqueId())) {
                    plugin.getOnboarding().complete(leader, "dungeon-entered");
                }
            });
        }
        DungeonDef def = defs.get(id.toLowerCase(Locale.ROOT));
        if (def == null) {
            say(leader, "dungeon.unknown", Map.of());
            return;
        }
        if (heroic && !def.heroic.enabled()) {
            say(leader, "dungeon.no-heroic", Map.of());
            return;
        }
        Rank needRank = heroic ? def.heroic.minRank() : def.minRank;
        boolean solo = false;
        boolean usePass = false;
        if (!enabled && !adminTest) {
            say(leader, "dungeon.disabled", Map.of());
            return;
        }
        if (byPlayer.containsKey(leader.getUniqueId())) {
            say(leader, "dungeon.already-in", Map.of());
            return;
        }
        List<Player> team = new ArrayList<>();
        if (adminTest) {
            team.add(leader);
        } else {
            PartyManager parties = plugin.getParties();
            Party group = def.raid ? parties.raid(leader.getUniqueId()) : parties.group(leader.getUniqueId());
            if (group != null && !group.getLeader().equals(leader.getUniqueId())) {
                say(leader, "dungeon.not-leader", Map.of());
                return;
            }
            if (group == null || (!def.raid && group.size() == 1)) {
                if (def.raid) {
                    say(leader, "dungeon.no-raid", Map.of());
                    return;
                }
                // одиночный вход: только по пропуску гильдии
                solo = true;
                if (soloNeedsPass && !leader.hasPermission("ag.admin") && soloPasses(leader) <= 0) {
                    say(leader, "dungeon.solo-denied", Map.of());
                    return;
                }
                group = null;
            }
            List<UUID> ids = new ArrayList<>();
            if (group == null) {
                ids.add(leader.getUniqueId());
            } else {
                if (def.raid) {
                    if (group.size() != parties.maxSize(Party.Type.RAID) || !parties.raidReady(group)) {
                        say(leader, "dungeon.raid-composition", Map.of("size", parties.maxSize(Party.Type.RAID),
                                "tanks", parties.need("tank"), "healers", parties.need("healer"),
                                "fighters", parties.need("fighter")));
                        return;
                    }
                } else if (group.size() < def.minPlayers || group.size() > def.maxPlayers) {
                    say(leader, "dungeon.size", Map.of("min", def.minPlayers, "max", def.maxPlayers));
                    return;
                }
                ids.addAll(group.members());
            }
            for (UUID member : ids) {
                Player player = Bukkit.getPlayer(member);
                if (player == null) {
                    say(leader, "dungeon.offline", Map.of());
                    return;
                }
                PlayerProfile profile = plugin.getProfileManager().getProfile(member);
                if (profile == null || !profile.getRank().isAtLeast(needRank)) {
                    say(leader, "dungeon.rank-low", Map.of("player", player.getName(), "rank", needRank.getDisplayName()));
                    return;
                }
                if (def.maxRank != null && !def.maxRank.isAtLeast(profile.getRank())) {
                    say(leader, "dungeon.rank-high", Map.of("player", player.getName(), "rank", def.maxRank.getDisplayName()));
                    return;
                }
                if (byPlayer.containsKey(member)) {
                    say(leader, "dungeon.member-busy", Map.of("player", player.getName()));
                    return;
                }
                if (heroic && heroicNeedsNormal && !cleared(player, def)) {
                    say(leader, "dungeon.heroic-locked", Map.of("player", player.getName()));
                    return;
                }
                int left = lockDaysLeft(player, def, heroic);
                if (left > 0) {
                    say(leader, "dungeon.locked", Map.of("player", player.getName(), "days", left));
                    return;
                }
                if (dailyLimit > 0 && runsToday(player) >= dailyLimit) {
                    say(leader, "dungeon.limit-daily", Map.of("player", player.getName(), "limit", dailyLimit));
                    return;
                }
                team.add(player);
            }
            if (!solo && !def.raid) {
                PartyManager.Composition comp = parties.composition(group);
                if (comp.tanks() < def.needTanks || comp.healers() < def.needHealers) {
                    say(leader, "dungeon.composition", Map.of("tanks", def.needTanks, "healers", def.needHealers));
                    return;
                }
            }
            usePass = solo && soloNeedsPass && !leader.hasPermission("ag.admin");
        }

        int slot = freeSlot();
        if (slot < 0) {
            say(leader, "dungeon.busy", Map.of());
            return;
        }
        World world = voidWorld(instanceWorldName);
        World template = voidWorld(def.templateWorld);
        if (world == null || template == null) {
            say(leader, "dungeon.world-error", Map.of());
            return;
        }
        int minY = Math.min(def.pos1[1], def.pos2[1]);
        Instance instance = new Instance(slot, def, new Location(world, 1000 + (double) slot * spacing, minY, 0));
        instance.modifier = pendingModifier.get(leader.getUniqueId());
        instance.admin = adminTest;
        instance.heroic = heroic;
        instances.put(slot, instance);
        if (usePass) {
            grantSoloPass(leader, -1);
            say(leader, "dungeon.solo-used", Map.of("left", soloPasses(leader)));
        }
        for (Player player : team) {
            instance.members.add(player.getUniqueId());
            instance.lives.put(player.getUniqueId(), instance.lives());
            byPlayer.put(player.getUniqueId(), instance);
            returnTo.put(player.getUniqueId(), player.getLocation().clone());
            if (!adminTest) {
                addRun(player);
            }
            say(player, "dungeon.loading", Map.of("name", modeName(instance)));
        }
        startCopy(instance, template);
    }

    /**
     * Запуск подземелья для вторжения: без проверок ранга, блокировок и дневного лимита.
     * Возвращает null при успехе или ключ ошибки из messages.yml (раздел dungeon).
     */
    public String startInvasion(Player leader, List<Player> team, String id, String tag) {
        DungeonDef def = defs.get(id.toLowerCase(Locale.ROOT));
        if (def == null) {
            return "dungeon.unknown";
        }
        for (Player player : team) {
            if (byPlayer.containsKey(player.getUniqueId())) {
                return "dungeon.already-in";
            }
        }
        if (team.size() > def.maxPlayers) {
            return "dungeon.size";
        }
        int slot = freeSlot();
        World world = voidWorld(instanceWorldName);
        World template = voidWorld(def.templateWorld);
        if (slot < 0) {
            return "dungeon.busy";
        }
        if (world == null || template == null) {
            return "dungeon.world-error";
        }
        int minY = Math.min(def.pos1[1], def.pos2[1]);
        Instance instance = new Instance(slot, def, new Location(world, 1000 + (double) slot * spacing, minY, 0));
        instance.modifier = pendingModifier.get(leader.getUniqueId());
        instance.invasion = tag;
        instances.put(slot, instance);
        for (Player player : team) {
            instance.members.add(player.getUniqueId());
            instance.lives.put(player.getUniqueId(), instance.lives());
            byPlayer.put(player.getUniqueId(), instance);
            returnTo.put(player.getUniqueId(), player.getLocation().clone());
            say(player, "dungeon.loading", Map.of("name", modeName(instance)));
        }
        startCopy(instance, template);
        return null;
    }

    private int freeSlot() {
        for (int i = 0; i < maxInstances; i++) {
            if (!instances.containsKey(i)) {
                return i;
            }
        }
        return -1;
    }

    // ---------------------------------------------------------------
    //  Копирование карты порциями (без лагов)
    // ---------------------------------------------------------------

    private void startCopy(Instance instance, World template) {
        DungeonDef def = instance.def;
        int minX = Math.min(def.pos1[0], def.pos2[0]);
        int minY = Math.min(def.pos1[1], def.pos2[1]);
        int minZ = Math.min(def.pos1[2], def.pos2[2]);
        int sx = Math.abs(def.pos1[0] - def.pos2[0]) + 1;
        int sy = Math.abs(def.pos1[1] - def.pos2[1]) + 1;
        int sz = Math.abs(def.pos1[2] - def.pos2[2]) + 1;
        long total = (long) sx * sy * sz;
        World world = instance.origin.getWorld();
        int ox = instance.origin.getBlockX();
        int oy = instance.origin.getBlockY();
        int oz = instance.origin.getBlockZ();
        instance.copyTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long end = Math.min(total, instance.copyIndex + copyPerTick);
            for (long i = instance.copyIndex; i < end; i++) {
                int x = (int) (i % sx);
                int z = (int) ((i / sx) % sz);
                int y = (int) (i / ((long) sx * sz));
                org.bukkit.block.Block source = template.getBlockAt(minX + x, minY + y, minZ + z);
                if (!source.getType().isAir()) {
                    world.getBlockAt(ox + x, oy + y, oz + z).setBlockData(source.getBlockData(), false);
                }
            }
            instance.copyIndex = end;
            if (end >= total) {
                instance.copyTask.cancel();
                onCopied(instance);
            }
        }, 1L, 1L);
    }

    private void onCopied(Instance instance) {
        if (instance.state != State.LOADING) {
            return;
        }
        instance.state = State.RUNNING;
        instance.checkpoint = instance.abs(instance.def.spawn);
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                player.teleport(instance.checkpoint);
                player.setFallDistance(0);
                if (instance.bar == null) {
                    instance.bar = BossBar.bossBar(Hud.legacy(instance.def.name), 1f,
                            BossBar.Color.PURPLE, BossBar.Overlay.PROGRESS);
                }
                say(player, "dungeon.started", Map.of("name", modeName(instance), "lives", instance.lives()));
            }
        }
    }

    // ---------------------------------------------------------------
    //  Ход подземелья
    // ---------------------------------------------------------------

    private void tick() {
        for (Instance instance : new ArrayList<>(instances.values())) {
            switch (instance.state) {
                case RUNNING -> tickRunning(instance);
                case COMPLETE, CLOSING -> {
                    if (System.currentTimeMillis() >= instance.closeAt) {
                        close(instance, true);
                    }
                }
                default -> {
                    // идёт копирование
                }
            }
        }
    }

    private List<Player> alive(Instance instance) {
        List<Player> result = new ArrayList<>();
        for (UUID id : instance.members) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline() && !player.isDead()
                    && player.getWorld().equals(instance.origin.getWorld())) {
                result.add(player);
            }
        }
        return result;
    }

    private void tickRunning(Instance instance) {
        DungeonDef def = instance.def;
        List<Player> players = alive(instance);
        if (instance.members.isEmpty()) {
            fail(instance, "dungeon.fail-empty");
            return;
        }
        if (instance.timeLimit() > 0
                && System.currentTimeMillis() - instance.created > instance.timeLimit() * 60_000L) {
            fail(instance, "dungeon.fail-time");
            return;
        }
        if (instance.room >= def.rooms.size()) {
            complete(instance);
            return;
        }
        DungeonDef.RoomDef room = def.rooms.get(instance.room);
        if (instance.wave == -1) {
            Location trigger = instance.abs(room.trigger());
            for (Player player : players) {
                if (player.getLocation().distanceSquared(trigger) <= room.radius() * room.radius()) {
                    startRoom(instance, room);
                    return;
                }
            }
            return;
        }
        // сколько живых мобов комнаты осталось
        instance.mobs.removeIf(id -> {
            Entity entity = Bukkit.getEntity(id);
            return entity == null || entity.isDead() || !entity.isValid();
        });
        if (room.isBoss()) {
            tickBoss(instance, room);
            return;
        }
        if (instance.mobs.isEmpty()) {
            if (instance.wave + 1 < room.waves().size()) {
                spawnWave(instance, room, instance.wave + 1);
            } else {
                clearRoom(instance, room);
            }
        }
    }

    private void startRoom(Instance instance, DungeonDef.RoomDef room) {
        for (DungeonDef.Region region : room.seal()) {
            fill(instance, region, region.material());
        }
        titleAll(instance, "&6" + room.name(), "&7Комната " + (instance.room + 1) + " из " + instance.def.rooms.size());
        if (room.isBoss()) {
            spawnBoss(instance, room);
            instance.wave = 0;
        } else if (!room.waves().isEmpty()) {
            spawnWave(instance, room, 0);
        } else {
            clearRoom(instance, room);
        }
    }

    private void spawnWave(Instance instance, DungeonDef.RoomDef room, int index) {
        DungeonDef.WaveDef wave = room.waves().get(index);
        instance.wave = index;
        sayAll(instance, "dungeon.wave", Map.of("n", index + 1, "total", room.waves().size()));
        if (wave.say() != null) {
            sayAll(instance, "dungeon.say", Map.of("text", wave.say()));
        }
        for (Map.Entry<EntityType, Integer> entry : wave.mobs().entrySet()) {
            for (int i = 0; i < entry.getValue(); i++) {
                spawnMob(instance, entry.getKey(), around(instance, wave.at(), wave.spread()), 0, 0, null);
            }
        }
    }

    private void spawnBoss(Instance instance, DungeonDef.RoomDef room) {
        DungeonDef.BossDef boss = room.boss();
        if (boss == null) {
            return;
        }
        LivingEntity entity = spawnMob(instance, boss.type(), instance.abs(boss.at()),
                boss.health(), boss.damage(), boss.name());
        if (entity != null) {
            instance.boss = entity.getUniqueId();
            instance.bossMax = entity.getAttribute(Attribute.MAX_HEALTH) != null
                    ? entity.getAttribute(Attribute.MAX_HEALTH).getValue() : entity.getHealth();
            instance.phasesDone.clear();
            if (instance.bar != null) {
                instance.bar.name(Hud.legacy(boss.name()));
                instance.bar.progress(1f);
                for (Player player : alive(instance)) {
                    player.showBossBar(instance.bar);
                }
            }
        }
    }

    private void tickBoss(Instance instance, DungeonDef.RoomDef room) {
        Entity entity = instance.boss == null ? null : Bukkit.getEntity(instance.boss);
        if (!(entity instanceof LivingEntity boss) || boss.isDead() || !boss.isValid()) {
            // босс убит
            for (Player player : alive(instance)) {
                if (instance.bar != null) {
                    player.hideBossBar(instance.bar);
                }
            }
            killMobs(instance);
            clearRoom(instance, room);
            return;
        }
        double ratio = Math.max(0, Math.min(1, boss.getHealth() / Math.max(1, instance.bossMax)));
        if (instance.bar != null) {
            instance.bar.progress((float) ratio);
        }
        tickEnrage(instance, boss);
        tickZones(instance, room, boss, ratio);
        tickCast(instance, room, boss, ratio);
        List<DungeonDef.PhaseDef> phases = room.boss().phases();
        for (int i = 0; i < phases.size(); i++) {
            DungeonDef.PhaseDef phase = phases.get(i);
            if (ratio <= phase.atHealth() && instance.phasesDone.add(i)) {
                if (phase.say() != null) {
                    titleAll(instance, "&c" + room.boss().name(), phase.say());
                    sayAll(instance, "dungeon.say", Map.of("text", phase.say()));
                }
                for (Map.Entry<EntityType, Integer> entry : phase.summon().entrySet()) {
                    for (int n = 0; n < entry.getValue(); n++) {
                        spawnMob(instance, entry.getKey(), boss.getLocation().clone().add(
                                random.nextDouble() * 6 - 3, 0, random.nextDouble() * 6 - 3), 0, 0, null);
                    }
                }
                applyEffect(boss, phase.effect());
            }
        }
    }

    /**
     * Ярость босса (раздел 26.2): не убили за enrage-minutes - урон и скорость растут.
     * Ключевая мысль: время становится ресурсом. Раньше любой бой можно было выиграть
     * «медленно и безопасно», поэтому риск ничего не значил.
     */
    private void tickEnrage(Instance instance, LivingEntity boss) {
        double limit = instance.def.rooms.get(instance.room).boss() == null ? 0
                : instance.def.rooms.get(instance.room).boss().enrageMinutes();
        if (limit <= 0) {
            return;
        }
        if (instance.bossStartedAt == 0) {
            instance.bossStartedAt = System.currentTimeMillis();
        }
        double elapsed = (System.currentTimeMillis() - instance.bossStartedAt) / 1000.0;
        if (!DungeonMechanics.enraged(elapsed, limit, instance.enrageStacks)) {
            return;
        }
        instance.enrageStacks++;
        AttributeInstance attack = boss.getAttribute(Attribute.ATTACK_DAMAGE);
        if (attack != null) {
            attack.setBaseValue(attack.getBaseValue() * 1.3);
        }
        boss.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 600, 0));
        titleAll(instance, "&4&lЯРОСТЬ", "&cБосс злится: урон +30% (" + instance.enrageStacks + ")");
        boss.getWorld().playSound(boss.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.7f);
    }

    /**
     * Зоны с телеграфом (раздел 26.1): босс подсвечивает область, через telegraph
     * секунд бьёт только внутри. Это первая механика, где нужно двигаться.
     */
    private void tickZones(Instance instance, DungeonDef.RoomDef room, LivingEntity boss, double ratio) {
        List<DungeonDef.ZoneDef> zones = room.boss().zones();
        if (zones.isEmpty()) {
            return;
        }
        List<Player> players = alive(instance);
        for (int i = 0; i < zones.size(); i++) {
            DungeonDef.ZoneDef zone = zones.get(i);
            if (ratio > zone.atHealth()) {
                continue;
            }
            if (instance.zonesDone.contains(i)) {
                if (zone.everySeconds() <= 0) {
                    continue;
                }
                // повторяющаяся зона: раз в every-seconds
                if (System.currentTimeMillis() - instance.lastCastAt < zone.everySeconds() * 1000) {
                    continue;
                }
                instance.lastCastAt = System.currentTimeMillis();
            }
            instance.zonesDone.add(i);
            double damage = zone.damage() * instance.mobDamage();
            mechanics.telegraph(boss, zone, players, player -> {
                player.damage(damage, boss);
                player.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR,
                        player.getLocation().add(0, 1, 0), 4, 0.3, 0.3, 0.3, 0);
            });
        }
    }

    /**
     * Касты босса (раздел 26.3): призывает свиту с полосой каста. Сбивается умениями
     * танка и бойца - впервые в игре появляется работа для роли «контроль».
     */
    private void tickCast(Instance instance, DungeonDef.RoomDef room, LivingEntity boss, double ratio) {
        // кастует только фаза с призывом: это и есть «опасное», что надо сбить
        List<DungeonDef.PhaseDef> phases = room.boss().phases();
        if (phases.isEmpty()) {
            return;
        }
        if (instance.cast != null && instance.cast.active()) {
            return;
        }
        if (System.currentTimeMillis() - instance.lastCastAt < 25_000L) {
            return;
        }
        for (DungeonDef.PhaseDef phase : phases) {
            if (ratio > phase.atHealth() || phase.summon().isEmpty()) {
                continue;
            }
            instance.lastCastAt = System.currentTimeMillis();
            Map<EntityType, Integer> summon = phase.summon();
            instance.cast = mechanics.cast(boss, "Призыв свиты", 3.0, () -> {
                for (Map.Entry<EntityType, Integer> entry : summon.entrySet()) {
                    for (int n = 0; n < Math.max(1, entry.getValue() / 2); n++) {
                        spawnMob(instance, entry.getKey(), boss.getLocation().clone().add(
                                random.nextDouble() * 6 - 3, 0, random.nextDouble() * 6 - 3), 0, 0, null);
                    }
                }
                sayAll(instance, "dungeon.cast-done", Map.of("name", boss.getName() == null
                        ? "Босс" : boss.getName()));
            });
            sayAll(instance, "dungeon.cast-start", Map.of("name", boss.getName() == null
                    ? "Босс" : boss.getName()));
            return;
        }
    }

    /**
     * Сбить каст босса: вызывается умениями танка (рывок, провокация) и бойца (выпад).
     * Возвращает true, если каст действительно был сбит.
     */
    public boolean interruptCast(Player player) {
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null || instance.cast == null || !instance.cast.active()) {
            return false;
        }
        if (!instance.cast.interrupt()) {
            return false;
        }
        sayAll(instance, "dungeon.cast-interrupted", Map.of("player", player.getName()));
        // сбитый каст считается в «Итоги подземелья» (раздел 26.4) и в славу
        instance.interrupts.merge(player.getUniqueId(), 1, Integer::sum);
        if (plugin.getGlory() != null) {
            plugin.getGlory().add(player, "INTERRUPTS", 1);
        }
        instance.cast = null;
        return true;
    }

    /** Рекорды подземелья для показа игроку: время и групповой урон по обоим режимам. */
    /**
     * Множитель лечения для игрока: произведение модификатора забега и проклятий.
     * Нужен тем, кто лечит через setHealth - событие EntityRegainHealthEvent они не поднимают.
     */
    public double healFactor(Player player) {
        Instance instance = byPlayer.get(player.getUniqueId());
        return instance == null || instance.state != State.RUNNING ? 1.0 : instance.playerHeal();
    }

    /** Игрок сейчас в забеге: сезон мира на него не действует. */
    public boolean inDungeon(Player player) {
        Instance instance = byPlayer.get(player.getUniqueId());
        return instance != null && instance.state == State.RUNNING;
    }

    /** Идентификаторы подземелий для автодополнения. */
    public java.util.Set<String> ids() {
        return defs.keySet();
    }

    public void printRecords(Player player, String dungeonId) {
        DungeonDef def = defs.get(dungeonId.toLowerCase(Locale.ROOT));
        if (def == null) {
            say(player, "dungeon.unknown", Map.of("id", dungeonId));
            return;
        }
        Path file = plugin.getDataFolder().toPath().resolve("records.yml");
        YamlConfiguration records = file.toFile().exists()
                ? YamlConfiguration.loadConfiguration(file.toFile())
                : new YamlConfiguration();
        say(player, "dungeon.records-header", Map.of("name", def.name));
        for (boolean heroic : new boolean[]{false, true}) {
            String mode = heroic ? "героический" : "обычный";
            long seconds = records.getLong(bestKey(def, heroic, "seconds"), 0);
            double dealt = records.getDouble(bestKey(def, heroic, "dealt"), 0);
            if (seconds <= 0 && dealt <= 0) {
                say(player, "dungeon.records-empty", Map.of("mode", mode));
                continue;
            }
            say(player, "dungeon.records-line", Map.of(
                    "mode", mode,
                    "time", seconds <= 0 ? "-" : String.format("%d:%02d", seconds / 60, seconds % 60),
                    "dealt", dealt <= 0 ? "-" : String.valueOf(Math.round(dealt))));
        }
    }

    private String bestKey(DungeonDef def, boolean heroic, String what) {
        return "dungeon_best_" + def.id + (heroic ? "_heroic" : "") + "_" + what;
    }

    /**
     * Сохраняем рекорд забега в файл и сообщаем, если он побит.
     * Рекорд держится на паре (время, урон группы) - так «быстрее» и «сильнее»
     * не спорят между собой: время главное, урон отыгрывает разницу.
     */
    private void recordBest(Instance instance) {
        if (instance.admin) {
            return;
        }
        long seconds = Math.max(1, (System.currentTimeMillis() - instance.created) / 1000);
        double dealtTotal = instance.dealt.values().stream().mapToDouble(Double::doubleValue).sum();
        Path file = plugin.getDataFolder().toPath().resolve("records.yml");
        YamlConfiguration records;
        try {
            records = file.toFile().exists()
                    ? YamlConfiguration.loadConfiguration(file.toFile())
                    : new YamlConfiguration();
        } catch (RuntimeException exception) {
            return;
        }
        boolean betterTime = !records.contains(bestKey(instance.def, instance.heroic, "seconds"))
                || seconds < records.getLong(bestKey(instance.def, instance.heroic, "seconds"));
        boolean betterDealt = !records.contains(bestKey(instance.def, instance.heroic, "dealt"))
                || dealtTotal > records.getDouble(bestKey(instance.def, instance.heroic, "dealt"));
        if (betterTime) {
            sayAll(instance, "dungeon.record-time", Map.of(
                    "name", instance.def.name,
                    "time", String.format("%d:%02d", seconds / 60, seconds % 60),
                    "mode", modeName(instance),
                    "old", records.contains(bestKey(instance.def, instance.heroic, "seconds"))
                            ? String.format("%d:%02d",
                            records.getLong(bestKey(instance.def, instance.heroic, "seconds")) / 60,
                            records.getLong(bestKey(instance.def, instance.heroic, "seconds")) % 60)
                            : "-"));
            records.set(bestKey(instance.def, instance.heroic, "seconds"), seconds);
        }
        if (betterDealt) {
            sayAll(instance, "dungeon.record-dealt", Map.of(
                    "dealt", String.valueOf(Math.round(dealtTotal)),
                    "old", records.contains(bestKey(instance.def, instance.heroic, "dealt"))
                            ? String.valueOf(Math.round(records.getDouble(bestKey(instance.def, instance.heroic, "dealt"))))
                            : "-"));
            records.set(bestKey(instance.def, instance.heroic, "dealt"), dealtTotal);
        }
        if (betterTime || betterDealt) {
            try {
                records.save(file.toFile());
            } catch (java.io.IOException exception) {
                plugin.getLogger().warning("Не сохранились рекорды подземелий: " + exception.getMessage());
            }
        }
    }

    /**
     * Итоги подземелья (раздел 26.4): кто сколько внёс. Наград за это нет -
     * работает признание: люди начинают соревноваться внутри группы и возвращаться,
     * чтобы улучшить свой результат. Это дешевле нового подземелья и работает сильнее.
     */
    private void summary(Instance instance) {
        if (instance.members.isEmpty()) {
            return;
        }
        List<UUID> order = new ArrayList<>(instance.members);
        order.sort((left, right) -> Double.compare(
                instance.dealt.getOrDefault(right, 0.0), instance.dealt.getOrDefault(left, 0.0)));
        long seconds = Math.max(1, (System.currentTimeMillis() - instance.created) / 1000);
        sayAll(instance, "dungeon.summary-header", Map.of(
                "name", instance.def.name,
                "time", String.format("%d:%02d", seconds / 60, seconds % 60),
                "mode", modeName(instance) + (instance.modifier == null ? ""
                        : " · " + instance.modifier.name())));
        int place = 1;
        for (UUID id : order) {
            Player player = Bukkit.getPlayer(id);
            String name = player == null ? "?" : player.getName();
            double dealt = instance.dealt.getOrDefault(id, 0.0);
            double taken = instance.taken.getOrDefault(id, 0.0);
            double healed = instance.healed.getOrDefault(id, 0.0);
            int deaths = instance.deaths.getOrDefault(id, 0);
            int interrupts = instance.interrupts.getOrDefault(id, 0);
            sayAll(instance, "dungeon.summary-line", Map.of(
                    "place", String.valueOf(place++),
                    "player", name,
                    "dealt", String.valueOf(Math.round(dealt)),
                    "taken", String.valueOf(Math.round(taken)),
                    "healed", String.valueOf(Math.round(healed)),
                    "deaths", String.valueOf(deaths),
                    "interrupts", String.valueOf(interrupts)));
        }
        // «лучший» в каждой роли: признание без награды
        UUID topDealt = best(instance.dealt);
        UUID topHealed = best(instance.healed);
        UUID topTaken = best(instance.taken);
        if (topDealt != null) {
            Player player = Bukkit.getPlayer(topDealt);
            if (player != null) {
                sayAll(instance, "dungeon.summary-best", Map.of(
                        "player", player.getName(), "what", "урон"));
            }
        }
        if (topHealed != null && instance.healed.getOrDefault(topHealed, 0.0) > 0) {
            Player player = Bukkit.getPlayer(topHealed);
            if (player != null) {
                sayAll(instance, "dungeon.summary-best", Map.of(
                        "player", player.getName(), "what", "лечение"));
            }
        }
        if (topTaken != null) {
            Player player = Bukkit.getPlayer(topTaken);
            if (player != null) {
                sayAll(instance, "dungeon.summary-best", Map.of(
                        "player", player.getName(), "what", "принятый урон"));
            }
        }
    }

    private UUID best(Map<UUID, Double> map) {
        return map.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey).orElse(null);
    }

    /** Сколько дополнительных рулонов добычи даёт модификатор (считается в выдаче). */
    public int modifierLootBonus(String modifierId) {
        DungeonDef.ModifierDef modifier = modifiers.get(modifierId == null ? "" : modifierId.toLowerCase(Locale.ROOT));
        return modifier == null ? 0 : modifier.lootBonus();
    }

    public DungeonDef.ModifierDef modifier(String id) {
        return id == null ? null : modifiers.get(id.toLowerCase(Locale.ROOT));
    }

    public Map<String, DungeonDef.ModifierDef> modifiers() {
        return modifiers;
    }

    private void applyEffect(LivingEntity target, String spec) {
        if (spec == null) {
            return;
        }
        String[] parts = spec.split(":");
        PotionEffectType type = org.bukkit.Registry.EFFECT.get(org.bukkit.NamespacedKey.minecraft(parts[0].toLowerCase(Locale.ROOT)));
        if (type == null) {
            return;
        }
        int seconds = parts.length > 1 ? Integer.parseInt(parts[1]) : 10;
        int amp = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
        target.addPotionEffect(new PotionEffect(type, seconds * 20, amp));
    }

    private void clearRoom(Instance instance, DungeonDef.RoomDef room) {
        for (DungeonDef.Region region : room.seal()) {
            fill(instance, region, Material.AIR);
        }
        for (DungeonDef.Region region : room.unlock()) {
            fill(instance, region, Material.AIR);
        }
        instance.checkpoint = instance.abs(room.trigger());
        instance.room++;
        instance.wave = -1;
        instance.mobs.clear();
        sayAll(instance, "dungeon.room-clear", Map.of("room", room.name()));
        if (instance.room >= instance.def.rooms.size()) {
            complete(instance);
        }
    }

    private Location around(Instance instance, double[] rel, double spread) {
        Location base = instance.abs(rel);
        return base.add((random.nextDouble() * 2 - 1) * spread, 0, (random.nextDouble() * 2 - 1) * spread);
    }

    private LivingEntity spawnMob(Instance instance, EntityType type, Location where,
                                  double health, double damage, String name) {
        World world = where.getWorld();
        Entity entity = world.spawnEntity(where, type);
        if (!(entity instanceof LivingEntity living)) {
            entity.remove();
            return null;
        }
        int extra = Math.max(0, instance.members.size() - 1);
        double healthScale = instance.mobHealth() * (1 + healthPerExtra * extra);
        double damageScale = instance.mobDamage() * (1 + damagePerExtra * extra);
        AttributeInstance hp = living.getAttribute(Attribute.MAX_HEALTH);
        if (hp != null) {
            double base = health > 0 ? health : hp.getBaseValue();
            hp.setBaseValue(Math.max(1, base * healthScale));
            living.setHealth(Math.max(1, base * healthScale));
        }
        AttributeInstance dmg = living.getAttribute(Attribute.ATTACK_DAMAGE);
        if (dmg != null) {
            double base = damage > 0 ? damage : dmg.getBaseValue();
            dmg.setBaseValue(base * damageScale);
        }
        if (name != null) {
            living.customName(Hud.legacy(name));
            living.setCustomNameVisible(true);
        }
        living.setRemoveWhenFarAway(false);
        living.setPersistent(true);
        living.getPersistentDataContainer().set(mobKey, PersistentDataType.INTEGER, instance.slot);
        instance.mobs.add(living.getUniqueId());
        if (living instanceof Mob mob) {
            Player nearest = null;
            double best = Double.MAX_VALUE;
            for (Player player : alive(instance)) {
                double dist = player.getLocation().distanceSquared(where);
                if (dist < best) {
                    best = dist;
                    nearest = player;
                }
            }
            if (nearest != null) {
                mob.setTarget(nearest);
            }
        }
        return living;
    }

    private void killMobs(Instance instance) {
        for (UUID id : new ArrayList<>(instance.mobs)) {
            Entity entity = Bukkit.getEntity(id);
            if (entity != null) {
                entity.remove();
            }
        }
        instance.mobs.clear();
    }

    private void fill(Instance instance, DungeonDef.Region region, Material material) {
        World world = instance.origin.getWorld();
        int ox = instance.origin.getBlockX();
        int oy = instance.origin.getBlockY();
        int oz = instance.origin.getBlockZ();
        int x1 = Math.min(region.from()[0], region.to()[0]);
        int x2 = Math.max(region.from()[0], region.to()[0]);
        int y1 = Math.min(region.from()[1], region.to()[1]);
        int y2 = Math.max(region.from()[1], region.to()[1]);
        int z1 = Math.min(region.from()[2], region.to()[2]);
        int z2 = Math.max(region.from()[2], region.to()[2]);
        for (int x = x1; x <= x2; x++) {
            for (int y = y1; y <= y2; y++) {
                for (int z = z1; z <= z2; z++) {
                    world.getBlockAt(ox + x, oy + y, oz + z).setType(material, false);
                }
            }
        }
    }

    // ---------------------------------------------------------------
    //  Завершение, награда, закрытие
    // ---------------------------------------------------------------

    private void complete(Instance instance) {
        if (instance.state != State.RUNNING) {
            return;
        }
        instance.state = State.COMPLETE;
        instance.closeAt = System.currentTimeMillis() + closeDelaySeconds * 1000L;
        killMobs(instance);
        titleAll(instance, "&a&lПобеда!", "&7" + modeName(instance));
        summary(instance);
        recordBest(instance);
        sayAll(instance, "dungeon.complete", Map.of("seconds", closeDelaySeconds));
        List<Player> winners = alive(instance);
        for (Player player : winners) {
            if (instance.bar != null) {
                player.hideBossBar(instance.bar);
            }
            if (!instance.admin) {
                if (!instance.heroic && instance.invasion == null) {
                    player.getPersistentDataContainer().set(clearKey(instance.def), PersistentDataType.BYTE, (byte) 1);
                }
                if (instance.invasion == null) {
                    setLock(player, instance.def, instance.heroic);
                }
                if (plugin.getCovenants() != null) {
                    plugin.getCovenants().getWeekly().dungeonCleared(player, instance.heroic, instance.def.raid);
                }
                if (plugin.getPets() != null) {
                    plugin.getPets().onDungeon(player);
                }
                if (plugin.getContracts() != null) {
                    plugin.getContracts().progress(player, "DUNGEON", instance.def.raid ? "RAID" : instance.heroic ? "HEROIC" : "NORMAL", 1);
                }
                if (plugin.getGlory() != null) {
                    plugin.getGlory().add(player, instance.def.raid ? "RAIDS" : instance.heroic ? "HEROICS" : "DUNGEONS", 1);
                }
            }
            givePersonalRewards(player, instance);
            if (probing(player)) {
                finishProbe(player, false);
            }
        }
        giveGroupLoot(winners, instance);
        if (instance.invasion != null && plugin.getInvasions() != null) {
            plugin.getInvasions().cleared(instance.invasion, alive(instance));
        }
    }

    private void givePersonalRewards(Player player, Instance instance) {
        DungeonDef def = instance.def;
        int points = instance.heroic ? def.heroic.points() : def.points;
        long coins = instance.heroic ? def.heroic.coins() : def.coins;
        if (instance.modifier != null) {
            // модификатор меняет и награду: риск без компенсации никто не возьмёт
            coins = Math.round(coins * instance.modifier.coinsFactor());
            points = (int) Math.round(points * Math.max(0.8, instance.modifier.coinsFactor()));
        }
        // сезон мира (раздел 29): действует и в подземельях - это общий фон недели
        if (plugin.getSeasonal() != null) {
            coins = Math.round(coins * plugin.getSeasonal().coinsFactor());
        }
        if (coins > 0 && plugin.getEconomy() != null) {
            plugin.getEconomy().reward(player, coins, "economy.reward-dungeon");
        }
        if (points > 0) {
            plugin.getQuests().adminAddPoints(player, points);
            say(player, "dungeon.points", Map.of("points", points));
        }
    }

    /** Создаёт один общий набор предметов и запускает Need/Greed для всех участников. */
    private void giveGroupLoot(List<Player> players, Instance instance) {
        if (players.isEmpty()) {
            return;
        }
        DungeonDef def = instance.def;
        List<DungeonDef.Loot> lootList = instance.heroic ? def.heroic.loot() : def.loot;
        List<LootDrop> drops = new ArrayList<>();
        List<DungeonDef.Loot> rarityPool = lootList.stream()
                .filter(loot -> loot.rarity() != null && !loot.rarity().isBlank() && loot.weight() > 0)
                .toList();

        // Старый chance-формат оставляем рабочим для совместимости.
        for (DungeonDef.Loot loot : lootList) {
            if (loot.rarity() != null && !loot.rarity().isBlank()) {
                continue;
            }
            if (random.nextDouble() >= loot.chance()) {
                continue;
            }
            ItemStack stack = createLootItem(loot, def);
            if (stack != null) {
                Rank itemRank = loot.requiredRank() == null ? def.lootRank : loot.requiredRank();
                LootDrop drop = new LootDrop(stack, loot.classes(), itemRank);
                if (players.stream().anyMatch(player -> canParticipate(player.getUniqueId(), drop))) {
                    drops.add(drop);
                }
            }
        }

        String mode = lootMode(instance);
        int slots = Math.max(0, lootConfig.getInt("modes." + mode + ".slots", def.raid ? 3 : 2));
        double extraChance = Math.max(0, Math.min(1,
                lootConfig.getDouble("modes." + mode + ".extra-slot-chance", 0)));
        if (random.nextDouble() < extraChance) {
            slots++;
        }
        slots += instance.extraRolls();
        for (int i = 0; i < slots && !rarityPool.isEmpty(); i++) {
            String rarity = rollRarity(mode, def.lootRank);
            DungeonDef.Loot entry = chooseLootEntry(rarityPool, rarity);
            if (entry == null) {
                continue;
            }
            ItemStack stack = createLootItem(entry, def);
            if (stack != null) {
                Rank itemRank = entry.requiredRank() == null ? def.lootRank : entry.requiredRank();
                LootDrop drop = new LootDrop(stack, entry.classes(), itemRank);
                if (players.stream().anyMatch(player -> canParticipate(player.getUniqueId(), drop))) {
                    drops.add(drop);
                }
            }
        }
        if (drops.isEmpty()) {
            for (Player player : players) {
                say(player, "dungeon.reward-empty", Map.of());
            }
            return;
        }
        Set<UUID> members = new HashSet<>();
        for (Player player : players) {
            members.add(player.getUniqueId());
        }
        LootSession session = new LootSession(members, drops, modeName(instance));
        for (Player player : players) {
            lootByPlayer.put(player.getUniqueId(), session);
            say(player, "dungeon.reward-ready", Map.of());
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline() && lootByPlayer.get(player.getUniqueId()) == session) {
                    openLootMenu(player, session);
                }
            }, 60L);
        }
    }

    private String lootMode(Instance instance) {
        if (instance.def.raid) {
            return instance.heroic ? "raid-heroic" : "raid";
        }
        return instance.heroic ? "heroic" : "normal";
    }

    private String rollRarity(String mode, Rank rank) {
        String path = "modes." + mode + ".ranks." + rank.getDisplayName();
        ConfigurationSection section = lootConfig.getConfigurationSection(path);
        if (section == null && mode.equals("raid-heroic")) {
            section = lootConfig.getConfigurationSection("modes.raid.ranks." + rank.getDisplayName());
        }
        if (section == null) {
            return "COMMON";
        }
        double total = 0;
        for (String key : section.getKeys(false)) {
            total += Math.max(0, section.getDouble(key));
        }
        if (total <= 0) {
            return "COMMON";
        }
        double roll = random.nextDouble() * total;
        for (String key : section.getKeys(false)) {
            roll -= Math.max(0, section.getDouble(key));
            if (roll < 0) {
                return key.toUpperCase(Locale.ROOT);
            }
        }
        return "COMMON";
    }

    private DungeonDef.Loot chooseLootEntry(List<DungeonDef.Loot> pool, String rarity) {
        List<String> tiers = List.of("COMMON", "UNCOMMON", "RARE", "EPIC", "LEGENDARY");
        int start = tiers.indexOf(rarity.toUpperCase(Locale.ROOT));
        if (start < 0) {
            start = 0;
        }
        for (int tier = start; tier >= 0; tier--) {
            String wanted = tiers.get(tier);
            List<DungeonDef.Loot> matching = pool.stream()
                    .filter(loot -> wanted.equalsIgnoreCase(loot.rarity()))
                    .toList();
            DungeonDef.Loot selected = weightedLoot(matching);
            if (selected != null) {
                return selected;
            }
        }
        return weightedLoot(pool);
    }

    private DungeonDef.Loot weightedLoot(List<DungeonDef.Loot> pool) {
        double total = pool.stream().mapToDouble(DungeonDef.Loot::weight).sum();
        if (pool.isEmpty() || total <= 0) {
            return null;
        }
        double roll = random.nextDouble() * total;
        for (DungeonDef.Loot loot : pool) {
            roll -= loot.weight();
            if (roll < 0) {
                return loot;
            }
        }
        return pool.get(pool.size() - 1);
    }

    private ItemStack createLootItem(DungeonDef.Loot loot, DungeonDef def) {
        ItemStack stack = null;
        GemManager gems = plugin.getGems();
        if (loot.gem() != null && gems != null && gems.type(loot.gem()) != null) {
            stack = gems.createGem(gems.type(loot.gem()), Math.max(1, loot.level()), false);
        } else if (loot.rune() != null && plugin.getRunes() != null) {
            stack = plugin.getRunes().create(loot.rune(), Math.max(1, loot.level()));
        } else if (loot.item() != null) {
            Material material = Material.matchMaterial(loot.item());
            if (material != null) {
                int amount = loot.min() + random.nextInt(loot.max() - loot.min() + 1);
                stack = new ItemStack(material, amount);
            }
        }
        if (stack != null) {
            decorateCustomLoot(stack, loot, def);
            // Проклятие накладывается последним, чтобы имя и лор предмета уже были на месте
            if (plugin.getCurses() != null) {
                Rank rank = loot.requiredRank() == null ? def.lootRank : loot.requiredRank();
                plugin.getCurses().curseIfLucky(stack, rank);
            }
        }
        return stack;
    }

    private void decorateCustomLoot(ItemStack stack, DungeonDef.Loot loot, DungeonDef def) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return;
        }
        if (loot.name() != null) {
            meta.displayName(Hud.legacy(loot.name()));
        }
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        for (String line : loot.lore()) {
            lore.add(Hud.legacy(line));
        }
        if (loot.rarity() != null && !loot.rarity().isBlank()) {
            lore.add(Hud.legacy("&8Редкость: " + rarityColor(loot.rarity()) + loot.rarity()));
            meta.getPersistentDataContainer().set(customLootRarityKey, PersistentDataType.STRING,
                    loot.rarity().toUpperCase(Locale.ROOT));
        }
        if (!lore.isEmpty()) {
            meta.lore(lore);
        }
        if (!loot.classes().isEmpty()) {
            String classes = loot.classes().stream()
                    .map(ru.adventurers.core.classes.PlayerClass::getId)
                    .sorted()
                    .collect(java.util.stream.Collectors.joining(","));
            meta.getPersistentDataContainer().set(customLootClassesKey, PersistentDataType.STRING, classes);
        }
        for (Map.Entry<String, Integer> entry : loot.enchants().entrySet()) {
            Enchantment enchantment = Registry.ENCHANTMENT.get(
                    NamespacedKey.minecraft(entry.getKey().toLowerCase(Locale.ROOT)));
            if (enchantment == null) {
                plugin.getLogger().warning("Подземелье " + def.id + ": неизвестное зачарование " + entry.getKey());
                continue;
            }
            meta.addEnchant(enchantment, Math.max(1, entry.getValue()), true);
        }
        if (loot.customId() != null && !loot.customId().isBlank()) {
            meta.getPersistentDataContainer().set(customLootIdKey, PersistentDataType.STRING, loot.customId());
            Rank required = loot.requiredRank() == null ? def.lootRank : loot.requiredRank();
            meta.getPersistentDataContainer().set(customLootRankKey, PersistentDataType.STRING, required.name());
            // Именная награда подземелья по умолчанию выглядит как экипировка пака этого
            // ранга (armor_<ранг>_*, weapon_*_<ранг>, shield_<ранг>), а не как ванильный
            // предмет. Если у строки дропа задана своя model - ставим её: именно так
            // босс-дропы получают уникальный арт (раздел 30 отчёта).
            if (loot.model() != null && !loot.model().isBlank()) {
                meta.setItemModel(NamespacedKey.fromString("adventurers:" + loot.model()));
            } else {
                PackItems.gear(meta, stack.getType(), required);
            }
        }
        stack.setItemMeta(meta);
    }

    private String rarityColor(String rarity) {
        return switch (rarity.toLowerCase(Locale.ROOT)) {
            case "common", "обычный" -> "&7";
            case "uncommon", "необычный" -> "&a";
            case "rare", "редкий" -> "&9";
            case "epic", "эпический" -> "&5";
            case "legendary", "легендарный" -> "&6";
            default -> "&f";
        };
    }

    public void openReward(Player player) {
        LootSession session = lootByPlayer.get(player.getUniqueId());
        if (session == null || session.closed || session.complete()) {
            lootByPlayer.remove(player.getUniqueId());
            say(player, "dungeon.no-reward", Map.of());
            return;
        }
        if (!session.members.contains(player.getUniqueId())) {
            say(player, "dungeon.no-reward", Map.of());
            return;
        }
        openLootMenu(player, session);
    }

    private void openLootMenu(Player player, LootSession session) {
        int count = Math.min(54, session.drops.size());
        int size = Math.max(9, Math.min(54, ((count + 8) / 9) * 9));
        Inventory inventory = Bukkit.createInventory(null, size,
                Hud.legacy("&6Общий лут: &f" + session.dungeonName));
        for (int i = 0; i < count; i++) {
            LootDrop drop = session.drops.get(i);
            if (drop.resolved) {
                continue;
            }
            ItemStack display = drop.item.clone();
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
                lore.add(Component.empty());
                if (canParticipate(player.getUniqueId(), drop)) {
                    lore.add(Hud.legacy("&eНажмите, чтобы выбрать Need / Greed / Pass"));
                } else {
                    lore.add(Hud.legacy("&cНедоступно: не подходит ваш класс или ранг."));
                }
                meta.lore(lore);
                display.setItemMeta(meta);
            }
            inventory.setItem(i, display);
        }
        lootMenus.put(inventory, session);
        player.openInventory(inventory);
    }

    @EventHandler
    public void onLootClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        LootChoiceView choiceView = lootChoiceMenus.get(event.getInventory());
        if (choiceView != null) {
            event.setCancelled(true);
            if (event.getClickedInventory() != event.getInventory()) {
                return;
            }
            LootChoice choice = switch (event.getSlot()) {
                case 2 -> LootChoice.NEED;
                case 4 -> LootChoice.GREED;
                case 6 -> LootChoice.PASS;
                default -> null;
            };
            if (choice != null) {
                lootChoiceMenus.remove(event.getInventory());
                event.getWhoClicked().closeInventory();
                submitLootChoice(choiceView, choice);
            }
            return;
        }
        LootSession session = lootMenus.get(event.getInventory());
        if (session == null) {
            return;
        }
        event.setCancelled(true);
        if (session.closed || session.complete()) {
            player.closeInventory();
            lootByPlayer.remove(player.getUniqueId(), session);
            say(player, "dungeon.no-reward", Map.of());
            return;
        }
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        if (slot < 0 || slot >= session.drops.size() || !session.members.contains(player.getUniqueId())) {
            return;
        }
        LootDrop drop = session.drops.get(slot);
        if (drop.resolved) {
            openLootMenu(player, session);
            return;
        }
        if (!canParticipate(player.getUniqueId(), drop)) {
            player.sendMessage(Hud.legacy("&cЭтот предмет недоступен вашему классу или рангу."));
            return;
        }
        if (drop.choices.containsKey(player.getUniqueId())) {
            player.sendMessage(Hud.legacy("&7Вы уже выбрали вариант для этого предмета."));
            return;
        }
        openLootChoice(player, session, drop);
    }

    private void openLootChoice(Player player, LootSession session, LootDrop drop) {
        Inventory inventory = Bukkit.createInventory(null, 9, Hud.legacy("&eРозыгрыш предмета"));
        boolean canNeed = canNeed(player.getUniqueId(), drop);
        inventory.setItem(2, lootButton(canNeed ? Material.LIME_DYE : Material.GRAY_DYE,
                canNeed ? "&aNeed — Необходимость" : "&8Need недоступен",
                canNeed ? "&7Приоритетный бросок за предмет." : "&7Этот предмет не подходит вашим классам."));
        inventory.setItem(4, lootButton(Material.YELLOW_DYE, "&eGreed — Жадность", "&7Бросок после всех заявок Need."));
        inventory.setItem(6, lootButton(Material.RED_DYE, "&cPass — Пропустить", "&7Не участвовать в розыгрыше."));
        lootChoiceMenus.put(inventory, new LootChoiceView(session, drop, player.getUniqueId()));
        player.openInventory(inventory);
    }

    private ItemStack lootButton(Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Hud.legacy(name));
            meta.lore(List.of(Hud.legacy(lore)));
            item.setItemMeta(meta);
        }
        return item;
    }

    private boolean canParticipate(UUID playerId, LootDrop drop) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(playerId);
        Rank playerRank = profile == null ? Rank.F : profile.getRank();
        if (!playerRank.isAtLeast(drop.requiredRank)) {
            return false;
        }
        if (drop.allowedClasses.isEmpty()) {
            return true;
        }
        ru.adventurers.core.classes.PlayerClass active = plugin.getClasses().activeClass(playerId);
        return active != null && (active == ru.adventurers.core.classes.PlayerClass.UNIVERSAL
                || drop.allowedClasses.contains(active));
    }

    private boolean canNeed(UUID playerId, LootDrop drop) {
        return canParticipate(playerId, drop);
    }

    private void submitLootChoice(LootChoiceView view, LootChoice choice) {
        LootSession session = view.session();
        LootDrop drop = view.drop();
        if (session.closed || drop.resolved || !session.members.contains(view.playerId())
                || drop.choices.containsKey(view.playerId())) {
            return;
        }
        if (!canParticipate(view.playerId(), drop)) {
            Player player = Bukkit.getPlayer(view.playerId());
            if (player != null) {
                player.sendMessage(Hud.legacy("&cЭтот предмет недоступен вашему классу или рангу."));
            }
            return;
        }
        drop.choices.put(view.playerId(), choice);
        if (drop.choices.size() == 1) {
            scheduleLootTimeout(session, drop);
        }
        Player voter = Bukkit.getPlayer(view.playerId());
        if (voter != null) {
            voter.sendMessage(Hud.legacy("&7Вы выбрали: " + switch (choice) {
                case NEED -> "&aNeed";
                case GREED -> "&eGreed";
                case PASS -> "&cPass";
            }));
        }
        if (drop.choices.size() >= session.members.size()) {
            resolveLootDrop(session, drop);
        }
    }

    private void scheduleLootTimeout(LootSession session, LootDrop drop) {
        int generation = ++drop.rollGeneration;
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!session.closed && !drop.resolved && drop.rollGeneration == generation) {
                resolveLootDrop(session, drop);
            }
        }, groupLootRollSeconds * 20L);
    }

    private void resolveLootDrop(LootSession session, LootDrop drop) {
        if (session.closed || drop.resolved) {
            return;
        }
        List<UUID> candidates = new ArrayList<>();
        for (Map.Entry<UUID, LootChoice> entry : drop.choices.entrySet()) {
            if (entry.getValue() == LootChoice.NEED && Bukkit.getPlayer(entry.getKey()) != null
                    && canParticipate(entry.getKey(), drop)) {
                candidates.add(entry.getKey());
            }
        }
        if (candidates.isEmpty()) {
            for (Map.Entry<UUID, LootChoice> entry : drop.choices.entrySet()) {
                if (entry.getValue() == LootChoice.GREED && Bukkit.getPlayer(entry.getKey()) != null
                        && canParticipate(entry.getKey(), drop)) {
                    candidates.add(entry.getKey());
                }
            }
        }
        if (candidates.isEmpty()) {
            if (drop.choices.isEmpty()) {
                return; // никто ещё не начал розыгрыш — предмет остаётся в общем сундуке
            }
            drop.resolved = true; // все Pass либо все заявки стали невалидны по классу/рангу
            notifyLootMembers(session, "&7Предмет &f" + drop.item.getType().name()
                    + " &7никому не нужен или недоступен и удалён из сундука.");
            finishLootIfComplete(session);
            return;
        }
        drop.resolved = true;
        Map<UUID, Integer> rolls = new HashMap<>();
        int highest = 0;
        for (UUID candidate : candidates) {
            int roll = random.nextInt(100) + 1;
            rolls.put(candidate, roll);
            highest = Math.max(highest, roll);
        }
        List<UUID> tied = new ArrayList<>();
        for (Map.Entry<UUID, Integer> entry : rolls.entrySet()) {
            if (entry.getValue() == highest) {
                tied.add(entry.getKey());
            }
        }
        UUID winnerId = tied.get(random.nextInt(tied.size()));
        Player winner = Bukkit.getPlayer(winnerId);
        String rollSummary = rolls.entrySet().stream()
                .map(entry -> {
                    Player player = Bukkit.getPlayer(entry.getKey());
                    String choice = drop.choices.get(entry.getKey()) == LootChoice.NEED ? "Need" : "Greed";
                    return (player == null ? "Игрок" : player.getName()) + " [" + choice + "]: " + entry.getValue();
                })
                .collect(java.util.stream.Collectors.joining(", "));
        notifyLootMembers(session, "&7Броски за &f" + drop.item.getType().name() + "&7: &f" + rollSummary);
        if (winner == null) {
            finishLootIfComplete(session);
            return;
        }
        ItemStack awarded = drop.item.clone();
        applyGenderModel(awarded, winner);
        bindLootTo(awarded, winner);
        Map<Integer, ItemStack> leftovers = winner.getInventory().addItem(awarded);
        for (ItemStack leftover : leftovers.values()) {
            winner.getWorld().dropItemNaturally(winner.getLocation(), leftover);
        }
        notifyLootMembers(session, "&e" + winner.getName() + " &7выиграл предмет &f" + drop.item.getType().name()
                + " &7с броском &f" + rolls.get(winnerId));
        finishLootIfComplete(session);
    }

    /**
     * Добыча выдаётся одному игроку, поэтому её модель подгоняется под его пол:
     * женскому персонажу - armor_female_*, мужскому и «пол не выбран» - обычная модель ранга.
     * Характеристики предмета (зачарования, редкость, привязка) не меняются.
     */
    private void applyGenderModel(ItemStack item, Player owner) {
        if (item == null || owner == null) {
            return;
        }
        ru.adventurers.core.profile.PlayerProfile profile =
                plugin.getProfileManager().getProfile(owner.getUniqueId());
        if (profile == null || !profile.getGender().isChosen()) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !(item.getType().name().endsWith("_HELMET")
                || item.getType().name().endsWith("_CHESTPLATE")
                || item.getType().name().endsWith("_LEGGINGS")
                || item.getType().name().endsWith("_BOOTS"))) {
            return;
        }
        // Ранг модели: у именной добычи он записан в предмет при создании, иначе - ранг подземелья.
        String stored = meta.getPersistentDataContainer().get(customLootRankKey, PersistentDataType.STRING);
        Rank rank = stored == null ? null : Rank.fromInput(stored);
        PackItems.gear(meta, item.getType(), rank == null ? Rank.F : rank,
                plugin.getClasses().activeClass(owner.getUniqueId()), profile.getGender());
        item.setItemMeta(meta);
    }

    private void bindLootTo(ItemStack item, Player owner) {
        if (item == null) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        meta.getPersistentDataContainer().set(dungeonLootOwnerKey, PersistentDataType.STRING,
                owner.getUniqueId().toString());
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Hud.legacy("&8Привязано к: &f" + owner.getName()));
        meta.lore(lore);
        item.setItemMeta(meta);
    }

    private String boundOwner(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer()
                .get(dungeonLootOwnerKey, PersistentDataType.STRING);
    }

    private boolean isDungeonBound(ItemStack item) {
        return boundOwner(item) != null;
    }

    private boolean belongsTo(ItemStack item, UUID playerId) {
        String owner = boundOwner(item);
        return owner != null && owner.equals(playerId.toString());
    }

    private void notifyLootMembers(LootSession session, String message) {
        for (UUID member : session.members) {
            Player player = Bukkit.getPlayer(member);
            if (player != null && player.isOnline()) {
                player.sendMessage(Hud.legacy(message));
            }
        }
    }

    private void finishLootIfComplete(LootSession session) {
        if (!session.complete()) {
            return;
        }
        session.closed = true;
        for (UUID member : session.members) {
            lootByPlayer.remove(member, session);
        }
    }

    @EventHandler
    public void onLootInventoryClose(InventoryCloseEvent event) {
        lootMenus.remove(event.getInventory());
        lootChoiceMenus.remove(event.getInventory());
    }

    /** Предмет, выигранный в розыгрыше, привязан к UUID победителя. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBoundItemDrop(PlayerDropItemEvent event) {
        if (isDungeonBound(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Hud.legacy("&cЭтот предмет привязан к вам и его нельзя выбросить."));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBoundItemPickup(EntityPickupItemEvent event) {
        if (!isDungeonBound(event.getItem().getItemStack())) {
            return;
        }
        if (!(event.getEntity() instanceof Player player)
                || !belongsTo(event.getItem().getItemStack(), player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBoundItemInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        ItemStack hotbar = event.getHotbarButton() >= 0
                ? player.getInventory().getItem(event.getHotbarButton()) : null;
        UUID playerId = player.getUniqueId();
        if ((isDungeonBound(current) && !belongsTo(current, playerId))
                || (isDungeonBound(cursor) && !belongsTo(cursor, playerId))
                || (isDungeonBound(hotbar) && !belongsTo(hotbar, playerId))) {
            event.setCancelled(true);
            player.sendMessage(Hud.legacy("&cЭтот предмет привязан к другому игроку."));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBoundItemInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        ItemStack cursor = event.getOldCursor();
        if (isDungeonBound(cursor) && !belongsTo(cursor, player.getUniqueId())) {
            event.setCancelled(true);
            player.sendMessage(Hud.legacy("&cЭтот предмет привязан к другому игроку."));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBoundItemHopperMove(InventoryMoveItemEvent event) {
        if (isDungeonBound(event.getItem())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBoundItemCraft(CraftItemEvent event) {
        for (ItemStack ingredient : event.getInventory().getMatrix()) {
            if (isDungeonBound(ingredient)) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onBoundItemAnvil(PrepareAnvilEvent event) {
        for (ItemStack ingredient : event.getInventory().getContents()) {
            if (isDungeonBound(ingredient)) {
                event.setResult(null);
                return;
            }
        }
    }

    @EventHandler
    public void onBoundItemGrindstone(PrepareGrindstoneEvent event) {
        for (ItemStack ingredient : event.getInventory().getContents()) {
            if (isDungeonBound(ingredient)) {
                event.setResult(null);
                return;
            }
        }
    }

    @EventHandler
    public void onBoundItemSmithing(PrepareSmithingEvent event) {
        for (ItemStack ingredient : event.getInventory().getContents()) {
            if (isDungeonBound(ingredient)) {
                event.setResult(null);
                return;
            }
        }
    }

    private void fail(Instance instance, String key) {
        if (instance.state == State.CLOSING) {
            return;
        }
        instance.state = State.CLOSING;
        instance.closeAt = System.currentTimeMillis() + 5000L;
        killMobs(instance);
        for (Player player : alive(instance)) {
            if (probing(player)) {
                finishProbe(player, true);
            }
        }
        sayAll(instance, key, Map.of());
        for (Player player : alive(instance)) {
            if (instance.bar != null) {
                player.hideBossBar(instance.bar);
            }
        }
    }

    private void returnPlayer(Player player) {
        Location back = returnTo.remove(player.getUniqueId());
        if (back == null || back.getWorld() == null) {
            back = Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        if (instancesWorld(player.getWorld())) {
            player.teleport(back);
        }
        player.removePotionEffect(PotionEffectType.GLOWING);
    }

    /** Замер нельзя держать открытым: если игрок ушёл, считаем бой прерванным. */
    private void closeProbeIfAbandoned(Player player) {
        CombatProbe probe = probes.get(player.getUniqueId());
        if (probe == null) {
            return;
        }
        if (byPlayer.containsKey(player.getUniqueId())) {
            finishProbe(player, true);
        } else {
            probes.remove(player.getUniqueId());
        }
    }

    public boolean isInstanceWorld(World world) {
        return instancesWorld(world);
    }

    private boolean instancesWorld(World world) {
        return world != null && world.getName().equals(instanceWorldName);
    }

    private void close(Instance instance, boolean teleport) {
        instance.state = State.CLOSING;
        if (instance.copyTask != null) {
            instance.copyTask.cancel();
        }
        killMobs(instance);
        for (UUID id : new ArrayList<>(instance.members)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                if (instance.bar != null) {
                    player.hideBossBar(instance.bar);
                }
                if (teleport) {
                    returnPlayer(player);
                }
            }
            byPlayer.remove(id);
        }
        instance.members.clear();
        instances.remove(instance.slot);
        clearArea(instance);
    }

    /** Чистим копию порциями, чтобы слот можно было занять снова. */
    private void clearArea(Instance instance) {
        DungeonDef def = instance.def;
        int sx = Math.abs(def.pos1[0] - def.pos2[0]) + 1;
        int sy = Math.abs(def.pos1[1] - def.pos2[1]) + 1;
        int sz = Math.abs(def.pos1[2] - def.pos2[2]) + 1;
        World world = instance.origin.getWorld();
        int ox = instance.origin.getBlockX();
        int oy = instance.origin.getBlockY();
        int oz = instance.origin.getBlockZ();
        long total = (long) sx * sy * sz;
        BoundingBox box = new BoundingBox(ox, oy, oz, ox + sx, oy + sy, oz + sz);
        for (Entity entity : world.getNearbyEntities(box)) {
            if (!(entity instanceof Player)) {
                entity.remove();
            }
        }
        final long[] index = {0};
        BukkitTask[] holder = new BukkitTask[1];
        holder[0] = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            long end = Math.min(total, index[0] + copyPerTick);
            for (long i = index[0]; i < end; i++) {
                int x = (int) (i % sx);
                int z = (int) ((i / sx) % sz);
                int y = (int) (i / ((long) sx * sz));
                org.bukkit.block.Block block = world.getBlockAt(ox + x, oy + y, oz + z);
                if (!block.getType().isAir()) {
                    block.setType(Material.AIR, false);
                }
            }
            index[0] = end;
            if (end >= total) {
                holder[0].cancel();
            }
        }, 1L, 1L);
    }

    // ---------------------------------------------------------------
    //  Игроки: выход, смерть, вход в игру
    // ---------------------------------------------------------------

    public void leave(Player player) {
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null) {
            say(player, "dungeon.not-in", Map.of());
            return;
        }
        removeMember(instance, player, true);
        say(player, "dungeon.left", Map.of());
    }

    private void removeMember(Instance instance, Player player, boolean teleport) {
        instance.members.remove(player.getUniqueId());
        instance.lives.remove(player.getUniqueId());
        byPlayer.remove(player.getUniqueId());
        if (instance.bar != null) {
            player.hideBossBar(instance.bar);
        }
        if (teleport) {
            returnPlayer(player);
        }
        if (instance.members.isEmpty() && instance.state != State.CLOSING) {
            close(instance, false);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getPlayer();
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null) {
            return;
        }
        event.setKeepInventory(true);
        event.setKeepLevel(true);
        event.getDrops().clear();
        event.setDroppedExp(0);
        int left = instance.lives.merge(player.getUniqueId(), -1, Integer::sum);
        if (left > 0) {
            say(player, "dungeon.lives-left", Map.of("lives", left));
        } else {
            say(player, "dungeon.eliminated", Map.of());
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null) {
            return;
        }
        if (instance.lives.getOrDefault(player.getUniqueId(), 0) > 0 && instance.checkpoint != null
                && instance.state != State.CLOSING) {
            event.setRespawnLocation(instance.checkpoint);
            return;
        }
        Location back = returnTo.get(player.getUniqueId());
        if (back != null && back.getWorld() != null) {
            event.setRespawnLocation(back);
        }
        returnTo.remove(player.getUniqueId());
        Bukkit.getScheduler().runTask(plugin, () -> {
            instance.members.remove(player.getUniqueId());
            instance.lives.remove(player.getUniqueId());
            byPlayer.remove(player.getUniqueId());
            if (instance.bar != null) {
                player.hideBossBar(instance.bar);
            }
            if (alive(instance).isEmpty() && instance.state == State.RUNNING) {
                fail(instance, "dungeon.fail-wipe");
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        closeProbeIfAbandoned(player);
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance != null && alive(instance).size() <= 1 && instance.state == State.RUNNING) {
            // последний вышедший: подземелье закрывается, игрок вернётся на прежнее место при входе
            fail(instance, "dungeon.fail-empty");
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (instancesWorld(player.getWorld()) && !byPlayer.containsKey(player.getUniqueId())) {
            Location back = returnTo.remove(player.getUniqueId());
            Location target = back != null && back.getWorld() != null
                    ? back : Bukkit.getWorlds().get(0).getSpawnLocation();
            Bukkit.getScheduler().runTask(plugin, () -> player.teleport(target));
        }
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        if (event.getEntity().getPersistentDataContainer().has(mobKey, PersistentDataType.INTEGER)) {
            event.getDrops().clear();
            event.setDroppedExp(0);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (instancesWorld(event.getBlock().getWorld()) && !(event.getPlayer().hasPermission("ag.admin")
                && event.getPlayer().getGameMode() == GameMode.CREATIVE)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (instancesWorld(event.getBlock().getWorld()) && !(event.getPlayer().hasPermission("ag.admin")
                && event.getPlayer().getGameMode() == GameMode.CREATIVE)) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------
    //  Админ: ключи, тест, построить пример, координаты
    // ---------------------------------------------------------------

    // ---------------------------------------------------------------
    //  Замер боя (/ag admin dungeon probe)
    //  Зачем: цифры HP и урона выставлены «по кривой рангов», а не по логам.
    //  Замер показывает на живом сервере, сколько секунд живёт группа в бою,
    //  сколько урона в секунду даёт и получает, и успевает ли лекарь.
    // ---------------------------------------------------------------

    /** Накопленная статистика одного игрока по всем замерам. */
    public static final class CombatStats {
        public long fights;
        public double seconds;
        public double dealt;
        public double taken;
        public double healing;
        public double bossHp;
        public int deaths;
        public int failed;
        /** Последний замер (для вывода). */
        public double lastSeconds;
        public double lastDealt;
        public double lastTaken;
        public double lastHealing;
        public double lastBossHp;
        public String lastResult = "нет";

        public double dealtPerSecond() {
            return seconds <= 0 ? 0 : dealt / seconds;
        }

        public double takenPerSecond() {
            return seconds <= 0 ? 0 : taken / seconds;
        }

        public double healingPerSecond() {
            return seconds <= 0 ? 0 : healing / seconds;
        }

        /** Сколько секунд группа живёт на своём уроне - грубая оценка «хватит ли DPS». */
        public String verdict(double bossHealth, double bossDamage) {
            if (seconds <= 0 || dealt <= 0) {
                return "&7нет данных";
            }
            double dps = dealtPerSecond();
            double ttk = bossHealth / dps;
            double healRate = healingPerSecond();
            double income = takenPerSecond() + bossDamage * 0.5;
            double sustain = healRate + income * 0.35;
            StringBuilder text = new StringBuilder();
            text.append("&7DOS &f").append(round(dps)).append("&7/с, боссу &f")
                    .append(round(bossHealth)).append("&7 HP -> &f").append(round(ttk)).append("&7 с");
            if (ttk > 600) {
                text.append(" &c(долго: проверьте урон оружия)");
            } else if (ttk < 15) {
                text.append(" &e(быстро: группа перероет босса)");
            }
            text.append("&8 | &7получаем &f").append(round(takenPerSecond() + bossDamage * 0.5)).append("&7/с, лечим &f")
                    .append(round(healRate)).append("&7/с");
            if (sustain < income * 0.8) {
                text.append(" &c(лечения не хватает)");
            } else if (sustain > income * 2) {
                text.append(" &a(с запасом)");
            }
            return text.toString();
        }
    }

    /** Замер одного боя: старт и накопление. */
    private static final class CombatProbe {
        final String dungeon;
        final boolean heroic;
        double dealt;
        double taken;
        double healing;
        long started = System.currentTimeMillis();
        double bossHp;

        CombatProbe(String dungeon, boolean heroic) {
            this.dungeon = dungeon;
            this.heroic = heroic;
        }
    }

    private static String round(double value) {
        return value >= 100 ? String.valueOf(Math.round(value)) : String.format(Locale.ROOT, "%.1f", value);
    }

    public CombatStats combatStats(Player player) {
        return combatStats.computeIfAbsent(player.getUniqueId(), key -> new CombatStats());
    }

    /** Старт замера. Возвращает false, если игрок не в подземелье. */
    public boolean startProbe(Player player) {
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null) {
            return false;
        }
        probes.put(player.getUniqueId(), new CombatProbe(instance.def.id, instance.heroic));
        say(player, "dungeon.probe-start", Map.of("name", modeName(instance)));
        return true;
    }

    /** Итог замера: переносит накопленное в статистику игрока. */
    public void finishProbe(Player player, boolean failed) {
        CombatProbe probe = probes.remove(player.getUniqueId());
        if (probe == null) {
            return;
        }
        Instance instance = byPlayer.get(player.getUniqueId());
        CombatStats stats = combatStats(player);
        stats.seconds += Math.max(0.1, (System.currentTimeMillis() - probe.started) / 1000.0);
        stats.fights++;
        stats.dealt += probe.dealt;
        stats.taken += probe.taken;
        stats.healing += probe.healing;
        if (instance != null && instance.bossMax > 0) {
            probe.bossHp = instance.bossMax;
        }
        stats.bossHp = Math.max(stats.bossHp, probe.bossHp);
        if (failed) {
            stats.failed++;
        }
        stats.lastSeconds = Math.max(0.1, (System.currentTimeMillis() - probe.started) / 1000.0);
        stats.lastDealt = probe.dealt;
        stats.lastTaken = probe.taken;
        stats.lastHealing = probe.healing;
        stats.lastBossHp = probe.bossHp;
        stats.lastResult = failed ? "&cпровал" : "&aпобеда";
        if (instance != null) {
            say(player, "dungeon.probe-done", Map.of(
                    "time", round(stats.lastSeconds),
                    "dps", round(probe.dealt / stats.lastSeconds),
                    "taken", round(probe.taken),
                    "heal", round(probe.healing),
                    "result", stats.lastResult));
        }
    }

    public boolean probing(Player player) {
        return probes.containsKey(player.getUniqueId());
    }

    private void probeDealt(Player player, double amount) {
        CombatProbe probe = probes.get(player.getUniqueId());
        if (probe != null) {
            probe.dealt += amount;
        }
    }

    private void probeTaken(Player player, double amount) {
        CombatProbe probe = probes.get(player.getUniqueId());
        if (probe != null) {
            probe.taken += amount;
        }
    }

    private void probeHealed(Player player, double amount) {
        CombatProbe probe = probes.get(player.getUniqueId());
        if (probe != null) {
            probe.healing += amount;
        }
    }

    /**
     * Модификатор «стеклянная пушка»: игроки бьют сильнее, но и получают сильнее.
     * Меняем урон до применения, чтобы это работало и на босса, и на мобов.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onModifierDamage(org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) {
            return;
        }
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null || instance.modifier == null) {
            return;
        }
        if (instance.playerDamage() != 1.0) {
            event.setDamage(event.getDamage() * instance.playerDamage());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onModifierHurt(org.bukkit.event.entity.EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null || instance.modifier == null) {
            return;
        }
        if (instance.playerTaken() != 1.0) {
            event.setDamage(event.getDamage() * instance.playerTaken());
        }
    }

    /**
     * Итоги забега (раздел 26.4): урон по мобам, полученный урон, лечение, смерти.
     * Считаем всегда, а не только во время замера: сводка выдаётся в конце подземелья.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSummaryDamage(org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) {
            return;
        }
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null || instance.state != State.RUNNING) {
            return;
        }
        if (!event.getEntity().getPersistentDataContainer().has(mobKey, PersistentDataType.INTEGER)) {
            return;
        }
        instance.dealt.merge(player.getUniqueId(), event.getFinalDamage(), Double::sum);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSummaryHurt(org.bukkit.event.entity.EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null || instance.state != State.RUNNING) {
            return;
        }
        instance.taken.merge(player.getUniqueId(), event.getFinalDamage(), Double::sum);
    }

    /** Модификатор «без лекаря» режет лечение; срабатывает раньше подсчёта итогов. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHealScale(org.bukkit.event.entity.EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null || instance.state != State.RUNNING) {
            return;
        }
        double factor = instance.playerHeal();
        if (factor != 1.0) {
            event.setAmount(Math.max(0, event.getAmount() * factor));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSummaryHeal(org.bukkit.event.entity.EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        Instance instance = byPlayer.get(player.getUniqueId());
        if (instance == null || instance.state != State.RUNNING) {
            return;
        }
        instance.healed.merge(player.getUniqueId(), event.getAmount(), Double::sum);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSummaryDeath(PlayerDeathEvent event) {
        Instance instance = byPlayer.get(event.getPlayer().getUniqueId());
        if (instance == null) {
            return;
        }
        instance.deaths.merge(event.getPlayer().getUniqueId(), 1, Integer::sum);
    }

    /** Удар по существу подземелья: считаем только урон игроков по мобам и боссу. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProbeDamage(org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        if (probes.isEmpty() || !(event.getDamager() instanceof Player player)) {
            return;
        }
        if (!event.getEntity().getPersistentDataContainer().has(mobKey, PersistentDataType.INTEGER)) {
            return;
        }
        probeDealt(player, event.getFinalDamage());
    }

    /** Урон по игроку в подземелье. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onProbeHurt(org.bukkit.event.entity.EntityDamageEvent event) {
        if (probes.isEmpty() || !(event.getEntity() instanceof Player player)
                || !probes.containsKey(player.getUniqueId())) {
            return;
        }
        probeTaken(player, event.getFinalDamage());
    }

    /** Лечение: сколько реально восстановлено здоровья (перелечивание не считается). */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onProbeHeal(org.bukkit.event.entity.EntityRegainHealthEvent event) {
        if (probes.isEmpty() || !(event.getEntity() instanceof Player player)
                || !probes.containsKey(player.getUniqueId())) {
            return;
        }
        probeHealed(player, event.getAmount());
    }

    /** Падение игрока во время замера. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onProbeDeath(PlayerDeathEvent event) {
        if (!probes.containsKey(event.getPlayer().getUniqueId())) {
            return;
        }
        CombatStats stats = combatStats(event.getPlayer());
        stats.deaths++;
    }

    public void admin(CommandSender sender, String[] args) {
        // args: ag admin dungeon <действие> ...
        String action = args.length > 3 ? args[3].toLowerCase(Locale.ROOT) : "status";
        switch (action) {
            case "reload" -> {
                reload();
                plugin.getMessages().send(sender, "dungeon.reloaded", Map.of("count", defs.size()));
            }
            case "status" -> {
                sender.sendMessage(Hud.legacy("&6Подземелья: &f" + defs.size() + " &7описано, &f"
                        + instances.size() + "&7/&f" + maxInstances + " &7запущено"));
                for (Instance instance : instances.values()) {
                    sender.sendMessage(Hud.legacy("&8» &f" + instance.def.id + " &7слот " + instance.slot
                            + ", игроков " + instance.members.size() + ", комната "
                            + Math.min(instance.room + 1, instance.def.rooms.size()) + "/" + instance.def.rooms.size()
                            + ", " + instance.state));
                }
            }
            case "close" -> {
                for (Instance instance : new ArrayList<>(instances.values())) {
                    close(instance, true);
                }
                sender.sendMessage(Hud.legacy("&aВсе подземелья закрыты."));
            }
            case "test" -> {
                if (sender instanceof Player player && args.length > 4) {
                    enter(player, args[4], args.length > 5 && args[5].equalsIgnoreCase("heroic"), true);
                } else {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon test <id>"));
                }
            }
            case "rel" -> {
                // rel <id>: координаты под ногами относительно угла шаблона
                if (!(sender instanceof Player player) || args.length < 5) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon rel <id>"));
                    return;
                }
                DungeonDef def = defs.get(args[4].toLowerCase(Locale.ROOT));
                if (def == null) {
                    sender.sendMessage(Hud.legacy("&cПодземелье не найдено."));
                    return;
                }
                Location loc = player.getLocation();
                int rx = loc.getBlockX() - Math.min(def.pos1[0], def.pos2[0]);
                int ry = loc.getBlockY() - Math.min(def.pos1[1], def.pos2[1]);
                int rz = loc.getBlockZ() - Math.min(def.pos1[2], def.pos2[2]);
                sender.sendMessage(Hud.legacy("&6Относительные координаты: &f[" + rx + ", " + ry + ", " + rz + "]"));
            }
            case "buildtest" -> buildTest(sender, args);
            case "reset" -> {
                // reset <игрок> [id]: снять блокировки и суточный лимит
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4]) : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon reset <игрок> [id]"));
                    return;
                }
                int count = resetLocks(target, args.length > 5 ? args[5] : null);
                sender.sendMessage(Hud.legacy("&aСброшено блокировок у &f" + target.getName() + "&a: " + count
                        + (args.length > 5 ? "" : " &7(и суточный лимит)")));
            }
            case "pass" -> {
                // pass <игрок> [число]: пропуск на одиночный вход (отрицательное число - забрать)
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4]) : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon pass <игрок> [число]"));
                    return;
                }
                int amount = 1;
                if (args.length > 5) {
                    try {
                        amount = Integer.parseInt(args[5]);
                    } catch (NumberFormatException exception) {
                        sender.sendMessage(Hud.legacy("&cЧисло введено неверно."));
                        return;
                    }
                }
                grantSoloPass(target, amount);
                say(target, "dungeon.pass-granted", Map.of("total", soloPasses(target)));
                sender.sendMessage(Hud.legacy("&aПропусков у &f" + target.getName() + "&a: " + soloPasses(target)));
            }
            case "probe" -> {
                // probe [ник]: начать/закончить замер боя у себя или у игрока
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4])
                        : sender instanceof Player self ? self : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon probe [ник]"));
                    return;
                }
                if (probing(target)) {
                    finishProbe(target, false);
                    sender.sendMessage(Hud.legacy("&aЗамер у &f" + target.getName() + "&a остановлен."));
                } else if (startProbe(target)) {
                    sender.sendMessage(Hud.legacy("&aЗамер боя начат у &f" + target.getName()
                            + "&a. Пробегите подземелье и введите команду ещё раз."));
                } else {
                    sender.sendMessage(Hud.legacy("&c" + target.getName() + " не в подземелье: замер не начат."));
                }
            }
            case "combat" -> {
                // combat [ник]: сводка замеров
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4])
                        : sender instanceof Player self ? self : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon combat <ник>"));
                    return;
                }
                CombatStats stats = combatStats(target);
                if (stats.fights == 0) {
                    sender.sendMessage(Hud.legacy("&7Замеров нет: &f/ag admin dungeon probe " + target.getName()));
                    return;
                }
                sender.sendMessage(Hud.legacy("&6Бои &f" + target.getName() + "&7: замеров &f" + stats.fights
                        + "&7, падений &f" + stats.deaths + "&7, провалов &f" + stats.failed));
                sender.sendMessage(Hud.legacy("&8» &7боёв на &f" + round(stats.seconds) + "&7 с суммарно"));
                sender.sendMessage(Hud.legacy("&8» &7последний: &f" + round(stats.lastSeconds) + "&7 с, босс &f"
                        + round(stats.lastBossHp) + "&7 HP, " + stats.lastResult));
                sender.sendMessage(Hud.legacy("&8» " + stats.verdict(stats.lastBossHp, 0)));
            }
            case "locks" -> {
                Player target = args.length > 4 ? Bukkit.getPlayer(args[4]) : null;
                if (target == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin dungeon locks <игрок>"));
                    return;
                }
                sender.sendMessage(Hud.legacy("&6Блокировки &f" + target.getName() + "&7 (заходов сегодня " + runsToday(target)
                        + "/" + dailyLimit + ", пропусков " + soloPasses(target) + ")"));
                for (DungeonDef def : defs.values()) {
                    int n = lockDaysLeft(target, def, false);
                    int h = lockDaysLeft(target, def, true);
                    if (n > 0 || h > 0) {
                        sender.sendMessage(Hud.legacy("&8» &f" + def.id + " &7обычный: " + n + " дн., героический: " + h + " дн."));
                    }
                }
            }
            default -> sender.sendMessage(Hud.legacy("&7/ag admin dungeon status|reload|close|test <id> [heroic]|rel <id>|buildtest <id>|reset <игрок> [id]|pass <игрок> [n]|locks <игрок>|probe [ник]|combat <ник>"));
        }
    }

    /** Строит пример карты (3 комнаты) в мире шаблонов: для проверки без собственной постройки. */
    /**
     * Строит черновой шаблон подземелья из его же конфига, чтобы админу было что
     * дорабатывать руками: пол, стены, перегородки в местах, где комнаты запечатаны
     * (seal) или открываются (unlock), факелы. Работает для любого dungeons/<id>.yml,
     * размеры берутся из template.pos1/pos2, а не зашиты в код.
     */
    /** Блок из имени в конфиге; опечатка в теме не должна ронять постройку. */
    private static Material material(String name, Material fallback) {
        Material parsed = name == null ? null : Material.matchMaterial(name.trim().toUpperCase(Locale.ROOT));
        return parsed == null ? fallback : parsed;
    }

    /** X площадки босса в координатах шаблона (нижний угол = 0); -100, если босса нет. */
    private static double bossX(DungeonDef def) {
        for (DungeonDef.RoomDef room : def.rooms) {
            if (room.isBoss() && room.boss() != null) {
                return room.boss().at()[0] - Math.min(def.pos1[0], def.pos2[0]);
            }
        }
        return -100;
    }

    private void buildTest(CommandSender sender, String[] args) {
        DungeonDef def = defs.get(args.length > 4 ? args[4].toLowerCase(Locale.ROOT) : "test");
        if (def == null) {
            sender.sendMessage(Hud.legacy("&cПодземелье не найдено. Файл: dungeons/<id>.yml, id - имя файла."));
            return;
        }
        World world = voidWorld(def.templateWorld);
        if (world == null) {
            sender.sendMessage(Hud.legacy("&cНе удалось открыть мир шаблонов."));
            return;
        }
        int x0 = Math.min(def.pos1[0], def.pos2[0]);
        int y0 = Math.min(def.pos1[1], def.pos2[1]);
        int z0 = Math.min(def.pos1[2], def.pos2[2]);
        int sx = Math.abs(def.pos1[0] - def.pos2[0]) + 1;
        int sy = Math.abs(def.pos1[1] - def.pos2[1]) + 1;
        int sz = Math.abs(def.pos1[2] - def.pos2[2]) + 1;

        // Внутри шаблона координаты задаются относительно нижнего угла (как в конфиге).
        Set<Integer> dividersX = new java.util.TreeSet<>();
        Set<Integer> dividerDoors = new java.util.TreeSet<>();
        Set<Integer> dividerSeals = new java.util.TreeSet<>();
        for (DungeonDef.RoomDef room : def.rooms) {
            for (DungeonDef.Region region : room.seal()) {
                // seal - вход к боссу: проём есть, но закрыт решёткой
                dividersX.add(region.from()[0]);
                dividerSeals.add(region.from()[0]);
            }
            for (DungeonDef.Region region : room.unlock()) {
                // unlock обычно означает "эта стена растворится": проём рисуем сразу.
                dividersX.add(region.from()[0]);
                dividerDoors.add(region.from()[0]);
            }
        }
        // Одна и та же стена может быть и дверью (unlock), и запечатанной (seal): дверь важнее,
        // иначе после зачистки зала проход остаётся закрытым решёткой.
        dividerSeals.removeAll(dividerDoors);
        // Материалы темы: у каждого подземелья свой набор блоков (theme.* в yml), иначе все
        // девять карт строятся одинаковым серым камнем.
        Material wallMaterial = material(def.themeWall, def.raid ? Material.DEEPSLATE_BRICKS : Material.STONE_BRICKS);
        Material floorMaterial = material(def.themeFloor, Material.POLISHED_DEEPSLATE);
        Material ceilingMaterial = material(def.themeCeiling, Material.STONE_BRICKS);
        Material lightMaterial = material(def.themeLight, Material.LANTERN);
        Material accentMaterial = material(def.themeAccent, Material.CHISELED_STONE_BRICKS);

        for (int x = 0; x < sx; x++) {
            for (int y = 0; y < sy; y++) {
                for (int z = 0; z < sz; z++) {
                    boolean shell = x == 0 || y == 0 || z == 0 || x == sx - 1 || y == sy - 1 || z == sz - 1;
                    boolean divider = dividersX.contains(x) && x != 0 && x != sx - 1;
                    Material material = shell || divider ? wallMaterial : Material.AIR;
                    if (y == 0) {
                        material = floorMaterial;
                    }
                    if (y == sy - 1) {
                        material = ceilingMaterial;
                    }
                    // Проход в перегородке: по центру, 3 блока в высоту.
                    if (divider && dividerDoors.contains(x) && y >= 1 && y <= 3
                            && z >= sz / 2 - 1 && z <= sz / 2 + 1) {
                        material = Material.AIR;
                    }
                    // Проём к боссу есть, но до зачистки зала закрыт решёткой (seal).
                    if (divider && dividerSeals.contains(x) && y >= 1 && y <= 3
                            && z >= sz / 2 - 1 && z <= sz / 2 + 1) {
                        material = Material.IRON_BARS;
                    }
                    // Свет по стенам: сам по себе блок света не ставится, только вместо воздуха.
                    if (y == Math.min(4, sy - 2) && (x % 6 == 3) && (z == 1 || z == sz - 2)
                            && material == Material.AIR) {
                        material = lightMaterial;
                    }
                    // Площадка босса: акцент в полу и колонны по углам - видно, где финал.
                    if (def.rooms.stream().anyMatch(DungeonDef.RoomDef::isBoss)) {
                        int bx = (int) bossX(def);
                        if (y == 0 && Math.abs(x - bx) <= 3 && Math.abs(z - sz / 2) <= 2) {
                            material = accentMaterial;
                        }
                        if (y >= 1 && y <= Math.min(5, sy - 2) && Math.abs(x - bx) == 3
                                && Math.abs(z - sz / 2) == 2) {
                            material = wallMaterial;
                        }
                    }
                    world.getBlockAt(x0 + x, y0 + y, z0 + z).setType(material, false);
                }
            }
        }
        sender.sendMessage(Hud.legacy("&aЧерновой шаблон &f" + def.id + "&a построен в мире &f"
                + def.templateWorld + "&a (" + sx + "x" + sy + "x" + sz + ")."));
        sender.sendMessage(Hud.legacy("&7Телепорт: &f/execute in " + def.templateWorld
                + " run tp @s " + (x0 + 2) + " " + (y0 + 1) + " " + (z0 + sz / 2)));
        sender.sendMessage(Hud.legacy("&7Дальше: доработайте комнаты руками, проверьте триггеры "
                + "(&f/ag admin dungeon rel " + def.id + "&7), затем &f/ag admin dungeon test " + def.id));
    }
}
