package ru.adventurers.core.dungeon;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import ru.adventurers.core.AdventurersCore;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Механики боя, которых не хватало: телеграфы с зонами, ярость и прерывание каста
 * (раздел 27 отчёта).
 *
 * <p>Раньше бой в подземельях был «стою и бью»: сложность задавалась только цифрами
 * (HP моба и его урон). Эти три механики заставляют игрока действовать:
 *
 * <ul>
 *   <li><b>Телеграф</b> - босс подсвечивает область и через {@code telegraph} секунд
 *       бьёт только внутри неё. Кто отошёл - жив. Это первое в игре «уклонись».</li>
 *   <li><b>Ярость</b> - если босса не убили за {@code enrage-minutes}, он начинает
 *       наращивать урон и скорость. Время становится ресурсом, «дожёвывать» бой
 *       в безопасности больше нельзя.</li>
 *   <li><b>Прерывание</b> - часть фаз босса кастует (лечение, призыв). Удар щитом,
 *       провокация или выпад сбивают каст, иначе эффект срабатывает.</li>
 * </ul>
 *
 * <p>Всё считается в основном потоке сервера: телеграф - это задача планировщика,
 * которая сначала рисует контур, потом наносит урон.
 */
public final class DungeonMechanics {

    private final AdventurersCore plugin;

    public DungeonMechanics(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    //  Телеграф
    // ---------------------------------------------------------------

    /**
     * Показать телеграф и нанести урон по области.
     *
     * @param boss    босс, от которого идёт удар
     * @param zone    описание зоны из dungeons.yml
     * @param playersMirror кто может пострадать: проверку «свой/чужой» делает вызывающий
     * @param onHit    что сделать с попавшими (обычно - вызвать дамаг)
     */
    public void telegraph(LivingEntity boss, DungeonDef.ZoneDef zone,
                          List<Player> playersMirror, Consumer<Player> onHit) {
        if (boss == null || zone == null || boss.isDead()) {
            return;
        }
        World world = boss.getWorld();
        Location origin = boss.getLocation().clone();
        Vector direction = origin.getDirection().setY(0);
        if (direction.lengthSquared() < 0.0001) {
            direction = new Vector(0, 0, 1);
        }
        direction.normalize();
        Vector finalDirection = direction;

        // 1) контур: частицы по краю зоны, повторяются каждые 4 тика всю подсветку
        long ticks = Math.max(8, (long) (zone.telegraph() * 20));
        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= ticks || boss.isDead()) {
                    // 2) удар: только по тем, кто остался внутри
                    List<Player> hit = new ArrayList<>();
                    for (Player player : playersMirror) {
                        if (player == null || !player.isOnline() || player.isDead()) {
                            continue;
                        }
                        if (inside(origin, finalDirection, zone, player.getLocation())) {
                            hit.add(player);
                        }
                    }
                    world.playSound(origin, impactSound(zone), 1.2f, 0.9f);
                    world.spawnParticle(Particle.EXPLOSION, origin.clone().add(
                            finalDirection.clone().multiply(zone.line() ? zone.radius() / 2 : 0)), 1);
                    for (Player player : hit) {
                        onHit.accept(player);
                    }
                    cancel();
                    return;
                }
                drawOutline(world, origin, finalDirection, zone, elapsed);
                elapsed += 4;
            }
        }.runTaskTimer(plugin, 0L, 4L);
    }

    /** Рисует контур зоны частицами: круг, линия или конус. */
    private void drawOutline(World world, Location origin, Vector direction,
                             DungeonDef.ZoneDef zone, int elapsed) {
        Particle particle = elapsed % 8 == 0 ? Particle.FLAME : Particle.SMOKE;
        if (zone.line()) {
            int steps = (int) Math.max(3, zone.radius() * 3);
            for (int i = 0; i <= steps; i++) {
                Location point = origin.clone().add(direction.clone().multiply(zone.radius() * i / steps));
                world.spawnParticle(particle, point.clone().add(0, 0.2, 0), 1, 0.15, 0, 0.15, 0);
            }
            return;
        }
        if (zone.cone()) {
            double half = Math.toRadians(zone.angle() / 2);
            int rays = 5;
            for (int r = 0; r < rays; r++) {
                double angle = -half + (2 * half) * r / (rays - 1);
                Vector rotated = direction.clone().rotateAroundY(angle);
                for (double d = 1; d <= zone.radius(); d += 1.0) {
                    world.spawnParticle(particle, origin.clone().add(rotated.clone().multiply(d))
                            .add(0, 0.2, 0), 1, 0.1, 0, 0.1, 0);
                }
            }
            return;
        }
        // CIRCLE: кольцо по краю
        int points = Math.max(12, (int) (zone.radius() * 5));
        for (int i = 0; i < points; i++) {
            double angle = 2 * Math.PI * i / points;
            Location point = origin.clone().add(Math.cos(angle) * zone.radius(), 0.2,
                    Math.sin(angle) * zone.radius());
            world.spawnParticle(particle, point, 1, 0.05, 0, 0.05, 0);
        }
    }

    private Sound impactSound(DungeonDef.ZoneDef zone) {
        return switch (zone.shape().toUpperCase(java.util.Locale.ROOT)) {
            case "LINE" -> Sound.ENTITY_RAVAGER_ROAR;
            case "CONE" -> Sound.ENTITY_WARDEN_SONIC_BOOM;
            default -> Sound.ENTITY_GENERIC_EXPLODE;
        };
    }

    /** Попала ли точка в зону. Для LINE ширина считается как 1.2 блока. */
    public static boolean inside(Location origin, Vector direction, DungeonDef.ZoneDef zone,
                                 Location point) {
        if (!origin.getWorld().equals(point.getWorld())) {
            return false;
        }
        Vector flat = point.toVector().subtract(origin.toVector());
        flat.setY(0);
        double distance = flat.length();
        if (distance > zone.radius()) {
            return false;
        }
        if (zone.line()) {
            // расстояние до линии вдоль направления
            Vector perpendicular = flat.clone().subtract(direction.clone().multiply(flat.dot(direction)));
            return perpendicular.length() <= 1.2 && flat.dot(direction) >= 0;
        }
        if (zone.cone()) {
            if (distance < 0.01) {
                return true;
            }
            double angle = Math.toDegrees(Math.acos(Math.min(1.0,
                    flat.normalize().dot(direction.clone().normalize()))));
            return angle <= zone.angle() / 2;
        }
        return true;   // CIRCLE
    }

    // ---------------------------------------------------------------
    //  Ярость
    // ---------------------------------------------------------------

    /**
     * Проверка ярости. Вызывается из тика босса.
     *
     * @param elapsedSeconds сколько длится бой
     * @param enrageMinutes  с какого времени босс злится (0 - отключено)
     * @param stacks         сколько раз ярость уже сработала (по числу интервалов)
     * @return true, если на этом тике надо применить очередную ступень ярости
     */
    public static boolean enraged(double elapsedSeconds, double enrageMinutes, int stacks) {
        if (enrageMinutes <= 0) {
            return false;
        }
        double enrageAfter = enrageMinutes * 60;
        // каждые 30 секунд после порога - ещё одна ступень
        return elapsedSeconds >= enrageAfter + stacks * 30
                && elapsedSeconds - enrageAfter - stacks * 30 < 10;
    }

    // ---------------------------------------------------------------
    //  Прерывание каста
    // ---------------------------------------------------------------

    /**
     * Каст босса: полоса в boss bar, через секунды эффект. Сбивается кнопкой
     * {@link #interrupt(LivingEntity)}.
     *
     * @param boss     кто кастует
     * @param name     название каста для полосы
     * @param seconds  сколько длится
     * @param onFinish что случится, если не сбили
     */
    public Cast cast(LivingEntity boss, String name, double seconds, Runnable onFinish) {
        return new Cast(boss, name, seconds, onFinish);
    }

    /** Активный каст: держит задачу и ссылку на босса. */
    public final class Cast {
        private final LivingEntity boss;
        private final String name;
        private final Runnable onFinish;
        private final int totalTicks;
        private int left;
        private boolean cancelled;
        private final org.bukkit.boss.BossBar bar;

        Cast(LivingEntity boss, String name, double seconds, Runnable onFinish) {
            this.boss = boss;
            this.name = name;
            this.onFinish = onFinish;
            this.totalTicks = (int) Math.max(20, seconds * 20);
            this.left = totalTicks;
            this.bar = org.bukkit.Bukkit.createBossBar(
                    "⚡ " + name + " - сбей ударом!",
                    org.bukkit.boss.BarColor.RED, org.bukkit.boss.BarStyle.SEGMENTED_10);
            boss.getWorld().getPlayers().forEach(bar::addPlayer);
            bar.setProgress(1.0f);
            boss.getWorld().playSound(boss.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.4f);
            new org.bukkit.scheduler.BukkitRunnable() {
                @Override
                public void run() {
                    if (cancelled || boss.isDead() || !boss.isValid()) {
                        cleanup();
                        cancel();
                        return;
                    }
                    left -= 2;
                    bar.setProgress(Math.max(0f, left / (float) totalTicks));
                    if (left <= 0) {
                        cleanup();
                        onFinish.run();
                        cancel();
                    }
                }
            }.runTaskTimer(plugin, 2L, 2L);
        }

        /** Сбить каст. Возвращает true, если каст был активен. */
        public boolean interrupt() {
            if (cancelled || left <= 0) {
                return false;
            }
            cancelled = true;
            cleanup();
            boss.getWorld().playSound(boss.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 0.7f);
            boss.getWorld().spawnParticle(Particle.CRIT, boss.getLocation().add(0, 1, 0),
                    20, 0.4, 0.4, 0.4, 0.1);
            return true;
        }

        public boolean active() {
            return !cancelled && left > 0;
        }

        public String name() {
            return name;
        }

        public LivingEntity boss() {
            return boss;
        }

        private void cleanup() {
            bar.removeAll();
        }
    }

    /**
     * Сбивает каст, если босс кастует. Вызывается из умений танка и бойца:
     * удар щитом, провокация, выпад - то, что делает роль «контроль», а не урон.
     *
     * @return true, если каст сбит
     */
    public boolean interruptDungeonBoss(Player player) {
        if (plugin.getDungeons() == null) {
            return false;
        }
        return plugin.getDungeons().interruptCast(player);
    }
}
