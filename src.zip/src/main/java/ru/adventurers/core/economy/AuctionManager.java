package ru.adventurers.core.economy;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.DatabaseManager;
import ru.adventurers.core.hud.Hud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

import static ru.adventurers.core.economy.EconomyManager.line;

/** Аукцион игроков: /ag ah, /ag ah sell &lt;цена&gt;. Лоты хранятся в таблице ag_auction. */
public class AuctionManager implements Listener {

    private static final class Listing {
        final int id;
        final UUID seller;
        final String sellerName;
        final ItemStack item;
        final long price;

        Listing(int id, UUID seller, String sellerName, ItemStack item, long price) {
            this.id = id;
            this.seller = seller;
            this.sellerName = sellerName;
            this.item = item;
            this.price = price;
        }
    }

    private enum Cat {
        ALL("Всё", Material.CHEST),
        WEAPONS("Оружие", Material.IRON_SWORD),
        ARMOR("Броня и щиты", Material.IRON_CHESTPLATE),
        TOOLS("Инструменты", Material.IRON_PICKAXE),
        MAGIC("Руны и самоцветы", Material.AMETHYST_SHARD),
        CONSUMABLES("Еда и эликсиры", Material.GOLDEN_CARROT),
        RESOURCES("Ресурсы", Material.IRON_INGOT),
        OTHER("Прочее", Material.BUNDLE);

        final String title;
        final Material icon;

        Cat(String title, Material icon) {
            this.title = title;
            this.icon = icon;
        }
    }

    private enum Sort {
        NEW("Сначала новые"), OLD("Сначала старые"), CHEAP("Сначала дешёвые"), EXPENSIVE("Сначала дорогие");

        final String title;

        Sort(String title) {
            this.title = title;
        }
    }

    private static final class Holder implements InventoryHolder {
        int page;
        Cat cat = Cat.ALL;
        Sort sort = Sort.NEW;
        boolean mine;
        final List<Listing> shown = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private Cat categoryOf(ItemStack item) {
        if (item.hasItemMeta()) {
            for (var key : item.getItemMeta().getPersistentDataContainer().getKeys()) {
                String name = key.getKey();
                if (name.contains("rune") || name.contains("gem")) {
                    return Cat.MAGIC;
                }
                if (name.equals("consumable")) {
                    return Cat.CONSUMABLES;
                }
            }
        }
        Material m = item.getType();
        String n = m.name();
        if (n.endsWith("_SWORD") || n.endsWith("_AXE") || m == Material.BOW || m == Material.CROSSBOW
                || m == Material.TRIDENT || m == Material.MACE || n.equals("ARROW") || n.endsWith("_ARROW")) {
            return Cat.WEAPONS;
        }
        if (n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")
                || m == Material.SHIELD || m == Material.ELYTRA || m == Material.TURTLE_HELMET) {
            return Cat.ARMOR;
        }
        if (n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE") || m == Material.FISHING_ROD
                || m == Material.SHEARS || m == Material.FLINT_AND_STEEL) {
            return Cat.TOOLS;
        }
        if (m.isEdible() || m == Material.HONEY_BOTTLE || n.contains("POTION")) {
            return Cat.CONSUMABLES;
        }
        if (n.endsWith("_INGOT") || n.endsWith("_NUGGET") || n.startsWith("RAW_") || n.endsWith("_ORE")
                || n.endsWith("_LOG") || n.endsWith("_PLANKS") || n.endsWith("_DYE") || n.endsWith("SHARD")
                || n.endsWith("CRYSTALS") || n.endsWith("_SCRAP") || n.endsWith("STONE") || n.endsWith("COBBLESTONE")
                || m == Material.DIAMOND || m == Material.EMERALD || m == Material.COAL || m == Material.REDSTONE
                || m == Material.LAPIS_LAZULI || m == Material.QUARTZ || m == Material.STRING || m == Material.LEATHER
                || m == Material.BONE || m == Material.GUNPOWDER || m == Material.BLAZE_ROD || m == Material.ENDER_PEARL) {
            return Cat.RESOURCES;
        }
        return Cat.OTHER;
    }

    private final AdventurersCore plugin;
    private final DatabaseManager database;
    private final NamespacedKey dungeonLootOwnerKey;
    private final List<Listing> listings = new CopyOnWriteArrayList<>();
    private int nextId = 1;
    private int maxPerPlayer = 8;
    private long maxPrice = 10_000_000L;
    private double tax = 0.05;

    public AuctionManager(AdventurersCore plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
        this.dungeonLootOwnerKey = new NamespacedKey(plugin, "dungeon_loot_owner");
    }

    public void init() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS ag_auction (
                    id INT NOT NULL PRIMARY KEY,
                    seller CHAR(36) NOT NULL,
                    seller_name VARCHAR(32) NOT NULL,
                    item MEDIUMBLOB NOT NULL,
                    price BIGINT NOT NULL,
                    created BIGINT NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        try (Connection connection = database.getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.executeUpdate();
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT id, seller, seller_name, item, price FROM ag_auction ORDER BY id");
                 ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    try {
                        ItemStack item = ItemStack.deserializeBytes(result.getBytes("item"));
                        listings.add(new Listing(result.getInt("id"), UUID.fromString(result.getString("seller")),
                                result.getString("seller_name"), item, result.getLong("price")));
                        nextId = Math.max(nextId, result.getInt("id") + 1);
                    } catch (RuntimeException exception) {
                        plugin.getLogger().warning("Auction: bad item in row " + result.getInt("id"));
                    }
                }
            }
        }
        reload();
    }

    public void reload() {
        var cfg = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(
                plugin.getFiles().file("economy.yml"));
        maxPerPlayer = Math.max(1, cfg.getInt("auction.max-per-player", 8));
        maxPrice = Math.max(1, cfg.getLong("auction.max-price", 10_000_000L));
        tax = Math.max(0, Math.min(0.9, cfg.getDouble("auction.tax", 0.05)));
    }

    private void insertAsync(Listing listing) {
        byte[] bytes = listing.item.serializeAsBytes();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            String sql = "INSERT INTO ag_auction (id, seller, seller_name, item, price, created) VALUES (?,?,?,?,?,?)";
            try (Connection connection = database.getConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, listing.id);
                statement.setString(2, listing.seller.toString());
                statement.setString(3, listing.sellerName);
                statement.setBytes(4, bytes);
                statement.setLong(5, listing.price);
                statement.setLong(6, System.currentTimeMillis());
                statement.executeUpdate();
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not save auction listing " + listing.id);
                exception.printStackTrace();
            }
        });
    }

    private void deleteAsync(int id) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try (Connection connection = database.getConnection();
                 PreparedStatement statement = connection.prepareStatement("DELETE FROM ag_auction WHERE id = ?")) {
                statement.setInt(1, id);
                statement.executeUpdate();
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });
    }

    // ---------------------------------------------------------------
    //  Выставление
    // ---------------------------------------------------------------

    public void sell(Player player, String priceText) {
        long price;
        try {
            price = Long.parseLong(priceText);
        } catch (NumberFormatException exception) {
            plugin.getMessages().send(player, "economy.ah-usage");
            return;
        }
        if (price < 1 || price > maxPrice) {
            plugin.getMessages().send(player, "economy.ah-price", Map.of("max", maxPrice));
            return;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            plugin.getMessages().send(player, "economy.ah-empty");
            return;
        }
        boolean dungeonBound = hand.hasItemMeta() && hand.getItemMeta().getPersistentDataContainer()
                .has(dungeonLootOwnerKey, PersistentDataType.STRING);
        if (dungeonBound
                || (plugin.getHealer() != null && plugin.getHealer().isStaff(hand))
                || (plugin.getTank() != null && plugin.getTank().isTankShield(hand))
                || hand.getType() == Material.BEDROCK) {
            plugin.getMessages().send(player, "economy.ah-bound");
            return;
        }
        long mine = listings.stream().filter(l -> l.seller.equals(player.getUniqueId())).count();
        if (mine >= maxPerPlayer) {
            plugin.getMessages().send(player, "economy.ah-limit", Map.of("max", maxPerPlayer));
            return;
        }
        Listing listing = new Listing(nextId++, player.getUniqueId(), player.getName(), hand.clone(), price);
        listings.add(listing);
        player.getInventory().setItemInMainHand(null);
        insertAsync(listing);
        plugin.getMessages().send(player, "economy.ah-listed", Map.of("coins", plugin.getEconomy().format(price)));
    }

    // ---------------------------------------------------------------
    //  Меню
    // ---------------------------------------------------------------

    public void open(Player player) {
        render(player, new Holder());
    }

    private void render(Player player, Holder holder) {
        Inventory inventory = Bukkit.createInventory(holder, 54,
                Hud.legacy(holder.mine ? "&8Аукцион: мои лоты" : "&8Аукцион игроков"));
        holder.shown.clear();
        List<Listing> all = new ArrayList<>();
        for (Listing listing : listings) {
            if (holder.mine && !listing.seller.equals(player.getUniqueId())) {
                continue;
            }
            if (holder.cat != Cat.ALL && categoryOf(listing.item) != holder.cat) {
                continue;
            }
            all.add(listing);
        }
        switch (holder.sort) {
            case NEW -> all.sort((x, y) -> Integer.compare(y.id, x.id));
            case OLD -> all.sort((x, y) -> Integer.compare(x.id, y.id));
            case CHEAP -> all.sort((x, y) -> Long.compare(x.price, y.price));
            case EXPENSIVE -> all.sort((x, y) -> Long.compare(y.price, x.price));
        }
        int from = holder.page * 45;
        if (from >= all.size() && holder.page > 0) {
            holder.page = 0;
            from = 0;
        }
        for (int i = from; i < Math.min(all.size(), from + 45); i++) {
            Listing listing = all.get(i);
            holder.shown.add(listing);
            ItemStack icon = listing.item.clone();
            ItemMeta meta = icon.getItemMeta();
            List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
            lore.add(Component.empty());
            lore.add(line("&7Цена: " + plugin.getEconomy().format(listing.price)));
            if (listing.item.getAmount() > 1) {
                lore.add(line("&7За штуку: " + plugin.getEconomy().format(Math.max(1, listing.price / listing.item.getAmount()))));
            }
            lore.add(line("&7Продавец: &f" + listing.sellerName));
            boolean own = listing.seller.equals(player.getUniqueId());
            lore.add(line(own ? "&cShift+ПКМ &7- снять с продажи" : "&eЛКМ &7- купить"));
            meta.lore(lore);
            icon.setItemMeta(meta);
            inventory.setItem(i - from, icon);
        }
        inventory.setItem(45, nav(Material.ARROW, "&7◀ Страница " + (holder.page + 1), holder.page > 0));
        inventory.setItem(53, nav(Material.ARROW, "&7Страница ▶", all.size() > from + 45));

        ItemStack category = new ItemStack(holder.cat.icon);
        ItemMeta catMeta = category.getItemMeta();
        catMeta.displayName(line("&6Раздел: &f" + holder.cat.title));
        List<Component> catLore = new ArrayList<>();
        for (Cat c : Cat.values()) {
            catLore.add(line((c == holder.cat ? "&e▶ " : "&8  ") + c.title));
        }
        catLore.add(Component.empty());
        catLore.add(line("&7ЛКМ - дальше, ПКМ - назад"));
        catMeta.lore(catLore);
        category.setItemMeta(catMeta);
        inventory.setItem(46, category);

        ItemStack sort = new ItemStack(Material.HOPPER);
        ItemMeta sortMeta = sort.getItemMeta();
        sortMeta.displayName(line("&6Сортировка: &f" + holder.sort.title));
        List<Component> sortLore = new ArrayList<>();
        for (Sort so : Sort.values()) {
            sortLore.add(line((so == holder.sort ? "&e▶ " : "&8  ") + so.title));
        }
        sortLore.add(Component.empty());
        sortLore.add(line("&7Клик - сменить"));
        sortMeta.lore(sortLore);
        sort.setItemMeta(sortMeta);
        inventory.setItem(47, sort);

        long mineCount = listings.stream().filter(l -> l.seller.equals(player.getUniqueId())).count();
        ItemStack mine = new ItemStack(holder.mine ? Material.ENDER_CHEST : Material.PLAYER_HEAD);
        ItemMeta mineMeta = mine.getItemMeta();
        mineMeta.displayName(line(holder.mine ? "&6Показать все лоты" : "&6Мои лоты &8(" + mineCount + "/" + maxPerPlayer + ")"));
        mineMeta.lore(List.of(line("&7Снять лот: Shift+ПКМ по нему")));
        mine.setItemMeta(mineMeta);
        inventory.setItem(48, mine);

        ItemStack info = new ItemStack(Material.GOLD_INGOT);
        ItemMeta meta = info.getItemMeta();
        meta.displayName(line("&6Кошелёк: " + plugin.getEconomy().format(plugin.getEconomy().balance(player.getUniqueId()))));
        meta.lore(List.of(line("&7Выставить: предмет в руке и"), line("&f/ag ah sell <цена>"),
                line("&8Налог с продажи: " + Math.round(tax * 100) + "%"),
                line("&8Лотов найдено: " + all.size())));
        info.setItemMeta(meta);
        inventory.setItem(49, info);

        ItemStack sellHint = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta hintMeta = sellHint.getItemMeta();
        hintMeta.displayName(line("&6Как выставить лот"));
        hintMeta.lore(List.of(line("&71. Возьмите предмет в основную руку"), line("&72. Введите &f/ag ah sell <цена>"),
                line("&7Цена за весь стак в руке.")));
        sellHint.setItemMeta(hintMeta);
        inventory.setItem(51, sellHint);
        player.openInventory(inventory);
    }

    private ItemStack nav(Material material, String name, boolean on) {
        ItemStack item = new ItemStack(on ? material : Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(on ? name : "&8·"));
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)
                || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        if (slot == 45 && holder.page > 0) {
            holder.page--;
        } else if (slot == 53 && event.getCurrentItem() != null && event.getCurrentItem().getType() == Material.ARROW) {
            holder.page++;
        } else if (slot == 46) {
            Cat[] cats = Cat.values();
            int step = event.getClick().isRightClick() ? cats.length - 1 : 1;
            holder.cat = cats[(holder.cat.ordinal() + step) % cats.length];
            holder.page = 0;
        } else if (slot == 47) {
            Sort[] sorts = Sort.values();
            holder.sort = sorts[(holder.sort.ordinal() + 1) % sorts.length];
            holder.page = 0;
        } else if (slot == 48) {
            holder.mine = !holder.mine;
            holder.page = 0;
        } else if (slot >= 0 && slot < 45 && slot < holder.shown.size()) {
            Listing listing = holder.shown.get(slot);
            if (listing.seller.equals(player.getUniqueId())) {
                if (event.getClick().isShiftClick() && event.getClick().isRightClick()) {
                    cancel(player, listing);
                }
            } else if (event.getClick().isLeftClick() && !event.getClick().isShiftClick()) {
                buy(player, listing);
            }
        } else {
            return;
        }
        render(player, holder);
    }

    private void give(Player player, ItemStack item) {
        for (ItemStack rest : player.getInventory().addItem(item).values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), rest);
        }
    }

    private void cancel(Player player, Listing listing) {
        if (!listings.remove(listing)) {
            plugin.getMessages().send(player, "economy.ah-gone");
            return;
        }
        deleteAsync(listing.id);
        give(player, listing.item.clone());
        plugin.getMessages().send(player, "economy.ah-cancelled");
    }

    private void buy(Player player, Listing listing) {
        if (!listings.contains(listing)) {
            plugin.getMessages().send(player, "economy.ah-gone");
            return;
        }
        EconomyManager economy = plugin.getEconomy();
        if (!economy.has(player.getUniqueId(), listing.price)) {
            plugin.getMessages().send(player, "economy.not-enough", Map.of("cost", economy.format(listing.price),
                    "have", economy.format(economy.balance(player.getUniqueId()))));
            return;
        }
        if (!listings.remove(listing)) {
            return;
        }
        deleteAsync(listing.id);
        economy.withdraw(player.getUniqueId(), listing.price);
        long income = listing.price - Math.round(listing.price * tax);
        economy.deposit(listing.seller, income);
        give(player, listing.item.clone());
        plugin.getMessages().send(player, "economy.ah-bought", Map.of("coins", economy.format(listing.price)));
        Player seller = Bukkit.getPlayer(listing.seller);
        if (seller != null) {
            plugin.getMessages().send(seller, "economy.ah-sold", Map.of("player", player.getName(),
                    "coins", economy.format(income)));
        }
    }
}
