package ru.adventurers.core.event;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Постройка арен испытаний прямо в игре, без схематик и без карт от билдера.
 *
 * <p>Почему так: у сервера нет готовых арен, а восемь режимов требуют восьми разных площадок.
 * Генерировать их кодом дешевле, чем просить восемь карт, и они всегда совпадают с
 * конфигом: координаты, число этажей и размер лабиринта берутся из events.yml.
 *
 * <p>Всё строится в отдельном мире (events.yml: world). Мир создаётся пустым, без
 * сохранения: если игрок что-то сломает, площадка перестроится при следующем запуске.
 */
public final class EventArena {

    private EventArena() {
    }

    /** Мир арен: создаётся пустым при первом обращении. */
    public static World world(String name) {
        World world = Bukkit.getWorld(name);
        if (world == null) {
            WorldCreator creator = new WorldCreator(name);
            creator.generator(new org.bukkit.generator.ChunkGenerator() {
                @Override
                public boolean shouldGenerateNoise() {
                    return false;
                }

                @Override
                public boolean shouldGenerateSurface() {
                    return false;
                }

                @Override
                public boolean shouldGenerateCaves() {
                    return false;
                }

                @Override
                public boolean shouldGenerateStructures() {
                    return false;
                }
            });
            world = creator.createWorld();
            if (world != null) {
                world.setAutoSave(false);
                world.setPVP(true);
                world.setTime(18000);      // «вечная ночь»: испытания выглядят как ночные вылазки
                world.setStorm(false);
                world.setDifficulty(org.bukkit.Difficulty.NORMAL);
            }
        }
        return world;
    }

    /**
     * Круглая арена: пол радиусом radius, стены высотой wall, факелы по кругу.
     * Материалы берутся из темы испытания (events.yml), чтобы башня, арена и шахта
     * не выглядели одинаково.
     */
    public static Location platform(World world, int centerX, int centerY, int centerZ, int radius,
                                    int wall, Material floor, Material rim, Material light) {
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                if (x * x + z * z > radius * radius) {
                    continue;
                }
                Block floorBlock = world.getBlockAt(centerX + x, centerY, centerZ + z);
                floorBlock.setType(floor, false);
                for (int y = 1; y <= wall; y++) {
                    boolean edge = x * x + z * z > (radius - 1) * (radius - 1);
                    Block block = world.getBlockAt(centerX + x, centerY + y, centerZ + z);
                    block.setType(edge ? rim : Material.AIR, false);
                }
                // свет по краю, чтобы арена не была чёрной дырой
                if (x * x + z * z > (radius - 2) * (radius - 2) && (x + z) % 5 == 0) {
                    world.getBlockAt(centerX + x, centerY + Math.max(1, wall - 1), centerZ + z).setType(light, false);
                }
            }
        }
        return new Location(world, centerX + 0.5, centerY + 1, centerZ + 0.5);
    }

    /** Этаж башни: площадка на высоте y, лестница-телепорт в центр (игрока поднимает менеджер). */
    public static Location towerFloor(World world, int centerX, int baseY, int centerZ, int floor,
                                      int radius, Material floorMaterial, Material rim, Material light) {
        int y = baseY + (floor - 1) * 8;
        return platform(world, centerX, y, centerZ, radius, 4, floorMaterial, rim, light);
    }

    /**
     * Лабиринт: сетка клеток 2x2, стены между ними. Генератор «recursive backtracker»,
     * сид недели - один лабиринт на всех, иначе рекорды по времени были бы нечестными.
     *
     * @return точка выхода из лабиринта
     */
    public static Location maze(World world, int centerX, int baseY, int centerZ, int size, long seed,
                                Material floor, Material wall, Material exit) {
        int cell = 3;
        int span = size * cell;
        Random random = new Random(seed);
        boolean[][] visited = new boolean[size][size];
        // стены: true - блок есть
        boolean[][] walls = new boolean[span + 1][span + 1];
        for (boolean[] row : walls) {
            java.util.Arrays.fill(row, true);
        }
        carve(random, walls, visited, 0, 0, size, cell);

        for (int x = 0; x <= span; x++) {
            for (int z = 0; z <= span; z++) {
                Block block = world.getBlockAt(centerX + x, baseY, centerZ + z);
                if (walls[x][z]) {
                    block.setType(wall, false);
                    world.getBlockAt(centerX + x, baseY + 1, centerZ + z).setType(wall, false);
                    world.getBlockAt(centerX + x, baseY + 2, centerZ + z).setType(wall, false);
                } else {
                    block.setType(floor, false);
                    for (int y = 1; y <= 3; y++) {
                        world.getBlockAt(centerX + x, baseY + y, centerZ + z).setType(Material.AIR, false);
                    }
                }
            }
        }
        // выход - дальний угол: подсвечен, чтобы его было видно, когда найдёшь
        Location exitAt = new Location(world, centerX + span + 0.5, baseY + 1, centerZ + span + 0.5);
        world.getBlockAt(exitAt.getBlockX(), baseY, exitAt.getBlockZ()).setType(exit, false);
        world.getBlockAt(exitAt.getBlockX(), baseY + 1, exitAt.getBlockZ()).setType(Material.AIR, false);
        return exitAt;
    }

    private static void carve(Random random, boolean[][] walls, boolean[][] visited,
                              int cx, int cz, int size, int cell) {
        visited[cx][cz] = true;
        int x = cx * cell + 1;
        int z = cz * cell + 1;
        walls[x][z] = false;
        int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        List<int[]> order = new ArrayList<>(List.of(dirs));
        java.util.Collections.shuffle(order, random);
        for (int[] dir : order) {
            int nx = cx + dir[0];
            int nz = cz + dir[1];
            if (nx < 0 || nz < 0 || nx >= size || nz >= size || visited[nx][nz]) {
                continue;
            }
            // прорубаем стену между клетками
            walls[x + dir[0] * 1][z + dir[1] * 1] = false;
            carve(random, walls, visited, nx, nz, size, cell);
        }
    }

    /**
     * Шахта: вертикальный колодец со ступенями-уступами и жилами руды по стенам.
     * Чем глубже, тем больше жил: глубина - это и есть счёт испытания.
     *
     * @return точка старта на поверхности
     */
    public static Location shaft(World world, int centerX, int topY, int centerZ, int depth,
                                 Material wall, Material[] ores, Material light, long seed) {
        Random random = new Random(seed);
        for (int y = topY; y > topY - depth; y--) {
            int layer = topY - y;
            int radius = 2 + (layer / 12);
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    Block block = world.getBlockAt(centerX + x, y, centerZ + z);
                    boolean shell = Math.abs(x) == radius || Math.abs(z) == radius;
                    if (!shell) {
                        block.setType(Material.AIR, false);
                        continue;
                    }
                    // жила: чем глубже, тем чаще
                    double chance = 0.04 + Math.min(0.18, layer * 0.004);
                    block.setType(random.nextDouble() < chance
                            ? ores[random.nextInt(ores.length)] : wall, false);
                }
            }
            // свет на дне каждого «уровня»
            if (layer % 10 == 0) {
                world.getBlockAt(centerX, y + 1, centerZ).setType(light, false);
            }
            // ступени по спирали, чтобы можно было спускаться пешком
            int step = layer % 4;
            if (step == 0) {
                world.getBlockAt(centerX + radius - 1, y, centerZ).setType(Material.COBBLESTONE, false);
            }
        }
        return new Location(world, centerX + 0.5, topY + 1, centerZ + 0.5);
    }

    /** Очистить область перед новой постройкой: арены перестраиваются каждую неделю. */
    public static void clear(World world, int centerX, int centerY, int centerZ, int radius, int height) {
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                for (int y = -2; y <= height; y++) {
                    world.getBlockAt(centerX + x, centerY + y, centerZ + z).setType(Material.AIR, false);
                }
            }
        }
    }
}
