package ru.adventurers.core.event;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.WeekFields;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Еженедельные испытания с прогрессией (раздел 19 отчёта).
 *
 * <p>Идея: каждую неделю идёт одно из восьми испытаний, у каждого - ступени (этажи, волны,
 * глубина). Игрок доходит до своей максимальной ступени, получает награду за первую пройденную
 * ступень и прибавку за каждую следующую; в конце недели топ-3 получает призовые и титул.
 *
 * <p>Важное решение по балансу: награда за ступень ниже дневного дохода ранга (events.yml,
 * coins-per-day), а за неделю испытание даёт не больше 2-3 дней дохода. Иначе испытание
 * превратилось бы в «фарми часами» и убило бы экономику из раздела 15. Поэтому у попыток есть
 * дневной лимит, а прогресс считается по ЛУЧШЕЙ ступени, а не по сумме всех заходов.
 *
 * <p>Второе решение: у испытаний нет «входного билета» и нет платных попыток. Донат даёт
 * косметику и удобство (см. DonateManager), но не ступени и не награды - иначе первое место
 * покупалось бы, а не выигрывалось.
 */
public class EventManager implements Listener {

    private final AdventurersCore plugin;
    private final MessageManager messages;
    private final EventRepository repository;
    private final Random random = new Random();

    private boolean enabled = true;
    private String worldName = "adventurers_events";
    /** Мир для Большой охоты: босс недели ходит по обычному миру. */
    private String huntWorldName = "";
    private int attemptsPerDay = 5;
    private double weeklyBonus = 1.0;
    /** Множитель награды по рангу игрока: испытание одно на всех, а доход рангов разный. */
    private final Map<Rank, Double> rankScale = new java.util.EnumMap<>(Rank.class);
    /** Первая неделя сезона: от неё считается номер недели и какое испытание идёт. */
    private long seasonStartEpochDay = LocalDate.of(2026, 1, 5).toEpochDay();
    private int resetDayOfWeek = 1;          // 1 = понедельник
    private int resetHour = 4;               // локальное время сервера
    private boolean announce = true;

    /** Описание каждого испытания из events.yml. */
    private final Map<EventType, Config> configs = new LinkedHashMap<>();
    /** Текущие забеги. */
    private final Map<UUID, Run> runs = new ConcurrentHashMap<>();
    /** Дневные попытки: uuid -> (дата, сколько потрачено). */
    private final Map<UUID, int[]> attemptsUsed = new ConcurrentHashMap<>();
    private final Map<UUID, String> attemptsDay = new ConcurrentHashMap<>();

    private BukkitTask ticker;
    /** Ключ недели, за которую призы уже выданы этим запуском (сбрасывается при смене недели). */
    private String lastWeek = "";
    private int tick;

    public EventManager(AdventurersCore plugin, MessageManager messages, EventRepository repository) {
        this.plugin = plugin;
        this.messages = messages;
        this.repository = repository;
    }

    // ---------------------------------------------------------------
    //  Описание испытаний
    // ---------------------------------------------------------------

    /**
     * Одно испытание из events.yml: где стоит арена, какие мобы, сколько ступеней, тема блоков.
     */
    public record Config(EventType type, boolean open, int stages, int bossEvery, int centerX, int centerY,
                         int centerZ, int radius, int timeLimitSeconds, int attemptLimit,
                         List<EntityType> mobs, EntityType boss, double hpBase, double hpGrowth,
                         double dmgBase, double dmgGrowth, int mobBase, int mobGrowth,
                         long coinsBase, double coinsGrowth, int pointsBase, double pointsGrowth,
                         int lootBase, int lootEvery, Material floor, Material wall, Material light,
                         Material accent, List<String> rewards, String titleUnlock) {

        /** Ступени испытания (с множителем недели). */
        public List<EventStage> stages(double bonus) {
            return EventStage.build(stages, bossEvery, hpBase, hpGrowth, dmgBase, dmgGrowth,
                    mobBase, mobGrowth, coinsBase, coinsGrowth, pointsBase, pointsGrowth,
                    lootBase, lootEvery).stream().map(stage -> stage.scaled(bonus)).toList();
        }
    }

    /** Один забег игрока: где он, на какой ступени, сколько осталось времени и что уже убито. */
    private static final class Run {
        final UUID uuid;
        final Player player;
        Player owner;
        final EventType type;
        final Config config;
        final World world;
        final long startedAt = System.currentTimeMillis();
        final List<Entity> spawned = new ArrayList<>();
        final java.util.Set<Entity> mobs = new java.util.HashSet<>();
        final java.util.Set<UUID> members = java.util.concurrent.ConcurrentHashMap.newKeySet();
        final Map<UUID, String> teamOf = new ConcurrentHashMap<>();
        int stage = 1;
        int maxStage = 1;
        int kills;
        int depth;
        boolean finished;
        boolean bossAlive;
        long deadline;
        /** Команда в Захвате флага (SURVIVOR-арена): общий счёт для двух групп. */
        String team = "";
        /** Флаг у игрока в руках (Захват флага). */
        boolean hasFlag;
        /** Убийца босса в Большой охоте - получает награду, остальные - половину. */
        boolean bossKiller;

        Run(Player player, EventType type, Config config, World world) {
            this.uuid = player.getUniqueId();
            this.player = player;
            this.owner = player;
            this.members.add(player.getUniqueId());
            this.type = type;
            this.config = config;
            this.world = world;
            this.deadline = startedAt + config.timeLimitSeconds() * 1000L;
        }
    }

    // ---------------------------------------------------------------
    //  Загрузка
    // ---------------------------------------------------------------

    public void init() {
        try {
            repository.createTable();
        } catch (Exception exception) {
            plugin.getLogger().severe("Испытания: не создалась таблица рекордов: " + exception.getMessage());
        }
        reload();
        // Монстр Лабиринта должен «дышать» отдельно от обычных мобов: раз в секунду.
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
        registerTitles();
        lastWeek = weekKey();
        scheduleWeekReset();
    }

    public void shutdown() {
        if (ticker != null) {
            ticker.cancel();
        }
        for (Run run : runs.values()) {
            cleanup(run);
        }
        runs.clear();
    }

    public void reload() {
        File file = plugin.getFiles().file("events.yml");
        if (!file.exists()) {
            plugin.getFiles().save("events.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        worldName = cfg.getString("world", "adventurers_events");
        huntWorldName = cfg.getString("hunt-world", "");
        attemptsPerDay = Math.max(0, cfg.getInt("attempts-per-day", 5));
        weeklyBonus = Math.max(0.5, cfg.getDouble("weekly-bonus", 1.0));
        rankScale.clear();
        ConfigurationSection scale = cfg.getConfigurationSection("rank-scale");
        if (scale != null) {
            for (String key : scale.getKeys(false)) {
                Rank rank = Rank.fromInput(key);
                if (rank != null) {
                    rankScale.put(rank, Math.max(0.1, scale.getDouble(key, 1.0)));
                }
            }
        }
        seasonStartEpochDay = LocalDate.parse(cfg.getString("season-start", "2026-01-05")).toEpochDay();
        resetDayOfWeek = Math.max(1, Math.min(7, cfg.getInt("reset-day-of-week", 1)));
        resetHour = Math.max(0, Math.min(23, cfg.getInt("reset-hour", 4)));
        announce = cfg.getBoolean("announce", true);

        configs.clear();
        ConfigurationSection section = cfg.getConfigurationSection("events");
        if (section == null) {
            plugin.getLogger().warning("events.yml: нет раздела events - испытания выключены");
            return;
        }
        for (String key : section.getKeys(false)) {
            EventType type = EventType.fromInput(key);
            if (type == null) {
                plugin.getLogger().warning("events.yml: неизвестное испытание " + key);
                continue;
            }
            ConfigurationSection s = section.getConfigurationSection(key);
            if (s == null) {
                continue;
            }
            configs.put(type, parse(type, s));
        }
    }

    private Config parse(EventType type, ConfigurationSection s) {
        List<EntityType> mobs = new ArrayList<>();
        for (String name : s.getStringList("mobs")) {
            EntityType entity = entity(name);
            if (entity == null) {
                plugin.getLogger().warning("events.yml/" + type.getId() + ": нет моба " + name);
            } else {
                mobs.add(entity);
            }
        }
        if (mobs.isEmpty()) {
            mobs.add(EntityType.ZOMBIE);
        }
        EntityType boss = entity(s.getString("boss", "WITHER_SKELETON"));
        String color = type.getColor();
        return new Config(type,
                s.getBoolean("open", true),
                Math.max(1, s.getInt("stages", 20)),
                Math.max(0, s.getInt("boss-every", 5)),
                s.getInt("arena.x", 0), s.getInt("arena.y", 100), s.getInt("arena.z", 0),
                Math.max(5, s.getInt("arena.radius", 14)),
                Math.max(60, s.getInt("time-limit-seconds", 600)),
                Math.max(0, s.getInt("attempts", attemptsPerDay)),
                mobs, boss == null ? EntityType.ZOMBIE : boss,
                s.getDouble("hp-base", 20), s.getDouble("hp-growth", 1.18),
                s.getDouble("dmg-base", 3), s.getDouble("dmg-growth", 1.10),
                s.getInt("mob-base", 4), s.getInt("mob-growth", 1),
                s.getLong("coins-base", 120), s.getDouble("coins-growth", 1.20),
                s.getInt("points-base", 4), s.getDouble("points-growth", 1.12),
                s.getInt("loot-base", 1), s.getInt("loot-every", 3),
                material(s.getString("theme.floor"), Material.POLISHED_BLACKSTONE_BRICKS),
                material(s.getString("theme.wall"), Material.DEEPSLATE_BRICKS),
                material(s.getString("theme.light"), Material.SOUL_LANTERN),
                material(s.getString("theme.accent"), Material.CRYING_OBSIDIAN),
                s.getStringList("rewards"),
                s.getString("title-unlock", ""));
    }

    private static EntityType entity(String name) {
        if (name == null || name.isBlank()) {
            return null;
        }
        try {
            return EntityType.valueOf(name.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            return null;
        }
    }

    private static Material material(String name, Material fallback) {
        Material parsed = name == null ? null : Material.matchMaterial(name.trim().toUpperCase(Locale.ROOT));
        return parsed == null ? fallback : parsed;
    }

    // ---------------------------------------------------------------
    //  Какая неделя и какое испытание
    // ---------------------------------------------------------------

    /** Ключ недели: "2026-W47". По нему хранятся рекорды. */
    public String weekKey() {
        LocalDate today = LocalDate.now();
        WeekFields fields = WeekFields.ISO;
        int week = today.get(fields.weekOfWeekBasedYear());
        int year = today.get(fields.weekBasedYear());
        return year + "-W" + String.format("%02d", week);
    }

    /** Номер недели сезона: 0, 1, 2... от season-start. */
    public int seasonWeek() {
        long days = LocalDate.now().toEpochDay() - seasonStartEpochDay;
        return (int) Math.max(0, days / 7);
    }

    /** Испытание этой недели: восемь режимов по кругу. */
    public EventType current() {
        EventType[] all = openTypes();
        if (all.length == 0) {
            return EventType.TOWER;
        }
        return all[seasonWeek() % all.length];
    }

    private EventType[] openTypes() {
        List<EventType> list = new ArrayList<>();
        for (EventType type : EventType.values()) {
            Config config = configs.get(type);
            if (config != null && config.open()) {
                list.add(type);
            }
        }
        return list.toArray(new EventType[0]);
    }

    public Config config(EventType type) {
        return configs.get(type);
    }

    public boolean isEnabled() {
        return enabled;
    }

    /** Сколько попыток осталось сегодня. */
    public int attemptsLeft(Player player, EventType type) {
        Config config = configs.get(type);
        if (config == null || config.attemptLimit() == 0) {
            return config == null ? 0 : 99;
        }
        String today = LocalDate.now().toString();
        if (!today.equals(attemptsDay.get(player.getUniqueId()))) {
            return config.attemptLimit();
        }
        int[] used = attemptsUsed.get(player.getUniqueId());
        return Math.max(0, config.attemptLimit() - (used == null ? 0 : used[0]));
    }

    private void useAttempt(Player player) {
        String today = LocalDate.now().toString();
        String known = attemptsDay.get(player.getUniqueId());
        if (!today.equals(known)) {
            attemptsDay.put(player.getUniqueId(), today);
            attemptsUsed.put(player.getUniqueId(), new int[]{0});
        }
        attemptsUsed.computeIfAbsent(player.getUniqueId(), key -> new int[]{0})[0]++;
    }

    // ---------------------------------------------------------------
    //  Запуск и остановка забега
    // ---------------------------------------------------------------

    /** Телепорт на арену и старт первой ступени. */
    public void join(Player player, EventType type) {
        if (!enabled) {
            messages.send(player, "events.disabled");
            return;
        }
        Config config = configs.get(type);
        if (config == null || !config.open()) {
            messages.send(player, "events.closed");
            return;
        }
        if (runs.containsKey(player.getUniqueId())) {
            messages.send(player, "events.already");
            return;
        }
        if (attemptsLeft(player, type) <= 0) {
            messages.send(player, "events.no-attempts");
            return;
        }
        // «Последний выживший» и «Осада» - общий забег: один на весь сервер, как и задумано
        // (общая арена, общий счёт). Личный забег в них заводить нельзя: два игрока
        // одновременно затоптали бы одну арену и удвоили мобов друг другу.
        if (type == EventType.SURVIVOR || type == EventType.SIEGE || type == EventType.FLAG) {
            joinShared(player, type, config);
            return;
        }
        World world = huntWorld(type);
        if (world == null) {
            messages.send(player, "events.world-error");
            return;
        }
        useAttempt(player);
        Run run = new Run(player, type, config, world);
        runs.put(player.getUniqueId(), run);
        buildArena(run);
        Location start = startPoint(run);
        player.teleport(start);
        messages.send(player, "events.started", Map.of(
                "event", type.coloredName(),
                "stage", String.valueOf(1),
                "time", String.valueOf(config.timeLimitSeconds() / 60)));
        spawnStage(run);
    }

    /**
     * Общий забег: все игроки на одной арене, мобы общие, счёт тоже.
     * Второй игрок не создаёт новый забег, а подключается к существующему.
     */
    private void joinShared(Player player, EventType type, Config config) {
        Run shared = null;
        for (Run run : runs.values()) {
            if (run.type == type) {
                shared = run;
                break;
            }
        }
        if (shared == null) {
            World world = EventArena.world(worldName);
            if (world == null) {
                messages.send(player, "events.world-error");
                return;
            }
            shared = new Run(player, type, config, world);
            runs.put(player.getUniqueId(), shared);
            buildArena(shared);
            spawnStage(shared);
            Bukkit.getOnlinePlayers().forEach(viewer -> messages.send(viewer, "events.shared-start",
                    Map.of("event", type.coloredName())));
        }
        Location start = new Location(shared.world, config.centerX() + 0.5, config.centerY() + 1,
                config.centerZ() + 0.5);
        player.teleport(start);
        if (type == EventType.FLAG) {
            shared.members.add(player.getUniqueId());
            // команды делятся по половинам: A и B, флаг у одной из них
            shared.teamOf.put(player.getUniqueId(), shared.teamOf.size() % 2 == 0 ? "A" : "B");
        }
        messages.send(player, "events.started", Map.of(
                "event", type.coloredName(),
                "stage", String.valueOf(shared.stage),
                "time", String.valueOf(config.timeLimitSeconds() / 60)));
    }

    /**
     * Большая охота идёт в обычном мире сервера (events.yml: hunt-world), а не на арене:
     * босс недели должен встретиться там, где игрок и так гуляет. Остальные - в мире арен.
     */
    private World huntWorld(EventType type) {
        if (type == EventType.HUNT && huntWorldName != null && !huntWorldName.isBlank()) {
            World world = Bukkit.getWorld(huntWorldName);
            if (world != null) {
                return world;
            }
        }
        return EventArena.world(worldName);
    }

    private Location startPoint(Run run) {
        Config config = run.config;
        return switch (run.type) {
            case TOWER -> EventArena.towerFloor(run.world, config.centerX(), config.centerY(),
                    config.centerZ(), 1, config.radius(), config.floor(), config.wall(), config.light());
            case MAZE -> new Location(run.world, config.centerX() + 1.5, config.centerY() + 1,
                    config.centerZ() + 1.5);
            case MINE -> EventArena.shaft(run.world, config.centerX(), config.centerY(),
                    config.centerZ(), Math.min(60, config.stages() * 3), config.wall(),
                    new Material[]{Material.DIAMOND_ORE, Material.GOLD_ORE, Material.IRON_ORE,
                            Material.EMERALD_ORE, Material.REDSTONE_ORE},
                    config.light(), seedFor(run.type));
            default -> EventArena.platform(run.world, config.centerX(), config.centerY(),
                    config.centerZ(), config.radius(), 4, config.floor(), config.wall(), config.light());
        };
    }

    private long seedFor(EventType type) {
        // один лабиринт на неделю: иначе рекорды по времени нельзя сравнивать
        return type.getId().hashCode() * 31L + weekKey().hashCode();
    }

    private void buildArena(Run run) {
        Config config = run.config;
        if (run.type == EventType.HUNT && huntWorldName != null && !huntWorldName.isBlank()
                && run.world.getName().equals(huntWorldName)) {
            return;   // в обычном мире ничего не строим: босс появляется рядом с игроком
        }
        EventArena.clear(run.world, config.centerX(), config.centerY() - 2, config.centerZ(),
                config.radius() + 6, 80);
        if (run.type == EventType.MAZE) {
            EventArena.maze(run.world, config.centerX(), config.centerY(), config.centerZ(),
                    12, seedFor(run.type), config.floor(), config.wall(), Material.GOLD_BLOCK);
        } else if (run.type != EventType.MINE) {
            EventArena.platform(run.world, config.centerX(), config.centerY(), config.centerZ(),
                    config.radius(), 4, config.floor(), config.wall(), config.light());
        }
    }

    /** Заспавнить мобов ступени вокруг арены. */
    private void spawnStage(Run run) {
        Config config = run.config;
        List<EventStage> stages = config.stages(weeklyBonus);
        if (run.stage > stages.size()) {
            finish(run, true);
            return;
        }
        EventStage stage = stages.get(run.stage - 1);
        run.bossAlive = stage.boss();
        run.maxStage = Math.max(run.maxStage, run.stage);
        Location center = run.type == EventType.HUNT
                ? run.player.getLocation().clone().add(6, 0, 0)
                : run.type == EventType.MAZE
                ? new Location(run.world, config.centerX() + 6, config.centerY() + 1, config.centerZ() + 6)
                : new Location(run.world, config.centerX() + 0.5, config.centerY() + 1, config.centerZ() + 0.5);
        // В Большой охоте не толпа: босс и небольшая свита, иначе это не охота, а мясорубка.
        int count = run.type == EventType.HUNT ? Math.min(4, stage.mobs()) : Math.min(24, stage.mobs());
        for (int i = 0; i < count; i++) {
            EntityType type = config.mobs().get(random.nextInt(config.mobs().size()));
            spawn(run, type, center, stage, false);
        }
        if (stage.boss()) {
            spawn(run, config.boss(), center, stage, true);
            messageAll(run, "events.boss", Map.of(
                    "stage", String.valueOf(stage.index()),
                    "event", run.type.coloredName()));
        }
        messageAll(run, "events.stage", Map.of(
                "stage", String.valueOf(stage.index()),
                "stages", String.valueOf(stages.size()),
                "mobs", String.valueOf(count)));
    }

    private void spawn(Run run, EntityType type, Location center, EventStage stage, boolean boss) {
        int spread = Math.max(3, run.config.radius() - 3);
        Location at = center.clone().add(random.nextInt(spread * 2) - spread, 0,
                random.nextInt(spread * 2) - spread);
        Entity entity = run.world.spawnEntity(at, type);
        if (entity instanceof LivingEntity living) {
            living.setPersistent(false);
            var maxHealth = living.getAttribute(Attribute.MAX_HEALTH);
            if (maxHealth != null) {
                double hp = Math.max(1, stage.hpFactor() * (boss ? 8 : 1));
                maxHealth.setBaseValue(hp);
                living.setHealth(hp);
            }
            var damage = living.getAttribute(Attribute.ATTACK_DAMAGE);
            if (damage != null) {
                damage.setBaseValue(Math.max(1, stage.dmgFactor()));
            }
            living.customName(Hud.legacy((boss ? "&c&lБОСС " : run.type.getColor())
                    + (boss ? type.name() : type.name()) + " &8[" + stage.index() + "]"));
            living.setCustomNameVisible(boss);
            // мобов нельзя увести с арены: они всегда возвращаются к центру
            if (living instanceof Mob mob) {
                mob.setRemoveWhenFarAway(false);
                mob.setTarget(run.player);
            }
            living.getPersistentDataContainer().set(eventMobKey(), PersistentDataType.STRING,
                    run.uuid.toString());
            run.mobs.add(living);
        }
        run.spawned.add(entity);
    }

    private org.bukkit.NamespacedKey eventMobKey() {
        return new org.bukkit.NamespacedKey(plugin, "event_mob");
    }

    /** Общий забег закончился: каждый участник получает свою награду и свой рекорд. */
    private void endShared(Run run) {
        if (run.finished) {
            return;
        }
        run.finished = true;
        runs.values().removeIf(value -> value == run);
        cleanup(run);
        List<EventStage> stages = run.config.stages(weeklyBonus);
        EventStage reached = run.stage <= stages.size() ? stages.get(Math.max(0, run.stage - 1)) : null;
        for (UUID member : run.members) {
            Player player = Bukkit.getPlayer(member);
            if (player == null || !player.isOnline()) {
                continue;
            }
            if (reached != null) {
                reward(player, reached, run);
            }
            messages.send(player, "events.finished", Map.of(
                    "event", run.type.coloredName(),
                    "stage", String.valueOf(run.stage),
                    "stages", String.valueOf(stages.size()),
                    "time", EventRecord.time(System.currentTimeMillis() - run.startedAt),
                    "coins", String.valueOf(reached == null ? 0 : Math.round(reached.coins() * rankScale(player))),
                    "points", String.valueOf(reached == null ? 0 : Math.round(reached.points() * rankScale(player)))));
            EventRecord record = new EventRecord(member, player.getName(), run.type, weekKey(),
                    run.stage, System.currentTimeMillis() - run.startedAt, 1, System.currentTimeMillis());
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    repository.save(record);
                } catch (Exception exception) {
                    plugin.getLogger().warning("Испытания: рекорд не сохранился: " + exception.getMessage());
                }
            });
        }
    }

    /** Забег завершён: награда за лучшую ступень, запись рекорда, телепорт обратно. */
    private void finish(Run run, boolean success) {
        if (run.finished) {
            return;
        }
        run.finished = true;
        runs.remove(run.uuid);
        cleanup(run);
        Player player = run.player;
        if (!player.isOnline()) {
            saveRecord(run);
            return;
        }
        if (run.type != EventType.MINE) {
            // Возврат туда, откуда пришёл: у каждого игрока свой спавн сервера.
        }
        int stage = run.maxStage;
        List<EventStage> stages = run.config.stages(weeklyBonus);
        EventStage reached = stage >= 1 && stage <= stages.size() ? stages.get(stage - 1) : null;
        if (success && reached != null) {
            reward(player, reached, run);
        }
        saveRecord(run);
        messages.send(player, success ? "events.finished" : "events.failed", Map.of(
                "event", run.type.coloredName(),
                "stage", String.valueOf(stage),
                "stages", String.valueOf(stages.size()),
                "time", EventRecord.time(System.currentTimeMillis() - run.startedAt),
                "coins", String.valueOf(reached == null ? 0 : Math.round(reached.coins() * rankScale(player))),
                "points", String.valueOf(reached == null ? 0 : Math.round(reached.points() * rankScale(player)))));
    }

    /**
     * Множитель награды по рангу: на F испытание не должно платить как на S, и наоборот.
     * Значения в events.yml (rank-scale), по умолчанию - линейка из economy.yml rank-income.
     */
    private double rankScale(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null || rankScale.isEmpty()) {
            return 1.0;
        }
        return rankScale.getOrDefault(profile.getRank(), 1.0);
    }

    private void reward(Player player, EventStage stage, Run run) {
        double scale = rankScale(player);
        long coins = Math.round(stage.coins() * scale);
        int points = (int) Math.round(stage.points() * scale);
        if (plugin.getEconomy() != null && coins > 0) {
            plugin.getEconomy().reward(player, coins, "economy.reward-event");
        }
        if (points > 0 && plugin.getQuests() != null) {
            plugin.getQuests().adminAddPoints(player, points);
        }
        // Табличные награды недели (events.yml: rewards): выдаются за ЛУЧШУЮ ступень один раз.
        List<String> loot = run.config.rewards();
        for (int i = 0; i < Math.min(stage.lootRolls(), loot.size()); i++) {
            String spec = loot.get(i);
            ItemStack stack = parseReward(spec);
            if (stack != null) {
                player.getInventory().addItem(stack).values()
                        .forEach(left -> player.getWorld().dropItemNaturally(player.getLocation(), left));
            }
        }
    }

    /** "DIAMOND:3" -> предмет; "rune:tank_bulwark" -> руна, если модуль рун загружен. */
    private ItemStack parseReward(String spec) {
        if (spec == null || spec.isBlank()) {
            return null;
        }
        if (spec.startsWith("rune:") && plugin.getRunes() != null) {
            return plugin.getRunes().create(spec.substring(5), 1);
        }
        String[] parts = spec.split(":");
        Material material = Material.matchMaterial(parts[0].trim().toUpperCase(Locale.ROOT));
        if (material == null) {
            return null;
        }
        int amount = parts.length > 1 ? Math.max(1, parseInt(parts[1])) : 1;
        return new ItemStack(material, amount);
    }

    private static int parseInt(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException exception) {
            return 1;
        }
    }

    private void cleanup(Run run) {
        for (Entity entity : run.spawned) {
            if (entity != null && entity.isValid()) {
                entity.remove();
            }
        }
        run.spawned.clear();
        run.mobs.clear();
    }

    private void saveRecord(Run run) {
        String week = weekKey();
        EventRecord record = new EventRecord(run.uuid, run.player.getName(), run.type, week,
                run.maxStage, System.currentTimeMillis() - run.startedAt, 1, System.currentTimeMillis());
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                EventRecord existing = repository.load(week, run.type, run.uuid);
                repository.save(existing == null ? record
                        : existing.withStage(run.maxStage, System.currentTimeMillis() - run.startedAt));
            } catch (Exception exception) {
                plugin.getLogger().warning("Испытания: рекорд не сохранился: " + exception.getMessage());
            }
        });
    }

    // ---------------------------------------------------------------
    //  Тик: время, Лабиринт, выживший, шахта
    // ---------------------------------------------------------------

    /**
     * Смена недели: считается раз в минуту. Когда ключ недели изменился, закрываем прошлую
     * (выдаём призы топ-3 и титулы) и объявляем новое испытание.
     *
     * <p>Проверка идёт в тике, а не по таймеру на точное время: сервер может быть выключен
     * в 4 утра понедельника, и тогда призы должны выдаться при первом же запуске, а не
     * потеряться. Двойной выдачи не будет - в БД стоит флаг rewarded.
     */
    public void scheduleWeekReset() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::checkWeek, 20L * 60L, 20L * 60L);
    }

    private void checkWeek() {
        String week = weekKey();
        if (week.equals(lastWeek)) {
            return;
        }
        EventType previous = typeFor(lastWeek);
        lastWeekKey = lastWeek;
        lastWeek = week;
        if (previous != null) {
            closeWeek(previous, lastWeekKey);
        }
        EventType current = current();
        if (announce) {
            Bukkit.getOnlinePlayers().forEach(viewer -> messages.send(viewer, "events.new-week",
                    Map.of("event", current.coloredName(), "week", String.valueOf(seasonWeek() + 1))));
        }
    }

    /** Ключ предыдущей недели: для закрытия нужно именно он, а не текущий. */
    private String lastWeekKey = "";

    private EventType typeFor(String week) {
        if (week == null || week.isBlank()) {
            return null;
        }
        // испытание недели считается от season-start, поэтому для прошлой недели
        // достаточно отнять у номера недели сезона единицу
        EventType[] all = openTypes();
        if (all.length == 0) {
            return null;
        }
        int index = Math.max(0, seasonWeek() - 1) % all.length;
        return all[index];
    }

    private void tick() {
        tick++;
        long now = System.currentTimeMillis();
        for (Run run : new ArrayList<>(runs.values())) {
            Player player = run.player;
            if (run.members.size() > 1 || (run.owner != null && !run.owner.getUniqueId().equals(run.uuid))) {
                // общий забег живёт, пока на арене есть хоть один участник
                boolean anyOnline = run.members.stream().map(Bukkit::getPlayer)
                        .anyMatch(member -> member != null && member.isOnline()
                                && member.getWorld() == run.world);
                if (!anyOnline) {
                    endShared(run);
                    continue;
                }
            } else if (!player.isOnline() || player.getWorld() != run.world) {
                finish(run, false);
                continue;
            }
            if (run.world != player.getWorld()) {
                finish(run, false);   // вышел из мира - забег закрыт
                continue;
            }
            if (now > run.deadline) {
                finish(run, run.type == EventType.SURVIVOR || run.type == EventType.MINE);
                continue;
            }
            switch (run.type) {
                case MAZE -> tickMaze(run, now);
                case MINE -> tickMine(run);
                case TOWER, SIEGE, BLOOD_MOON, FLAG, HUNT -> {
                    // волна считается пройденной, когда все мобы ступени мертвы
                    if (run.mobs.stream().noneMatch(entity -> entity.isValid() && !entity.isDead())) {
                        nextStage(run);
                    }
                }
                case SURVIVOR -> {
                    if (run.mobs.stream().noneMatch(entity -> entity.isValid() && !entity.isDead())) {
                        nextStage(run);
                    }
                }
            }
        }
    }

    /** Следующая ступень: +1 и новый спавн; после последней - победа. */
    private void nextStage(Run run) {
        if (run.finished) {
            return;
        }
        List<EventStage> stages = run.config.stages(weeklyBonus);
        if (run.stage >= stages.size()) {
            finish(run, true);
            return;
        }
        run.stage++;
        run.mobs.removeIf(entity -> !entity.isValid() || entity.isDead());
        spawnStage(run);
    }

    /**
     * Лабиринт: Пожиратель идёт по следу игрока и не убивается. Чем дольше игрок бегает,
     * тем выше ступень (каждые 45 секунд) - то есть награда растёт со временем, а не с убийствами.
     */
    private void tickMaze(Run run, long now) {
        int minutes = (int) ((now - run.startedAt) / 45_000L) + 1;
        if (minutes > run.stage) {
            run.stage = Math.min(run.config.stages(), minutes);
            run.maxStage = Math.max(run.maxStage, run.stage);
        }
        // выход: игрок рядом с золотым блоком
        int span = 12 * 3;
        Location exit = new Location(run.world, run.config.centerX() + span + 0.5,
                run.config.centerY() + 1, run.config.centerZ() + span + 0.5);
        if (run.player.getLocation().distanceSquared(exit) < 6) {
            finish(run, true);
        }
    }

    /** Шахта: глубина игрока - это ступень; каждые 3 блока вниз - новая ступень. */
    private void tickMine(Run run) {
        int depth = Math.max(0, run.config.centerY() - run.player.getLocation().getBlockY());
        run.depth = depth;
        int stage = Math.min(run.config.stages(), depth / 3 + 1);
        if (stage > run.stage) {
            run.stage = stage;
            run.maxStage = Math.max(run.maxStage, stage);
            messageAll(run, "events.depth", Map.of(
                    "stage", String.valueOf(stage),
                    "depth", String.valueOf(depth)));
        }
    }

    // ---------------------------------------------------------------
    //  События: смерть мобов, урон, выход
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMobDeath(EntityDeathEvent event) {
        if (event.getEntity().getKiller() == null) {
            return;
        }
        for (Run run : runs.values()) {
            if (run.mobs.remove(event.getEntity())) {
                run.kills++;
                // В выжившем и осаде счёт - убийства: волны идут, даже если мобы ещё живы.
                if (run.type == EventType.SURVIVOR || run.type == EventType.SIEGE
                        || run.type == EventType.BLOOD_MOON) {
                    int perStage = Math.max(1, run.config.mobBase());
                    int stage = Math.min(run.config.stages(), run.kills / perStage + 1);
                    if (stage > run.stage) {
                        run.stage = stage;
                        run.maxStage = Math.max(run.maxStage, stage);
                        spawnStage(run);
                    }
                }
                event.getDrops().clear();   // добыча идёт через награду ступени, а не с пола
                return;
            }
        }
    }

    /** Пожиратель в лабиринте: урон проходит всегда, убить его нельзя. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        Run run = runs.get(player.getUniqueId());
        if (run == null || run.type != EventType.MAZE) {
            return;
        }
        Entity damager = event.getDamager();
        if (damager.getPersistentDataContainer().has(eventMobKey(), PersistentDataType.STRING)) {
            // Пожиратель бьёт больно, но не убивает с одного удара: 35% текущего здоровья.
            double health = player.getHealth();
            event.setDamage(Math.min(event.getDamage(), Math.max(2, health * 0.35)));
            player.sendActionBar(Hud.legacy("&8Пожиратель рядом! &7Беги к выходу."));
        }
    }

    /**
     * Захват флага: сдал флаг - ступень. Флаг выдаётся в меню испытания (клик по кнопке),
     * а сдаётся на своей базе: блок-акцент на краю арены.
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(org.bukkit.event.player.PlayerInteractEvent event) {
        Player player = event.getPlayer();
        Run run = runs.get(player.getUniqueId());
        if (run == null || run.type != EventType.FLAG || event.getClickedBlock() == null) {
            return;
        }
        if (event.getClickedBlock().getType() != Material.LODESTONE) {
            return;
        }
        if (!run.hasFlag) {
            return;
        }
        run.hasFlag = false;
        ItemStack flag = new ItemStack(Material.WHITE_BANNER);
        player.getInventory().remove(flag);
        run.stage = Math.min(run.config.stages(), run.stage + 1);
        run.maxStage = Math.max(run.maxStage, run.stage);
        messages.send(player, "events.flag", Map.of("stage", String.valueOf(run.stage)));
        if (run.stage >= run.config.stages()) {
            endShared(run);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Run run = runs.remove(event.getPlayer().getUniqueId());
        if (run != null) {
            finish(run, false);
        }
        attemptsUsed.remove(event.getPlayer().getUniqueId());
        attemptsDay.remove(event.getPlayer().getUniqueId());
    }

    // ---------------------------------------------------------------
    //  Топы, рекорды, титулы
    // ---------------------------------------------------------------

    /** Топ недели (синхронно, только для меню и команд: список короткий). */
    public List<EventRecord> top(EventType type, int limit) {
        try {
            return repository.top(weekKey(), type, limit);
        } catch (Exception exception) {
            plugin.getLogger().warning("Испытания: топ не прочитался: " + exception.getMessage());
            return List.of();
        }
    }

    public EventRecord record(Player player, EventType type) {
        try {
            return repository.load(weekKey(), type, player.getUniqueId());
        } catch (Exception exception) {
            return null;
        }
    }

    /**
     * Закрыть неделю: выдать призовые топ-3 и повесить титулы. Вызывается вручную
     * (/ag admin event close) и автоматически при смене недели, один раз (флаг в БД).
     */
    public void closeWeek(EventType type) {
        closeWeek(type, weekKey());
    }

    /**
     * Призы топ-3 недели: доля от награды за лучшую ступень испытания.
     * 1 место - 1.6 лучшей ступени, 2 - 0.8, 3 - 0.4. То есть победитель недели
     * получает примерно полторы награды за прохождение, а не поток монет.
     */
    private long[] prizes(EventType type) {
        Config config = configs.get(type);
        if (config == null) {
            return new long[]{500, 250, 100};
        }
        List<EventStage> stages = config.stages(weeklyBonus);
        long best = stages.isEmpty() ? 500 : stages.get(stages.size() - 1).coins();
        return new long[]{
                Math.round(best * 1.6),
                Math.round(best * 0.8),
                Math.round(best * 0.4)};
    }

    public void closeWeek(EventType type, String week) {
        try {
            if (repository.rewarded(week, type)) {
                return;
            }
            List<EventRecord> top = repository.top(week, type, 3);
            List<UUID> winners = new ArrayList<>();
            // Призы недели считаются от награды ЗА СТУПЕНЬ, а не от coins-base: у испытаний
            // база подобрана под баланс (у флага она в 25 раз выше), и призы «x40 базы»
            // дали бы 11 000 монет за первое место вместо ~2 000.
            long[] prizes = prizes(type);
            for (int i = 0; i < top.size(); i++) {
                EventRecord row = top.get(i);
                winners.add(row.uuid());
                Player online = Bukkit.getPlayer(row.uuid());
                if (online != null && plugin.getEconomy() != null) {
                    plugin.getEconomy().reward(online, prizes[Math.min(i, prizes.length - 1)],
                            "economy.reward-event-top");
                }
                if (announce) {
                    String place = String.valueOf(i + 1);
                    Bukkit.getOnlinePlayers().forEach(viewer -> messages.send(viewer, "events.top-announce",
                            Map.of("place", place, "player", row.playerName(),
                                    "stage", String.valueOf(row.bestStage()),
                                    "event", type.coloredName())));
                }
            }
            repository.closeWeek(week, type, winners);
            // Титул победителя недели: other:event-top держится, пока игрок в топе хоть раз
            awardedTop.put(type, new java.util.HashSet<>(winners));
        } catch (Exception exception) {
            plugin.getLogger().warning("Испытания: не удалось закрыть неделю: " + exception.getMessage());
        }
    }

    /** Победители прошлых недель в памяти: титул «Победитель недели» должен работать и после. */
    private final Map<EventType, java.util.Set<UUID>> awardedTop =
            java.util.Collections.synchronizedMap(new java.util.HashMap<>());

    /** Регистрация условий титулов: other:event-<id>-<ступень> и other:event-top. */
    private void registerTitles() {
        if (plugin.getGlory() == null) {
            return;
        }
        plugin.getGlory().registerUnlock("event-top", player -> awardedTop.values().stream()
                .anyMatch(set -> set.contains(player.getUniqueId())));
        for (EventType type : EventType.values()) {
            Config config = configs.get(type);
            int stages = config == null ? 20 : config.stages();
            for (int stage : new int[]{5, 10, 15, 20, stages}) {
                String key = "event-" + type.getId() + "-" + stage;
                plugin.getGlory().registerUnlock(key, player -> bestStage(player, type) >= stage);
            }
            plugin.getGlory().registerUnlock("event-" + type.getId() + "-boss",
                    player -> bestStage(player, type) >= (config == null ? 5 : config.bossEvery()));
        }
    }

    /** Лучшая ступень игрока в испытании: рекорд текущей недели и сохранённый в профиле. */
    public int bestStage(Player player, EventType type) {
        EventRecord record = record(player, type);
        return record == null ? 0 : record.bestStage();
    }

    // ---------------------------------------------------------------
    //  Сообщения и меню
    // ---------------------------------------------------------------

    private void messageAll(Run run, String key, Map<String, String> placeholders) {
        if (run.player.isOnline()) {
            messages.send(run.player, key, placeholders);
        }
    }

    /** Меню испытания: описание, ступени, рекорд, топ-3, кнопка входа. */
    public void open(Player player) {
        EventType current = current();
        Config config = configs.get(current);
        Inventory inventory = Bukkit.createInventory(new MenuHolder(current), 45,
                Hud.legacy(current.getColor() + current.getDisplayName()));
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.displayName(Component.empty());
            filler.setItemMeta(fillerMeta);
        }
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
        // описание
        ItemStack info = new ItemStack(config == null ? Material.BARRIER : Material.BOOK);
        ItemMeta infoMeta = info.getItemMeta();
        if (infoMeta != null) {
            infoMeta.displayName(Hud.legacy(current.getColor() + "&l" + current.getDisplayName()));
            List<Component> lines = new ArrayList<>();
            lines.add(Hud.legacy("&7" + current.getDescription()));
            lines.add(Component.empty());
            if (config != null) {
                lines.add(Hud.legacy("&7Ступеней: &f" + config.stages()
                        + " &7(босс каждые &f" + config.bossEvery() + "&7)"));
                lines.add(Hud.legacy("&7Лимит времени: &f" + (config.timeLimitSeconds() / 60) + " мин"));
                lines.add(Hud.legacy("&7Попыток сегодня: &f" + attemptsLeft(player, current)
                        + "&7/&f" + config.attemptLimit()));
            }
            EventRecord mine = record(player, current);
            lines.add(Hud.legacy("&7Твой рекорд: &f" + (mine == null ? "—"
                    : mine.bestStage() + " ступень · " + EventRecord.time(mine.bestMillis()))));
            infoMeta.lore(lines);
            info.setItemMeta(infoMeta);
        }
        inventory.setItem(4, info);

        // ступени: первые 20 в сетке, начиная со слота 9
        if (config != null) {
            List<EventStage> stages = config.stages(weeklyBonus);
            int slot = 9;
            for (EventStage stage : stages) {
                if (slot >= 36) {
                    break;
                }
                boolean reached = bestStage(player, current) >= stage.index();
                ItemStack item = new ItemStack(stage.boss() ? Material.WITHER_SKELETON_SKULL
                        : reached ? Material.LIME_STAINED_GLASS_PANE : Material.LIGHT_GRAY_STAINED_GLASS_PANE);
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.displayName(Hud.legacy((stage.boss() ? "&c&l" : "&f")
                            + stage.index() + (stage.boss() ? "-я ступень · БОСС" : "-я ступень")));
                    meta.lore(List.of(
                            Hud.legacy("&7Мобов: &f" + stage.mobs() + " &7· HP x&f" + format(stage.hpFactor())),
                            Hud.legacy("&7Награда: &6" + stage.coins() + " монет &7· &b"
                                    + stage.points() + " очков"),
                            Hud.legacy(reached ? "&aПройдено" : "&8Ещё не пройдено")));
                    item.setItemMeta(meta);
                }
                inventory.setItem(slot++, item);
            }
        }

        // кнопка входа
        ItemStack enter = new ItemStack(Material.ENDER_PEARL);
        ItemMeta enterMeta = enter.getItemMeta();
        if (enterMeta != null) {
            enterMeta.displayName(Hud.legacy("&a&lВойти в испытание"));
            enterMeta.lore(List.of(
                    Hud.legacy("&7Нажми, чтобы начать забег."),
                    Hud.legacy("&8Топ-3 недели получают призовые и титул.")));
            enter.setItemMeta(enterMeta);
        }
        inventory.setItem(40, enter);

        // топ-3
        int slot = 36;
        for (EventRecord row : top(current, 3)) {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            ItemMeta headMeta = head.getItemMeta();
            if (headMeta instanceof org.bukkit.inventory.meta.SkullMeta skull) {
                skull.setOwningPlayer(Bukkit.getOfflinePlayer(row.uuid()));
                skull.displayName(Hud.legacy("&e" + (37 - slot + 36) + ". &f" + row.playerName()));
                skull.lore(List.of(Hud.legacy("&7Ступень: &f" + row.bestStage()
                        + " &7· время &f" + EventRecord.time(row.bestMillis()))));
                head.setItemMeta(headMeta);
            }
            inventory.setItem(slot, head);
            slot++;
        }
        player.openInventory(inventory);
    }

    private static String format(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    /** Владелец меню испытаний: по нему ловим клик. */
    public static final class MenuHolder implements InventoryHolder {
        private final EventType type;
        private Inventory inventory;

        public MenuHolder(EventType type) {
            this.type = type;
        }

        public EventType type() {
            return type;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }

        public void setInventory(Inventory inventory) {
            this.inventory = inventory;
        }
    }

    public boolean isEventMenu(Inventory inventory) {
        return inventory != null && inventory.getHolder() instanceof MenuHolder;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(org.bukkit.event.inventory.InventoryClickEvent event) {
        if (!isEventMenu(event.getInventory())) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getSlot() == 40) {
            player.closeInventory();
            EventType type = current();
            join(player, type);
            if (type == EventType.FLAG) {
                Run run = runs.get(player.getUniqueId());
                if (run != null) {
                    run.hasFlag = true;
                    ItemStack flag = new ItemStack(Material.WHITE_BANNER);
                    ItemMeta meta = flag.getItemMeta();
                    if (meta != null) {
                        meta.displayName(Hud.legacy("&bФлаг чужой базы"));
                        meta.lore(List.of(Hud.legacy("&7Сдай его на свой маяк (LODESTONE):"),
                                Hud.legacy("&7каждая сдача = +1 ступень.")));
                        flag.setItemMeta(meta);
                    }
                    player.getInventory().addItem(flag);
                }
            }
        }
    }
}
