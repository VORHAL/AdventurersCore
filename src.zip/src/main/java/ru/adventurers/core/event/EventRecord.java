package ru.adventurers.core.event;

import java.util.UUID;

/**
 * Личный рекорд игрока в испытании: до какой ступени дошёл, когда и с какой попытки.
 * Хранится в таблице event_records и в кэше на неделю.
 */
public record EventRecord(UUID uuid, String playerName, EventType type, String week,
                          int bestStage, long bestMillis, int attempts, long updatedAt) {

    public EventRecord withStage(int stage, long millis) {
        return new EventRecord(uuid, playerName, type, week, Math.max(bestStage, stage),
                bestStage >= stage ? Math.min(bestMillis, millis) : millis, attempts + 1,
                System.currentTimeMillis());
    }

    public EventRecord withAttempt() {
        return new EventRecord(uuid, playerName, type, week, bestStage, bestMillis, attempts + 1, updatedAt);
    }

    /** Время в формате 4:07 (минуты:секунды) для меню и топов. */
    public static String time(long millis) {
        if (millis <= 0) {
            return "—";
        }
        long totalSeconds = millis / 1000;
        return (totalSeconds / 60) + ":" + String.format("%02d", totalSeconds % 60);
    }
}
