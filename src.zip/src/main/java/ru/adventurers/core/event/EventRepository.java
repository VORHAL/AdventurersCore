package ru.adventurers.core.event;

import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.DatabaseManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Хранение рекордов испытаний и истории недель.
 *
 * <p>Две таблицы: ag_event_record (лучший результат игрока за конкретную неделю) и
 * ag_event_week (какое испытание шло, кто занял 1-3 место и получил ли награду).
 * Разделение важно: рекорд недели нужен для топов, а история недель - чтобы показать
 * «прошлые испытания» и не выдать награду дважды.
 */
public class EventRepository {

    private final AdventurersCore plugin;
    private final DatabaseManager database;

    public EventRepository(AdventurersCore plugin, DatabaseManager database) {
        this.plugin = plugin;
        this.database = database;
    }

    public void createTable() throws SQLException {
        String records = """
                CREATE TABLE IF NOT EXISTS ag_event_record (
                    week VARCHAR(12) NOT NULL,
                    event VARCHAR(16) NOT NULL,
                    uuid CHAR(36) NOT NULL,
                    player_name VARCHAR(16) NOT NULL,
                    best_stage INT NOT NULL DEFAULT 0,
                    best_millis BIGINT NOT NULL DEFAULT 0,
                    attempts INT NOT NULL DEFAULT 0,
                    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (week, event, uuid),
                    INDEX idx_event_top (week, event, best_stage)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        String weeks = """
                CREATE TABLE IF NOT EXISTS ag_event_week (
                    week VARCHAR(12) NOT NULL,
                    event VARCHAR(16) NOT NULL,
                    started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    rewarded TINYINT NOT NULL DEFAULT 0,
                    first_uuid CHAR(36) NULL,
                    second_uuid CHAR(36) NULL,
                    third_uuid CHAR(36) NULL,
                    PRIMARY KEY (week, event)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
                """;
        try (Connection connection = database.getConnection()) {
            for (String sql : List.of(records, weeks)) {
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.executeUpdate();
                }
            }
        }
    }

    /** Записать или обновить рекорд (upsert: берём максимум ступени, минимум времени). */
    public void save(EventRecord record) throws SQLException {
        String sql = """
                INSERT INTO ag_event_record (week, event, uuid, player_name, best_stage, best_millis, attempts)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    player_name = VALUES(player_name),
                    best_stage = GREATEST(best_stage, VALUES(best_stage)),
                    best_millis = IF(VALUES(best_stage) > best_stage, VALUES(best_millis),
                                     LEAST(best_millis, VALUES(best_millis))),
                    attempts = attempts + 1
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, record.week());
            statement.setString(2, record.type().name());
            statement.setString(3, record.uuid().toString());
            statement.setString(4, record.playerName());
            statement.setInt(5, record.bestStage());
            statement.setLong(6, record.bestMillis());
            statement.setInt(7, record.attempts());
            statement.executeUpdate();
        }
    }

    /** Рекорд игрока за неделю. */
    public EventRecord load(String week, EventType type, UUID uuid) throws SQLException {
        String sql = "SELECT player_name, best_stage, best_millis, attempts FROM ag_event_record "
                + "WHERE week = ? AND event = ? AND uuid = ?";
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, week);
            statement.setString(2, type.name());
            statement.setString(3, uuid.toString());
            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    return new EventRecord(uuid, result.getString("player_name"), type, week,
                            result.getInt("best_stage"), result.getLong("best_millis"),
                            result.getInt("attempts"), System.currentTimeMillis());
                }
            }
        }
        return null;
    }

    /** Топ недели: сначала ступень, при равенстве - меньше времени. */
    public List<EventRecord> top(String week, EventType type, int limit) throws SQLException {
        String sql = """
                SELECT uuid, player_name, best_stage, best_millis, attempts
                FROM ag_event_record
                WHERE week = ? AND event = ? AND best_stage > 0
                ORDER BY best_stage DESC, best_millis ASC
                LIMIT ?
                """;
        List<EventRecord> rows = new ArrayList<>();
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, week);
            statement.setString(2, type.name());
            statement.setInt(3, Math.max(1, limit));
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    rows.add(new EventRecord(UUID.fromString(result.getString("uuid")),
                            result.getString("player_name"), type, week,
                            result.getInt("best_stage"), result.getLong("best_millis"),
                            result.getInt("attempts"), System.currentTimeMillis()));
                }
            }
        }
        return rows;
    }

    /** Место игрока в топе недели (1..N), 0 - не в топе. */
    public int rank(String week, EventType type, UUID uuid) throws SQLException {
        List<EventRecord> rows = top(week, type, 100);
        for (int i = 0; i < rows.size(); i++) {
            if (rows.get(i).uuid().equals(uuid)) {
                return i + 1;
            }
        }
        return 0;
    }

    /** Отметить неделю пройденной и выдать ли награды. */
    public void closeWeek(String week, EventType type, List<UUID> winners) throws SQLException {
        String sql = """
                INSERT INTO ag_event_week (week, event, rewarded, first_uuid, second_uuid, third_uuid)
                VALUES (?, ?, 1, ?, ?, ?)
                ON DUPLICATE KEY UPDATE rewarded = 1, first_uuid = VALUES(first_uuid),
                    second_uuid = VALUES(second_uuid), third_uuid = VALUES(third_uuid)
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, week);
            statement.setString(2, type.name());
            for (int i = 0; i < 3; i++) {
                statement.setString(3 + i, i < winners.size() ? winners.get(i).toString() : null);
            }
            statement.executeUpdate();
        }
    }

    /** Награждена ли неделя (чтобы не выдать призовые дважды). */
    public boolean rewarded(String week, EventType type) throws SQLException {
        String sql = "SELECT rewarded FROM ag_event_week WHERE week = ? AND event = ?";
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, week);
            statement.setString(2, type.name());
            try (ResultSet result = statement.executeQuery()) {
                return result.next() && result.getInt("rewarded") == 1;
            }
        }
    }
}
