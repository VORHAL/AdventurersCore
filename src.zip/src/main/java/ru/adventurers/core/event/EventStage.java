package ru.adventurers.core.event;

import java.util.List;

/**
 * Ступень испытания: этаж башни, волна выжившего, глубина шахты, круг осады.
 *
 * <p>Все числа считаются из одного описания (events.yml), а не пишутся руками для 20-30 ступеней:
 * здоровье мобов и урон растут множителем, награда - тоже. Так видно, во сколько раз десятый
 * этаж дороже первого, и баланс можно поправить одной строкой, не пересчитывая таблицу.
 *
 * @param index      номер ступени, с 1
 * @param boss       ступень - босс (каждая 5-я в башне)
 * @param hpFactor   множитель здоровья мобов относительно базы испытания
 * @param dmgFactor  множитель урона мобов
 * @param mobs       сколько мобов на ступени (волна/этаж)
 * @param coins      монеты за прохождение (база x рост)
 * @param points     очки гильдии за прохождение
 * @param lootRolls  сколько предметов из таблицы добычи падает
 */
public record EventStage(int index, boolean boss, double hpFactor, double dmgFactor, int mobs,
                         long coins, int points, int lootRolls) {

    /** Награда за ступень - с учётом множителя недели (events.yml: weekly-bonus). */
    public EventStage scaled(double bonus) {
        return new EventStage(index, boss, hpFactor, dmgFactor, mobs,
                Math.round(coins * bonus), (int) Math.round(points * bonus), lootRolls);
    }

    /** Ступени для испытания: обычная арифметика, босс каждые bossEvery ступеней. */
    public static List<EventStage> build(int count, int bossEvery, double hpBase, double hpGrowth,
                                        double dmgBase, double dmgGrowth, int mobBase, int mobGrowth,
                                        long coinsBase, double coinsGrowth, int pointsBase,
                                        double pointsGrowth, int lootBase, int lootEvery) {
        List<EventStage> stages = new java.util.ArrayList<>();
        for (int i = 1; i <= count; i++) {
            boolean boss = bossEvery > 0 && i % bossEvery == 0;
            double hp = hpBase * Math.pow(hpGrowth, i - 1) * (boss ? 1.6 : 1.0);
            double dmg = dmgBase * Math.pow(dmgGrowth, i - 1) * (boss ? 1.3 : 1.0);
            // мобов на ступени: на боссе волна ТА ЖЕ плюс сам босс (босс не заменяет волну,
            // иначе пятый этаж оказывался легче четвёртого - на это указала проверка баланса)
            int mobs = mobBase + (i - 1) * mobGrowth;
            long coins = Math.round(coinsBase * Math.pow(coinsGrowth, i - 1) * (boss ? 2.2 : 1.0));
            int points = (int) Math.round(pointsBase * Math.pow(pointsGrowth, i - 1) * (boss ? 2.0 : 1.0));
            int rolls = lootBase + (lootEvery > 0 ? (i - 1) / lootEvery : 0) + (boss ? 1 : 0);
            stages.add(new EventStage(i, boss, hp, dmg, mobs, coins, points, rolls));
        }
        return stages;
    }

    /** Короткая подпись для меню и сообщений: «12 этаж · босс · 8 мобов · 4 200 монет». */
    public String shortText(String unitName, String bossName) {
        return index + " " + unitName + (boss ? " · " + bossName : "") + " · " + mobs
                + " мобов · " + coins + " монет · " + points + " очков";
    }
}
