package ru.adventurers.core.event;

/**
 * Восемь еженедельных испытаний. Каждую неделю идёт одно, по кругу: так у игрока всегда
 * есть «испытание недели», а не восемь мертвых вкладок, и сервер успевает проверить
 * по одному режиму за неделю.
 *
 * <p>У всех одна механика прогрессии: ступень (этаж, волна, глубина, флаг) - чем выше,
 * тем сложнее и дороже награда. Отличаются тем, ЧТО делает игрок: идёт вверх, сидит
 * в волнах, ищет выход, копает вниз, держит ворота или охотится на босса недели.
 */
public enum EventType {
    /** Башня Злобы: этажи вверх, каждая 5-я ступень - босс. */
    TOWER("tower", "Башня Злобы", "&5", "Поднимайся по этажам: 5-й, 10-й, 15-й - боссы."),
    /** Последний выживший: общая арена, волны мобов, счёт по волнам. */
    SURVIVOR("survivor", "Последний выживший", "&c", "Держись как можно дольше: волны идут без остановки."),
    /** Лабиринт Ужасов: поиск выхода под охотой неубиваемого монстра. */
    MAZE("maze", "Лабиринт Ужасов", "&8", "Найди выход, пока Пожиратель идёт по пятам. Выход один."),
    /** Проклятье шахтёра: копать вниз, глубже - опаснее и богаче. */
    MINE("mine", "Проклятье шахтёра", "&7", "Копай вниз: чем глубже, тем злее порода и вкуснее жила."),
    /** Осада: общая цель - отбить волны у ворот, очки идут команде. */
    SIEGE("siege", "Осада Ворот", "&6", "Держи ворота: волны растут, счёт общий на всех."),
    /** Кровавая луна: одна ночь, много мобов, гонка по очкам. */
    BLOOD_MOON("blood_moon", "Кровавая луна", "&4", "Одна ночь, много мобов: успей набрать больше всех."),
    /** Захват флага: PvP-испытание на арене без потери вещей. */
    FLAG("flag", "Захват флага", "&b", "Укради флаг чужой команды и принеси свой - без потери вещей."),
    /** Большая охота: босс недели в открытом мире. */
    HUNT("hunt", "Большая охота", "&2", "Босс недели бродит по миру: найди, позови группу, добей.");

    private final String id;
    private final String displayName;
    private final String color;
    private final String description;

    EventType(String id, String displayName, String color, String description) {
        this.id = id;
        this.displayName = displayName;
        this.color = color;
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getColor() {
        return color;
    }

    public String getDescription() {
        return description;
    }

    /** Название с цветом: "&5Башня Злобы". */
    public String coloredName() {
        return color + displayName;
    }

    public static EventType fromInput(String input) {
        if (input == null) {
            return null;
        }
        String value = input.trim().toLowerCase(java.util.Locale.ROOT);
        for (EventType type : values()) {
            if (type.id.equals(value)) {
                return type;
            }
        }
        return null;
    }
}
