package ru.adventurers.core.gear;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerItemBreakEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.Rank;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * «Проклятые» предметы (раздел 26, вторая волна): сила в обмен на цену.
 *
 * <p>Обычный лут отвечает на вопрос «стало ли у меня больше силы». Проклятый предмет
 * отвечает на другой: «готов ли я за это платить». Каждое проклятие даёт плюс
 * (урон, броня, скорость) и минус (получаемый урон, лечение, голод, вес), и минус
 * действует всё время, пока предмет надет - и в подземелье, и в мире.
 *
 * <p>Где взять: проклятия не заменяют обычные награды, а с шансом
 * {@code cursed.chance} накладываются на предмет, выпавший в подземелье ранга
 * {@code cursed.min-rank} и выше. Отсюда два следствия:
 * <ul>
 *   <li>проклятый предмет - это тот же предмет, а не отдельная строка дропа,
 *       поэтому балансить надо только сами проклятия;</li>
 *   <li>проклятие снимается зельем {@code uncursing} из конфига - это трата,
 *       а не потеря предмета (наказывать за любопытство нельзя).</li>
 * </ul>
 *
 * <p>Урон и броня накладываются через {@link AttributeModifier}, поэтому работают
 * с любым оружием и не конфликтуют с бронёй. Пересчёт идёт на тике брони
 * ({@code gear.armor-check-interval-ticks}), а не на каждом ударе.
 */
public final class CursedGear implements Listener {

    /** Одно проклятие: плюс и минус, оба обязательны. */
    public record Curse(String id, String name, double attackDamage, double armor,
                        double moveSpeed, double taken, double healFactor,
                        int hungerSeconds, boolean keepOnDeath) {
    }

    /** Что именно сейчас действует на игрока - чтобы не пересчитывать зря. */
    private static final class Applied {
        final Map<String, Curse> curses = new LinkedHashMap<>();
        int signature = 0;
    }

    private final AdventurersCore plugin;
    private final Random random = new Random();
    private final Map<String, Curse> curses = new LinkedHashMap<>();
    private final Map<UUID, Applied> applied = new LinkedHashMap<>();

    private NamespacedKey curseKey;
    private NamespacedKey markerKey;
    private BukkitTask task;

    private boolean enabled = true;
    private double chance = 0.12;
    private Rank minRank = Rank.C;
    private int refreshTicks = 10;

    public CursedGear(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    //  Загрузка
    // ---------------------------------------------------------------

    public void reload() {
        curseKey = new NamespacedKey(plugin, "curse");
        markerKey = new NamespacedKey(plugin, "cursed_item");
        curses.clear();
        java.io.File file = plugin.getFiles().file("cursed.yml");
        if (!file.exists()) {
            plugin.getFiles().save("cursed.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        chance = Math.max(0, Math.min(1, cfg.getDouble("cursed.chance", 0.12)));
        minRank = Rank.fromInput(cfg.getString("cursed.min-rank", "C"));
        refreshTicks = Math.max(5, cfg.getInt("cursed.refresh-ticks", 10));

        ConfigurationSection section = cfg.getConfigurationSection("curses");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(id);
                if (s == null) {
                    continue;
                }
                CursedGear.Curse curse = new CursedGear.Curse(
                        id.toLowerCase(Locale.ROOT),
                        s.getString("name", id),
                        s.getDouble("attack-damage", 0),
                        s.getDouble("armor", 0),
                        s.getDouble("move-speed", 0),
                        s.getDouble("taken", 1.0),
                        s.getDouble("heal-factor", 1.0),
                        Math.max(0, s.getInt("hunger-seconds", 0)),
                        s.getBoolean("keep-on-death", false));
                // Проклятие без плюса или без минуса - это не проклятие, а подарок или мусор.
                if (!hasPlus(curse) || !hasMinus(curse)) {
                    plugin.getLogger().warning("Проклятие " + id + ": нужен и плюс, и минус - пропущено");
                    continue;
                }
                curses.put(curse.id(), curse);
            }
        }
        restart();
    }

    private static boolean hasPlus(CursedGear.Curse curse) {
        return curse.attackDamage() > 0 || curse.armor() > 0 || curse.moveSpeed() > 0
                || curse.healFactor() > 1.0;
    }

    private static boolean hasMinus(CursedGear.Curse curse) {
        return curse.attackDamage() < 0 || curse.armor() < 0 || curse.moveSpeed() < 0
                || curse.taken() > 1.0 || curse.healFactor() < 1.0 || curse.hungerSeconds() > 0;
    }

    private void restart() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        if (!enabled || curses.isEmpty()) {
            clearAll();
            return;
        }
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::refreshAll, 20L, refreshTicks);
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        clearAll();
    }

    public boolean enabled() {
        return enabled && !curses.isEmpty();
    }

    public Map<String, CursedGear.Curse> curses() {
        return curses;
    }

    // ---------------------------------------------------------------
    //  Выдача: накладываем проклятие на выпавший предмет
    // ---------------------------------------------------------------

    /**
     * Может ли предмет получить проклятие: ранг подземелья достаточный, предмет
     * не самоцвет/руна/зелье (проклинать расходники бессмысленно).
     */
    public boolean canCurse(ItemStack stack, Rank rank) {
        if (!enabled() || stack == null || stack.getType().isAir()) {
            return false;
        }
        if (rank == null || minRank == null || !rank.isAtLeast(minRank)) {
            return false;
        }
        if (isCursed(stack)) {
            return false;
        }
        return stack.getType().getMaxDurability() > 0
                || stack.getType().name().endsWith("_SWORD")
                || stack.getType().name().endsWith("_AXE")
                || stack.getType().name().endsWith("_BOW")
                || stack.getType().name().endsWith("_HELMET")
                || stack.getType().name().endsWith("_CHESTPLATE")
                || stack.getType().name().endsWith("_LEGGINGS")
                || stack.getType().name().endsWith("_BOOTS");
    }

    /**
     * Накладывает случайное проклятие с шансом из конфига.
     *
     * @return true, если проклятие наложено
     */
    public boolean curseIfLucky(ItemStack stack, Rank rank) {
        if (!canCurse(stack, rank) || random.nextDouble() >= chance) {
            return false;
        }
        List<CursedGear.Curse> pool = new ArrayList<>(curses.values());
        return apply(stack, pool.get(random.nextInt(pool.size())));
    }

    /** Накладывает конкретное проклятие: имя, лор, метки. */
    public boolean apply(ItemStack stack, CursedGear.Curse curse) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null || curse == null) {
            return false;
        }
        meta.getPersistentDataContainer().set(curseKey, PersistentDataType.STRING, curse.id());
        meta.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);
        List<net.kyori.adventure.text.Component> lore = meta.lore() == null
                ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Hud.legacy("&8&m                        "));
        lore.add(Hud.legacy("&5&l✦ ПРОКЛЯТИЕ: &d" + curse.name()));
        for (String line : describe(curse)) {
            lore.add(Hud.legacy(line));
        }
        lore.add(Hud.legacy("&8Снять: зелье «Снятие проклятия»"));
        meta.lore(lore);
        stack.setItemMeta(meta);
        return true;
    }

    /** Строки описания: плюсы зелёным, минусы красным. */
    public static List<String> describe(CursedGear.Curse curse) {
        List<String> lines = new ArrayList<>();
        if (curse.attackDamage() != 0) {
            lines.add(sign(curse.attackDamage(), " &7урон: ", "%+.1f", curse.attackDamage()));
        }
        if (curse.armor() != 0) {
            lines.add(sign(curse.armor(), " &7броня: ", "%+.1f", curse.armor()));
        }
        if (curse.moveSpeed() != 0) {
            lines.add(sign(curse.moveSpeed(), " &7скорость: ", "%+.0f%%", curse.moveSpeed() * 100));
        }
        if (curse.taken() != 1.0) {
            lines.add(sign(curse.taken() - 1.0, " &7получаемый урон: ", "%+.0f%%", (curse.taken() - 1.0) * 100));
        }
        if (curse.healFactor() != 1.0) {
            lines.add(sign(curse.healFactor() - 1.0, " &7лечение: ", "%+.0f%%", (curse.healFactor() - 1.0) * 100));
        }
        if (curse.hungerSeconds() > 0) {
            lines.add("&c - голод каждые " + curse.hungerSeconds() + " с");
        }
        return lines;
    }

    private static String sign(double value, String label, String format, double shown) {
        String color = value > 0 ? "&a +" : "&c ";
        return color + String.format(Locale.ROOT, format, shown) + label;
    }

    // ---------------------------------------------------------------
    //  Проверки
    // ---------------------------------------------------------------

    public boolean isCursed(ItemStack stack) {
        if (stack == null || curseKey == null) {
            return false;
        }
        ItemMeta meta = stack.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE);
    }

    public String curseId(ItemStack stack) {
        if (stack == null || curseKey == null) {
            return null;
        }
        ItemMeta meta = stack.getItemMeta();
        return meta == null ? null : meta.getPersistentDataContainer().get(curseKey, PersistentDataType.STRING);
    }

    /** Снять проклятие (для зелья и админской команды). Возвращает id снятого или null. */
    public String remove(ItemStack stack) {
        if (!isCursed(stack)) {
            return null;
        }
        String id = curseId(stack);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        meta.getPersistentDataContainer().remove(curseKey);
        meta.getPersistentDataContainer().remove(markerKey);
        if (meta.lore() != null) {
            List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
            for (net.kyori.adventure.text.Component line : meta.lore()) {
                String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer
                        .plainText().serialize(line);
                if (plain.startsWith("✦ ПРОКЛЯТИЕ") || plain.contains("Снять: зелье")
                        || plain.startsWith(" +") || plain.startsWith(" -")
                        || plain.contains("голод каждые")) {
                    continue;
                }
                lore.add(line);
            }
            meta.lore(lore.isEmpty() ? null : lore);
        }
        stack.setItemMeta(meta);
        return id;
    }

    // ---------------------------------------------------------------
    //  Действие на игрока
    // ---------------------------------------------------------------

    private static final String MODIFIER_NAME = "adventurers_curse";

    private void refreshAll() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            refresh(player);
        }
    }

    private void clearAll() {
        for (UUID id : new ArrayList<>(applied.keySet())) {
            Player player = plugin.getServer().getPlayer(id);
            if (player != null) {
                clear(player);
            }
        }
        applied.clear();
    }

    /** Пересчитывает действующие проклятия по надетым предметам. */
    public void refresh(Player player) {
        Map<String, CursedGear.Curse> active = new LinkedHashMap<>();
        for (ItemStack stack : player.getInventory().getArmorContents()) {
            collect(stack, active);
        }
        collect(player.getInventory().getItemInMainHand(), active);
        collect(player.getInventory().getItemInOffHand(), active);

        CursedGear.Applied state = applied.computeIfAbsent(player.getUniqueId(), id -> new CursedGear.Applied());
        int signature = active.keySet().hashCode();
        if (state.signature == signature) {
            return;
        }
        state.curses.clear();
        state.curses.putAll(active);
        state.signature = signature;
        pushAttributes(player, active.values());
    }

    private void collect(ItemStack stack, Map<String, CursedGear.Curse> active) {
        if (stack == null || stack.getType().isAir() || !isCursed(stack)) {
            return;
        }
        CursedGear.Curse curse = curses.get(curseId(stack));
        if (curse != null) {
            active.put(curse.id() + ":" + stack.getType().name(), curse);
        }
    }

    /** Накладывает и снимает модификаторы атрибутов, чтобы не копились. */
    private void pushAttributes(Player player, java.util.Collection<CursedGear.Curse> active) {
        double damage = 0, armor = 0, speed = 0;
        for (CursedGear.Curse curse : active) {
            damage += curse.attackDamage();
            armor += curse.armor();
            speed += curse.moveSpeed();
        }
        for (Attribute attribute : new Attribute[]{Attribute.ATTACK_DAMAGE, Attribute.ARMOR,
                Attribute.MOVEMENT_SPEED}) {
            AttributeInstance instance = player.getAttribute(attribute);
            if (instance == null) {
                continue;
            }
            removeOurModifiers(instance);
            double amount;
            if (attribute == Attribute.ATTACK_DAMAGE) {
                amount = damage;
            } else if (attribute == Attribute.ARMOR) {
                amount = armor;
            } else {
                amount = speed;
            }
            if (Math.abs(amount) < 0.0001) {
                continue;
            }
            AttributeModifier.Operation operation = attribute == Attribute.MOVEMENT_SPEED
                    ? AttributeModifier.Operation.ADD_SCALAR
                    : AttributeModifier.Operation.ADD_NUMBER;
            instance.addModifier(new AttributeModifier(
                    new NamespacedKey(plugin, MODIFIER_NAME + "_" + attribute.name().toLowerCase(Locale.ROOT)),
                    amount, operation, EquipmentSlotGroup.ANY));
        }
        boolean hunger = active.stream().anyMatch(curse -> curse.hungerSeconds() > 0);
        if (hunger) {
            int period = active.stream().filter(curse -> curse.hungerSeconds() > 0)
                    .mapToInt(CursedGear.Curse::hungerSeconds).min().orElse(60);
            if (player.getFoodLevel() > 6 && random.nextInt(Math.max(1, period / 2)) == 0) {
                player.setFoodLevel(Math.max(0, player.getFoodLevel() - 1));
            }
        }
    }

    private void removeOurModifiers(AttributeInstance instance) {
        for (AttributeModifier modifier : new ArrayList<>(instance.getModifiers())) {
            if (modifier.getKey().getKey().startsWith(MODIFIER_NAME)) {
                instance.removeModifier(modifier);
            }
        }
    }

    private void clear(Player player) {
        for (Attribute attribute : new Attribute[]{Attribute.ATTACK_DAMAGE, Attribute.ARMOR,
                Attribute.MOVEMENT_SPEED}) {
            AttributeInstance instance = player.getAttribute(attribute);
            if (instance != null) {
                removeOurModifiers(instance);
            }
        }
        applied.remove(player.getUniqueId());
    }

    /** Множитель получаемого урона от всех надетых проклятий. */
    public double takenFactor(Player player) {
        CursedGear.Applied state = applied.get(player.getUniqueId());
        if (state == null || state.curses.isEmpty()) {
            return 1.0;
        }
        double factor = 1.0;
        for (CursedGear.Curse curse : state.curses.values()) {
            factor *= curse.taken();
        }
        return factor;
    }

    /** Общий множитель лечения: сначала проклятия, потом эффекты места (подземелье). */
    public double healMultiplier(Player player) {
        double factor = healFactor(player);
        if (plugin.getDungeons() != null) {
            factor *= plugin.getDungeons().healFactor(player);
        }
        return factor;
    }

    /** Множитель лечения от всех надетых проклятий. */
    public double healFactor(Player player) {
        CursedGear.Applied state = applied.get(player.getUniqueId());
        if (state == null || state.curses.isEmpty()) {
            return 1.0;
        }
        double factor = 1.0;
        for (CursedGear.Curse curse : state.curses.values()) {
            factor *= curse.healFactor();
        }
        return factor;
    }

    // ---------------------------------------------------------------
    //  События
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        double factor = takenFactor(player);
        if (factor != 1.0) {
            event.setDamage(event.getDamage() * factor);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHeal(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        double factor = healFactor(player);
        if (factor != 1.0) {
            event.setAmount(Math.max(0, event.getAmount() * factor));
        }
    }

    /** Проклятая вещь горит быстрее - цена за силу видна на прочность. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDurability(PlayerItemDamageEvent event) {
        if (isCursed(event.getItem())) {
            event.setDamage(Math.max(1, (int) Math.ceil(event.getDamage() * 1.3)));
        }
    }

    /** «Переживает смерть»: без этой ветки проклятие терялось бы вместе с предметом молча. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onBreak(PlayerItemBreakEvent event) {
        ItemStack broken = event.getBrokenItem();
        if (isCursed(broken)) {
            event.getPlayer().sendMessage(Hud.legacy(
                    "&5Проклятие сгорело вместе с вещью. Такая цена."));
        }
    }

    /**
     * Зелье «Снятие проклятия»: берём проклятую вещь из руки и снимаем проклятие.
     * Зелье при этом тратится только если было что снимать - иначе игрок может
     * выпить его случайно и потерять рецепт впустую.
     */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrink(org.bukkit.event.player.PlayerItemConsumeEvent event) {
        ItemStack potion = event.getItem();
        ItemMeta meta = potion.getItemMeta();
        if (meta == null || !meta.getPersistentDataContainer().has(uncursingKey(), PersistentDataType.BYTE)) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack held = player.getInventory().getItemInMainHand();
        String removed = remove(held);
        if (removed == null) {
            // Зелье не тратим: в руке нет проклятой вещи.
            event.setCancelled(true);
            player.sendMessage(Hud.legacy("&5Держите проклятую вещь в руке, иначе зелью нечего снимать."));
            return;
        }
        event.setCancelled(true);
        potion.setAmount(potion.getAmount() - 1);
        player.sendMessage(Hud.legacy("&aПроклятие снято: &f"
                + (curses.containsKey(removed) ? curses.get(removed).name() : removed)));
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BEACON_DEACTIVATE, 0.7f, 1.3f);
        refresh(player);
    }

    private NamespacedKey uncursingKey() {
        return new NamespacedKey(plugin, "uncursing");
    }

    /** Пометить зелье как «снятие проклятия» (вызывается при крафте и админом). */
    public ItemStack markPotion(ItemStack potion) {
        ItemMeta meta = potion.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(uncursingKey(), PersistentDataType.BYTE, (byte) 1);
            potion.setItemMeta(meta);
        }
        return potion;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent event) {
        applied.remove(event.getPlayer().getUniqueId());
    }
}
