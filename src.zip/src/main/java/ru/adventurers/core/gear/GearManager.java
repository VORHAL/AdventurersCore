package ru.adventurers.core.gear;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.ProfileManager;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.survival.SurvivalManager;

import java.io.File;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class GearManager {

    private static final Set<String> ARMOR_TYPES =
            Set.of("HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS");
    private static final Set<String> TOOL_TYPES =
            Set.of("SWORD", "AXE", "PICKAXE", "SHOVEL", "HOE", "SPEAR");
    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private final AdventurersCore plugin;
    private final ProfileManager profiles;
    private final NamespacedKey customLootClassesKey;
    private final NamespacedKey customLootRankKey;

    private final Map<String, Rank> armorTiers = new HashMap<>();
    private final Map<String, Rank> toolTiers = new HashMap<>();
    private final Map<Material, Rank> overrides = new EnumMap<>(Material.class);
    private final Map<UUID, Long> lastWarning = new ConcurrentHashMap<>();

    private boolean enabled;
    private boolean rankGearBypass;
    private long warningCooldownMs;
    private BukkitTask task;

    public GearManager(AdventurersCore plugin, ProfileManager profiles) {
        this.plugin = plugin;
        this.profiles = profiles;
        this.customLootClassesKey = new NamespacedKey(plugin, "custom_loot_classes");
        this.customLootRankKey = new NamespacedKey(plugin, "custom_loot_rank");
        reload();
    }

    public void reload() {
        File file = plugin.getFiles().file("gear.yml");
        if (!file.exists()) {
            plugin.getFiles().save("gear.yml");
        }
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        enabled = cfg.getBoolean("enabled", true);
        rankGearBypass = cfg.getBoolean("rank-gear-bypass", true);
        warningCooldownMs = cfg.getLong("warning-cooldown-seconds", 3) * 1000L;
        int interval = Math.max(1, cfg.getInt("armor-check-interval-ticks", 10));

        armorTiers.clear();
        toolTiers.clear();
        overrides.clear();
        readTiers(cfg.getConfigurationSection("armor"), armorTiers);
        readTiers(cfg.getConfigurationSection("tools"), toolTiers);

        ConfigurationSection section = cfg.getConfigurationSection("overrides");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Material material = Material.matchMaterial(key);
                Rank rank = Rank.fromInput(section.getString(key));
                if (material == null || rank == null) {
                    plugin.getLogger().warning("gear.yml: неверная запись overrides." + key);
                    continue;
                }
                overrides.put(material, rank);
            }
        }

        if (task != null) {
            task.cancel();
            task = null;
        }
        if (enabled) {
            task = Bukkit.getScheduler().runTaskTimer(
                    plugin, this::enforceAllArmor, interval, interval);
        }
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    public void forget(UUID uuid) {
        lastWarning.remove(uuid);
    }

    private void readTiers(ConfigurationSection section, Map<String, Rank> target) {
        if (section == null) {
            return;
        }
        for (String prefix : section.getKeys(false)) {
            Rank rank = Rank.fromInput(section.getString(prefix));
            if (rank == null) {
                plugin.getLogger().warning("gear.yml: неизвестный ранг у " + prefix);
                continue;
            }
            target.put(prefix.toUpperCase(Locale.ROOT), rank);
        }
    }

    /** Минимальный ранг для предмета или null, если ограничений нет. */
    public Rank getRequiredRank(Material material) {
        Rank override = overrides.get(material);
        if (override != null) {
            return override;
        }
        String name = material.name();
        int underscore = name.indexOf('_');
        if (underscore < 0) {
            return null;
        }
        String prefix = name.substring(0, underscore);
        String type = name.substring(underscore + 1);

        if (ARMOR_TYPES.contains(type)) {
            return armorTiers.get(prefix);
        }
        if (TOOL_TYPES.contains(type)) {
            return toolTiers.get(prefix);
        }
        return null;
    }

    /**
     * Минимальный ранг для конкретного предмета. Экипировка, выданная Мастером Гильдии,
     * помечена рангом выдачи: её можно носить на этом ранге и выше, даже если таблица
     * gear.yml открывает такой материал позже (rank-gear-bypass в gear.yml).
     */
    public Rank getRequiredRank(ItemStack item) {
        if (item.hasItemMeta()) {
            String customRank = item.getItemMeta().getPersistentDataContainer()
                    .get(customLootRankKey, PersistentDataType.STRING);
            Rank parsedCustomRank = Rank.fromInput(customRank);
            if (parsedCustomRank != null) {
                return parsedCustomRank;
            }
            if (rankGearBypass) {
                NamespacedKey key = SurvivalManager.rankGearKey(plugin);
                String issued = item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
                if (issued != null) {
                    try {
                        return Rank.valueOf(issued);
                    } catch (IllegalArgumentException ignored) {
                        // неизвестная метка: считаем по таблице
                    }
                }
            }
        }
        return getRequiredRank(item.getType());
    }

    /** Ранг игрока или null, пока профиль ещё грузится. */
    private Rank getRank(Player player) {
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        return profile != null ? profile.getRank() : null;
    }

    /** Можно ли использовать предмет. Если нет, сам шлёт игроку сообщение. */
    public boolean canUse(Player player, ItemStack item) {
        if (!enabled || item == null || item.getType().isAir()) {
            return true;
        }
        if (player.hasPermission("ag.bypass.gear")) {
            return true;
        }
        if (item.hasItemMeta()) {
            String allowedClasses = item.getItemMeta().getPersistentDataContainer()
                    .get(customLootClassesKey, PersistentDataType.STRING);
            if (allowedClasses != null && !allowedClasses.isBlank()) {
                PlayerClass active = plugin.getClasses().activeClass(player.getUniqueId());
                boolean allowed = active == PlayerClass.UNIVERSAL
                        || (active != null && java.util.Arrays.asList(allowedClasses.split(",")).contains(active.getId()));
                if (!allowed) {
                    player.sendMessage(Component.text("Этот предмет доступен только указанным классам: " + allowedClasses));
                    return false;
                }
            }
        }
        Rank required = getRequiredRank(item);
        if (required == null) {
            return true;
        }
        Rank current = getRank(player);
        if (current == null) {
            current = Rank.F; // профиль грузится: временно считаем новичком
        }
        if (current.isAtLeast(required)) {
            return true;
        }
        warn(player, "gear.use-denied", item, current, required);
        return false;
    }

    private void enforceAllArmor() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            enforceArmor(player);
        }
    }

    private void enforceArmor(Player player) {
        if (player.hasPermission("ag.bypass.gear")) {
            return;
        }
        Rank current = getRank(player);
        if (current == null) {
            return; // профиль ещё грузится: ничего не снимаем
        }

        PlayerInventory inventory = player.getInventory();
        for (EquipmentSlot slot : ARMOR_SLOTS) {
            ItemStack piece = inventory.getItem(slot);
            if (piece == null || piece.getType().isAir()) {
                continue;
            }
            Rank required = getRequiredRank(piece);
            if (required == null || current.isAtLeast(required)) {
                continue;
            }

            ItemStack copy = piece.clone();
            inventory.setItem(slot, null);
            giveBack(player, copy);
            warn(player, "gear.armor-removed", copy, current, required);
        }
    }

    private void giveBack(Player player, ItemStack item) {
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
        for (ItemStack rest : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), rest);
        }
    }

    private void warn(Player player, String key, ItemStack item, Rank current, Rank required) {
        long now = System.currentTimeMillis();
        Long last = lastWarning.get(player.getUniqueId());
        if (last != null && now - last < warningCooldownMs) {
            return;
        }
        lastWarning.put(player.getUniqueId(), now);

        MessageManager messages = plugin.getMessages();
        messages.send(player, key, Map.of(
                "rank", messages.rankName(current),
                "required", messages.rankName(required),
                "item", Component.translatable(item.getType().translationKey())
        ));
    }
}