package ru.adventurers.core.gear;

import ru.adventurers.core.DatabaseManager;
import ru.adventurers.core.profile.Rank;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.UUID;

/** Таблица player_gear_claims: какие наборы Мастера Гильдии игрок уже получил. Методы блокирующие. */
public class GuildGearRepository {

    private final DatabaseManager database;

    public GuildGearRepository(DatabaseManager database) {
        this.database = database;
    }

    public void createTable() throws SQLException {
        String sql = """
                CREATE TABLE IF NOT EXISTS player_gear_claims (
                    uuid CHAR(36) NOT NULL,
                    rank_id VARCHAR(16) NOT NULL,
                    claimed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (uuid, rank_id)
                ) ENGINE=InnoDB
                  DEFAULT CHARSET=utf8mb4
                  COLLATE=utf8mb4_unicode_ci
                """;
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }
    }

    /** Записывает получение набора. Возвращает false, если набор уже был получен (атомарно). */
    public boolean tryClaim(UUID uuid, Rank rank) throws SQLException {
        String sql = "INSERT IGNORE INTO player_gear_claims (uuid, rank_id) VALUES (?, ?)";
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, uuid.toString());
            statement.setString(2, rank.name());
            return statement.executeUpdate() > 0;
        }
    }

    /** Получал ли игрок набор этого ранга (условие ранга "needs-gear"). */
    public boolean hasClaimed(UUID uuid, Rank rank) throws SQLException {
        String sql = "SELECT 1 FROM player_gear_claims WHERE uuid = ? AND rank_id = ? LIMIT 1";
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, uuid.toString());
            statement.setString(2, rank.name());
            try (java.sql.ResultSet rows = statement.executeQuery()) {
                return rows.next();
            }
        }
    }

    public void unclaim(UUID uuid, Rank rank) throws SQLException {
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "DELETE FROM player_gear_claims WHERE uuid = ? AND rank_id = ?")) {
            statement.setString(1, uuid.toString());
            statement.setString(2, rank.name());
            statement.executeUpdate();
        }
    }

    public void deleteAll(UUID uuid) throws SQLException {
        try (Connection connection = database.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "DELETE FROM player_gear_claims WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            statement.executeUpdate();
        }
    }
}
