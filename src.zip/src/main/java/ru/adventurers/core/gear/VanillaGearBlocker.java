package ru.adventurers.core.gear;

import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.survival.SurvivalManager;

import java.io.File;

/**
 * Убирает из игры обычные боевые вещи (броня, мечи, луки, арбалеты, щиты, трезубцы, булавы, копья).
 * Остаются инструменты и вещи гильдии (с меткой класса или ранга). Настройки: gear.yml, блок vanilla-gear.
 */
public class VanillaGearBlocker implements Listener {

    private final AdventurersCore plugin;
    private boolean enabled = true;
    private boolean purge = true;
    private boolean blockPotions = true;

    public VanillaGearBlocker(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "gear.yml"));
        enabled = cfg.getBoolean("vanilla-gear.block", true);
        purge = cfg.getBoolean("vanilla-gear.purge-inventory", true);
        blockPotions = cfg.getBoolean("vanilla-gear.block-potions", true);
    }

    private static boolean isPotionType(Material type) {
        return type == Material.POTION || type == Material.SPLASH_POTION
                || type == Material.LINGERING_POTION || type == Material.TIPPED_ARROW;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrink(org.bukkit.event.player.PlayerItemConsumeEvent event) {
        if (enabled && vanilla(event.getItem())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onUse(org.bukkit.event.player.PlayerInteractEvent event) {
        ItemStack item = event.getItem();
        if (enabled && item != null && isPotionType(item.getType()) && vanilla(item)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBrew(org.bukkit.event.inventory.BrewEvent event) {
        if (enabled && blockPotions) {
            event.setCancelled(true);
        }
    }

    public static boolean combat(Material type) {
        String n = type.name();
        return n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")
                || n.endsWith("_SWORD") || n.endsWith("_SPEAR") || n.equals("MACE") || n.equals("TRIDENT")
                || n.equals("BOW") || n.equals("CROSSBOW") || n.equals("SHIELD") || n.equals("ELYTRA")
                || n.equals("TURTLE_HELMET") || n.equals("WOLF_ARMOR");
    }

    /** true, если это обычная боевая вещь без метки гильдии. */
    public boolean vanilla(ItemStack item) {
        if (item != null && blockPotions && isPotionType(item.getType())) {
            return !plugin.getPotions().isGuildPotion(item);
        }
        if (item == null || item.getType().isAir() || !combat(item.getType())) {
            return false;
        }
        if (!item.hasItemMeta()) {
            return true;
        }
        PersistentDataContainer data = item.getItemMeta().getPersistentDataContainer();
        if (data.has(GuildGearService.classKey(plugin)) || data.has(SurvivalManager.rankGearKey(plugin))) {
            return false;
        }
        return !plugin.getTank().isTankShield(item);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCraft(PrepareItemCraftEvent event) {
        if (enabled && event.getInventory().getResult() != null && vanilla(event.getInventory().getResult())) {
            event.getInventory().setResult(null);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent event) {
        if (enabled && !(event.getEntity() instanceof Player)) {
            event.getDrops().removeIf(this::vanilla);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onLoot(LootGenerateEvent event) {
        if (enabled) {
            event.getLoot().removeIf(this::vanilla);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTrade(VillagerAcquireTradeEvent event) {
        if (enabled && vanilla(event.getRecipe().getResult())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (enabled && event.getEntity() instanceof Player && vanilla(event.getItem().getItemStack())) {
            event.setCancelled(true);
            Item entity = event.getItem();
            entity.remove();
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!enabled || !purge) {
            return;
        }
        Player player = event.getPlayer();
        if (player.hasPermission("ag.bypass.gear")) {
            return;
        }
        var inv = player.getInventory();
        ItemStack[] contents = inv.getContents();
        for (int i = 0; i < contents.length; i++) {
            if (vanilla(contents[i])) {
                inv.setItem(i, null);
            }
        }
        for (ItemStack[] arr : new ItemStack[][]{inv.getArmorContents()}) {
            ItemStack[] copy = arr.clone();
            boolean changed = false;
            for (int i = 0; i < copy.length; i++) {
                if (vanilla(copy[i])) {
                    copy[i] = null;
                    changed = true;
                }
            }
            if (changed) {
                inv.setArmorContents(copy);
            }
        }
        if (vanilla(inv.getItemInOffHand())) {
            inv.setItemInOffHand(null);
        }
    }
}
