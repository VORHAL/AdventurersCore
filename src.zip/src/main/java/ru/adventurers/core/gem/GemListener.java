package ru.adventurers.core.gem;

import org.bukkit.GameMode;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.quest.QuestGuard;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/** Добыча самоцветов и боевые эффекты камней. */
public class GemListener implements Listener {

    private static final Set<EntityDamageEvent.DamageCause> ELEMENTS = EnumSet.of(
            EntityDamageEvent.DamageCause.FIRE, EntityDamageEvent.DamageCause.FIRE_TICK,
            EntityDamageEvent.DamageCause.LAVA, EntityDamageEvent.DamageCause.HOT_FLOOR,
            EntityDamageEvent.DamageCause.POISON, EntityDamageEvent.DamageCause.WITHER,
            EntityDamageEvent.DamageCause.BLOCK_EXPLOSION, EntityDamageEvent.DamageCause.ENTITY_EXPLOSION);

    private final AdventurersCore plugin;
    private final GemManager gems;
    private final QuestGuard guard;
    private final Map<UUID, Long> lastSurvivor = new HashMap<>();
    private boolean reflecting;

    public GemListener(AdventurersCore plugin, GemManager gems, QuestGuard guard) {
        this.plugin = plugin;
        this.gems = gems;
        this.guard = guard;
    }

    private void proc(Player player, String key, String fallback) {
        plugin.getSkillHud().flash(player, Hud.legacy(plugin.getMessages().text(key, fallback)));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.SURVIVAL && event.isDropItems()) {
            gems.rollBlock(player, event.getBlock().getType(), event.getBlock().getLocation().add(0.5, 0.5, 0.5));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMobDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof Player || event.getEntity() instanceof ArmorStand) {
            return;
        }
        Player killer = event.getEntity().getKiller();
        if (killer == null || killer.getGameMode() != GameMode.SURVIVAL || guard.isMarked(event.getEntity())) {
            return;
        }
        ItemStack gem = gems.rollMob(event.getEntity().getType().name());
        if (gem != null) {
            event.getDrops().add(gem);
        }
    }

    /** Защита игрока: стихии, блок, снижение урона от монстров, второе дыхание. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHurt(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        double factor = 1.0;

        if (ELEMENTS.contains(event.getCause())) {
            factor *= 1.0 - Math.min(0.7, gems.power(player, GemManager.Effect.RESIST));
        }
        if (event instanceof EntityDamageByEntityEvent byEntity && !(byEntity.getDamager() instanceof Player)) {
            factor *= 1.0 - Math.min(0.6, gems.power(player, GemManager.Effect.REDUCE));
        }
        double block = Math.min(0.5, gems.power(player, GemManager.Effect.BLOCK));
        if (block > 0 && event.getCause() != EntityDamageEvent.DamageCause.VOID
                && ThreadLocalRandom.current().nextDouble() < block) {
            factor *= 1.0 - gems.getBlockReduction();
            proc(player, "gems.proc-block", "&9⛨ Блок!");
        }
        if (factor < 1.0) {
            event.setDamage(event.getDamage() * factor);
        }

        // Второе дыхание: смертельный удар оставляет 1 здоровья (с задержкой).
        double survivor = gems.power(player, GemManager.Effect.SURVIVOR);
        if (survivor > 0 && player.getHealth() - event.getFinalDamage() <= 0
                && event.getCause() != EntityDamageEvent.DamageCause.VOID) {
            long now = System.currentTimeMillis();
            Long last = lastSurvivor.get(player.getUniqueId());
            if ((last == null || now - last >= gems.getSurvivorCooldownMs())
                    && ThreadLocalRandom.current().nextDouble() < Math.min(0.6, survivor)) {
                lastSurvivor.put(player.getUniqueId(), now);
                event.setCancelled(true);
                player.setHealth(1.0);
                player.setNoDamageTicks(30);
                proc(player, "gems.proc-survivor", "&6✦ Второе дыхание!");
            }
        }
    }

    /** Нападение игрока: критический удар, добивание, вампиризм, поджог; шипы у защитника. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (reflecting) {
            return;
        }
        Entity damager = event.getDamager();
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Entity shooter) {
            damager = shooter;
        }

        if (damager instanceof Player attacker) {
            double multiplier = 1.0;
            double crit = Math.min(0.5, gems.power(attacker, GemManager.Effect.CRIT));
            if (crit > 0 && ThreadLocalRandom.current().nextDouble() < crit) {
                multiplier += gems.getCritBonus();
                proc(attacker, "gems.proc-crit", "&c⚔ Критический удар!");
            }
            double execute = gems.power(attacker, GemManager.Effect.EXECUTE);
            if (execute > 0 && event.getEntity() instanceof LivingEntity target) {
                AttributeInstance max = target.getAttribute(Attribute.MAX_HEALTH);
                double limit = max != null ? max.getValue() : 20.0;
                if (target.getHealth() / limit <= gems.getExecuteThreshold()) {
                    multiplier += execute;
                }
            }
            if (multiplier > 1.0) {
                event.setDamage(event.getDamage() * multiplier);
            }

            double damage = event.getFinalDamage();
            double lifesteal = gems.power(attacker, GemManager.Effect.LIFESTEAL);
            if (lifesteal > 0 && plugin.getCurses() != null) {
                lifesteal *= plugin.getCurses().healMultiplier(attacker);
            }
            if (lifesteal > 0) {
                AttributeInstance max = attacker.getAttribute(Attribute.MAX_HEALTH);
                double limit = max != null ? max.getValue() : 20.0;
                attacker.setHealth(Math.min(limit, attacker.getHealth() + damage * lifesteal));
            }
            double ignite = gems.power(attacker, GemManager.Effect.IGNITE);
            if (ignite > 0 && event.getEntity() instanceof LivingEntity victim
                    && ThreadLocalRandom.current().nextDouble() < ignite) {
                victim.setFireTicks(gems.getIgniteTicks());
            }
        }

        if (event.getEntity() instanceof Player defender && damager instanceof LivingEntity source
                && !source.equals(defender)) {
            double thorns = gems.power(defender, GemManager.Effect.THORNS);
            if (thorns > 0) {
                double reflected = event.getFinalDamage() * thorns;
                if (reflected > 0.1) {
                    reflecting = true;
                    try {
                        source.damage(reflected, defender);
                    } finally {
                        reflecting = false;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        gems.forget(event.getPlayer().getUniqueId());
        lastSurvivor.remove(event.getPlayer().getUniqueId());
    }
}
