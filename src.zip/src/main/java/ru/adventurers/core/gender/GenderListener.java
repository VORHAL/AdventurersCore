package ru.adventurers.core.gender;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import ru.adventurers.core.AdventurersCore;

/**
 * Клик по кнопке в меню выбора пола и открытие меню при входе.
 *
 * <p>Меню открывается не в onJoin напрямую: профиль грузится асинхронно, и в момент события
 * его ещё нет. Поэтому ждём пару тиков и открываем меню, только если профиль уже пришёл и пол
 * не выбран.
 */
public class GenderListener implements Listener {

    private final AdventurersCore plugin;
    private final GenderManager genders;

    public GenderListener(AdventurersCore plugin, GenderManager genders) {
        this.plugin = plugin;
        this.genders = genders;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent event) {
        if (!genders.isGenderMenu(event.getInventory())) {
            return;
        }
        // В нашем меню нельзя ничего брать, перемещать или выбрасывать.
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        genders.clickMenu(player, event.getCurrentItem());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent event) {
        if (genders.isGenderMenu(event.getInventory())) {
            event.setCancelled(true);
        }
    }

    /**
     * Профиль грузится из базы асинхронно, поэтому после входа пробуем несколько раз:
     * на медленной базе первый заход (2 секунды) может прийти раньше профиля.
     * Меню откроется только один раз - после выбора needsChoice уже false.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        attempt(player, 0);
    }

    private void attempt(Player player, int tries) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) {
                return;
            }
            var profile = plugin.getProfileManager().getProfile(player.getUniqueId());
            if (profile == null && tries < 5) {
                attempt(player, tries + 1);   // профиль ещё не пришёл
                return;
            }
            if (genders.needsChoice(player) && player.getOpenInventory().getType()
                    == org.bukkit.event.inventory.InventoryType.CRAFTING) {
                genders.openMenu(player);
            }
        }, 40L);
    }
}
