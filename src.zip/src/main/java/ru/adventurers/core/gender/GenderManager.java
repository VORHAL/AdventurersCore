package ru.adventurers.core.gender;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.hud.PackItems;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.profile.Gender;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.ProfileManager;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Выбор пола персонажа и его показ в чате и TAB.
 *
 * <p>Пол обязателен для игры (gender.yml: required: true): меню открывается сразу после
 * загрузки профиля, а пока пол не выбран, игрок не может пользоваться командами гильдии.
 * Так выбор нельзя «забыть» на неделю, зато он не отбирает у игрока вход на сервер целиком -
 * если админ поставит required: false, всё продолжает работать без выбора.
 *
 * <p>Что даёт пол ровно: значок в чате и TAB (глиф пака E050/E051), подпись в карточке
 * игрока и отдельные женские модели брони. Характеристики не меняются - это косметика,
 * а не второй класс (раздел 17 отчёта).
 */
public class GenderManager {

    private final AdventurersCore plugin;
    private final ProfileManager profiles;
    private final MessageManager messages;

    private boolean enabled = true;
    private boolean required = true;
    private final Set<UUID> prompted = new HashSet<>();

    private String title = "&8Выбор пола";
    private List<String> intro = List.of();
    private String maleName = "&bМужской";
    private String maleLore = "&7Классические модели брони.";
    private String maleIcon = "IRON_CHESTPLATE";
    private String maleHead = "";
    private String femaleName = "&dЖенский";
    private String femaleLore = "&7Свои модели брони: armor_female_*.";
    private String femaleIcon = "GOLDEN_CHESTPLATE";
    private String femaleHead = "";
    private boolean glow = true;

    public GenderManager(AdventurersCore plugin, ProfileManager profiles, MessageManager messages) {
        this.plugin = plugin;
        this.profiles = profiles;
        this.messages = messages;
    }

    /**
     * Владелец окна меню: по нему слушатель понимает, что клик пришёл в наше окно,
     * а не в сундук или в меню другого плагина. Сравнивать название окна нельзя -
     * игрок может открыть свой сундук с таким же названием.
     */
    public static final class MenuHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    /** Это наше меню пола? */
    public boolean isGenderMenu(Inventory inventory) {
        return inventory != null && inventory.getHolder() instanceof MenuHolder;
    }

    public void reload() {
        File file = plugin.getFiles().file("gender.yml");
        if (!file.exists()) {
            plugin.getFiles().save("gender.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        required = cfg.getBoolean("required", true);
        title = cfg.getString("menu.title", title);
        intro = cfg.getStringList("menu.intro");
        maleName = cfg.getString("menu.male.name", maleName);
        maleLore = cfg.getString("menu.male.lore", maleLore);
        maleIcon = cfg.getString("menu.male.icon", maleIcon);
        maleHead = cfg.getString("menu.male.head", "");
        femaleName = cfg.getString("menu.female.name", femaleName);
        femaleLore = cfg.getString("menu.female.lore", femaleLore);
        femaleIcon = cfg.getString("menu.female.icon", femaleIcon);
        femaleHead = cfg.getString("menu.female.head", "");
        glow = cfg.getBoolean("menu.glow", true);
    }

    public boolean isEnabled() {
        return enabled;
    }

    public boolean isRequired() {
        return required;
    }

    /** Нужно ли спрашивать пол у этого игрока (профиль уже загружен, пола нет). */
    public boolean needsChoice(Player player) {
        if (!enabled || !required || player == null) {
            return false;
        }
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        return profile != null && !profile.hasGender();
    }

    /** Меню выбора: два предмета, клик выдаёт пол. */
    public void openMenu(Player player) {
        if (!enabled) {
            messages.send(player, "gender.disabled");
            return;
        }
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        if (profile == null) {
            messages.send(player, "profile.loading");
            return;
        }
        MenuHolder holder = new MenuHolder();
        Inventory inventory = Bukkit.createInventory(holder, 27, Hud.legacy(apply(player, title)));
        holder.inventory = inventory;
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        if (fillerMeta != null) {
            fillerMeta.displayName(Component.empty());
            filler.setItemMeta(fillerMeta);
        }
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
        inventory.setItem(11, button(player, Gender.MALE, maleIcon, maleHead, maleName, maleLore));
        inventory.setItem(15, button(player, Gender.FEMALE, femaleIcon, femaleHead, femaleName, femaleLore));
        player.openInventory(inventory);
        for (String line : intro) {
            messages.send(player, line, Map.of());
        }
        prompted.add(player.getUniqueId());
    }

    private ItemStack button(Player player, Gender gender, String icon, String head, String name, String lore) {
        Material material = head != null && !head.isBlank() ? Material.PLAYER_HEAD
                : Material.matchMaterial(icon == null ? "" : icon.toUpperCase(Locale.ROOT));
        if (material == null) {
            material = gender == Gender.FEMALE ? Material.GOLDEN_CHESTPLATE : Material.IRON_CHESTPLATE;
        }
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        if (head != null && !head.isBlank() && meta instanceof SkullMeta skull) {
            Player owner = Bukkit.getPlayerExact(head);
            if (owner != null) {
                skull.setOwningPlayer(owner);
            }
        }
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        boolean current = profile != null && profile.getGender() == gender;
        meta.displayName(Hud.legacy(apply(player, name) + (current ? " &8(выбран)" : "")));
        List<Component> lines = new ArrayList<>();
        for (String line : (lore == null ? "" : lore).split("\n")) {
            if (!line.isBlank()) {
                lines.add(Hud.legacy(apply(player, line)));
            }
        }
        if (profile != null && profile.getGender().isChosen()) {
            lines.add(Component.empty());
            lines.add(Hud.legacy("&8Сейчас: " + apply(player, profile.getGender().getDisplayName())));
        }
        meta.lore(lines);
        if (glow) {
            meta.setEnchantmentGlintOverride(true);
        }
        meta.getPersistentDataContainer().set(genderKey(), PersistentDataType.STRING, gender.getId());
        item.setItemMeta(meta);
        return item;
    }

    private NamespacedKey genderKey() {
        return new NamespacedKey(plugin, "gender_choice");
    }

    /** Пол из клика по кнопке меню: null, если предмет не наш. */
    public Gender clickedGender(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        String value = meta.getPersistentDataContainer().get(genderKey(), PersistentDataType.STRING);
        return value == null ? null : Gender.fromInput(value);
    }

    /** Обработка клика в меню. Возвращает true, если клик был по нашей кнопке. */
    public boolean clickMenu(Player player, ItemStack item) {
        Gender gender = clickedGender(item);
        if (gender == null || !gender.isChosen()) {
            return false;
        }
        player.closeInventory();
        setGender(player, gender);
        return true;
    }

    /** Сохраняет пол и сразу обновляет модель выданной брони, TAB и панель. */
    public boolean setGender(Player player, Gender gender) {
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        if (profile == null) {
            messages.send(player, "profile.loading");
            return false;
        }
        profile.setGender(gender);
        profiles.saveNow(profile);
        messages.send(player, "gender.chosen", Map.of("gender", apply(player, gender.getDisplayName())));
        if (plugin.getGuildGear() != null) {
            plugin.getGuildGear().refreshModels(player);
        }
        if (plugin.getTabList() != null) {
            plugin.getTabList().update(player);
        }
        if (plugin.getScoreboard() != null) {
            plugin.getScoreboard().update(player);
        }
        return true;
    }

    /** Значок пола для формата чата/TAB: глиф пака; пусто без пака или без выбора. */
    public Component badge(Player player) {
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        if (profile == null || !profile.getGender().isChosen()) {
            return Component.empty();
        }
        return PackItems.gender(profile.getGender());
    }

    /** Подпись пола для {gender} в текстах: «Мужской»/«Женский» (под цвет профиля). */
    public String apply(Player player, String text) {
        if (text == null || !text.contains("{gender}")) {
            return text;
        }
        PlayerProfile profile = player == null ? null : profiles.getProfile(player.getUniqueId());
        String name = profile == null ? "" : profile.getGender().getDisplayName();
        return text.replace("{gender}", name);
    }

    public void forget(UUID uuid) {
        prompted.remove(uuid);
    }

    /** Показывали ли меню в эту сессию (чтобы не открывать его на каждое действие). */
    public boolean wasPrompted(UUID uuid) {
        return prompted.contains(uuid);
    }
}
