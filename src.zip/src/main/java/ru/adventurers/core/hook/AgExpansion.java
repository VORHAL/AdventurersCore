package ru.adventurers.core.hook;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.ClassManager;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.classes.PlayerClasses;
import ru.adventurers.core.message.MessageManager;
import ru.adventurers.core.party.Party;
import ru.adventurers.core.party.PartyManager;
import ru.adventurers.core.quest.QuestDef;
import ru.adventurers.core.quest.QuestManager;
import ru.adventurers.core.rank.RankManager;
import ru.adventurers.core.profession.PlayerProfessions;
import ru.adventurers.core.profession.Profession;
import ru.adventurers.core.profession.ProfessionManager;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.ProfileManager;
import ru.adventurers.core.profile.Rank;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class AgExpansion extends PlaceholderExpansion {

    private final AdventurersCore plugin;
    private final ProfileManager profiles;
    private final MessageManager messages;

    public AgExpansion(AdventurersCore plugin, ProfileManager profiles, MessageManager messages) {
        this.plugin = plugin;
        this.profiles = profiles;
        this.messages = messages;
    }

    @Override
    public String getIdentifier() {
        return "ag";
    }

    @Override
    public String getAuthor() {
        return "AdventurersGuild";
    }

    @Override
    public String getVersion() {
        return plugin.getPluginMeta().getVersion();
    }

    @Override
    public boolean persist() {
        return true; // иначе /papi reload отключит наши плейсхолдеры
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (player == null) {
            return "";
        }
        PlayerProfile profile = profiles.getProfile(player.getUniqueId());
        if (profile == null) {
            return ""; // профиль ещё не загружен или игрок не в сети
        }

        Rank rank = profile.getRank();
        Rank next = rank.next();
        String key = params.toLowerCase(Locale.ROOT);

        String genderValue = genderPlaceholder(profile, key);
        if (genderValue != null) {
            return genderValue;
        }

        switch (key) {
            case "rank":
                return rank.getDisplayName();
            case "rank_colored":
                return messages.toSection(messages.rankName(rank));
            case "rank_index":
                return String.valueOf(rank.ordinal() + 1);
            case "next_rank":
                return next != null
                        ? next.getDisplayName()
                        : messages.stripColors(messages.maxRankText());
            case "next_rank_colored":
                return next != null
                        ? messages.toSection(messages.rankName(next))
                        : messages.toSection(messages.maxRankText());
            case "username":
                return profile.getUsername();
            case "online":
                return String.valueOf(org.bukkit.Bukkit.getOnlinePlayers().size());
            case "max_online":
                return String.valueOf(org.bukkit.Bukkit.getMaxPlayers());
            case "ping":
                return player instanceof org.bukkit.entity.Player online ? online.getPing() + " мс" : "";
            case "sb_state":
                return player instanceof org.bukkit.entity.Player viewer
                        && plugin.getScoreboard().isVisible(viewer) ? "§aвкл" : "§cвыкл";
            default:
                break;
        }

        // %ag_atleast_C% -> true, если ранг игрока не ниже C
        if (key.startsWith("atleast_")) {
            Rank required = Rank.fromInput(params.substring("atleast_".length()));
            if (required == null) {
                return null;
            }
            return String.valueOf(rank.isAtLeast(required));
        }

        if (key.startsWith("group_") || key.startsWith("raid_")) {
            return partyPlaceholder(player, key);
        }
        if (key.startsWith("promo_")) {
            return promoPlaceholder(player, rank, key.substring("promo_".length()));
        }
        if (key.equals("quests_done")) {
            QuestManager done = plugin.getQuests();
            return done != null ? String.valueOf(done.completed(player.getUniqueId())) : "0";
        }
        if (key.equals("bank") || key.equals("purse")) {
            if (plugin.getEconomy() == null) {
                return "0";
            }
            long value = key.equals("bank") ? plugin.getEconomy().bank(player.getUniqueId())
                    : (player.getPlayer() == null ? 0 : plugin.getEconomy().purse(player.getPlayer()));
            return plugin.getEconomy().plain(value);
        }
        if (key.equals("pet")) {
            org.bukkit.entity.Player online = player.getPlayer();
            return online == null || plugin.getPets() == null ? "" : plugin.getPets().activeText(online);
        }
        if (key.equals("title") || key.equals("achievements")) {
            org.bukkit.entity.Player online = player.getPlayer();
            if (online == null || plugin.getGlory() == null) {
                return key.equals("title") ? "" : "0";
            }
            return key.equals("title") ? plugin.getGlory().titleName(online)
                    : plugin.getGlory().doneCount(online) + "/" + plugin.getGlory().totalCount();
        }
        if (key.equals("covenant") || key.equals("covenant_role") || key.equals("covenant_members")) {
            var cov = plugin.getCovenants() == null ? null : plugin.getCovenants().of(player.getUniqueId());
            if (cov == null) {
                return key.equals("covenant_members") ? "0" : "-";
            }
            return switch (key) {
                case "covenant" -> cov.name;
                case "covenant_members" -> String.valueOf(cov.members.size());
                default -> cov.role(player.getUniqueId()).title;
            };
        }
        if (key.equals("coins")) {
            return plugin.getEconomy() != null ? plugin.getEconomy().plain(plugin.getEconomy().balance(player.getUniqueId())) : "0";
        }
        if (key.equals("points")) {
            QuestManager quests = plugin.getQuests();
            return quests != null ? String.valueOf(quests.points(player.getUniqueId())) : "0";
        }
        if (key.startsWith("quest_")) {
            return questPlaceholder(player, key);
        }

        if (key.startsWith("class")) {
            return classPlaceholder(player, key);
        }

        // %ag_prof_...% -> профессии
        if (key.startsWith("prof_")) {
            return professionPlaceholder(player, rank, key.substring("prof_".length()));
        }
        return null; // неизвестный плейсхолдер
    }

    /**
     * %ag_group_size%  %ag_group_info% ("3/5" или "-")  %ag_group_leader%
     * %ag_group_member_<n>_has|name|class|role|leader%  участник n (1-5)
     * %ag_raid_size%  %ag_raid_info%  %ag_raid_ready% (true/false)
     * %ag_raid_tanks% %ag_raid_healers% %ag_raid_fighters%  "1/2" (зелёным, если набрано)
     */
    private String partyPlaceholder(OfflinePlayer offline, String key) {
        PartyManager parties = plugin.getParties();
        if (parties == null) {
            return "";
        }
        UUID uuid = offline.getUniqueId();
        boolean raid = key.startsWith("raid_");
        Party party = raid ? parties.raid(uuid) : parties.group(uuid);
        Party.Type type = raid ? Party.Type.RAID : Party.Type.GROUP;
        String what = key.substring(raid ? "raid_".length() : "group_".length());
        int max = parties.maxSize(type);

        switch (what) {
            case "size":
                return String.valueOf(party != null ? party.size() : 0);
            case "info":
                return party != null ? party.size() + "/" + max : "-";
            case "leader": {
                if (party == null) {
                    return "-";
                }
                org.bukkit.OfflinePlayer leader = org.bukkit.Bukkit.getOfflinePlayer(party.getLeader());
                return leader.getName() != null ? leader.getName() : "?";
            }
            case "ready":
                return String.valueOf(raid && party != null && parties.raidReady(party));
            default:
                break;
        }

        if (raid && party != null && (what.equals("tanks") || what.equals("healers") || what.equals("fighters"))) {
            PartyManager.Composition c = parties.composition(party);
            String role = what.substring(0, what.length() - 1); // tank/healer/fighter
            int have = switch (what) {
                case "tanks" -> c.tanks();
                case "healers" -> c.healers();
                default -> c.fighters();
            };
            int need = parties.need(role);
            return (have >= need ? "§a" : "§e") + have + "§8/§f" + need;
        }
        if (raid && (what.equals("tanks") || what.equals("healers") || what.equals("fighters"))) {
            String role = what.substring(0, what.length() - 1);
            return "§c0§8/§f" + parties.need(role);
        }

        if (what.startsWith("member_")) {
            String[] parts = what.split("_", 3); // member, n, field
            if (parts.length < 3) {
                return null;
            }
            int index;
            try {
                index = Integer.parseInt(parts[1]);
            } catch (NumberFormatException exception) {
                return null;
            }
            UUID member = null;
            if (party != null) {
                int i = 1;
                for (UUID id : party.members()) {
                    if (i++ == index) {
                        member = id;
                        break;
                    }
                }
            }
            switch (parts[2]) {
                case "has":
                    return String.valueOf(member != null);
                case "name": {
                    if (member == null) {
                        return "";
                    }
                    String name = org.bukkit.Bukkit.getOfflinePlayer(member).getName();
                    return name != null ? name : "?";
                }
                case "class": {
                    PlayerClass active = member != null ? plugin.getClasses().activeClass(member) : null;
                    return active != null ? messages.toSection(plugin.getClasses().displayName(active)) : "§8—";
                }
                case "role": {
                    PlayerClass active = member != null ? plugin.getClasses().activeClass(member) : null;
                    return active != null ? messages.toSection(plugin.getClasses().role(active)) : "§8—";
                }
                case "leader":
                    return String.valueOf(member != null && party.getLeader().equals(member));
                default:
                    return null;
            }
        }
        return null;
    }

    /**
     * %ag_promo_ready%        true, если все условия повышения выполнены
     * %ag_promo_max%          true, если ранг максимальный
     * %ag_promo_points%       "30/50" (зелёным, если выполнено; красным, если нет)
     * %ag_promo_quests%, %ag_promo_profession%, %ag_promo_days%, %ag_promo_class%
     *                         то же для остальных условий; "-" если для ранга не требуется
     * %ag_quests_done%        выполнено заданий всего
     */
    private String promoPlaceholder(OfflinePlayer offline, Rank rank, String what) {
        if (what.equals("max")) {
            return String.valueOf(rank.next() == null);
        }
        if (!(offline instanceof org.bukkit.entity.Player player) || plugin.getRanks() == null) {
            return "";
        }
        if (what.equals("ready")) {
            return String.valueOf(plugin.getRanks().canPromote(player));
        }
        for (RankManager.Status status : plugin.getRanks().check(player)) {
            if (status.id().equals(what)) {
                return (status.ok() ? "§a" : "§c") + status.current() + "§8/§f" + status.needed();
            }
        }
        return rank.next() == null ? "§8-" : "§8-";
    }

    /**
     * %ag_points%              очки гильдии
     * %ag_quest_left%          сколько заданий ещё можно принять сегодня
     * %ag_quest_limit%         дневной лимит
     * %ag_quest_active%        сколько заданий сейчас активно
     * %ag_quest_max_active%    сколько можно держать одновременно
     * %ag_quest_<n>_title%     название задания в ячейке n (1-8)
     * %ag_quest_<n>_state%     empty / available / limited / active / ready / done
     * %ag_quest_<n>_goal%      цель, %ag_quest_<n>_reward% награда, %ag_quest_<n>_progress% "3/8"
     * %ag_quest_<n>_story_1% .. _3  строки истории
     */
    private String questPlaceholder(OfflinePlayer offline, String key) {
        QuestManager quests = plugin.getQuests();
        if (quests == null || !(offline instanceof org.bukkit.entity.Player player)
                || quests.get(player.getUniqueId()) == null) {
            return "";
        }
        switch (key) {
            case "quest_left":
                return String.valueOf(quests.dailyLeft(player));
            case "quest_limit":
                return String.valueOf(quests.getDailyLimit());
            case "quest_active":
                return String.valueOf(quests.activeCount(player));
            case "quest_max_active":
                return String.valueOf(quests.getMaxActive());
            default:
                break;
        }

        String[] parts = key.split("_", 3); // quest, n, what
        if (parts.length < 3) {
            return null;
        }
        int slot;
        try {
            slot = Integer.parseInt(parts[1]);
        } catch (NumberFormatException exception) {
            return null;
        }
        String what = parts[2];
        if (what.equals("state")) {
            return quests.state(player, slot);
        }
        QuestDef def = quests.slot(player, slot);
        if (def == null) {
            return "";
        }
        switch (what) {
            case "title":
                return messages.toSection(def.title());
            case "goal":
                return messages.toSection("&f" + quests.goalText(def));
            case "reward":
                return messages.toSection(quests.rewardText(def));
            case "progress":
                return quests.progress(player, def) + "/" + def.amount();
            case "type":
                return def.type().name().toLowerCase(java.util.Locale.ROOT);
            default:
                break;
        }
        if (what.startsWith("story_")) {
            try {
                int line = Integer.parseInt(what.substring("story_".length()));
                return line >= 1 && line <= def.story().size()
                        ? messages.toSection(def.story().get(line - 1)) : "";
            } catch (NumberFormatException exception) {
                return null;
            }
        }
        return null;
    }

    /**
     * %ag_class%               активный класс с цветом (пусто, если нет)
     * %ag_class_id%            tank / healer / fighter / universal (пусто, если нет)
     * %ag_class_role%          роль: Защита / Поддержка / Урон
     * %ag_class_count%         сколько классов выбрано (0-2)
     * %ag_class_can_choose%    true, если сейчас можно выбрать новый класс
     * %ag_class_has_<id>%      true, если класс выбран игроком
     * %ag_class_active_<id>%   true, если класс сейчас активен
     * %ag_class_available_<id>% true, если им можно пользоваться (выбран или универсал на ранге S)
     */
    /**
     * Пол персонажа (раздел 17 отчёта):
     * %ag_gender%          подпись с цветом: «&bМужской» / «&dЖенский» (пусто, если не выбран)
     * %ag_gender_id%       male / female / unset
     * %ag_gender_icon%     глиф пака (E050 женский, E051 мужской) - только с pack.glyphs: true
     * %ag_gender_symbol%   ♀ / ♂ обычным текстом - работает без пака
     */
    private String genderPlaceholder(PlayerProfile profile, String key) {
        if (!key.startsWith("gender")) {
            return null;
        }
        var gender = profile.getGender();
        return switch (key) {
            case "gender" -> gender.isChosen() ? messages.toSection(gender.getDisplayName()) : "";
            case "gender_id" -> gender.getId();
            case "gender_icon" -> switch (gender) {
                case FEMALE -> "\uE050";
                case MALE -> "\uE051";
                default -> "";
            };
            case "gender_symbol" -> switch (gender) {
                case FEMALE -> "♀";
                case MALE -> "♂";
                default -> "";
            };
            case "gender_chosen" -> String.valueOf(gender.isChosen());
            default -> null;
        };
    }

    private String classPlaceholder(OfflinePlayer offline, String key) {
        ClassManager classes = plugin.getClasses();
        if (classes == null) {
            return "";
        }
        PlayerClasses data = classes.get(offline.getUniqueId());
        if (data == null) {
            return "";
        }
        PlayerClass active = data.getActive();
        switch (key) {
            case "class":
                return active != null ? messages.toSection(classes.displayName(active)) : "§8—";
            case "mana":
                return plugin.getServer().getPlayer(offline.getUniqueId()) instanceof org.bukkit.entity.Player manaPlayer
                        && plugin.getHealer().canUse(manaPlayer)
                        ? String.valueOf((int) plugin.getHealer().getMana(manaPlayer)) : "0";
            case "mana_max":
                return plugin.getServer().getPlayer(offline.getUniqueId()) instanceof org.bukkit.entity.Player manaMaxPlayer
                        && plugin.getHealer().canUse(manaMaxPlayer)
                        ? String.valueOf((int) plugin.getHealer().maxMana(manaMaxPlayer)) : "0";
            case "class_icon":
                return classes.icon(active);
            case "class_tag":
                return classes.tag(offline.getUniqueId());
            case "class_id":
                return active != null ? active.getId() : "";
            case "class_role":
                return active != null ? messages.toSection(classes.role(active)) : "§8—";
            case "class_count":
                return String.valueOf(data.count());
            case "class_can_choose":
                return offline instanceof org.bukkit.entity.Player p
                        ? String.valueOf(classes.canChooseNew(p)) : "false";
            default:
                break;
        }
        for (String prefix : new String[]{"class_has_", "class_active_", "class_available_"}) {
            if (key.startsWith(prefix)) {
                PlayerClass target = PlayerClass.fromInput(key.substring(prefix.length()));
                if (target == null) {
                    return null;
                }
                if (prefix.equals("class_has_")) {
                    return String.valueOf(data.owns(target));
                }
                if (prefix.equals("class_active_")) {
                    return String.valueOf(active == target);
                }
                boolean available = data.owns(target) || (target == PlayerClass.UNIVERSAL
                        && offline instanceof org.bukkit.entity.Player p && classes.universalAvailable(p));
                return String.valueOf(available);
            }
        }
        return null;
    }

    /**
     * %ag_prof_count%          сколько профессий знает игрок
     * %ag_prof_max%            сколько профессий можно знать всего
     * %ag_prof_cap%            максимальный уровень профессии на его ранге
     * %ag_prof_list%           "Охотник 3, Алхимик 1" с цветами
     * %ag_prof_hunter_level%   уровень профессии (0, если не знает)
     * %ag_prof_hunter_xp%      накопленный опыт
     * %ag_prof_hunter_has%     true или false
     * %ag_prof_hunter_next%    опыт до следующего уровня ("-" на максимуме)
     * %ag_prof_hunter_percent% прогресс до следующего уровня, 0-100
     * %ag_prof_hunter_bar%     полоска прогресса из 10 символов
     * %ag_prof_max%            сколько профессий можно знать
     */
    private String professionPlaceholder(OfflinePlayer player, Rank rank, String rest) {
        ProfessionManager professions = plugin.getProfessions();
        if (professions == null) {
            return "";
        }
        PlayerProfessions data = professions.get(player.getUniqueId());
        if (data == null) {
            return "";
        }

        switch (rest) {
            case "count":
                return String.valueOf(data.count());
            case "cap":
                return String.valueOf(professions.levelCapFor(rank));
            case "max":
                return String.valueOf(professions.getMaxProfessions());
            case "max_main":
                return String.valueOf(professions.getMaxMain());
            case "max_extra":
                return String.valueOf(professions.getMaxExtra());
            case "main_count":
                return String.valueOf(professions.count(data, true));
            case "extra_count":
                return String.valueOf(professions.count(data, false));
            case "main_full":
                return String.valueOf(professions.count(data, true) >= professions.getMaxMain());
            case "extra_full":
                return String.valueOf(professions.count(data, false) >= professions.getMaxExtra());
            case "list": {
                List<String> parts = new ArrayList<>();
                for (Profession profession : data.professions()) {
                    PlayerProfessions.Progress progress = data.get(profession);
                    if (progress != null) {
                        parts.add(messages.toSection(
                                professions.displayName(profession) + " &f" + progress.getLevel()));
                    }
                }
                return String.join("§7, ", parts);
            }
            default:
                break;
        }

        int split = rest.lastIndexOf('_');
        if (split <= 0) {
            return null;
        }
        Profession profession = Profession.fromInput(rest.substring(0, split));
        if (profession == null) {
            return null;
        }
        PlayerProfessions.Progress progress = data.get(profession);

        switch (rest.substring(split + 1)) {
            case "level":
                return String.valueOf(progress != null ? progress.getLevel() : 0);
            case "xp":
                return String.valueOf(progress != null ? progress.getXp() : 0);
            case "has":
                return String.valueOf(progress != null);
            case "next": {
                if (progress == null) {
                    return "0";
                }
                int need = professions.xpToNext(progress.getLevel());
                return need < 0 ? "-" : String.valueOf(need);
            }
            case "percent": {
                if (progress == null) {
                    return "0";
                }
                int need = professions.xpToNext(progress.getLevel());
                if (need <= 0) {
                    return "100";
                }
                return String.valueOf(Math.min(100, progress.getXp() * 100 / need));
            }
            case "bar": {
                if (progress == null) {
                    return "";
                }
                int need = professions.xpToNext(progress.getLevel());
                int filled = need <= 0 ? 10 : Math.min(10, progress.getXp() * 10 / need);
                return "§a" + "|".repeat(filled) + "§8" + "|".repeat(10 - filled);
            }
            default:
                return null;
        }
    }
}
