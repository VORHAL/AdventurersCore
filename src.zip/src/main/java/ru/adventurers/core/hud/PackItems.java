package ru.adventurers.core.hud;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.components.EquippableComponent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionType;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.profile.Gender;
import ru.adventurers.core.profile.Rank;

import java.util.Locale;
import java.util.Set;

/**
 * Свои модели предметов из ресурспака Adventurers (item_model) и вид брони на игроке.
 * Включается в frames.yml: pack.item-models: true (только когда пак уже раздаётся игрокам,
 * иначе у игроков без пака вместо предмета будет "пурпурная" заглушка).
 *
 * <p>Имена моделей взяты из AdventurersPack:
 * <ul>
 *   <li>броня: {@code armor_<класс>_<ранг>_<часть>} для классов из pack.gear-classes
 *       (в паке боец, лекарь и танк нарисованы на всех рангах, с F по S) и
 *       {@code armor_<ранг>_<часть>} для остальных;</li>
 *   <li>оружие: {@code weapon_sword|axe|mace|spear|bow|crossbow_<ранг>} и {@code sword_<ранг>};</li>
 *   <li>щиты: {@code shield_tank} и {@code shield_<ранг>};</li>
 *   <li>зелья: {@code potion_hp|mana|cure_1..3};</li>
 *   <li>прочее: {@code staff}, {@code coin_*}, {@code gem_*}, {@code gem_raw};</li>
 *   <li>пол: {@code armor_<male|female>_<класс>_<ранг>_<часть>} и слой
 *       {@code <male|female>_<класс>_<ранг>} - только внешность, статы не меняются.</li>
 * </ul>
 * Если модели в паке нет, предмет останется ванильным: клиент просто не найдёт модель.
 */
public final class PackItems {

    /** Уровни зелий в паке: 1 - обычное, 2 - длинное (long), 3 - усиленное (strong). */
    private static final int POTION_LEVELS = 3;

    private static boolean enabled = false;
    private static boolean glyphs = false;

    /**
     * Классы, для которых в паке нарисована отдельная броня на A+ и S
     * ({@code armor_fighter_a_plus_helmet}). Остальные классы берут общую модель ранга.
     * Задаётся в frames.yml: pack.gear-classes - список нужно держать в согласии с паком,
     * сверка: tools/pack_models.py <папка пака>.
     */
    private static final Set<String> GEAR_CLASSES = new java.util.HashSet<>(Set.of("fighter", "healer", "tank"));

    private PackItems() {
    }

    public static void setEnabled(boolean value) {
        enabled = value;
    }

    public static void setGlyphs(boolean value) {
        glyphs = value;
    }

    /** Классы с собственной моделью брони в паке; пустой список - все классы получают общую модель. */
    public static void setGearClasses(java.util.List<String> ids) {
        GEAR_CLASSES.clear();
        if (ids != null) {
            for (String id : ids) {
                if (id != null && !id.isBlank()) {
                    GEAR_CLASSES.add(id.trim().toLowerCase(Locale.ROOT));
                }
            }
        }
    }

    /** Есть ли в паке отдельная броня этого класса на высоких рангах. */
    public static boolean hasClassArmor(PlayerClass playerClass) {
        return playerClass != null && GEAR_CLASSES.contains(playerClass.getId().toLowerCase(Locale.ROOT));
    }

    /**
     * Значок ранга шрифтом пака для {badge} в чате и TAB. Пусто, если glyphs выключены.
     * Включайте только вместе с force: true для пака, иначе у игроков без пака будут квадраты.
     */
    public static net.kyori.adventure.text.Component badge(Rank rank) {
        return glyph(0xE020, rank == null ? -1 : rank.ordinal());
    }

    /**
     * Значок пола шрифтом пака: E050 - женский, E051 - мужской (hud/gender_female.png,
     * hud/gender_male.png). Пусто, если глифы выключены или пол не выбран.
     */
    public static net.kyori.adventure.text.Component gender(Gender gender) {
        if (gender == null || !gender.isChosen()) {
            return net.kyori.adventure.text.Component.empty();
        }
        return glyph(gender == Gender.FEMALE ? 0xE050 : 0xE051, 0);
    }

    /** Значок класса шрифтом пака (E010..E013). */
    public static net.kyori.adventure.text.Component classIcon(PlayerClass playerClass) {
        return glyph(0xE010, playerClass == null ? -1 : playerClass.ordinal());
    }

    /** Иконка {@code {ico:имя}} - те же коды, что использует Hud. */
    public static net.kyori.adventure.text.Component icon(String name) {
        int index = ICON_NAMES.indexOf(name == null ? "" : name.toLowerCase(Locale.ROOT));
        return glyph(0xE030, index);
    }

    private static final java.util.List<String> ICON_NAMES = java.util.List.of(
            "rank", "class", "prof", "coin", "quest", "group", "online", "ping", "points", "bank");

    private static net.kyori.adventure.text.Component glyph(int base, int index) {
        if (!glyphs || index < 0) {
            return net.kyori.adventure.text.Component.empty();
        }
        return net.kyori.adventure.text.Component.text(String.valueOf((char) (base + index)))
                .font(net.kyori.adventure.key.Key.key("adventurers", "hud"))
                .color(net.kyori.adventure.text.format.TextColor.color(0xffffff));
    }

    public static boolean glyphsEnabled() {
        return glyphs;
    }

    public static boolean enabled() {
        return enabled;
    }

    private static NamespacedKey key(String path) {
        return NamespacedKey.fromString("adventurers:" + path);
    }

    /** Ранг в имени моделей: a_plus, f, s... (как в паке). */
    private static String rank(Rank rank) {
        return rank.name().toLowerCase(Locale.ROOT);
    }

    /**
     * Ранг с классом: {@code fighter_a_plus}, {@code tank_f}. В паке классовая броня
     * нарисована на всех рангах (armor_fighter_f ... armor_fighter_s), поэтому класс
     * подставляется сразу, а не с A+: игрок с F ранга видит свою броню, а не общую.
     * Для класса без своего арта остаётся общая модель ранга.
     */
    private static String rankFor(PlayerClass playerClass, Rank rank, Gender gender) {
        String base = hasClassArmor(playerClass)
                ? playerClass.getId() + "_" + rank(rank)
                : rank(rank);
        return hasGenderArmor(gender) ? gender.modelPart() + "_" + base : base;
    }

    /** Женские модели отдельные; мужские совпадают с общими (в паке нет armor_male_*). */
    private static boolean hasGenderArmor(Gender gender) {
        return gender == Gender.FEMALE;
    }

    /** Часть комплекта по материалу: helmet, chestplate, leggings, boots или null. */
    private static String piece(Material material) {
        String name = material.name();
        if (name.endsWith("_HELMET")) {
            return "helmet";
        }
        if (name.endsWith("_CHESTPLATE")) {
            return "chestplate";
        }
        if (name.endsWith("_LEGGINGS")) {
            return "leggings";
        }
        if (name.endsWith("_BOOTS")) {
            return "boots";
        }
        return null;
    }

    private static EquipmentSlot slotOf(String piece) {
        return switch (piece) {
            case "helmet" -> EquipmentSlot.HEAD;
            case "chestplate" -> EquipmentSlot.CHEST;
            case "leggings" -> EquipmentSlot.LEGS;
            default -> EquipmentSlot.FEET;
        };
    }

    /** Модель оружия по материалу и рангу; null, если пак такой вид не рисует. */
    private static String weaponModel(Material material, String rk) {
        String name = material.name();
        if (name.endsWith("_SWORD")) {
            return "weapon_sword_" + rk;
        }
        if (name.endsWith("_AXE")) {
            return "weapon_axe_" + rk;
        }
        if (name.equals("MACE")) {
            return "weapon_mace_" + rk;
        }
        if (name.equals("TRIDENT")) {
            return "weapon_spear_" + rk;
        }
        if (name.equals("BOW")) {
            return "weapon_bow_" + rk;
        }
        if (name.equals("CROSSBOW")) {
            return "weapon_crossbow_" + rk;
        }
        return null;
    }

    /**
     * Гильдейская экипировка: броня, щит и оружие по рангу (и по классу на A+ и S).
     *
     * @param playerClass активный класс владельца; null - используются общие модели
     */
    public static void gear(ItemMeta meta, Material material, Rank rank, PlayerClass playerClass) {
        gear(meta, material, rank, playerClass, Gender.UNSET);
    }

    /**
     * Гильдейская экипировка с учётом пола: у женского персонажа своя модель брони
     * ({@code armor_female_fighter_f_chestplate}) и свой слой на теле
     * ({@code equipment/female_fighter_f}); мужской персонаж и «пол не выбран»
     * получают общие модели ранга. Характеристики предмета не меняются.
     */
    public static void gear(ItemMeta meta, Material material, Rank rank, PlayerClass playerClass,
                            Gender gender) {
        if (!enabled || meta == null || rank == null) {
            return;
        }
        Gender effective = gender == null ? Gender.UNSET : gender;
        String rk = rankFor(playerClass, rank, effective);
        String piece = piece(material);
        if (piece != null) {
            meta.setItemModel(key("armor_" + rk + "_" + piece));
            EquippableComponent equippable = meta.getEquippable();
            equippable.setSlot(slotOf(piece));
            // Слой брони на теле игрока. В паке есть и общий equipment/rank_<ранг>.json,
            // и классовые equipment/<класс>_<ранг>.json - берём классовый, если он есть,
            // иначе на теле будет общий слой, а классовая разница пропадёт.
            String layer = (hasClassArmor(playerClass) ? playerClass.getId() + "_" : "rank_") + rank(rank);
            if (hasGenderArmor(effective)) {
                layer = effective.modelPart() + "_" + layer;
            }
            equippable.setModel(key(layer));
            meta.setEquippable(equippable);
            return;
        }
        if (material == Material.SHIELD) {
            meta.setItemModel(key(playerClass == PlayerClass.TANK ? "shield_tank" : "shield_" + rank(rank)));
            return;
        }
        String weapon = weaponModel(material, rk);
        if (weapon != null) {
            meta.setItemModel(key(weapon));
        }
    }

    /** Перегрузка для мест, где класс неизвестен: общие модели без класса. */
    public static void gear(ItemMeta meta, Material material, Rank rank) {
        gear(meta, material, rank, null);
    }

    /**
     * Модель зелья по его типу: в паке три набора (лечение, мана, противоядие)
     * по три уровня. Уровень берётся из длительности эффекта: длинное зелье - 2,
     * усиленное - 3, обычное - 1.
     */
    public static void potion(ItemMeta meta, PotionType type) {
        if (!enabled || meta == null || type == null) {
            return;
        }
        String family = potionFamily(type);
        if (family == null) {
            return;
        }
        meta.setItemModel(key("potion_" + family + "_" + potionLevel(type)));
    }

    /**
     * Семейство модели: hp (лечение, регенерация), mana (сила, скорость, ночное зрение)
     * или cure (противоядие: яд, урон, иссушение, слабость). В паке три набора по три уровня,
     * поэтому остальные зелья (невидимость, подводное дыхание) остаются ванильными:
     * лучше ванильная модель, чем неверная.
     */
    private static String potionFamily(PotionType type) {
        for (PotionEffect effect : type.getPotionEffects()) {
            String id = effect.getType().getKey().getKey();
            switch (id) {
                case "instant_health", "regeneration" -> {
                    return "hp";
                }
                case "poison", "instant_damage", "wither", "weakness" -> {
                    return "cure";
                }
                case "strength", "speed", "night_vision", "jump_boost" -> {
                    return "mana";
                }
                default -> {
                    // остальные эффекты не рисуем: в паке для них нет модели
                }
            }
        }
        return null;
    }

    /** 1 - обычное, 2 - длинное, 3 - усиленное (по длительности/уровню эффектов). */
    private static int potionLevel(PotionType type) {
        boolean upgraded = false;
        boolean extended = false;
        for (PotionEffect effect : type.getPotionEffects()) {
            if (effect.getAmplifier() > 0) {
                upgraded = true;
            }
            if (effect.getDuration() > 3600) {
                extended = true;
            }
        }
        if (upgraded) {
            return 3;
        }
        return extended ? 2 : 1;
    }

    /** Зелье прямо из метаданных предмета (если это зелье). */
    public static void potion(ItemMeta meta) {
        if (meta instanceof PotionMeta potionMeta) {
            potion(meta, potionMeta.getBasePotionType());
        }
    }

    /** Сколько уровней зелий нарисовано в паке (для проверки при обновлении пака). */
    public static int potionLevels() {
        return POTION_LEVELS;
    }

    /** Простая модель по имени: staff, shield_tank, gem_<id>, gem_raw. */
    public static void model(ItemMeta meta, String name) {
        if (enabled && meta != null) {
            meta.setItemModel(key(name));
        }
    }
}
