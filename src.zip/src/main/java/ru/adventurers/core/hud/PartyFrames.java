package ru.adventurers.core.hud;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.party.Party;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Рамки союзников слева, как в MMO: по строке на каждого игрока группы.
 * С ресурспаком строки рисуются шрифтом adventurers:hud, без него это обычные боссбары.
 * Настройки: frames.yml. Только основной поток.
 */
public class PartyFrames implements Listener {

    // Геометрия пака (см. tools/mkpack.py): ширины в пикселях интерфейса.
    private static final int BG_ADV = 161;     // рамка 160 px + 1
    private static final int PAD_LEFT = 4;
    private static final int ICON_ADV = 9;
    private static final int ICON_GAP = 3;
    private static final int SEGMENTS = 12;
    private static final int SEG_ADV = 5;
    private static final int BAR_GAP = 4;

    private static final char BG = '';
    private static final char SEG = '';
    private static final char ICON_NONE = '';

    private static final Key HUD_FONT = Key.key("adventurers", "hud");
    private static final Key DEFAULT_FONT = Key.key("minecraft", "default");

    private final AdventurersCore plugin;
    private final NamespacedKey offKey;
    private final Map<UUID, List<BossBar>> shown = new HashMap<>();
    private final Set<UUID> packLoaded = new HashSet<>();
    private BukkitTask task;

    private boolean enabled = true;
    private String mode = "auto";
    private int updateTicks = 10;
    private boolean showSelf = false;
    private int maxRows = 5;
    private int nameMax = 13;
    private int offset = 250;
    private boolean sendOnJoin = true;
    private String packUrl = "";
    private String packSha1 = "";
    private boolean packForce = false;
    private String packPrompt = "";
    private TextColor colFull = TextColor.color(0x5fd75f);
    private TextColor colHalf = TextColor.color(0xffd23c);
    private TextColor colLow = TextColor.color(0xff4d4d);
    private TextColor colEmpty = TextColor.color(0x2a2a30);
    private int textBarLength = 10;
    private String textBarChar = "█";
    private String textFormat = "{icon}&f{name} &8| {bar} &f{hp}&8/&f{max}";

    public PartyFrames(AdventurersCore plugin) {
        this.plugin = plugin;
        this.offKey = new NamespacedKey(plugin, "frames_off");
    }

    public void init() {
        reload();
    }

    public void reload() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        File file = plugin.getFiles().file("frames.yml");
        if (!file.exists()) {
            plugin.getFiles().save("frames.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        mode = cfg.getString("mode", "auto").toLowerCase(Locale.ROOT);
        updateTicks = Math.max(2, cfg.getInt("update-ticks", 10));
        showSelf = cfg.getBoolean("show-self", false);
        maxRows = Math.max(1, Math.min(8, cfg.getInt("max-rows", 5)));
        nameMax = Math.max(4, cfg.getInt("name-max-length", 13));
        offset = Math.max(50, cfg.getInt("offset-left", 250));
        sendOnJoin = cfg.getBoolean("pack.send-on-join", true);
        packUrl = cfg.getString("pack.url", "");
        packSha1 = cfg.getString("pack.sha1", "");
        packForce = cfg.getBoolean("pack.force", false);
        PackItems.setEnabled(cfg.getBoolean("pack.item-models", false));
        PackItems.setGlyphs(cfg.getBoolean("pack.glyphs", false));
        PackItems.setGearClasses(cfg.getStringList("pack.gear-classes"));
        packPrompt = cfg.getString("pack.prompt", "");
        colFull = color(cfg.getString("colors.full"), colFull);
        colHalf = color(cfg.getString("colors.half"), colHalf);
        colLow = color(cfg.getString("colors.low"), colLow);
        colEmpty = color(cfg.getString("colors.empty-segment"), colEmpty);
        textBarLength = Math.max(4, cfg.getInt("text.bar-length", 10));
        textBarChar = cfg.getString("text.bar-char", "█");
        textFormat = cfg.getString("text.format", textFormat);

        clearAll();
        if (enabled) {
            task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, updateTicks);
        }
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
        }
        clearAll();
    }

    private static TextColor color(String hex, TextColor fallback) {
        TextColor parsed = hex == null ? null : TextColor.fromHexString(hex);
        return parsed == null ? fallback : parsed;
    }

    // ---------------------------------------------------------------
    //  События
    // ---------------------------------------------------------------

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (!sendOnJoin || packUrl.isBlank()) {
            return;
        }
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                sendPack(player);
            }
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        packLoaded.remove(id);
        shown.remove(id);
    }

    @EventHandler
    public void onPack(PlayerResourcePackStatusEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        switch (event.getStatus()) {
            case SUCCESSFULLY_LOADED -> packLoaded.add(id);
            case DECLINED, FAILED_DOWNLOAD, FAILED_RELOAD, INVALID_URL, DISCARDED -> packLoaded.remove(id);
            default -> {
                // загрузка идёт - ничего не меняем
            }
        }
    }

    private void sendPack(Player player) {
        byte[] hash = null;
        if (packSha1.length() == 40) {
            hash = new byte[20];
            try {
                for (int i = 0; i < 20; i++) {
                    hash[i] = (byte) Integer.parseInt(packSha1.substring(i * 2, i * 2 + 2), 16);
                }
            } catch (NumberFormatException exception) {
                hash = null;
            }
        }
        UUID packId = UUID.nameUUIDFromBytes(("adventurers-pack:" + packUrl).getBytes());
        player.setResourcePack(packId, packUrl, hash, Hud.legacy(packPrompt), packForce);
    }

    // ---------------------------------------------------------------
    //  Включение и выключение для игрока: /ag frames
    // ---------------------------------------------------------------

    public boolean toggle(Player player) {
        boolean off = player.getPersistentDataContainer().has(offKey, PersistentDataType.BYTE);
        if (off) {
            player.getPersistentDataContainer().remove(offKey);
        } else {
            player.getPersistentDataContainer().set(offKey, PersistentDataType.BYTE, (byte) 1);
        }
        return off;
    }

    private boolean disabledBy(Player player) {
        return player.getPersistentDataContainer().has(offKey, PersistentDataType.BYTE);
    }

    // ---------------------------------------------------------------
    //  Обновление
    // ---------------------------------------------------------------

    private void clearAll() {
        for (Map.Entry<UUID, List<BossBar>> entry : shown.entrySet()) {
            Player player = Bukkit.getPlayer(entry.getKey());
            if (player != null) {
                for (BossBar bar : entry.getValue()) {
                    player.hideBossBar(bar);
                }
            }
        }
        shown.clear();
    }

    private void tick() {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            List<Player> allies = alliesOf(viewer);
            List<BossBar> bars = shown.computeIfAbsent(viewer.getUniqueId(), k -> new ArrayList<>());
            boolean usePack = usePack(viewer);

            for (int i = 0; i < allies.size(); i++) {
                Player ally = allies.get(i);
                double max = maxHealth(ally);
                double hp = Math.max(0, Math.min(max, ally.getHealth()));
                double ratio = max <= 0 ? 0 : hp / max;
                Component title = usePack ? packTitle(ally, ratio) : textTitle(ally, hp, max, ratio);
                BossBar.Color barColor = ratio > 0.6 ? BossBar.Color.GREEN : ratio > 0.3 ? BossBar.Color.YELLOW : BossBar.Color.RED;
                if (usePack) {
                    barColor = BossBar.Color.WHITE; // у белого боссбара пак убирает полоску
                }
                if (i < bars.size()) {
                    BossBar bar = bars.get(i);
                    bar.name(title);
                    bar.progress((float) Math.max(0.0, Math.min(1.0, ratio)));
                    bar.color(barColor);
                    bar.overlay(BossBar.Overlay.PROGRESS);
                } else {
                    BossBar bar = BossBar.bossBar(title, (float) Math.max(0.0, Math.min(1.0, ratio)),
                            barColor, BossBar.Overlay.PROGRESS);
                    bars.add(bar);
                    viewer.showBossBar(bar);
                }
            }
            while (bars.size() > allies.size()) {
                viewer.hideBossBar(bars.remove(bars.size() - 1));
            }
        }
        shown.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
    }

    private List<Player> alliesOf(Player viewer) {
        List<Player> result = new ArrayList<>();
        if (disabledBy(viewer)) {
            return result;
        }
        Party group = plugin.getParties().group(viewer.getUniqueId());
        if (group == null) {
            return result;
        }
        for (UUID id : group.members()) {
            if (id.equals(viewer.getUniqueId()) && !showSelf) {
                continue;
            }
            Player ally = Bukkit.getPlayer(id);
            if (ally != null && ally.isOnline()) {
                result.add(ally);
                if (result.size() >= maxRows) {
                    break;
                }
            }
        }
        return result;
    }

    private boolean usePack(Player viewer) {
        return switch (mode) {
            case "pack" -> true;
            case "text" -> false;
            default -> packLoaded.contains(viewer.getUniqueId());
        };
    }

    private static double maxHealth(Player player) {
        AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
        return attr == null ? 20.0 : attr.getValue();
    }

    // ---------------------------------------------------------------
    //  Простой вид (без ресурспака)
    // ---------------------------------------------------------------

    private Component textTitle(Player ally, double hp, double max, double ratio) {
        PlayerClass active = plugin.getClasses().activeClass(ally.getUniqueId());
        String icon = active == null ? "" : plugin.getClasses().icon(active) + " ";
        int filled = (int) Math.ceil(ratio * textBarLength);
        if (hp > 0) {
            filled = Math.max(1, filled);
        }
        StringBuilder bar = new StringBuilder();
        String col = ratio > 0.6 ? "&a" : ratio > 0.3 ? "&e" : "&c";
        bar.append(col).append(textBarChar.repeat(Math.min(filled, textBarLength)))
                .append("&8").append(textBarChar.repeat(Math.max(0, textBarLength - filled)));
        String text = textFormat
                .replace("{icon}", icon)
                .replace("{name}", ally.getName())
                .replace("{bar}", bar)
                .replace("{hp}", String.valueOf((int) Math.ceil(hp)))
                .replace("{max}", String.valueOf((int) Math.ceil(max)));
        return Hud.legacy(text);
    }

    // ---------------------------------------------------------------
    //  Вид с ресурспаком
    // ---------------------------------------------------------------

    private Component packTitle(Player ally, double ratio) {
        PlayerClass active = plugin.getClasses().activeClass(ally.getUniqueId());
        char icon = iconChar(active);
        String name = ally.getName();
        if (name.length() > nameMax) {
            name = name.substring(0, nameMax);
        }
        int filled = (int) Math.ceil(ratio * SEGMENTS);
        if (ratio > 0) {
            filled = Math.max(1, filled);
        }
        filled = Math.min(SEGMENTS, filled);
        TextColor hpColor = ratio > 0.6 ? colFull : ratio > 0.3 ? colHalf : colLow;

        int consumed = PAD_LEFT + ICON_ADV + ICON_GAP + SEGMENTS * SEG_ADV + BAR_GAP + textWidth(name);
        int last = 2 * offset - consumed;

        String head = String.valueOf(BG) + shift(-BG_ADV) + shift(PAD_LEFT) + icon + shift(ICON_GAP);
        Component row = Component.text(head).font(HUD_FONT).color(TextColor.color(0xffffff));
        if (filled > 0) {
            row = row.append(Component.text(String.valueOf(SEG).repeat(filled)).font(HUD_FONT).color(hpColor));
        }
        if (filled < SEGMENTS) {
            row = row.append(Component.text(String.valueOf(SEG).repeat(SEGMENTS - filled)).font(HUD_FONT).color(colEmpty));
        }
        row = row.append(Component.text(shift(BAR_GAP)).font(HUD_FONT));
        row = row.append(Component.text(name).font(HUD_FONT).color(TextColor.color(0xf2f2f2)));
        row = row.append(Component.text(shift(last)).font(HUD_FONT));
        return row;
    }

    private static char iconChar(PlayerClass playerClass) {
        if (playerClass == null) {
            return ICON_NONE;
        }
        return switch (playerClass) {
            case TANK -> '';
            case HEALER -> '';
            case FIGHTER -> '';
            case UNIVERSAL -> '';
        };
    }

    /** Строка из "пустых" символов-сдвигов: положительный n вправо, отрицательный влево. */
    static String shift(int n) {
        if (n == 0) {
            return "";
        }
        int base = n < 0 ? 0xE110 : 0xE100;
        int value = Math.abs(n);
        StringBuilder sb = new StringBuilder();
        for (int bit = 9; bit >= 0; bit--) {
            if (((value >> bit) & 1) == 1) {
                sb.append((char) (base + bit));
            }
        }
        // значения больше 1023 раскладываем повторением старшего бита
        int rest = value >> 10;
        for (int i = 0; i < rest; i++) {
            sb.append((char) (base + 9));
            sb.append((char) (base + 9));
        }
        return sb.toString();
    }

    /** Приблизительная ширина ника в обычном шрифте (пикселей, с промежутком). */
    static int textWidth(String text) {
        int width = 0;
        for (char c : text.toCharArray()) {
            width += switch (c) {
                case 'i', '!', ':', ';', '.', ',', '|', '\'' -> 3;
                case 'l', 'I', '`' -> 4;
                case 't', 'f', 'k', ' ', '<', '>', '(', ')', '[', ']', '{', '}', '*', '"' -> 5;
                case '@', '~' -> 7;
                case 'Ж', 'Ш', 'Щ', 'Ю', 'Ы', 'ж', 'ш', 'щ', 'ю', 'ы', 'Ф', 'ф', 'М', 'м' -> 7;
                default -> 6;
            };
        }
        return width;
    }
}
