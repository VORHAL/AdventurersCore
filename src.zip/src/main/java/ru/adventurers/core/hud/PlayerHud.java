package ru.adventurers.core.hud;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.object.ObjectContents;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;

import java.io.File;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Рамка героя вверху экрана: портрет игрока, полоса здоровья и (только у Лекаря) полоса маны.
 * Рисуется боссбаром со шрифтом пака (нужны pack.glyphs: true). Настройки: playerhud.yml.
 */
public class PlayerHud {

    private static final Key FONT = Key.key("adventurers", "hud");
    static final char FRAME = '';
    static final char HP_FULL = '';
    static final char HP_EMPTY = '';
    static final char MP_FULL = '';
    static final char MP_EMPTY = '';
    private static final int FRAME_ADV = 177;     // ширина картинки рамки 176 + 1
    private static final int SEG_ADV = 4;         // сегмент 3 px + 1

    private final AdventurersCore plugin;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Set<UUID> hidden = new HashSet<>();
    private BukkitTask task;
    private boolean enabled = true;
    private int interval = 4;
    private int segments = 30;
    private int hpColor = 0xe0303c;
    private int hpLow = 0xff7a2a;
    private int hpEmpty = 0x3a1a22;
    private int mpColor = 0x3c8cff;
    private int mpEmpty = 0x16213a;
    private boolean numbers = true;

    public PlayerHud(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void init() {
        reload();
    }

    public void reload() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        File file = new File(plugin.getDataFolder(), "playerhud.yml");
        if (!file.exists()) {
            plugin.saveResource("playerhud.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true) && PackItems.glyphsEnabled();
        interval = Math.max(2, cfg.getInt("interval-ticks", 4));
        segments = Math.max(5, Math.min(30, cfg.getInt("segments", 30)));
        hpColor = color(cfg.getString("hp-color", "#e0303c"), 0xe0303c);
        hpLow = color(cfg.getString("hp-low-color", "#ff7a2a"), 0xff7a2a);
        hpEmpty = color(cfg.getString("hp-empty-color", "#3a1a22"), 0x3a1a22);
        mpColor = color(cfg.getString("mana-color", "#3c8cff"), 0x3c8cff);
        mpEmpty = color(cfg.getString("mana-empty-color", "#16213a"), 0x16213a);
        numbers = cfg.getBoolean("numbers", true);
        for (Map.Entry<UUID, BossBar> e : bars.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null) {
                p.hideBossBar(e.getValue());
            }
        }
        bars.clear();
        if (enabled) {
            task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, interval);
        }
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
        }
        for (Map.Entry<UUID, BossBar> e : bars.entrySet()) {
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null) {
                p.hideBossBar(e.getValue());
            }
        }
        bars.clear();
    }

    public void forget(UUID uuid) {
        bars.remove(uuid);
    }

    /** Включает или выключает рамку для игрока. Возвращает новое состояние. */
    public boolean toggle(Player player) {
        boolean nowHidden = hidden.add(player.getUniqueId());
        if (!nowHidden) {
            hidden.remove(player.getUniqueId());
        }
        BossBar bar = bars.remove(player.getUniqueId());
        if (bar != null) {
            player.hideBossBar(bar);
        }
        return !nowHidden;
    }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID id = player.getUniqueId();
            if (hidden.contains(id) || plugin.getProfileManager().getProfile(id) == null) {
                BossBar old = bars.remove(id);
                if (old != null) {
                    player.hideBossBar(old);
                }
                continue;
            }
            BossBar bar = bars.get(id);
            if (bar == null) {
                bar = BossBar.bossBar(Component.empty(), 1f, BossBar.Color.WHITE, BossBar.Overlay.PROGRESS);
                bars.put(id, bar);
                player.showBossBar(bar);
            }
            bar.name(build(player));
        }
    }

    private Component build(Player player) {
        AttributeInstance maxAttr = player.getAttribute(Attribute.MAX_HEALTH);
        double max = maxAttr != null ? maxAttr.getValue() : 20.0;
        double hp = Math.max(0, Math.min(max, player.getHealth()));
        double ratio = max <= 0 ? 0 : hp / max;
        int filled = (int) Math.ceil(ratio * segments - 1e-9);
        if (hp > 0 && filled == 0) {
            filled = 1;
        }
        boolean healer = plugin.getHealer() != null && plugin.getHealer().canUse(player);

        Component row = Component.text(String.valueOf(FRAME) + PartyFrames.shift(-FRAME_ADV) + PartyFrames.shift(5))
                .font(FONT).color(TextColor.color(0xffffff));
        row = row.append(Component.object(ObjectContents.playerHead(player.getUniqueId())));
        row = row.append(Component.text(PartyFrames.shift(6)).font(FONT));
        TextColor hpCol = TextColor.color(ratio < 0.3 ? hpLow : hpColor);
        row = row.append(segs(HP_FULL, filled, hpCol)).append(segs(HP_EMPTY, segments - filled, TextColor.color(hpEmpty)));
        if (numbers) {
            row = row.append(Component.text(PartyFrames.shift(3)).font(FONT));
            row = row.append(Component.text(String.valueOf((int) Math.ceil(hp))).color(TextColor.color(0xf2f2f2)));
        }
        if (healer) {
            double mm = plugin.getHealer().maxMana(player);
            double mn = plugin.getHealer().getMana(player);
            int mf = mm <= 0 ? 0 : (int) Math.round(mn / mm * segments);
            // возврат в начало полосы: назад на всё написанное справа
            int back = segments * SEG_ADV + (numbers ? 3 + 6 * String.valueOf((int) Math.ceil(hp)).length() : 0);
            row = row.append(Component.text(PartyFrames.shift(-back)).font(FONT));
            row = row.append(segs(MP_FULL, mf, TextColor.color(mpColor))).append(segs(MP_EMPTY, segments - mf, TextColor.color(mpEmpty)));
        }
        return row;
    }

    private static Component segs(char glyph, int n, TextColor color) {
        if (n <= 0) {
            return Component.empty();
        }
        return Component.text(String.valueOf(glyph).repeat(n)).font(FONT).color(color);
    }

    private static int color(String hex, int def) {
        try {
            return Integer.parseInt(hex.replace("#", ""), 16);
        } catch (Exception ex) {
            return def;
        }
    }
}
