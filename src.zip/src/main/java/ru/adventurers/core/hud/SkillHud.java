package ru.adventurers.core.hud;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;

import java.io.File;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Постоянная панель над хотбаром: готовность умений Танка и Лекаря, мана Лекаря.
 * Короткие сообщения умений через {@link #flash} перекрывают панель на пару секунд.
 * Настройки: skillhud.yml. Только основной поток.
 */
public class SkillHud {

    private final AdventurersCore plugin;
    private final Map<UUID, Long> holdUntil = new HashMap<>();
    private final Map<UUID, Map<String, Boolean>> wasReady = new HashMap<>();
    private BukkitTask task;

    private boolean enabled = true;
    private int interval = 5;
    private long flashMs = 1800;
    private boolean readySound = true;
    private double soundMinSeconds = 10;
    private String ready = "&a✔";
    private String separator = " &8│ ";
    private int segments = 5;
    private String barFilled = "&a|";
    private String barEmpty = "&8|";
    private String secondsFormat = "&7{seconds}с";
    private boolean icons = true;
    private int iconGap = 3;
    private YamlConfiguration cfg = new YamlConfiguration();

    public SkillHud(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void init() {
        reload();
    }

    public void reload() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        File file = plugin.getFiles().file("skillhud.yml");
        if (!file.exists()) {
            plugin.getFiles().save("skillhud.yml");
        }
        cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        interval = Math.max(2, cfg.getInt("interval-ticks", 5));
        flashMs = (long) (cfg.getDouble("flash-seconds", 1.8) * 1000);
        readySound = cfg.getBoolean("ready-sound", true);
        soundMinSeconds = cfg.getDouble("ready-sound-min-cooldown-seconds", 10);
        ready = cfg.getString("ready", "&a✔");
        separator = cfg.getString("separator", " &8│ ");
        segments = Math.max(2, cfg.getInt("bar-segments", 5));
        barFilled = cfg.getString("bar-filled", "&a|");
        barEmpty = cfg.getString("bar-empty", "&8|");
        secondsFormat = cfg.getString("seconds", "&7{seconds}с");
        icons = cfg.getBoolean("icons", true);
        iconGap = Math.max(0, cfg.getInt("icon-gap", 3));
        if (enabled) {
            task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, interval);
        }
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    public void forget(UUID uuid) {
        holdUntil.remove(uuid);
        wasReady.remove(uuid);
    }

    /** Короткое сообщение над хотбаром: панель умений на пару секунд уступает ему место. */
    public void flash(Player player, Component message) {
        holdUntil.put(player.getUniqueId(), System.currentTimeMillis() + flashMs);
        player.sendActionBar(message);
    }

    // ---------------------------------------------------------------
    //  Панель
    // ---------------------------------------------------------------

    private void tick() {
        long now = System.currentTimeMillis();
        for (Player player : Bukkit.getOnlinePlayers()) {
            Long hold = holdUntil.get(player.getUniqueId());
            if (hold != null && now < hold) {
                continue;
            }
            Panel panel = build(player);
            if (panel != null) {
                for (Slot slot : panel.slots()) {
                    track(player, slot);
                }
                player.sendActionBar(icons && PackItems.glyphsEnabled() ? iconLine(panel) : Hud.legacy(textLine(player, panel)));
            }
        }
    }

    /** Одно умение панели: ключ, название, оставшаяся и полная пауза (мс). */
    private record Slot(String key, String label, long remaining, long total) {
    }

    /** Что показать: префикс, дополнительный текст (мана) и три умения. */
    private record Panel(String prefix, String extra, java.util.List<Slot> slots) {
    }

    private static final String[] ORDER = {"taunt", "wall", "dash", "heal", "pulse", "bolt",
            "sweep", "rage", "lunge", "volley", "aim", "backstep"};

    /** Отслеживает готовность для звукового сигнала. */
    private void track(Player player, Slot slot) {
        Map<String, Boolean> state = wasReady.computeIfAbsent(player.getUniqueId(), id -> new HashMap<>());
        boolean isReady = slot.remaining() <= 0;
        Boolean before = state.put(slot.key(), isReady);
        if (readySound && isReady && Boolean.FALSE.equals(before) && slot.total() >= soundMinSeconds * 1000) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 0.6f, 1.7f);
        }
    }

    private String textLine(Player player, Panel panel) {
        StringBuilder line = new StringBuilder(panel.prefix());
        if (panel.extra() != null) {
            line.append(panel.extra());
        }
        boolean first = panel.extra() == null;
        for (Slot slot : panel.slots()) {
            if (!first) {
                line.append(separator);
            }
            first = false;
            if (slot.remaining() <= 0) {
                line.append(slot.label()).append(' ').append(ready);
                continue;
            }
            double fraction = slot.total() <= 0 ? 1.0 : 1.0 - (double) slot.remaining() / slot.total();
            int filled = (int) Math.max(0, Math.min(segments, Math.round(fraction * segments)));
            StringBuilder bar = new StringBuilder();
            for (int i = 0; i < segments; i++) {
                bar.append(i < filled ? barFilled : barEmpty);
            }
            long seconds = slot.remaining() / 1000 + 1;
            line.append(slot.label()).append(' ').append(bar).append(' ')
                    .append(secondsFormat.replace("{seconds}", String.valueOf(seconds)));
        }
        return line.toString();
    }

    private static final net.kyori.adventure.key.Key HUD_FONT = net.kyori.adventure.key.Key.key("adventurers", "hud");
    private static final int ICON_ADV = 17;      // значок 16 px + 1

    /** Значки умений шрифтом пака: готово = яркий, пауза = тёмный и число секунд по центру. */
    private Component iconLine(Panel panel) {
        Component row = Component.empty();
        if (panel.extra() != null) {
            row = row.append(Hud.legacy(panel.extra()).font(HUD_FONT)).append(
                    Component.text(PartyFrames.shift(8)).font(HUD_FONT));
        }
        net.kyori.adventure.text.format.TextColor white = net.kyori.adventure.text.format.TextColor.color(0xffffff);
        for (int i = 0; i < panel.slots().size(); i++) {
            Slot slot = panel.slots().get(i);
            int index = java.util.Arrays.asList(ORDER).indexOf(slot.key());
            boolean isReady = slot.remaining() <= 0;
            char glyph = (char) (0xE200 + Math.max(0, index) * 2 + (isReady ? 0 : 1));
            StringBuilder head = new StringBuilder(String.valueOf(glyph));
            Component part = Component.text(head.toString()).font(HUD_FONT).color(white);
            row = row.append(part);
            int advance = ICON_ADV;
            if (!isReady) {
                long seconds = slot.remaining() / 1000 + 1;
                String digits = seconds > 99 ? (seconds / 60 + 1) + "м" : String.valueOf(seconds);
                int width = digits.length() * 6 - 1;
                int start = Math.max(0, (16 - width) / 2);
                row = row.append(Component.text(PartyFrames.shift(-(ICON_ADV - start))).font(HUD_FONT));
                row = row.append(Component.text(digits).font(HUD_FONT)
                        .color(net.kyori.adventure.text.format.TextColor.color(0xffffff)));
                advance = start + digits.length() * 6;
            }
            if (i < panel.slots().size() - 1) {
                row = row.append(Component.text(PartyFrames.shift(ICON_ADV + iconGap - advance)).font(HUD_FONT));
            }
        }
        return row;
    }

    private Slot slot(String key, String label, long remaining, long total) {
        return new Slot(key, label, remaining, total);
    }

    /** Панель для игрока или null, если показывать нечего. */
    private Panel build(Player player) {
        var classes = plugin.getClasses();
        if (classes == null || plugin.getTank() == null || plugin.getHealer() == null) {
            return null;
        }
        var tank = plugin.getTank();
        var healer = plugin.getHealer();

        if (tank.isEnabled() && tank.canUse(player)) {
            java.util.List<Slot> slots = new java.util.ArrayList<>();
            for (String key : new String[]{"taunt", "wall", "dash"}) {
                slots.add(slot(key, cfg.getString("tank." + key, key), tank.remaining(player, key), tank.total(key)));
            }
            boolean cooling = slots.stream().anyMatch(value -> value.remaining() > 0);
            if (tank.hasShield(player) || cooling) {
                return new Panel(cfg.getString("tank.prefix", "&9⛨ "), null, slots);
            }
        }

        var weapon = plugin.getWeapon();
        if (weapon != null && weapon.isEnabled()) {
            org.bukkit.inventory.ItemStack held = player.getInventory().getItemInMainHand();
            String[] keys = null;
            String prefix = null;
            String group = null;
            if (ru.adventurers.core.combat.WeaponSkills.isMelee(held)) {
                keys = new String[]{"sweep", "rage", "lunge"};
                prefix = cfg.getString("fighter.prefix", "&c⚔ ");
                group = "fighter.";
            } else if (ru.adventurers.core.combat.WeaponSkills.isRanged(held)) {
                keys = new String[]{"volley", "aim", "backstep"};
                prefix = cfg.getString("archer.prefix", "&6➹ ");
                group = "archer.";
            }
            var active = classes.activeClass(player.getUniqueId());
            if (keys != null && (active == ru.adventurers.core.classes.PlayerClass.FIGHTER
                    || active == ru.adventurers.core.classes.PlayerClass.UNIVERSAL)
                    && !(tank.isEnabled() && tank.canUse(player) && tank.hasShield(player))) {
                java.util.List<Slot> slots = new java.util.ArrayList<>();
                for (String key : keys) {
                    slots.add(slot(key, cfg.getString(group + key, key), weapon.remaining(player, key), weapon.total(key)));
                }
                return new Panel(prefix, null, slots);
            }
        }

        if (healer.isEnabled() && healer.canUse(player)) {
            boolean staff = healer.isStaff(player.getInventory().getItemInMainHand());
            long pulse = healer.remaining(player, "pulse");
            boolean cooling = pulse > 0;
            double mana = healer.getMana(player);
            double max = healer.maxMana(player);
            if (staff || cooling) {
                java.util.List<Slot> slots = new java.util.ArrayList<>();
                for (String key : new String[]{"heal", "pulse", "bolt"}) {
                    slots.add(slot(key, cfg.getString("healer." + key, key), healer.remaining(player, key), healer.total(key)));
                }
                String extra = cfg.getString("healer.mana", "&b✦ Мана &f{mana}&8/&f{max}")
                        .replace("{mana}", String.valueOf((int) mana)).replace("{max}", String.valueOf((int) max));
                return new Panel(cfg.getString("healer.prefix", "&a✚ "), extra, slots);
            }
        }
        return null;
    }
}
