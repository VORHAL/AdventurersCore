package ru.adventurers.core.invasion;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapCursor;
import org.bukkit.map.MapCursorCollection;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.party.Party;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Вторжения: в случайное время и в случайном месте открывается портал на подземелье с финальным боссом.
 * Не больше max-per-day в сутки, в основном днём (по МСК), при достаточном онлайне. Каждому игроку
 * по attempts попыток. Портал виден на карте мира (/ag invasion map). Настройки: invasions.yml.
 */
public class InvasionManager {

    /**
     * cost - входная плата монетами (0 = бесплатно). Вторжение приносит около двух дней
     * дохода ранга, поэтому вход должен что-то стоить: иначе это бесконечный источник монет
     * для тех, кто просто стоит у портала. Проверяется тестом BalanceConfigTest.
     */
    record Tier(Rank rank, List<String> dungeons, long coins, int points, long cost) {
    }

    private static final class Portal {
        final String id;
        final Rank rank;
        final Location at;
        final String dungeon;
        final long expires;
        final Map<UUID, Integer> attempts = new HashMap<>();
        UUID label;
        boolean cleared;
        long closeAt;

        Portal(String id, Rank rank, Location at, String dungeon, long expires) {
            this.id = id;
            this.rank = rank;
            this.at = at;
            this.dungeon = dungeon;
            this.expires = expires;
        }
    }

    private static final ZoneId ZONE = ZoneId.of("Europe/Moscow");

    private final AdventurersCore plugin;
    private final Map<String, Portal> portals = new LinkedHashMap<>();
    private final Map<Rank, Tier> tiers = new LinkedHashMap<>();
    private final Random random = new Random();
    private final NamespacedKey labelKey;
    private final File dataFile;
    private boolean enabled = true;
    private List<String> worlds = List.of("world");
    private int minOnline = 3;
    private int maxPerDay = 3;
    private int fromHour = 8;
    private int toHour = 22;
    private int minGap = 60;
    private int maxGap = 180;
    private int minRadius = 300;
    private int maxRadius = 2000;
    private int lifetime = 90;
    private int attempts = 2;
    private double enterRadius = 2.5;
    private int mapScale = 4;
    private boolean announceCoords = true;
    private long day;
    private int countToday;
    private long nextAt;
    private int mapId = -1;
    private int counter;

    public InvasionManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.labelKey = new NamespacedKey(plugin, "invasion_label");
        this.dataFile = plugin.getFiles().file("invasions-data.yml");
    }

    // ---------------------------------------------------------------
    //  Настройки
    // ---------------------------------------------------------------

    public void init() {
        reload();
        YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
        day = data.getLong("day", 0);
        countToday = data.getInt("count", 0);
        nextAt = data.getLong("next", 0);
        mapId = data.getInt("map", -1);
        Bukkit.getScheduler().runTaskTimer(plugin, this::schedule, 200L, 20L * 30);
        Bukkit.getScheduler().runTaskTimer(plugin, this::visuals, 40L, 10L);
        // «осиротевшие» подписи портала после аварийного выключения
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity.getPersistentDataContainer().has(labelKey, PersistentDataType.BYTE)) {
                    entity.remove();
                }
            }
        }
    }

    public void shutdown() {
        for (Portal portal : new ArrayList<>(portals.values())) {
            removeLabel(portal);
        }
        portals.clear();
        saveData();
    }

    public void reload() {
        File file = plugin.getFiles().file("invasions.yml");
        if (!file.exists()) {
            plugin.getFiles().save("invasions.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        worlds = cfg.getStringList("worlds");
        if (worlds.isEmpty()) {
            worlds = List.of("world");
        }
        minOnline = cfg.getInt("min-online", 3);
        maxPerDay = cfg.getInt("max-per-day", 3);
        fromHour = cfg.getInt("hours.from", 8);
        toHour = cfg.getInt("hours.to", 22);
        minGap = Math.max(1, cfg.getInt("gap-minutes.min", 60));
        maxGap = Math.max(minGap, cfg.getInt("gap-minutes.max", 180));
        minRadius = cfg.getInt("spawn.min-radius", 300);
        maxRadius = Math.max(minRadius + 1, cfg.getInt("spawn.max-radius", 2000));
        lifetime = Math.max(5, cfg.getInt("lifetime-minutes", 90));
        attempts = Math.max(1, cfg.getInt("attempts", 2));
        enterRadius = cfg.getDouble("enter-radius", 2.5);
        mapScale = Math.max(0, Math.min(4, cfg.getInt("map.scale", 4)));
        announceCoords = cfg.getBoolean("announce-coordinates", true);
        tiers.clear();
        ConfigurationSection ts = cfg.getConfigurationSection("tiers");
        if (ts != null) {
            for (String key : ts.getKeys(false)) {
                Rank rank = Rank.fromInput(key);
                ConfigurationSection t = ts.getConfigurationSection(key);
                if (rank != null && t != null) {
                    tiers.put(rank, new Tier(rank, t.getStringList("dungeons"), t.getLong("coins", 0),
                            t.getInt("points", 0), Math.max(0, t.getLong("cost", 0))));
                }
            }
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    private void saveData() {
        YamlConfiguration data = new YamlConfiguration();
        data.set("day", day);
        data.set("count", countToday);
        data.set("next", nextAt);
        data.set("map", mapId);
        try {
            data.save(dataFile);
        } catch (IOException exception) {
            plugin.getLogger().warning("invasions-data.yml: " + exception.getMessage());
        }
    }

    // ---------------------------------------------------------------
    //  Расписание
    // ---------------------------------------------------------------

    private static boolean inRank(Rank player, Rank invasion) {
        return Math.abs(player.ordinal() - invasion.ordinal()) <= 1;
    }

    private Rank rankOf(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? Rank.F : profile.getRank();
    }

    private void schedule() {
        long now = System.currentTimeMillis();
        for (Portal portal : new ArrayList<>(portals.values())) {
            if (portal.cleared ? now >= portal.closeAt : now >= portal.expires) {
                close(portal, portal.cleared ? null : "invasion.expired");
            }
        }
        if (!enabled) {
            return;
        }
        ZonedDateTime time = ZonedDateTime.now(ZONE);
        long today = LocalDate.now(ZONE).toEpochDay();
        if (day != today) {
            day = today;
            countToday = 0;
            nextAt = 0;
            saveData();
        }
        int hour = time.getHour();
        if (hour < fromHour || hour >= toHour || countToday >= maxPerDay || !portals.isEmpty() && portals.size() >= 2) {
            return;
        }
        if (Bukkit.getOnlinePlayers().isEmpty() || Bukkit.getOnlinePlayers().size() < minOnline) {
            return;
        }
        if (nextAt == 0) {
            nextAt = now + (long) random.nextInt(maxGap - minGap + 1) * 60_000L + minGap * 60_000L / 2;
            saveData();
        }
        if (now >= nextAt) {
            Player seed = null;
            List<Player> online = new ArrayList<>(Bukkit.getOnlinePlayers());
            seed = online.get(random.nextInt(online.size()));
            spawn(rankOf(seed), null);
        }
    }

    /** Открыть вторжение; at == null: случайное место. Возвращает портал или null. */
    private Portal spawn(Rank rank, Location at) {
        Tier tier = tiers.get(rank);
        if (tier == null || tier.dungeons().isEmpty()) {
            return null;
        }
        Location where = at != null ? at : randomSpot();
        if (where == null) {
            return null;
        }
        counter++;
        String id = "i" + System.currentTimeMillis() % 100000 + counter;
        String dungeon = tier.dungeons().get(random.nextInt(tier.dungeons().size()));
        Portal portal = new Portal(id, rank, where, dungeon, System.currentTimeMillis() + lifetime * 60_000L);
        portals.put(id, portal);
        countToday++;
        nextAt = System.currentTimeMillis() + (minGap + (long) random.nextInt(maxGap - minGap + 1)) * 60_000L;
        saveData();
        try {
            TextDisplay label = where.getWorld().spawn(where.clone().add(0, 3.2, 0), TextDisplay.class, display -> {
                display.text(Hud.legacy("&5&lВторжение &8[" + plugin.getMessages().rankName(rank) + "&8]"));
                display.setBillboard(org.bukkit.entity.Display.Billboard.CENTER);
                display.setPersistent(false);
                display.getPersistentDataContainer().set(labelKey, PersistentDataType.BYTE, (byte) 1);
            });
            portal.label = label.getUniqueId();
        } catch (RuntimeException exception) {
            plugin.getLogger().warning("invasion label: " + exception.getMessage());
        }
        announce(portal);
        return portal;
    }

    private Location randomSpot() {
        World world = null;
        for (int i = 0; i < 5 && world == null; i++) {
            world = Bukkit.getWorld(worlds.get(random.nextInt(worlds.size())));
        }
        if (world == null) {
            return null;
        }
        Location center = world.getSpawnLocation();
        for (int tries = 0; tries < 25; tries++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double radius = minRadius + random.nextDouble() * (maxRadius - minRadius);
            int x = (int) (center.getX() + Math.cos(angle) * radius);
            int z = (int) (center.getZ() + Math.sin(angle) * radius);
            if (!world.getWorldBorder().isInside(new Location(world, x, 64, z))) {
                continue;
            }
            int y = world.getHighestBlockYAt(x, z);
            Material ground = world.getBlockAt(x, y, z).getType();
            if (ground == Material.WATER || ground == Material.LAVA || ground == Material.ICE) {
                continue;
            }
            Location spot = new Location(world, x + 0.5, y + 1, z + 0.5);
            if (plugin.getCovenants() != null && plugin.getCovenants().at(spot) != null) {
                continue;
            }
            return spot;
        }
        return null;
    }

    private String where(Portal portal) {
        Location l = portal.at;
        return l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ();
    }

    private void announce(Portal portal) {
        Map<String, Object> values = Map.of("rank", plugin.getMessages().rankName(portal.rank),
                "where", announceCoords ? where(portal) : "?", "minutes", lifetime,
                "attempts", attempts);
        for (Player player : Bukkit.getOnlinePlayers()) {
            plugin.getMessages().send(player, "invasion.opened", values);
            player.playSound(player.getLocation(), Sound.EVENT_RAID_HORN, 0.6f, 0.8f);
        }
    }

    private void close(Portal portal, String key) {
        portals.remove(portal.id);
        removeLabel(portal);
        if (key != null) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                plugin.getMessages().send(player, key, Map.of("rank", plugin.getMessages().rankName(portal.rank)));
            }
        }
    }

    private void removeLabel(Portal portal) {
        if (portal.label != null) {
            Entity entity = Bukkit.getEntity(portal.label);
            if (entity != null) {
                entity.remove();
            }
        }
    }

    // ---------------------------------------------------------------
    //  Портал: вид и вход
    // ---------------------------------------------------------------

    private void visuals() {
        if (portals.isEmpty()) {
            return;
        }
        for (Portal portal : portals.values()) {
            World world = portal.at.getWorld();
            if (world == null) {
                continue;
            }
            Location base = portal.at;
            Particle.DustOptions dust = new Particle.DustOptions(org.bukkit.Color.fromRGB(0x7b1fa2), 1.6f);
            for (int i = 0; i < 6; i++) {
                world.spawnParticle(Particle.DUST, base.clone().add(random.nextDouble() * 1.6 - 0.8, i * 0.5,
                        random.nextDouble() * 1.6 - 0.8), 2, 0.1, 0.1, 0.1, 0, dust);
            }
            world.spawnParticle(Particle.PORTAL, base.clone().add(0, 1.5, 0), 25, 0.6, 1.2, 0.6, 0.4);
            for (Player player : world.getPlayers()) {
                if (player.getLocation().distanceSquared(base) > enterRadius * enterRadius) {
                    continue;
                }
                if (portal.cleared) {
                    player.sendActionBar(Hud.legacy("&7Портал закрывается..."));
                } else if (player.isSneaking()) {
                    tryEnter(player, portal);
                } else {
                    player.sendActionBar(Hud.legacy("&5Вторжение &8[" + plugin.getMessages().rankName(portal.rank)
                            + "&8] &7- присядьте, чтобы войти &8(попыток: "
                            + Math.max(0, attempts - portal.attempts.getOrDefault(player.getUniqueId(), 0)) + ")"));
                }
            }
        }
    }

    private long lastTry(UUID uuid) {
        return tries.getOrDefault(uuid, 0L);
    }

    private final Map<UUID, Long> tries = new HashMap<>();

    private void tryEnter(Player leader, Portal portal) {
        long now = System.currentTimeMillis();
        if (now - lastTry(leader.getUniqueId()) < 3000) {
            return;
        }
        tries.put(leader.getUniqueId(), now);
        Party group = plugin.getParties().group(leader.getUniqueId());
        if (group != null && !group.getLeader().equals(leader.getUniqueId())) {
            plugin.getMessages().send(leader, "invasion.not-leader");
            return;
        }
        List<Player> team = new ArrayList<>();
        team.add(leader);
        if (group != null) {
            for (UUID member : group.members()) {
                Player other = Bukkit.getPlayer(member);
                if (other == null || other.equals(leader)) {
                    continue;
                }
                if (other.getWorld().equals(portal.at.getWorld())
                        && other.getLocation().distanceSquared(portal.at) <= 100) {
                    team.add(other);
                }
            }
        }
        for (Player player : team) {
            if (!inRank(rankOf(player), portal.rank)) {
                plugin.getMessages().send(leader, "invasion.rank", Map.of("player", player.getName(),
                        "rank", plugin.getMessages().rankName(portal.rank)));
                return;
            }
            if (portal.attempts.getOrDefault(player.getUniqueId(), 0) >= attempts) {
                plugin.getMessages().send(leader, "invasion.no-attempts", Map.of("player", player.getName()));
                return;
            }
        }
        // Вход платный: списываем ПОСЛЕ проверок, но ДО входа, и у всех участников сразу.
        // Если у кого-то не хватает - не входит никто (иначе группа заходит на чужие монеты).
        Tier tier = tiers.get(portal.rank);
        long cost = tier == null ? 0 : tier.cost();
        if (cost > 0 && plugin.getEconomy() != null) {
            for (Player player : team) {
                if (!plugin.getEconomy().has(player.getUniqueId(), cost)) {
                    plugin.getMessages().send(leader, "invasion.cost", Map.of(
                            "player", player.getName(),
                            "cost", plugin.getEconomy().format(cost),
                            "have", plugin.getEconomy().format(plugin.getEconomy().balance(player.getUniqueId()))));
                    return;
                }
            }
        }
        String error = plugin.getDungeons().startInvasion(leader, team, portal.dungeon, portal.id);
        if (error != null) {
            plugin.getMessages().send(leader, error, Map.of("min", 1, "max", 5));
            return;
        }
        for (Player player : team) {
            if (cost > 0 && plugin.getEconomy() != null) {
                plugin.getEconomy().withdraw(player.getUniqueId(), cost);
            }
            portal.attempts.merge(player.getUniqueId(), 1, Integer::sum);
            plugin.getMessages().send(player, "invasion.entered", Map.of(
                    "left", attempts - portal.attempts.get(player.getUniqueId()),
                    "cost", plugin.getEconomy() == null ? "0" : plugin.getEconomy().format(cost)));
        }
    }

    /** Вызывается подземельем при победе: награда и закрытие портала. */
    public void cleared(String id, List<Player> players) {
        Portal portal = portals.get(id);
        Tier tier = portal == null ? null : tiers.get(portal.rank);
        for (Player player : players) {
            if (tier != null) {
                if (tier.coins() > 0 && plugin.getEconomy() != null) {
                    plugin.getEconomy().give(player, tier.coins());
                }
                if (tier.points() > 0 && plugin.getQuests() != null) {
                    plugin.getQuests().adminAddPoints(player, tier.points());
                }
                plugin.getMessages().send(player, "invasion.reward", Map.of(
                        "coins", plugin.getEconomy() != null ? plugin.getEconomy().format(tier.coins()) : "0",
                        "points", String.valueOf(tier.points())));
            }
            if (plugin.getGlory() != null) {
                plugin.getGlory().add(player, "INVASIONS", 1);
            }
        }
        if (portal != null && !portal.cleared) {
            portal.cleared = true;
            portal.closeAt = System.currentTimeMillis() + 30_000L;
            for (Player player : Bukkit.getOnlinePlayers()) {
                plugin.getMessages().send(player, "invasion.cleared", Map.of(
                        "rank", plugin.getMessages().rankName(portal.rank),
                        "player", players.isEmpty() ? "?" : players.get(0).getName()));
            }
        }
    }

    // ---------------------------------------------------------------
    //  Игрок: список и карта
    // ---------------------------------------------------------------

    public void command(Player player, String[] args) {
        if (args.length > 1 && args[1].equalsIgnoreCase("map")) {
            giveMap(player);
            return;
        }
        if (!enabled) {
            plugin.getMessages().send(player, "invasion.disabled");
            return;
        }
        if (portals.isEmpty()) {
            plugin.getMessages().send(player, "invasion.none", Map.of("count", countToday, "max", maxPerDay));
            return;
        }
        plugin.getMessages().send(player, "invasion.list-head");
        for (Portal portal : portals.values()) {
            long minutes = Math.max(0, (portal.expires - System.currentTimeMillis()) / 60000);
            String distance = portal.at.getWorld() != null && portal.at.getWorld().equals(player.getWorld())
                    ? String.valueOf((int) player.getLocation().distance(portal.at)) + " бл." : "другой мир";
            plugin.getMessages().send(player, "invasion.list-line", Map.of(
                    "rank", plugin.getMessages().rankName(portal.rank),
                    "where", announceCoords ? where(portal) : "?", "distance", distance,
                    "minutes", minutes,
                    "left", Math.max(0, attempts - portal.attempts.getOrDefault(player.getUniqueId(), 0)),
                    "state", portal.cleared ? "зачищено" : inRank(rankOf(player), portal.rank) ? "доступно" : "не для вашего ранга"));
        }
    }

    private MapView mapView() {
        World world = Bukkit.getWorld(worlds.get(0));
        if (world == null) {
            return null;
        }
        MapView view = mapId >= 0 ? Bukkit.getMap(mapId) : null;
        if (view == null) {
            view = Bukkit.createMap(world);
            mapId = view.getId();
            saveData();
        }
        view.setWorld(world);
        view.setScale(MapView.Scale.valueOf(switch (mapScale) {
            case 0 -> "CLOSEST";
            case 1 -> "CLOSE";
            case 2 -> "NORMAL";
            case 3 -> "FAR";
            default -> "FARTHEST";
        }));
        Location spawn = world.getSpawnLocation();
        view.setCenterX(spawn.getBlockX());
        view.setCenterZ(spawn.getBlockZ());
        view.setTrackingPosition(true);
        view.setUnlimitedTracking(false);
        boolean hasOurs = view.getRenderers().stream().anyMatch(r -> r instanceof PortalRenderer);
        if (!hasOurs) {
            view.addRenderer(new PortalRenderer());
        }
        return view;
    }

    private void giveMap(Player player) {
        MapView view = mapView();
        if (view == null) {
            plugin.getMessages().send(player, "invasion.no-world");
            return;
        }
        ItemStack map = new ItemStack(Material.FILLED_MAP);
        MapMeta meta = (MapMeta) map.getItemMeta();
        meta.setMapView(view);
        meta.displayName(Hud.legacy("&5Карта вторжений").decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
        meta.lore(List.of(Hud.legacy("&7Красные крестики: порталы вторжений.").decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false),
                Hud.legacy("&7Нужно исследовать местность, чтобы она отрисовалась.").decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false)));
        map.setItemMeta(meta);
        player.getInventory().addItem(map).values().forEach(rest -> player.getWorld().dropItem(player.getLocation(), rest));
        plugin.getMessages().send(player, "invasion.map-given");
    }

    private final class PortalRenderer extends MapRenderer {
        PortalRenderer() {
            super(true);
        }

        @Override
        public void render(MapView map, MapCanvas canvas, Player viewer) {
            MapCursorCollection cursors = canvas.getCursors();
            while (cursors.size() > 0) {
                cursors.removeCursor(cursors.getCursor(0));
            }
            double blocksPerPixel = 1 << mapScale;
            for (Portal portal : portals.values()) {
                if (portal.cleared || portal.at.getWorld() == null || map.getWorld() == null
                        || !portal.at.getWorld().equals(map.getWorld())) {
                    continue;
                }
                double dx = (portal.at.getX() - map.getCenterX()) / blocksPerPixel * 2;
                double dz = (portal.at.getZ() - map.getCenterZ()) / blocksPerPixel * 2;
                if (Math.abs(dx) > 127 || Math.abs(dz) > 127) {
                    continue;
                }
                cursors.addCursor(new MapCursor((byte) dx, (byte) dz, (byte) 8, MapCursor.Type.RED_X, true));
            }
        }
    }

    // ---------------------------------------------------------------
    //  Админ: /ag admin invasion ...
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        String action = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
        switch (action) {
            case "spawn" -> {
                Rank rank = args.length > 3 ? Rank.fromInput(args[3]) : null;
                if (rank == null) {
                    sender.sendMessage(Hud.legacy("&c/ag admin invasion spawn <ранг> [here]"));
                    return;
                }
                Location at = args.length > 4 && args[4].equalsIgnoreCase("here") && sender instanceof Player p
                        ? p.getLocation().clone() : null;
                Portal portal = spawn(rank, at);
                sender.sendMessage(Hud.legacy(portal == null ? "&cНе удалось: нет подземелий для ранга в invasions.yml или нет места."
                        : "&aВторжение открыто: &f" + where(portal) + " &7(" + portal.dungeon + ")"));
            }
            case "list" -> {
                sender.sendMessage(Hud.legacy("&6Вторжения: &f" + portals.size() + " &7(сегодня " + countToday + "/" + maxPerDay + ")"));
                portals.values().forEach(p -> sender.sendMessage(Hud.legacy("&8» &f" + p.id + " &7" + p.rank.name()
                        + " " + where(p) + " " + p.dungeon + (p.cleared ? " &a(зачищено)" : ""))));
            }
            case "clear" -> {
                new ArrayList<>(portals.values()).forEach(p -> close(p, null));
                sender.sendMessage(Hud.legacy("&aВсе порталы закрыты."));
            }
            case "reload" -> {
                reload();
                sender.sendMessage(Hud.legacy("&aНастройки вторжений перечитаны."));
            }
            default -> sender.sendMessage(Hud.legacy("&7/ag admin invasion spawn <ранг> [here]|list|clear|reload"));
        }
    }
}
