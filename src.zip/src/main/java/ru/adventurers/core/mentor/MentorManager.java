package ru.adventurers.core.mentor;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Наставничество. Игрок ранга A и выше берёт под опеку новичка (ранг не выше max-student-rank).
 * Ученик получает прирост опыта профессий и шанс дополнительной добычи (больше, когда наставник рядом).
 * Наставник получает награду за успехи ученика и за его выпуск. Настройки: mentor.yml.
 */
public class MentorManager implements Listener {

    private static final class Pair {
        final UUID student;
        final UUID mentor;
        String studentName;
        String mentorName;

        Pair(UUID student, UUID mentor, String studentName, String mentorName) {
            this.student = student;
            this.mentor = mentor;
            this.studentName = studentName;
            this.mentorName = mentorName;
        }
    }

    private record Invite(UUID mentor, String mentorName, long until) {
    }

    private final AdventurersCore plugin;
    private final File dataFile;
    private final Random random = new Random();
    private final Map<UUID, Pair> byStudent = new LinkedHashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();
    private boolean enabled = true;
    private Rank mentorRank = Rank.A;
    private Rank maxStudentRank = Rank.C;
    private int maxStudents = 2;
    private int inviteSeconds = 60;
    private double nearRadius = 40;
    private double xpBonus = 0.10;
    private double xpBonusNear = 0.25;
    private double dropChance = 0.05;
    private double dropChanceNear = 0.12;
    private long promoteCoins = 300;
    private int promotePoints = 5;
    private long graduateCoins = 3000;
    private int graduatePoints = 30;
    private List<String> dropBlocks = List.of("_ORE", "_LOG", "ANCIENT_DEBRIS");

    public MentorManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.dataFile = plugin.getFiles().file("mentors-data.yml");
    }

    // ---------------------------------------------------------------
    //  Настройки и хранение
    // ---------------------------------------------------------------

    public void init() {
        reload();
        YamlConfiguration data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection pairs = data.getConfigurationSection("pairs");
        if (pairs != null) {
            for (String key : pairs.getKeys(false)) {
                ConfigurationSection s = pairs.getConfigurationSection(key);
                try {
                    if (s != null) {
                        UUID student = UUID.fromString(key);
                        UUID mentor = UUID.fromString(s.getString("mentor", ""));
                        byStudent.put(student, new Pair(student, mentor, s.getString("name", "?"), s.getString("mentor-name", "?")));
                    }
                } catch (IllegalArgumentException ignored) {
                    // повреждённая запись
                }
            }
        }
    }

    public void reload() {
        File file = plugin.getFiles().file("mentor.yml");
        if (!file.exists()) {
            plugin.getFiles().save("mentor.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        Rank r = Rank.fromInput(cfg.getString("mentor-min-rank", "A"));
        mentorRank = r == null ? Rank.A : r;
        r = Rank.fromInput(cfg.getString("max-student-rank", "C"));
        maxStudentRank = r == null ? Rank.C : r;
        maxStudents = Math.max(1, cfg.getInt("max-students", 2));
        inviteSeconds = Math.max(10, cfg.getInt("invite-seconds", 60));
        nearRadius = cfg.getDouble("near-radius", 40);
        xpBonus = cfg.getDouble("student.xp-bonus", 0.10);
        xpBonusNear = cfg.getDouble("student.xp-bonus-near", 0.25);
        dropChance = cfg.getDouble("student.extra-drop-chance", 0.05);
        dropChanceNear = cfg.getDouble("student.extra-drop-chance-near", 0.12);
        List<String> blocks = cfg.getStringList("student.drop-blocks");
        dropBlocks = blocks.isEmpty() ? List.of("_ORE", "_LOG", "ANCIENT_DEBRIS") : blocks;
        promoteCoins = cfg.getLong("mentor.promote-coins", 300);
        promotePoints = cfg.getInt("mentor.promote-points", 5);
        graduateCoins = cfg.getLong("mentor.graduate-coins", 3000);
        graduatePoints = cfg.getInt("mentor.graduate-points", 30);
    }

    public boolean isEnabled() {
        return enabled;
    }

    private void save() {
        YamlConfiguration data = new YamlConfiguration();
        for (Pair pair : byStudent.values()) {
            String path = "pairs." + pair.student;
            data.set(path + ".mentor", pair.mentor.toString());
            data.set(path + ".name", pair.studentName);
            data.set(path + ".mentor-name", pair.mentorName);
        }
        try {
            data.save(dataFile);
        } catch (IOException exception) {
            plugin.getLogger().warning("mentors-data.yml: " + exception.getMessage());
        }
    }

    private Rank rankOf(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile == null ? Rank.F : profile.getRank();
    }

    private List<Pair> studentsOf(UUID mentor) {
        List<Pair> list = new ArrayList<>();
        for (Pair pair : byStudent.values()) {
            if (pair.mentor.equals(mentor)) {
                list.add(pair);
            }
        }
        return list;
    }

    private boolean near(Player student) {
        Pair pair = byStudent.get(student.getUniqueId());
        Player mentor = pair == null ? null : Bukkit.getPlayer(pair.mentor);
        return mentor != null && mentor.getWorld().equals(student.getWorld())
                && mentor.getLocation().distanceSquared(student.getLocation()) <= nearRadius * nearRadius;
    }

    // ---------------------------------------------------------------
    //  Бонусы ученика
    // ---------------------------------------------------------------

    /** Множитель опыта профессий (1.0, если игрок не ученик). */
    public double xpMultiplier(Player player) {
        if (!enabled || !byStudent.containsKey(player.getUniqueId())) {
            return 1.0;
        }
        return 1.0 + (near(player) ? xpBonusNear : xpBonus);
    }

    private boolean extraRoll(Player player) {
        if (!enabled || !byStudent.containsKey(player.getUniqueId())) {
            return false;
        }
        return random.nextDouble() < (near(player) ? dropChanceNear : dropChance);
    }

    private boolean dropBlock(Material material) {
        String name = material.name();
        for (String pattern : dropBlocks) {
            if (pattern.startsWith("_") ? name.endsWith(pattern) : name.equals(pattern)) {
                return true;
            }
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockDrop(BlockDropItemEvent event) {
        Player player = event.getPlayer();
        if (event.getItems().isEmpty() || !dropBlock(event.getBlockState().getType()) || !extraRoll(player)) {
            return;
        }
        Item source = event.getItems().get(random.nextInt(event.getItems().size()));
        ItemStack extra = source.getItemStack().clone();
        extra.setAmount(1);
        Location where = event.getBlock().getLocation().add(0.5, 0.5, 0.5);
        Bukkit.getScheduler().runTask(plugin, () -> where.getWorld().dropItemNaturally(where, extra));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        Entity dead = event.getEntity();
        Player killer = event.getEntity().getKiller();
        if (killer == null || dead instanceof Player || event.getDrops().isEmpty() || !extraRoll(killer)) {
            return;
        }
        if (plugin.getQuests() != null && plugin.getQuests().getGuard().isMarked(dead)) {
            return;
        }
        ItemStack pick = event.getDrops().get(random.nextInt(event.getDrops().size()));
        if (pick != null && !pick.getType().isAir()) {
            event.getDrops().add(pick.clone());
        }
    }

    // ---------------------------------------------------------------
    //  Награды наставнику
    // ---------------------------------------------------------------

    private void pay(UUID mentorId, long coins, int points) {
        Player mentor = Bukkit.getPlayer(mentorId);
        if (mentor == null) {
            return; // офлайн: награда за выпуск не копится, это небольшой бонус
        }
        if (coins > 0 && plugin.getEconomy() != null) {
            plugin.getEconomy().give(mentor, coins);
        }
        if (points > 0 && plugin.getQuests() != null) {
            plugin.getQuests().adminAddPoints(mentor, points);
        }
    }

    /** Вызывается после повышения ранга игрока. */
    public void onPromote(Player player, Rank next) {
        if (!enabled) {
            return;
        }
        Pair pair = byStudent.get(player.getUniqueId());
        if (pair == null) {
            return;
        }
        Player mentor = Bukkit.getPlayer(pair.mentor);
        if (next.ordinal() > maxStudentRank.ordinal()) {
            graduate(pair, player, mentor);
            return;
        }
        pay(pair.mentor, promoteCoins, promotePoints);
        if (mentor != null) {
            plugin.getMessages().send(mentor, "mentor.student-promoted", Map.of("player", player.getName(),
                    "rank", plugin.getMessages().rankName(next),
                    "coins", plugin.getEconomy() != null ? plugin.getEconomy().format(promoteCoins) : "0",
                    "points", String.valueOf(promotePoints)));
        }
    }

    private void graduate(Pair pair, Player student, Player mentor) {
        byStudent.remove(pair.student);
        save();
        pay(pair.mentor, graduateCoins, graduatePoints);
        plugin.getMessages().send(student, "mentor.graduated", Map.of("mentor", pair.mentorName));
        if (mentor != null) {
            plugin.getMessages().send(mentor, "mentor.graduated-mentor", Map.of("player", pair.studentName,
                    "coins", plugin.getEconomy() != null ? plugin.getEconomy().format(graduateCoins) : "0",
                    "points", String.valueOf(graduatePoints)));
            if (plugin.getGlory() != null) {
                plugin.getGlory().add(mentor, "MENTEES", 1);
            }
        }
    }

    // ---------------------------------------------------------------
    //  Команды: /ag mentor ...
    // ---------------------------------------------------------------

    public void command(Player player, String[] args) {
        if (!enabled) {
            plugin.getMessages().send(player, "mentor.disabled");
            return;
        }
        String action = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "info";
        switch (action) {
            case "invite" -> invite(player, args);
            case "accept" -> accept(player);
            case "deny" -> {
                invites.remove(player.getUniqueId());
                plugin.getMessages().send(player, "mentor.denied");
            }
            case "leave" -> leave(player);
            case "kick" -> kick(player, args);
            default -> info(player);
        }
    }

    private void info(Player player) {
        Pair mine = byStudent.get(player.getUniqueId());
        if (mine != null) {
            boolean close = near(player);
            plugin.getMessages().send(player, "mentor.info-student", Map.of("mentor", mine.mentorName,
                    "xp", String.valueOf(Math.round((close ? xpBonusNear : xpBonus) * 100)),
                    "drop", String.valueOf(Math.round((close ? dropChanceNear : dropChance) * 100)),
                    "near", close ? "наставник рядом" : "наставник далеко"));
            return;
        }
        List<Pair> students = studentsOf(player.getUniqueId());
        if (!students.isEmpty()) {
            plugin.getMessages().send(player, "mentor.info-mentor-head", Map.of("count", students.size(), "max", maxStudents));
            for (Pair pair : students) {
                plugin.getMessages().send(player, "mentor.info-mentor-line", Map.of("player", pair.studentName));
            }
            return;
        }
        plugin.getMessages().send(player, "mentor.help", Map.of("rank", plugin.getMessages().rankName(mentorRank),
                "max", plugin.getMessages().rankName(maxStudentRank), "students", maxStudents));
    }

    private void invite(Player mentor, String[] args) {
        if (!rankOf(mentor).isAtLeast(mentorRank)) {
            plugin.getMessages().send(mentor, "mentor.rank-mentor", Map.of("rank", plugin.getMessages().rankName(mentorRank)));
            return;
        }
        if (byStudent.containsKey(mentor.getUniqueId())) {
            plugin.getMessages().send(mentor, "mentor.you-student");
            return;
        }
        Player target = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
        if (target == null || target.equals(mentor)) {
            plugin.getMessages().send(mentor, "mentor.usage");
            return;
        }
        if (studentsOf(mentor.getUniqueId()).size() >= maxStudents) {
            plugin.getMessages().send(mentor, "mentor.full", Map.of("max", maxStudents));
            return;
        }
        if (rankOf(target).ordinal() > maxStudentRank.ordinal() || byStudent.containsKey(target.getUniqueId())
                || !studentsOf(target.getUniqueId()).isEmpty()) {
            plugin.getMessages().send(mentor, "mentor.bad-student", Map.of("player", target.getName(),
                    "rank", plugin.getMessages().rankName(maxStudentRank)));
            return;
        }
        invites.put(target.getUniqueId(), new Invite(mentor.getUniqueId(), mentor.getName(),
                System.currentTimeMillis() + inviteSeconds * 1000L));
        plugin.getMessages().send(mentor, "mentor.invited", Map.of("player", target.getName()));
        plugin.getMessages().send(target, "mentor.invite", Map.of("mentor", mentor.getName(), "seconds", inviteSeconds,
                "xp", String.valueOf(Math.round(xpBonus * 100)), "xpnear", String.valueOf(Math.round(xpBonusNear * 100))));
    }

    private void accept(Player student) {
        Invite invite = invites.remove(student.getUniqueId());
        if (invite == null || invite.until() < System.currentTimeMillis()) {
            plugin.getMessages().send(student, "mentor.no-invite");
            return;
        }
        if (byStudent.containsKey(student.getUniqueId()) || studentsOf(invite.mentor()).size() >= maxStudents) {
            plugin.getMessages().send(student, "mentor.cant-accept");
            return;
        }
        byStudent.put(student.getUniqueId(), new Pair(student.getUniqueId(), invite.mentor(), student.getName(), invite.mentorName()));
        // цепочка первых шагов (раздел 24): у новичка появился наставник
        if (plugin.getOnboarding() != null) {
            plugin.getOnboarding().complete(student, "mentor-linked");
        }
        save();
        plugin.getMessages().send(student, "mentor.accepted", Map.of("mentor", invite.mentorName()));
        Player mentor = Bukkit.getPlayer(invite.mentor());
        if (mentor != null) {
            plugin.getMessages().send(mentor, "mentor.accepted-mentor", Map.of("player", student.getName()));
        }
    }

    private void leave(Player player) {
        Pair pair = byStudent.remove(player.getUniqueId());
        if (pair == null) {
            plugin.getMessages().send(player, "mentor.not-student");
            return;
        }
        save();
        plugin.getMessages().send(player, "mentor.left");
        Player mentor = Bukkit.getPlayer(pair.mentor);
        if (mentor != null) {
            plugin.getMessages().send(mentor, "mentor.left-mentor", Map.of("player", player.getName()));
        }
    }

    private void kick(Player mentor, String[] args) {
        String name = args.length > 2 ? args[2] : "";
        for (Pair pair : studentsOf(mentor.getUniqueId())) {
            if (pair.studentName.equalsIgnoreCase(name)) {
                byStudent.remove(pair.student);
                save();
                plugin.getMessages().send(mentor, "mentor.kicked", Map.of("player", pair.studentName));
                Player student = Bukkit.getPlayer(pair.student);
                if (student != null) {
                    plugin.getMessages().send(student, "mentor.kicked-student", Map.of("mentor", mentor.getName()));
                }
                return;
            }
        }
        plugin.getMessages().send(mentor, "mentor.usage");
    }

    // ---------------------------------------------------------------
    //  Админ: /ag admin mentor clear <ник> | list
    // ---------------------------------------------------------------

    public void admin(CommandSender sender, String[] args) {
        String action = args.length > 2 ? args[2].toLowerCase(Locale.ROOT) : "";
        if (action.equals("list")) {
            sender.sendMessage(Hud.legacy("&6Наставники: &f" + byStudent.size() + " &7пар"));
            byStudent.values().forEach(p -> sender.sendMessage(Hud.legacy("&8» &f" + p.mentorName + " &7-> &f" + p.studentName)));
        } else if (action.equals("clear") && args.length > 3) {
            int before = byStudent.size();
            byStudent.values().removeIf(p -> p.studentName.equalsIgnoreCase(args[3]) || p.mentorName.equalsIgnoreCase(args[3]));
            save();
            sender.sendMessage(Hud.legacy("&aУдалено пар: " + (before - byStudent.size())));
        } else if (action.equals("reload")) {
            reload();
            sender.sendMessage(Hud.legacy("&aНастройки наставничества перечитаны."));
        } else {
            sender.sendMessage(Hud.legacy("&7/ag admin mentor list|clear <ник>|reload"));
        }
    }
}
