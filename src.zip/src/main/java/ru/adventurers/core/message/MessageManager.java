package ru.adventurers.core.message;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hook.PapiHook;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageManager {

    // "&6текст" и "&#ff8800текст" -> Component
    private static final LegacyComponentSerializer AMPERSAND =
            LegacyComponentSerializer.builder()
                    .character(LegacyComponentSerializer.AMPERSAND_CHAR)
                    .hexColors()
                    .build();

    // Component -> строка с §-кодами (для PlaceholderAPI и меню)
    private static final LegacyComponentSerializer SECTION =
            LegacyComponentSerializer.builder()
                    .character(LegacyComponentSerializer.SECTION_CHAR)
                    .hexColors()
                    .useUnusualXRepeatedCharacterHexFormat()
                    .build();

    private final AdventurersCore plugin;
    private YamlConfiguration config;

    public MessageManager(AdventurersCore plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File file = plugin.getFiles().file("messages.yml");
        if (!file.exists()) {
            plugin.getFiles().save("messages.yml");
        }
        YamlConfiguration loaded = YamlConfiguration.loadConfiguration(file);

        // Недостающие ключи берём из встроенной копии,
        // чтобы после обновления плагина ничего не ломалось.
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                loaded.setDefaults(YamlConfiguration.loadConfiguration(
                        new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (IOException exception) {
            plugin.getLogger().warning(
                    "Could not read built-in messages.yml: " + exception.getMessage());
        }
        this.config = loaded;
    }

    // ---------- отправка ----------

    public void send(CommandSender to, String key) {
        send(to, key, Map.of());
    }

    public void send(CommandSender to, String key, Map<String, ?> placeholders) {
        Player papiPlayer = to instanceof Player player ? player : null;
        for (Component line : render(key, placeholders, papiPlayer)) {
            // Команды вида /ag prof в тексте становятся кликабельными (вставка в чат)
            to.sendMessage(Hud.clickable(plugin, line));
        }
    }

    /** Все строки сообщения одним компонентом (для kick и т.п.). */
    public Component joined(String key) {
        return Component.join(JoinConfiguration.newlines(), render(key, Map.of(), null));
    }

    // ---------- ранги ----------

    /** Название ранга с цветом из messages.yml, в формате с "&". */
    public String rankName(Rank rank) {
        return config.getString("rank-names." + rank.getDisplayName(), rank.getDisplayName());
    }

    public String maxRankText() {
        return config.getString("placeholders.max-rank", "MAX");
    }

    // ---------- вспомогательное ----------

    /** "&6Текст" -> строка с §-кодами. */
    public String toSection(String ampersandText) {
        return SECTION.serialize(AMPERSAND.deserialize(ampersandText));
    }

    /** "&6Текст" -> "Текст" без цветов. */
    public String stripColors(String ampersandText) {
        return PlainTextComponentSerializer.plainText()
                .serialize(AMPERSAND.deserialize(ampersandText));
    }

    public String text(String key, String fallback) {
        return config.getString(key, fallback);
    }

    private List<String> raw(String key) {
        if (config.isList(key)) {
            return config.getStringList(key);
        }
        String value = config.getString(key);
        if (value == null) {
            return List.of("&cMissing message: " + key);
        }
        return List.of(value);
    }

    private List<Component> render(String key, Map<String, ?> placeholders, Player papiPlayer) {
        List<String> lines = raw(key);
        List<Component> result = new ArrayList<>(lines.size());
        String prefix = config.getString("prefix", "");

        for (String line : lines) {
            if (line.isEmpty()) {
                continue; // пустая строка отключает сообщение
            }

            String text = line.replace("{prefix}", prefix);
            Map<String, Component> components = new HashMap<>();

            for (Map.Entry<String, ?> entry : placeholders.entrySet()) {
                if (entry.getValue() instanceof Component component) {
                    components.put(entry.getKey(), component);
                } else {
                    text = text.replace("{" + entry.getKey() + "}",
                            String.valueOf(entry.getValue()));
                }
            }

            if (papiPlayer != null && plugin.isPapiEnabled()) {
                text = PapiHook.apply(papiPlayer, text).replace('§', '&');
            }

            Component rendered = AMPERSAND.deserialize(text);
            for (Map.Entry<String, Component> entry : components.entrySet()) {
                String token = "{" + entry.getKey() + "}";
                Component replacement = entry.getValue();
                rendered = rendered.replaceText(builder ->
                        builder.matchLiteral(token).replacement(replacement));
            }
            result.add(rendered);
        }
        return result;
    }
}