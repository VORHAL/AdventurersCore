package ru.adventurers.core.nav;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import ru.adventurers.core.AdventurersCore;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;

/**
 * Зеркало меню: модуль строит инвентарь как раньше, но игроку показывается меню DeluxeMenus,
 * а названия и описания предметов подставляются плейсхолдерами %ag_menu_&lt;модуль&gt;_&lt;вид&gt;_&lt;слот&gt;_&lt;поле&gt;%.
 * Поля: on (1 если в слоте есть предмет), mat (материал, PANE для заливки), name, head (ник для головы), l1..l14 (описание).
 * Клик в DM вызывает /ag menu &lt;модуль&gt; &lt;вид&gt; &lt;слот&gt; [shift] - тот же обработчик, что был у встроенного меню.
 */
public final class MenuMirror {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&').hexColors().build();
    private static final long TTL_MS = 1500;

    @FunctionalInterface
    public interface Clicker {
        void click(Player player, Inventory inventory, int slot, boolean shift);
    }

    private record Source(BiConsumer<Player, String> opener, Clicker clicker) {
    }

    private record Cached(Inventory inventory, long time) {
    }

    private final AdventurersCore plugin;
    private final Map<String, Source> sources = new HashMap<>();
    private final Map<String, Cached> cache = new HashMap<>();
    private final Set<UUID> capturing = new HashSet<>();
    private final Set<UUID> shown = new HashSet<>();

    public MenuMirror(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void register(String module, BiConsumer<Player, String> opener, Clicker clicker) {
        sources.put(module, new Source(opener, clicker));
    }

    private static String key(Player player, String module, String view) {
        return player.getUniqueId() + "|" + module + "|" + view;
    }

    private static String dmName(String module, String view) {
        return view.equals("main") ? "ag_" + module : "ag_" + module + "_" + view;
    }

    /** Вместо player.openInventory(inventory): запоминает содержимое и открывает меню DeluxeMenus. */
    public void show(Player player, String module, String view, Inventory inventory) {
        cache.put(key(player, module, view), new Cached(inventory, System.currentTimeMillis()));
        if (capturing.contains(player.getUniqueId())) {
            return;
        }
        shown.add(player.getUniqueId());
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "dm open " + dmName(module, view) + " " + player.getName());
    }

    private Inventory build(Player player, String module, String view) {
        Source source = sources.get(module);
        if (source == null) {
            return null;
        }
        UUID id = player.getUniqueId();
        boolean added = capturing.add(id);
        try {
            source.opener().accept(player, view);
        } finally {
            if (added) {
                capturing.remove(id);
            }
        }
        Cached cached = cache.get(key(player, module, view));
        return cached == null ? null : cached.inventory();
    }

    private Inventory get(Player player, String module, String view) {
        Cached cached = cache.get(key(player, module, view));
        if (cached != null && System.currentTimeMillis() - cached.time() < TTL_MS) {
            return cached.inventory();
        }
        return build(player, module, view);
    }

    /** Значение плейсхолдера: parts = модуль, вид, слот, поле. */
    public String field(Player player, String module, String view, int slot, String field) {
        Inventory inventory = get(player, module, view);
        ItemStack item = inventory == null || slot < 0 || slot >= inventory.getSize() ? null : inventory.getItem(slot);
        boolean pane = item != null && item.getType().name().endsWith("GLASS_PANE");
        switch (field) {
            case "on":
                return item == null || pane || item.getType().isAir() ? "0" : "1";
            case "mat":
                return item == null ? "NONE" : pane ? "PANE" : item.getType().name();
            default:
                break;
        }
        if (item == null || pane) {
            return "";
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return "";
        }
        if (field.equals("name")) {
            Component name = meta.displayName();
            return name == null ? "" : LEGACY.serialize(name);
        }
        if (field.equals("head")) {
            if (meta instanceof SkullMeta skull && skull.getOwningPlayer() != null && skull.getOwningPlayer().getName() != null) {
                return skull.getOwningPlayer().getName();
            }
            return "Steve";
        }
        if (field.startsWith("l")) {
            try {
                int index = Integer.parseInt(field.substring(1)) - 1;
                List<Component> lore = meta.lore();
                if (lore != null && index >= 0 && index < lore.size()) {
                    String text = LEGACY.serialize(lore.get(index));
                    return text.isEmpty() ? " " : text;
                }
            } catch (NumberFormatException ignored) {
                return "";
            }
        }
        return "";
    }

    /** Клик из DM: прогоняет тот же обработчик, что был у встроенного меню. */
    public void click(Player player, String module, String view, int slot, boolean shift) {
        Source source = sources.get(module);
        if (source == null) {
            return;
        }
        cache.remove(key(player, module, view));
        Inventory inventory = build(player, module, view);
        if (inventory == null) {
            return;
        }
        UUID id = player.getUniqueId();
        shown.remove(id);
        source.clicker().click(player, inventory, slot, shift);
        cache.keySet().removeIf(k -> k.startsWith(id + "|"));
        if (shown.remove(id)) {
            return;                                   // обработчик сам открыл нужный вид
        }
        if (player.getOpenInventory().getTopInventory().getType() != InventoryType.CRAFTING) {
            Inventory fresh = build(player, module, view);   // остались на том же виде: обновить
            if (fresh != null) {
                show(player, module, view, fresh);
            }
        }
    }
}
