package ru.adventurers.core.nav;

import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;

import java.util.List;

/**
 * Единая кнопка «Назад» для встроенных меню. Цель: "dm:ag_me" (меню DeluxeMenus) или "cmd:ag pet"
 * (команда от имени игрока). Кнопку ставит каждое меню в свободный слот, клик ловит этот слушатель.
 */
public class NavManager implements Listener {

    private final AdventurersCore plugin;
    private final NamespacedKey key;

    public NavManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "nav_target");
    }

    public ItemStack back(String target) {
        ItemStack stack = new ItemStack(Material.ARROW);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(Hud.legacy("&7◀ Назад").decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(Hud.legacy("&8Вернуться в предыдущее меню").decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, target);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Ставит кнопку «Назад» в слот меню. */
    public void place(Inventory inventory, int slot, String target) {
        if (slot >= 0 && slot < inventory.getSize()) {
            inventory.setItem(slot, back(target));
        }
    }

    public void go(Player player, String target) {
        if (target.startsWith("dm:")) {
            if (plugin.getServer().getPluginManager().isPluginEnabled("DeluxeMenus")) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "dm open " + target.substring(3) + " " + player.getName());
            }
        } else if (target.startsWith("cmd:")) {
            player.performCommand(target.substring(4));
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent event) {
        ItemStack stack = event.getCurrentItem();
        if (stack == null || !stack.hasItemMeta() || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        String target = stack.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (target == null) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() == event.getView().getTopInventory()) {
            Bukkit.getScheduler().runTask(plugin, () -> go(player, target));
        }
    }
}
