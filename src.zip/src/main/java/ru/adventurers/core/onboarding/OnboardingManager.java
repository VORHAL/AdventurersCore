package ru.adventurers.core.onboarding;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.message.MessageManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Втягивание игроков (раздел 24 отчёта): цепочка первых шагов, возвращение, зов на сервер.
 *
 * <p>Почему сделано именно так, а не «ежедневная награда за вход»:
 * <ul>
 *   <li>новичок уходит не из-за бедности, а из-за непонимания. Поэтому в цепочке
 *       шесть конкретных действий по одному, а не пачка наград;</li>
 *   <li>ежедневные награды приучают заходить ради награды, а не играть; награды
 *       за отсутствие наказывают тех, кто играет каждый день;</li>
 *   <li>подсказки показываются в HUD по одной и не чаще, чем раз в N секунд,
 *       и после двух напоминаний замолкают - иначе это спам и его выключают.</li>
 * </ul>
 *
 * <p>Состояние этапов хранится в памяти и в профайле: после перезапуска сервера
 * игрок продолжает с того же шага, а не с начала.
 */
public class OnboardingManager {

    private final AdventurersCore plugin;
    private final MessageManager messages;

    private boolean enabled = true;
    private boolean hud = true;
    private int hintIntervalSeconds = 90;
    private int hintAttempts = 2;
    private String newbieTitle = "&7[Новичок]";
    private int newbieTitleHours = 72;

    private boolean returningEnabled = true;
    private int returningDays = 3;
    private int offerQuests = 3;
    private String returningMessage = "";

    private boolean inviteEnabled = true;
    private int minOnlineToCall = 6;
    private int cooldownMinutes = 45;
    private int quietFrom = 1;
    private int quietTo = 9;
    private final List<String> inviteMessages = new ArrayList<>();

    /** Титул новичка: выдан при первом входе, снимается после посвящения или через N часов. */
    private final Map<UUID, Long> newbieSince = new ConcurrentHashMap<>();
    /** Событие из конфига (done-when) -> id шага: связывает yml и вызовы из кода. */
    private final Map<String, String> byEvent = new LinkedHashMap<>();

    /** Этапы цепочки в порядке прохождения. */
    private final List<Step> steps = new ArrayList<>();
    /** Пройденные этапы: игрок -> набор id. */
    private final Map<UUID, java.util.Set<String>> done = new ConcurrentHashMap<>();
    /** Когда игроку в последний раз показывали подсказку: игрок -> время. */
    private final Map<UUID, Long> lastHint = new ConcurrentHashMap<>();
    /** Сколько раз напоминали про текущий шаг: игрок -> (id шага -> попытки). */
    private final Map<UUID, Map<String, Integer>> hintCounts = new ConcurrentHashMap<>();
    /** Время последнего зова на сервер. */
    private long lastCall = 0;
    /** Когда игрок последний раз выходил (для «с возвращением»). */
    private final Map<UUID, Long> lastSeen = new ConcurrentHashMap<>();

    private BukkitTask ticker;

    /**
     * Этап: одно действие, награда и текст.
     *
     * @param id      идентификатор события (class-chosen, quest-taken...)
     * @param hint    подсказка в HUD
     * @param coins   монеты за выполнение
     * @param points  очки гильдии
     * @param xp      опыт профессий
     * @param message сообщение при выполнении
     */
    public record Step(String id, String hint, long coins, int points, int xp, String message) {
    }

    public OnboardingManager(AdventurersCore plugin, MessageManager messages) {
        this.plugin = plugin;
        this.messages = messages;
    }

    public void init() {
        reload();
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L * 20L, 20L * 20L);
    }

    public void shutdown() {
        if (ticker != null) {
            ticker.cancel();
        }
    }

    @SuppressWarnings("unchecked")
    public void reload() {
        YamlConfiguration cfg = plugin.getFiles().load("onboarding.yml");
        enabled = cfg.getBoolean("enabled", true);
        hud = cfg.getBoolean("hud", true);
        hintIntervalSeconds = Math.max(20, cfg.getInt("hint-interval-seconds", hintIntervalSeconds));
        hintAttempts = Math.max(1, cfg.getInt("hint-attempts", hintAttempts));
        newbieTitle = cfg.getString("newbie-title", newbieTitle);
        newbieTitleHours = Math.max(1, cfg.getInt("newbie-title-hours", newbieTitleHours));

        returningEnabled = cfg.getBoolean("returning.enabled", true);
        returningDays = Math.max(1, cfg.getInt("returning.after-days", returningDays));
        offerQuests = Math.max(1, cfg.getInt("returning.offer-quests", offerQuests));
        returningMessage = cfg.getString("returning.message", "");

        inviteEnabled = cfg.getBoolean("invite.enabled", true);
        minOnlineToCall = Math.max(1, cfg.getInt("invite.min-online-to-call", minOnlineToCall));
        cooldownMinutes = Math.max(5, cfg.getInt("invite.cooldown-minutes", cooldownMinutes));
        List<Integer> quiet = cfg.getIntegerList("invite.quiet-hours");
        if (quiet.size() == 2) {
            quietFrom = quiet.get(0);
            quietTo = quiet.get(1);
        }
        inviteMessages.clear();
        inviteMessages.addAll(cfg.getStringList("invite.messages"));

        steps.clear();
        byEvent.clear();
        List<Map<?, ?>> rows = cfg.getMapList("steps");
        for (Map<?, ?> row : rows) {
            String id = String.valueOf(row.get("id"));
            Map<String, Object> reward = row.get("reward") instanceof Map<?, ?> map
                    ? (Map<String, Object>) map : Map.of();
            Object event = row.get("done-when");
            if (event != null) {
                byEvent.put(String.valueOf(event), id);
            }
            steps.add(new Step(
                    id,
                    String.valueOf(row.get("hint")),
                    reward.get("coins") instanceof Number coins ? coins.longValue() : 0,
                    reward.get("points") instanceof Number points ? points.intValue() : 0,
                    reward.get("xp") instanceof Number xp ? xp.intValue() : 0,
                    String.valueOf(row.get("message"))));
        }
        plugin.getLogger().info("Втягивание игроков: этапов " + steps.size()
                + ", подсказка раз в " + hintIntervalSeconds + " с");
    }

    public boolean isEnabled() {
        return enabled;
    }

    public List<Step> steps() {
        return steps;
    }

    // ---------------------------------------------------------------
    //  Этапы
    // ---------------------------------------------------------------

    /** Текущий (первый невыполненный) этап игрока или null, если цепочка пройдена. */
    public Step current(Player player) {
        java.util.Set<String> completed = done.getOrDefault(player.getUniqueId(), java.util.Set.of());
        for (Step step : steps) {
            if (!completed.contains(step.id())) {
                return step;
            }
        }
        return null;
    }

    /**
     * Игрок сделал шаг цепочки. Вызывается из слушателей: выбор класса, взятие задания,
     * сдача задания, открытие меню, наставничество, вход в подземелье.
     *
     * @return true, если шаг засчитан именно сейчас (награда выдана)
     */
    public boolean complete(Player player, String stepId) {
        if (!enabled || stepId == null) {
            return false;
        }
        // код называет событие (class-chosen, quest-taken...), а в конфиге у этапа есть id.
        // Если совпадения нет - значит администратор переименовал этап, и шаг просто не засчитается.
        String stepKey = byEvent.getOrDefault(stepId, stepId);
        Step step = steps.stream().filter(each -> each.id().equals(stepKey)).findFirst().orElse(null);
        if (step == null) {
            return false;
        }
        java.util.Set<String> completed = done.computeIfAbsent(player.getUniqueId(),
                key -> ConcurrentHashMap.newKeySet());
        if (!completed.add(stepKey)) {
            return false;   // уже было: награда не повторяется
        }
        if (step.coins() > 0 && plugin.getEconomy() != null) {
            plugin.getEconomy().reward(player, step.coins(), "economy.reward-onboarding");
        }
        if (step.points() > 0 && plugin.getQuests() != null) {
            plugin.getQuests().adminAddPoints(player, step.points());
        }
        if (step.xp() > 0 && plugin.getProfessions() != null) {
            // опыт идёт в первую изученную профессию игрока: «просто опыт» девать некуда,
            // а новичок чаще всего выбирает её как основную
            var data = plugin.getProfessions().get(player.getUniqueId());
            if (data != null && !data.professions().isEmpty()) {
                plugin.getProfessions().addXp(player,
                        data.professions().iterator().next(), step.xp());
            }
        }
        if (step.message() != null && !step.message().isBlank()) {
            player.sendMessage(Hud.legacy(step.message()));
        }
        Step next = current(player);
        if (next == null) {
            // посвящение: титул новичка больше не нужен
            newbieSince.remove(player.getUniqueId());
            plugin.getGlory().registerUnlock("onboarding-done", p -> done
                    .getOrDefault(p.getUniqueId(), java.util.Set.of()).size() >= steps.size());
            messages.send(player, "onboarding.finished");
        }
        return true;
    }

    /** Сколько этапов пройдено (для HUD и /ag start). */
    public int progress(Player player) {
        return done.getOrDefault(player.getUniqueId(), java.util.Set.of()).size();
    }

    // ---------------------------------------------------------------
    //  Подсказки в HUD
    // ---------------------------------------------------------------

    private void tick() {
        if (!enabled) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            hint(player);
        }
        call();
    }

    private void hint(Player player) {
        if (!hud) {
            return;
        }
        Step step = current(player);
        if (step == null) {
            return;
        }
        long now = System.currentTimeMillis();
        Long last = lastHint.get(player.getUniqueId());
        if (last != null && now - last < hintIntervalSeconds * 1000L) {
            return;
        }
        Map<String, Integer> counts = hintCounts.computeIfAbsent(player.getUniqueId(),
                key -> new LinkedHashMap<>());
        int shown = counts.getOrDefault(step.id(), 0);
        if (shown >= hintAttempts) {
            return;   // два раза напомнили - молчим, дальше это спам
        }
        counts.put(step.id(), shown + 1);
        lastHint.put(player.getUniqueId(), now);
        if (plugin.getSkillHud() != null) {
            plugin.getSkillHud().flash(player, Hud.legacy(step.hint()));
        }
    }

    // ---------------------------------------------------------------
    //  Возвращение
    // ---------------------------------------------------------------

    /** Вход игрока: приветствие новичку или «с возвращением» после долгого отсутствия. */
    public void join(Player player) {
        if (!enabled) {
            return;
        }
        // титул новичка: чтобы в чате было видно, кто только пришёл - и к кому подойти
        newbieSince.putIfAbsent(player.getUniqueId(), System.currentTimeMillis());
        Long seen = lastSeen.get(player.getUniqueId());
        long now = System.currentTimeMillis();
        lastSeen.put(player.getUniqueId(), now);
        if (seen == null) {
            return;
        }
        long days = (now - seen) / 86_400_000L;
        if (returningEnabled && days >= returningDays) {
            String text = returningMessage.replace("{count}", String.valueOf(offerQuests));
            if (!text.isBlank()) {
                player.sendMessage(Hud.legacy(text));
            }
            messages.send(player, "onboarding.returning", Map.of(
                    "days", String.valueOf(days), "count", String.valueOf(offerQuests)));
        }
        Step step = current(player);
        if (step != null) {
            // вернувшемуся напоминаем сразу, не через 90 секунд
            lastHint.remove(player.getUniqueId());
        }
    }

    /** Носить ли титул новичка: пока цепочка не пройдена и не истекли отведённые часы. */
    public boolean newbie(Player player) {
        if (!enabled) {
            return false;
        }
        Long since = newbieSince.get(player.getUniqueId());
        if (since == null) {
            return false;
        }
        if (current(player) == null) {
            return false;
        }
        return System.currentTimeMillis() - since < newbieTitleHours * 3_600_000L;
    }

    public String newbieTitle() {
        return newbieTitle;
    }

    public void quit(Player player) {
        lastSeen.put(player.getUniqueId(), System.currentTimeMillis());
        hintCounts.remove(player.getUniqueId());
        lastHint.remove(player.getUniqueId());
    }

    // ---------------------------------------------------------------
    //  Зов на сервер
    // ---------------------------------------------------------------

    /**
     * Если онлайн низкий и есть повод - зовём в чат на общее занятие.
     * Зов идёт не «зайди», а «через 10 минут идём в подземелье»: люди приходят
     * на событие, а не на пустой сервер.
     */
    private void call() {
        if (!inviteEnabled || inviteMessages.isEmpty()) {
            return;
        }
        int online = Bukkit.getOnlinePlayers().size();
        if (online == 0 || online >= minOnlineToCall) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - lastCall < cooldownMinutes * 60_000L) {
            return;
        }
        // тихие часы считаются по реальному времени сервера, а не по игровому: ночью люди спят
        int localHour = java.time.LocalTime.now().getHour();
        boolean quiet = quietFrom <= quietTo
                ? localHour >= quietFrom && localHour < quietTo
                : localHour >= quietFrom || localHour < quietTo;
        if (quiet) {
            return;
        }
        lastCall = now;
        String text = inviteMessages.get(java.util.concurrent.ThreadLocalRandom.current()
                .nextInt(inviteMessages.size()));
        Bukkit.broadcast(Hud.legacy(text));
    }

    /** Состояние для /ag start: что уже сделано и что дальше. */
    public List<String> describe(Player player) {
        List<String> lines = new ArrayList<>();
        java.util.Set<String> completed = done.getOrDefault(player.getUniqueId(), java.util.Set.of());
        lines.add("&8Первые шаги: &f" + completed.size() + "&8/&f" + steps.size());
        for (Step step : steps) {
            boolean ok = completed.contains(step.id());
            lines.add((ok ? "&a✔ " : "&7• ") + (ok ? "&8" : "&f") + hintWithoutColors(step.hint()));
        }
        return lines;
    }

    private static String hintWithoutColors(String hint) {
        return hint.replaceAll("&[0-9a-fk-or]", "").replace("/ag ", "/ag ");
    }
}
