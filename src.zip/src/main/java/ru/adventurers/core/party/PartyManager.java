package ru.adventurers.core.party;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Группы (до 5 игроков) и рейды (ровно 10: 2 танка, 2 лекаря, 6 бойцов). Только основной поток. */
public class PartyManager {

    private record Invite(Party party, long expires) {
    }

    private static final String MENU = "ag_party";

    private final AdventurersCore plugin;

    private final Map<UUID, Party> groups = new HashMap<>();
    private final Map<UUID, Party> raids = new HashMap<>();
    private final Map<UUID, Invite> groupInvites = new HashMap<>();
    private final Map<UUID, Invite> raidInvites = new HashMap<>();

    private int groupMax = 5;
    private int raidSize = 10;
    private int raidTanks = 2;
    private int raidHealers = 2;
    private int raidFighters = 6;
    private Rank raidMinRank = Rank.D;
    private long inviteMs = 60_000L;
    private double shareRadius = 30;

    public PartyManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    public void init() {
        reload();
    }

    public void reload() {
        File file = plugin.getFiles().file("party.yml");
        if (!file.exists()) {
            plugin.getFiles().save("party.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        groupMax = Math.max(2, cfg.getInt("group.max-size", 5));
        raidTanks = Math.max(0, cfg.getInt("raid.tanks", 2));
        raidHealers = Math.max(0, cfg.getInt("raid.healers", 2));
        raidFighters = Math.max(0, cfg.getInt("raid.fighters", 6));
        raidSize = raidTanks + raidHealers + raidFighters;
        Rank parsed = Rank.fromInput(cfg.getString("raid.min-rank", "D"));
        raidMinRank = parsed != null ? parsed : Rank.D;
        inviteMs = Math.max(5, cfg.getInt("invite-timeout-seconds", 60)) * 1000L;
        shareRadius = Math.max(0, cfg.getDouble("share-kills-radius", 30));
    }

    public void shutdown() {
        groups.clear();
        raids.clear();
        groupInvites.clear();
        raidInvites.clear();
    }

    // ---------------------------------------------------------------
    //  Запросы
    // ---------------------------------------------------------------

    private Map<UUID, Party> map(Party.Type type) {
        return type == Party.Type.GROUP ? groups : raids;
    }

    private Map<UUID, Invite> invites(Party.Type type) {
        return type == Party.Type.GROUP ? groupInvites : raidInvites;
    }

    public Party group(UUID uuid) {
        return groups.get(uuid);
    }

    public Party raid(UUID uuid) {
        return raids.get(uuid);
    }

    public Party of(UUID uuid, Party.Type type) {
        return map(type).get(uuid);
    }

    public boolean inSameGroup(Player a, Player b) {
        Party party = groups.get(a.getUniqueId());
        return party != null && party.has(b.getUniqueId());
    }

    public boolean inSameRaid(Player a, Player b) {
        Party party = raids.get(a.getUniqueId());
        return party != null && party.has(b.getUniqueId());
    }

    public int maxSize(Party.Type type) {
        return type == Party.Type.GROUP ? groupMax : raidSize;
    }

    public double getShareRadius() {
        return shareRadius;
    }

    public List<Player> onlineMembers(Party party) {
        List<Player> result = new ArrayList<>();
        if (party != null) {
            for (UUID uuid : party.members()) {
                Player player = Bukkit.getPlayer(uuid);
                if (player != null && player.isOnline()) {
                    result.add(player);
                }
            }
        }
        return result;
    }

    /** Игроки группы рядом с killer (в том числе он сам): им засчитывается убийство для заданий. */
    public List<Player> shareTargets(Player killer) {
        List<Player> result = new ArrayList<>();
        result.add(killer);
        Party party = groups.get(killer.getUniqueId());
        if (party == null || shareRadius <= 0) {
            return result;
        }
        for (Player member : onlineMembers(party)) {
            if (!member.equals(killer) && member.getWorld().equals(killer.getWorld())
                    && member.getLocation().distanceSquared(killer.getLocation()) <= shareRadius * shareRadius) {
                result.add(member);
            }
        }
        return result;
    }

    // ---------------------------------------------------------------
    //  Состав рейда
    // ---------------------------------------------------------------

    public record Composition(int tanks, int healers, int fighters, int universals, int none, int size) {
        /**
         * Рейд готов, если собрано ровно нужное число игроков с классами и лишних танков,
         * лекарей и бойцов нет. Универсалы закрывают любые недостающие места.
         */
        public boolean valid(int needTanks, int needHealers, int needFighters) {
            return none == 0
                    && size == needTanks + needHealers + needFighters
                    && tanks <= needTanks && healers <= needHealers && fighters <= needFighters;
        }
    }

    public Composition composition(Party party) {
        int tanks = 0;
        int healers = 0;
        int fighters = 0;
        int universals = 0;
        int none = 0;
        for (UUID uuid : party.members()) {
            PlayerClass active = plugin.getClasses().activeClass(uuid);
            if (active == null) {
                none++;
            } else {
                switch (active) {
                    case TANK -> tanks++;
                    case HEALER -> healers++;
                    case FIGHTER -> fighters++;
                    case UNIVERSAL -> universals++;
                }
            }
        }
        return new Composition(tanks, healers, fighters, universals, none, party.size());
    }

    public boolean raidReady(Party raid) {
        return composition(raid).valid(raidTanks, raidHealers, raidFighters);
    }

    public int need(String role) {
        return switch (role) {
            case "tank" -> raidTanks;
            case "healer" -> raidHealers;
            default -> raidFighters;
        };
    }

    // ---------------------------------------------------------------
    //  Команды: /ag group ..., /ag raid ...
    // ---------------------------------------------------------------

    public void handle(Player player, Party.Type type, String[] args) {
        String sub = args.length > 1 ? args[1].toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "" -> showOrMenu(player, type);
            case "create" -> create(player, type);
            case "invite" -> invite(player, type, args);
            case "accept" -> accept(player, type);
            case "decline" -> decline(player, type);
            case "leave" -> leave(player, type, true);
            case "kick" -> kick(player, type, args);
            case "promote" -> promote(player, type, args);
            case "disband" -> disband(player, type);
            case "list" -> list(player, type);
            case "check" -> check(player, type);
            default -> plugin.getMessages().send(player, "parties.usage-" + type.name().toLowerCase(Locale.ROOT));
        }
    }

    private String kind(Party.Type type, String form) {
        return plugin.getMessages().text("parties.kind." + type.name().toLowerCase(Locale.ROOT) + "." + form,
                type.name().toLowerCase(Locale.ROOT));
    }

    private Map<String, Object> ph(Party.Type type, Object... pairs) {
        Map<String, Object> map = new HashMap<>();
        map.put("kind", kind(type, "nom"));
        map.put("kind_acc", kind(type, "acc"));
        map.put("cmd", type.name().toLowerCase(Locale.ROOT));
        map.put("max", maxSize(type));
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            map.put(String.valueOf(pairs[i]), pairs[i + 1]);
        }
        return map;
    }

    private void showOrMenu(Player player, Party.Type type) {
        if (plugin.getServer().getPluginManager().isPluginEnabled("DeluxeMenus")
                && Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "dm open " + MENU + " " + player.getName())) {
            return;
        }
        list(player, type);
    }

    private void create(Player player, Party.Type type) {
        UUID uuid = player.getUniqueId();
        if (map(type).containsKey(uuid)) {
            plugin.getMessages().send(player, "parties.already-in", ph(type));
            return;
        }
        if (type == Party.Type.RAID) {
            PlayerProfile profile = plugin.getProfileManager().getProfile(uuid);
            if (profile == null || !profile.getRank().isAtLeast(raidMinRank)) {
                plugin.getMessages().send(player, "parties.raid-rank", Map.of(
                        "rank", plugin.getMessages().rankName(raidMinRank)));
                return;
            }
        }
        map(type).put(uuid, new Party(type, uuid));
        plugin.getMessages().send(player, "parties.created", ph(type));
    }

    private void invite(Player leader, Party.Type type, String[] args) {
        Party party = map(type).get(leader.getUniqueId());
        if (party == null) {
            plugin.getMessages().send(leader, "parties.not-in", ph(type));
            return;
        }
        if (!party.getLeader().equals(leader.getUniqueId())) {
            plugin.getMessages().send(leader, "parties.leader-only", ph(type));
            return;
        }
        Player target = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
        if (target == null) {
            plugin.getMessages().send(leader, "commands.admin.player-not-found");
            return;
        }
        if (target.equals(leader) || map(type).containsKey(target.getUniqueId())) {
            plugin.getMessages().send(leader, "parties.target-busy", ph(type, "player", target.getName()));
            return;
        }
        if (party.size() >= maxSize(type)) {
            plugin.getMessages().send(leader, "parties.full", ph(type));
            return;
        }
        invites(type).put(target.getUniqueId(), new Invite(party, System.currentTimeMillis() + inviteMs));
        plugin.getMessages().send(leader, "parties.invite-sent", ph(type, "player", target.getName()));
        plugin.getMessages().send(target, "parties.invite-received", ph(type,
                "player", leader.getName(),
                "command", "/ag " + type.name().toLowerCase(Locale.ROOT) + " accept"));
    }

    private void accept(Player player, Party.Type type) {
        UUID uuid = player.getUniqueId();
        Invite invite = invites(type).remove(uuid);
        if (invite == null || invite.expires() < System.currentTimeMillis()) {
            plugin.getMessages().send(player, "parties.no-invite", ph(type));
            return;
        }
        Party party = invite.party();
        if (map(type).containsKey(uuid)) {
            plugin.getMessages().send(player, "parties.already-in", ph(type));
            return;
        }
        if (!isAlive(party, type)) {
            plugin.getMessages().send(player, "parties.no-invite", ph(type));
            return;
        }
        if (party.size() >= maxSize(type)) {
            plugin.getMessages().send(player, "parties.full", ph(type));
            return;
        }
        party.members().add(uuid);
        map(type).put(uuid, party);
        broadcast(party, "parties.joined", ph(type, "player", player.getName()));
    }

    private boolean isAlive(Party party, Party.Type type) {
        return map(type).get(party.getLeader()) == party;
    }

    private void decline(Player player, Party.Type type) {
        Invite invite = invites(type).remove(player.getUniqueId());
        if (invite == null) {
            plugin.getMessages().send(player, "parties.no-invite", ph(type));
            return;
        }
        plugin.getMessages().send(player, "parties.declined", ph(type));
        Player leader = Bukkit.getPlayer(invite.party().getLeader());
        if (leader != null) {
            plugin.getMessages().send(leader, "parties.declined-by", ph(type, "player", player.getName()));
        }
    }

    /** Выход из группы/рейда. Если вышел лидер, лидерство переходит следующему, пустая группа удаляется. */
    public void leave(Player player, Party.Type type, boolean notifySelf) {
        UUID uuid = player.getUniqueId();
        Party party = map(type).remove(uuid);
        if (party == null) {
            if (notifySelf) {
                plugin.getMessages().send(player, "parties.not-in", ph(type));
            }
            return;
        }
        party.members().remove(uuid);
        if (notifySelf) {
            plugin.getMessages().send(player, "parties.left", ph(type));
        }
        if (party.members().isEmpty()) {
            return;
        }
        if (party.getLeader().equals(uuid)) {
            party.setLeader(party.members().iterator().next());
            Player newLeader = Bukkit.getPlayer(party.getLeader());
            broadcast(party, "parties.new-leader", ph(type,
                    "player", newLeader != null ? newLeader.getName() : "?"));
        }
        broadcast(party, "parties.member-left", ph(type, "player", player.getName()));
        if (party.size() == 1 && type == Party.Type.GROUP) {
            // группа из одного человека остаётся: игрок может снова пригласить друзей
            return;
        }
    }

    private void kick(Player leader, Party.Type type, String[] args) {
        Party party = map(type).get(leader.getUniqueId());
        if (party == null) {
            plugin.getMessages().send(leader, "parties.not-in", ph(type));
            return;
        }
        if (!party.getLeader().equals(leader.getUniqueId())) {
            plugin.getMessages().send(leader, "parties.leader-only", ph(type));
            return;
        }
        Player target = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
        if (target == null || target.equals(leader) || !party.has(target.getUniqueId())) {
            plugin.getMessages().send(leader, "parties.not-member", ph(type));
            return;
        }
        party.members().remove(target.getUniqueId());
        map(type).remove(target.getUniqueId());
        plugin.getMessages().send(target, "parties.kicked", ph(type));
        broadcast(party, "parties.member-kicked", ph(type, "player", target.getName()));
    }

    private void promote(Player leader, Party.Type type, String[] args) {
        Party party = map(type).get(leader.getUniqueId());
        if (party == null || !party.getLeader().equals(leader.getUniqueId())) {
            plugin.getMessages().send(leader, "parties.leader-only", ph(type));
            return;
        }
        Player target = args.length > 2 ? Bukkit.getPlayerExact(args[2]) : null;
        if (target == null || !party.has(target.getUniqueId()) || target.equals(leader)) {
            plugin.getMessages().send(leader, "parties.not-member", ph(type));
            return;
        }
        party.setLeader(target.getUniqueId());
        broadcast(party, "parties.new-leader", ph(type, "player", target.getName()));
    }

    private void disband(Player leader, Party.Type type) {
        Party party = map(type).get(leader.getUniqueId());
        if (party == null || !party.getLeader().equals(leader.getUniqueId())) {
            plugin.getMessages().send(leader, "parties.leader-only", ph(type));
            return;
        }
        broadcast(party, "parties.disbanded", ph(type));
        for (UUID uuid : new ArrayList<>(party.members())) {
            map(type).remove(uuid);
        }
        party.members().clear();
    }

    private void list(Player player, Party.Type type) {
        Party party = map(type).get(player.getUniqueId());
        if (party == null) {
            plugin.getMessages().send(player, "parties.not-in", ph(type));
            return;
        }
        plugin.getMessages().send(player, "parties.list-header", ph(type, "size", party.size()));
        for (UUID uuid : party.members()) {
            Player member = Bukkit.getPlayer(uuid);
            PlayerClass active = plugin.getClasses().activeClass(uuid);
            plugin.getMessages().send(player, "parties.list-entry", ph(type,
                    "player", member != null ? member.getName() : "?",
                    "class", active != null ? plugin.getClasses().displayName(active) : "&8—",
                    "leader", party.getLeader().equals(uuid) ? "&6★ " : "&8• "));
        }
    }

    private void check(Player player, Party.Type type) {
        Party party = map(type).get(player.getUniqueId());
        if (party == null || type != Party.Type.RAID) {
            plugin.getMessages().send(player, "parties.not-in", ph(type));
            return;
        }
        Composition c = composition(party);
        Map<String, Object> values = new HashMap<>();
        values.put("size", c.size());
        values.put("need", raidSize);
        values.put("tanks", c.tanks());
        values.put("need_tanks", raidTanks);
        values.put("healers", c.healers());
        values.put("need_healers", raidHealers);
        values.put("fighters", c.fighters());
        values.put("need_fighters", raidFighters);
        values.put("universals", c.universals());
        values.put("none", c.none());
        values.put("ready", plugin.getMessages().text(
                raidReady(party) ? "parties.ready-yes" : "parties.ready-no", ""));
        plugin.getMessages().send(player, "parties.raid-check", values);
    }

    public void broadcast(Party party, String key, Map<String, ?> placeholders) {
        for (Player member : onlineMembers(party)) {
            plugin.getMessages().send(member, key, placeholders);
        }
    }

    /** При выходе игрока с сервера. */
    public void onQuit(Player player) {
        leave(player, Party.Type.GROUP, false);
        leave(player, Party.Type.RAID, false);
        groupInvites.remove(player.getUniqueId());
        raidInvites.remove(player.getUniqueId());
    }
}
