package ru.adventurers.core.potion;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.hud.PackItems;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Бутылочки здоровья и маны трёх размеров. Настройки: potions.yml. */
public class PotionManager implements Listener {

    private final AdventurersCore plugin;
    private final NamespacedKey kindKey;
    private final NamespacedKey tierKey;
    private final Map<UUID, Long> cooldown = new HashMap<>();
    private YamlConfiguration cfg = new YamlConfiguration();

    public PotionManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.kindKey = new NamespacedKey(plugin, "potion_kind");
        this.tierKey = new NamespacedKey(plugin, "potion_tier");
    }

    public void reload() {
        File file = new File(plugin.getDataFolder(), "potions.yml");
        if (!file.exists()) {
            plugin.saveResource("potions.yml", false);
        }
        cfg = YamlConfiguration.loadConfiguration(file);
    }

    public void forget(UUID uuid) {
        cooldown.remove(uuid);
    }

    /** kind: hp или mana, tier: 1..3. */
    public ItemStack create(String kind, int tier, int amount) {
        if (kind.startsWith("arrow_")) {
            return createArrow(kind.substring(6), amount);
        }
        ConfigurationSection sec = cfg.getConfigurationSection(kind + "." + tier);
        ItemStack item = new ItemStack(Material.POTION, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        String name = sec != null ? sec.getString("name", kind + " " + tier) : kind + " " + tier;
        meta.displayName(Hud.legacy(name).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        if (sec != null) {
            for (String line : sec.getStringList("lore")) {
                lore.add(Hud.legacy(line).decoration(TextDecoration.ITALIC, false));
            }
        }
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        meta.setMaxStackSize(16);
        meta.getPersistentDataContainer().set(kindKey, PersistentDataType.STRING, kind);
        meta.getPersistentDataContainer().set(tierKey, PersistentDataType.INTEGER, tier);
        PackItems.model(meta, "potion_" + kind + "_" + tier);
        item.setItemMeta(meta);
        return item;
    }

    /** Стрелы с эффектом: poison, slow, weakness, glow. */
    public ItemStack createArrow(String type, int amount) {
        ConfigurationSection sec = cfg.getConfigurationSection("arrows." + type);
        if (sec == null) {
            return null;
        }
        ItemStack item = new ItemStack(Material.TIPPED_ARROW, Math.max(1, Math.min(64, amount)));
        org.bukkit.inventory.meta.PotionMeta meta = (org.bukkit.inventory.meta.PotionMeta) item.getItemMeta();
        org.bukkit.potion.PotionEffectType effect = org.bukkit.Registry.EFFECT
                .get(NamespacedKey.minecraft(sec.getString("effect", "poison")));
        if (effect != null) {
            meta.addCustomEffect(new org.bukkit.potion.PotionEffect(effect,
                    (int) (sec.getDouble("seconds", 5) * 20), sec.getInt("amplifier", 0)), true);
        }
        meta.setColor(org.bukkit.Color.fromRGB(sec.getInt("color", 0x55aa55)));
        meta.displayName(Hud.legacy(sec.getString("name", "&aСтрела")).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String line : sec.getStringList("lore")) {
            lore.add(Hud.legacy(line).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        meta.getPersistentDataContainer().set(kindKey, PersistentDataType.STRING, "arrow_" + type);
        item.setItemMeta(meta);
        return item;
    }

    public java.util.Set<String> arrowTypes() {
        ConfigurationSection sec = cfg.getConfigurationSection("arrows");
        return sec == null ? java.util.Set.of() : sec.getKeys(false);
    }

    public boolean isGuildPotion(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(kindKey, PersistentDataType.STRING);
    }

    private static final java.util.Set<String> BAD = java.util.Set.of("poison", "wither", "slowness", "weakness",
            "blindness", "nausea", "hunger", "darkness", "mining_fatigue", "levitation", "bad_omen");

    @EventHandler
    public void onMobDeath(org.bukkit.event.entity.EntityDeathEvent event) {
        var entity = event.getEntity();
        Player killer = entity.getKiller();
        if (killer == null || entity instanceof Player || !(entity instanceof org.bukkit.entity.Monster)
                || !cfg.getBoolean("drops.enabled", true)) {
            return;
        }
        AttributeInstance hpAttr = entity.getAttribute(Attribute.MAX_HEALTH);
        double mobHp = hpAttr != null ? hpAttr.getValue() : 20;
        double chance = cfg.getDouble("drops.chance", 0.04);
        if (mobHp >= cfg.getDouble("drops.boss-health", 100)) {
            chance = Math.min(1.0, chance * cfg.getDouble("drops.boss-multiplier", 6));
        }
        if (Math.random() >= chance) {
            return;
        }
        var profile = plugin.getProfileManager().getProfile(killer.getUniqueId());
        int rank = profile == null ? 0 : profile.getRank().ordinal();
        int tier = rank >= 5 ? (Math.random() < 0.5 ? 3 : 2) : rank >= 3 ? (Math.random() < 0.6 ? 2 : 1) : 1;
        String kind = "hp";
        double roll = Math.random();
        if (roll < cfg.getDouble("drops.cure-share", 0.1)) {
            kind = "cure";
            tier = 1;
        } else if (roll < 0.45 && plugin.getHealer() != null && plugin.getHealer().canUse(killer)) {
            kind = "mana";
        }
        event.getDrops().add(create(kind, tier, 1));
    }

    @EventHandler
    public void onMobArrowDrop(org.bukkit.event.entity.EntityDeathEvent event) {
        var entity = event.getEntity();
        if (entity.getKiller() == null || !(entity instanceof org.bukkit.entity.Monster)
                || !cfg.getBoolean("arrows.drops.enabled", true)) {
            return;
        }
        double chance = cfg.getDouble("arrows.drops.chance", 0.06);
        String id = entity.getType().name();
        if (id.equals("SKELETON") || id.equals("STRAY") || id.equals("BOGGED") || id.equals("PILLAGER")) {
            chance *= cfg.getDouble("arrows.drops.shooter-multiplier", 2.5);
        }
        if (Math.random() >= chance) {
            return;
        }
        List<String> types = new ArrayList<>(cfg.getConfigurationSection("arrows").getKeys(false));
        types.remove("drops");
        if (types.isEmpty()) {
            return;
        }
        ItemStack arrow = createArrow(types.get((int) (Math.random() * types.size())), 4 + (int) (Math.random() * 5));
        if (arrow != null) {
            event.getDrops().add(arrow);
        }
    }

    public boolean give(Player target, String kind, int tier, int amount) {
        if (kind.startsWith("arrow_")) {
            ItemStack arrow = createArrow(kind.substring(6), amount);
            if (arrow == null) {
                return false;
            }
            for (ItemStack extra : target.getInventory().addItem(arrow).values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), extra);
            }
            return true;
        }
        if (!(kind.equals("hp") || kind.equals("mana") || kind.equals("cure")) || tier < 1 || tier > 3) {
            return false;
        }
        Map<Integer, ItemStack> left = target.getInventory().addItem(create(kind, tier, amount));
        for (ItemStack extra : left.values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), extra);
        }
        return true;
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent event) {
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) {
            return;
        }
        var data = item.getItemMeta().getPersistentDataContainer();
        String kind = data.get(kindKey, PersistentDataType.STRING);
        Integer tier = data.get(tierKey, PersistentDataType.INTEGER);
        if (kind == null || tier == null) {
            return;
        }
        Player player = event.getPlayer();
        long now = System.currentTimeMillis();
        Long until = cooldown.get(player.getUniqueId());
        String cdKey = kind;
        if (until != null && now < until && cooldownKind.getOrDefault(player.getUniqueId(), "").equals(cdKey)) {
            event.setCancelled(true);
            plugin.getMessages().send(player, "potion.cooldown", Map.of("seconds", (until - now) / 1000 + 1));
            return;
        }
        double percent = cfg.getDouble(kind + "." + tier + ".percent", 30);
        if (kind.equals("cure")) {
            boolean any = false;
            for (var effect : new ArrayList<>(player.getActivePotionEffects())) {
                String key = effect.getType().getKey().getKey();
                if (BAD.contains(key)) {
                    player.removePotionEffect(effect.getType());
                    any = true;
                }
            }
            if (!any) {
                event.setCancelled(true);
                plugin.getMessages().send(player, "potion.cure-none");
                return;
            }
        } else if (kind.equals("hp")) {
            AttributeInstance max = player.getAttribute(Attribute.MAX_HEALTH);
            double m = max != null ? max.getValue() : 20.0;
            if (player.getHealth() >= m - 0.01) {
                event.setCancelled(true);
                plugin.getMessages().send(player, "potion.hp-full");
                return;
            }
            player.setHealth(Math.min(m, player.getHealth() + m * percent / 100.0));
        } else {
            if (plugin.getHealer() == null || !plugin.getHealer().canUse(player)) {
                event.setCancelled(true);
                plugin.getMessages().send(player, "potion.mana-only-healer");
                return;
            }
            plugin.getHealer().restoreMana(player, plugin.getHealer().maxMana(player) * percent / 100.0);
        }
        long cd = (long) (cfg.getDouble(kind + "." + tier + ".cooldown-seconds", 20) * 1000);
        cooldown.put(player.getUniqueId(), now + cd);
        cooldownKind.put(player.getUniqueId(), cdKey);
        event.setReplacement(new ItemStack(Material.AIR));
    }

    private final Map<UUID, String> cooldownKind = new HashMap<>();
}
