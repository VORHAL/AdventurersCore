package ru.adventurers.core.profession;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.FurnaceExtractEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.potion.PotionType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.party.Party;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

/**
 * Эффекты дополнительных профессий: охотник и рудокоп (больше добычи),
 * кулинар (бафы от еды), алхимик (зелья дольше). Настройки: professions.yml, раздел extras.
 */
public class ExtraEffects implements Listener {

    private final AdventurersCore plugin;
    private final NamespacedKey potionMark;
    private final Random random = new Random();

    private double hunterChance = 0.03;
    private double minerChance = 0.03;
    private int minerXp = 2;
    private final List<String> minerBlocks = new ArrayList<>();
    private int cookXp = 2;
    private double cookRadius = 10;
    private final List<String> cookFoods = new ArrayList<>();
    private int regenBase = 6;
    private int regenPerLevel = 1;
    private int absorbBase = 60;
    private int absorbPerLevel = 12;
    private int absorbLevelPer = 4;
    private double alchemistBonus = 0.05;
    private int alchemistXp = 3;

    public ExtraEffects(AdventurersCore plugin) {
        this.plugin = plugin;
        this.potionMark = new NamespacedKey(plugin, "alch_xp");
    }

    public void reload() {
        File file = plugin.getFiles().file("professions.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        hunterChance = cfg.getDouble("extras.hunter.drop-chance-per-level", 0.03);
        minerChance = cfg.getDouble("extras.miner.drop-chance-per-level", 0.03);
        minerXp = cfg.getInt("extras.miner.xp-per-block", 2);
        minerBlocks.clear();
        for (String s : cfg.getStringList("extras.miner.blocks")) {
            minerBlocks.add(s.toUpperCase(Locale.ROOT));
        }
        cookXp = cfg.getInt("extras.cook.xp-per-food", 2);
        cookRadius = cfg.getDouble("extras.cook.group-radius", 10);
        cookFoods.clear();
        for (String s : cfg.getStringList("extras.cook.foods")) {
            cookFoods.add(s.toUpperCase(Locale.ROOT));
        }
        ConfigurationSection buff = cfg.getConfigurationSection("extras.cook.buff");
        if (buff != null) {
            regenBase = buff.getInt("regeneration-seconds-base", 6);
            regenPerLevel = buff.getInt("regeneration-seconds-per-level", 1);
            absorbBase = buff.getInt("absorption-seconds-base", 60);
            absorbPerLevel = buff.getInt("absorption-seconds-per-level", 12);
            absorbLevelPer = Math.max(1, buff.getInt("absorption-level-per", 4));
        }
        alchemistBonus = cfg.getDouble("extras.alchemist.duration-bonus-per-level", 0.05);
        alchemistXp = cfg.getInt("extras.alchemist.xp-per-potion", 3);
    }

    private int level(Player player, Profession profession) {
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        if (data == null) {
            return 0;
        }
        PlayerProfessions.Progress progress = data.get(profession);
        return progress == null ? 0 : progress.getLevel();
    }

    private boolean isMinerBlock(Material material) {
        String name = material.name();
        for (String pattern : minerBlocks) {
            if (pattern.startsWith("_") ? name.endsWith(pattern) : name.equals(pattern)) {
                return true;
            }
        }
        return false;
    }

    private boolean isCookFood(Material material) {
        String name = material.name();
        return name.startsWith("COOKED_") || cookFoods.contains(name);
    }

    // ---------------------------------------------------------------
    //  Охотник: добыча с монстров
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onKill(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null || event.getEntity() instanceof Player || event.getDrops().isEmpty()) {
            return;
        }
        int level = level(killer, Profession.HUNTER);
        if (level <= 0 || random.nextDouble() >= level * hunterChance) {
            return;
        }
        List<ItemStack> drops = event.getDrops();
        ItemStack pick = drops.get(random.nextInt(drops.size()));
        if (pick != null && !pick.getType().isAir()) {
            drops.add(pick.clone());
        }
    }

    // ---------------------------------------------------------------
    //  Рудокоп: руда и дерево
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockDrop(BlockDropItemEvent event) {
        Player player = event.getPlayer();
        Material type = event.getBlockState().getType();
        if (!isMinerBlock(type) || event.getItems().isEmpty()) {
            return;
        }
        int level = level(player, Profession.MINER);
        if (level <= 0) {
            return;
        }
        if (minerXp > 0) {
            plugin.getProfessions().addXp(player, Profession.MINER, minerXp);
        }
        if (random.nextDouble() < level * minerChance) {
            Item source = event.getItems().get(random.nextInt(event.getItems().size()));
            ItemStack extra = source.getItemStack().clone();
            extra.setAmount(1);
            Location where = event.getBlock().getLocation().add(0.5, 0.5, 0.5);
            Bukkit.getScheduler().runTask(plugin, () -> where.getWorld().dropItemNaturally(where, extra));
        }
    }

    // ---------------------------------------------------------------
    //  Кулинар: опыт за готовку и бафы от еды
    // ---------------------------------------------------------------

    @EventHandler(ignoreCancelled = true)
    public void onExtract(FurnaceExtractEvent event) {
        Player player = event.getPlayer();
        if (cookXp <= 0 || level(player, Profession.COOK) <= 0 || !isCookFood(event.getItemType())) {
            return;
        }
        plugin.getProfessions().addXp(player, Profession.COOK, cookXp * Math.max(1, event.getItemAmount()));
    }

    @EventHandler(ignoreCancelled = true)
    public void onEat(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        Material type = event.getItem().getType();
        if (type == Material.POTION) {
            alchemistDrink(player, event.getItem());
            return;
        }
        if (!isCookFood(type)) {
            return;
        }
        int level = level(player, Profession.COOK);
        if (level <= 0) {
            return;
        }
        applyFoodBuff(player, level, 1.0);
        Party group = plugin.getParties().group(player.getUniqueId());
        if (group == null) {
            return;
        }
        for (UUID id : group.members()) {
            Player ally = Bukkit.getPlayer(id);
            if (ally != null && !ally.equals(player)
                    && ally.getWorld().equals(player.getWorld())
                    && ally.getLocation().distanceSquared(player.getLocation()) <= cookRadius * cookRadius) {
                applyFoodBuff(ally, level, 0.5);
            }
        }
    }

    private void applyFoodBuff(Player target, int level, double factor) {
        int regen = (int) Math.round((regenBase + regenPerLevel * level) * 20 * factor);
        int absorb = (int) Math.round((absorbBase + absorbPerLevel * level) * 20 * factor);
        int absorbAmp = Math.max(0, (level - 1) / absorbLevelPer);
        target.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, regen, 0, false, true, true));
        target.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, absorb, absorbAmp, false, true, true));
    }

    // ---------------------------------------------------------------
    //  Алхимик: зелья дольше и опыт за новые зелья из стойки
    // ---------------------------------------------------------------

    private void alchemistDrink(Player player, ItemStack potion) {
        int level = level(player, Profession.ALCHEMIST);
        if (level <= 0 || alchemistBonus <= 0 || !(potion.getItemMeta() instanceof PotionMeta meta)) {
            return;
        }
        List<PotionEffect> effects = new ArrayList<>();
        PotionType base = meta.getBasePotionType();
        if (base != null) {
            effects.addAll(base.getPotionEffects());
        }
        effects.addAll(meta.getCustomEffects());
        double factor = level * alchemistBonus;
        if (effects.isEmpty()) {
            return;
        }
        Bukkit.getScheduler().runTask(plugin, () -> {
            for (PotionEffect effect : effects) {
                if (effect.getType().isInstant()) {
                    continue;
                }
                int extra = (int) Math.round(effect.getDuration() * (1.0 + factor));
                player.addPotionEffect(new PotionEffect(effect.getType(), extra, effect.getAmplifier(),
                        effect.isAmbient(), effect.hasParticles(), effect.hasIcon()));
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onBrewTake(InventoryClickEvent event) {
        if (alchemistXp <= 0 || event.getClickedInventory() == null
                || event.getClickedInventory().getType() != InventoryType.BREWING
                || event.getSlot() > 2 || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType().isAir() || level(player, Profession.ALCHEMIST) <= 0) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null || meta.getPersistentDataContainer().has(potionMark, PersistentDataType.BYTE)) {
            return;
        }
        meta.getPersistentDataContainer().set(potionMark, PersistentDataType.BYTE, (byte) 1);
        // Модель зелья из ресурспака (potion_hp_1, potion_mana_2, potion_cure_3).
        ru.adventurers.core.hud.PackItems.potion(meta);
        item.setItemMeta(meta);
        plugin.getProfessions().addXp(player, Profession.ALCHEMIST, alchemistXp);
    }
}
