package ru.adventurers.core.profile;

import java.util.Locale;

/**
 * Пол персонажа: выбор при первом входе, влияет ТОЛЬКО на внешность.
 *
 * <p>Разделение чисто косметическое (решение по балансу из раздела 17 отчёта): одинаковый ранг,
 * одинаковые характеристики, различаются модель предмета и слой брони на игроке. Поэтому пол
 * нельзя использовать как «второй класс» и нельзя им что-то выиграть.
 *
 * <p>UNSET - состояние до выбора: игрок ещё не проходил меню. Профиль с UNSET не пускают в игру
 * (gender.required в gender.yml), чтобы выбор был обязательным, но не блокировал вход навсегда,
 * если админ отключит требование.
 */
public enum Gender {
    UNSET("unset", "&8не выбран", ""),
    MALE("male", "&bМужской", "male"),
    FEMALE("female", "&dЖенский", "female");

    private final String id;
    private final String displayName;
    /** Часть имени модели: armor_<род>_<класс>_<ранг>_<часть>; пусто у UNSET (общие модели). */
    private final String modelPart;

    Gender(String id, String displayName, String modelPart) {
        this.id = id;
        this.displayName = displayName;
        this.modelPart = modelPart;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String modelPart() {
        return modelPart;
    }

    public boolean isChosen() {
        return this != UNSET;
    }

    public Gender other() {
        return this == MALE ? FEMALE : MALE;
    }

    /** Из базы или команды: male/male/m/м/мужской -> MALE; пусто и неизвестное -> UNSET. */
    public static Gender fromInput(String input) {
        if (input == null) {
            return UNSET;
        }
        String value = input.trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "male", "m", "man", "м", "муж", "мужской", "мужчина" -> MALE;
            case "female", "f", "woman", "ж", "жен", "женский", "женщина" -> FEMALE;
            default -> UNSET;
        };
    }

    /** Строгое чтение для команды: null - не распознано (чтобы не молчать об опечатке). */
    public static Gender parse(String input) {
        Gender gender = fromInput(input);
        return gender.isChosen() ? gender : null;
    }
}
