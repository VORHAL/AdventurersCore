
package ru.adventurers.core.profile;

import java.util.UUID;

public class PlayerProfile {

    private final UUID uuid;
    private String username;
    private Rank rank;
    /** Пол персонажа: выбор при первом входе, влияет только на внешность (см. Gender). */
    private Gender gender;

    public PlayerProfile(UUID uuid, String username, Rank rank) {
        this(uuid, username, rank, Gender.UNSET);
    }

    public PlayerProfile(UUID uuid, String username, Rank rank, Gender gender) {
        this.uuid = uuid;
        this.username = username;
        this.rank = rank;
        this.gender = gender == null ? Gender.UNSET : gender;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Rank getRank() {
        return rank;
    }

    public void setRank(Rank rank) {
        this.rank = rank;
    }

    public Gender getGender() {
        return gender == null ? Gender.UNSET : gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender == null ? Gender.UNSET : gender;
    }

    /** Пол выбран - игрок прошёл меню и может играть. */
    public boolean hasGender() {
        return gender != null && gender.isChosen();
    }
}
