package ru.adventurers.core.quest;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Защита заданий от накрутки: мобы из спавнеров/яиц/разведения/големы не считаются,
 * убийства в творческом режиме не считаются, слишком частые убийства в одном месте
 * (мобофермы) не засчитываются. Настройки: раздел anti-farm в quests.yml. Основной поток.
 */
public class QuestGuard {

    private record Kill(long time, String world, double x, double y, double z) {
    }

    private static final long WARNING_COOLDOWN_MS = 15_000L;

    private final AdventurersCore plugin;
    private final NamespacedKey markKey;
    private final Map<UUID, Deque<Kill>> recent = new HashMap<>();
    private final Map<UUID, Long> lastWarning = new HashMap<>();

    private boolean enabled = true;
    private boolean survivalOnly = true;
    private final Set<CreatureSpawnEvent.SpawnReason> blockedReasons = new HashSet<>();
    private long windowMs = 120_000L;
    private double radiusSquared = 100.0;
    private int maxKills = 30;

    public QuestGuard(AdventurersCore plugin) {
        this.plugin = plugin;
        this.markKey = new NamespacedKey(plugin, "no_quest");
    }

    public void reload() {
        File file = plugin.getFiles().file("quests.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("anti-farm.enabled", true);
        survivalOnly = cfg.getBoolean("anti-farm.survival-only", true);
        windowMs = Math.max(10, cfg.getInt("anti-farm.window-seconds", 120)) * 1000L;
        double radius = Math.max(2, cfg.getDouble("anti-farm.radius", 10.0));
        radiusSquared = radius * radius;
        maxKills = Math.max(1, cfg.getInt("anti-farm.max-kills", 30));

        blockedReasons.clear();
        List<String> names = cfg.contains("anti-farm.blocked-spawn-reasons")
                ? cfg.getStringList("anti-farm.blocked-spawn-reasons")
                : new ArrayList<>(List.of("SPAWNER", "SPAWNER_EGG", "DISPENSE_EGG", "EGG", "BREEDING",
                        "BUILD_IRONGOLEM", "BUILD_SNOWMAN", "BUILD_WITHER"));
        for (String name : names) {
            try {
                blockedReasons.add(CreatureSpawnEvent.SpawnReason.valueOf(name.trim().toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException exception) {
                plugin.getLogger().warning("quests.yml, anti-farm: неизвестная причина спавна " + name);
            }
        }
    }

    /** Помечает существо, которое не должно давать прогресс. */
    public void onSpawn(Entity entity, CreatureSpawnEvent.SpawnReason reason) {
        if (enabled && blockedReasons.contains(reason)) {
            entity.getPersistentDataContainer().set(markKey, PersistentDataType.BYTE, (byte) 1);
        }
    }

    /** true, если существо помечено как «не засчитывать» (спавнер, яйцо, разведение, голем). */
    public boolean isMarked(Entity entity) {
        return enabled && entity.getPersistentDataContainer().has(markKey, PersistentDataType.BYTE);
    }

    /** true, если убийство можно засчитать. Вызывать один раз на убийство, для убийцы. */
    public boolean allow(Player killer, Entity victim) {
        if (!enabled) {
            return true;
        }
        if (survivalOnly && killer.getGameMode() != GameMode.SURVIVAL && killer.getGameMode() != GameMode.ADVENTURE) {
            return false;
        }
        if (victim.getPersistentDataContainer().has(markKey, PersistentDataType.BYTE)) {
            return false;
        }

        long now = System.currentTimeMillis();
        Location at = victim.getLocation();
        Deque<Kill> queue = recent.computeIfAbsent(killer.getUniqueId(), id -> new ArrayDeque<>());
        while (!queue.isEmpty() && now - queue.peekFirst().time() > windowMs) {
            queue.pollFirst();
        }
        String world = at.getWorld() != null ? at.getWorld().getName() : "";
        int nearby = 0;
        for (Kill kill : queue) {
            if (kill.world().equals(world)) {
                double dx = kill.x() - at.getX();
                double dy = kill.y() - at.getY();
                double dz = kill.z() - at.getZ();
                if (dx * dx + dy * dy + dz * dz <= radiusSquared) {
                    nearby++;
                }
            }
        }
        if (nearby >= maxKills) {
            warn(killer, now);
            return false;
        }
        queue.addLast(new Kill(now, world, at.getX(), at.getY(), at.getZ()));
        return true;
    }

    private void warn(Player player, long now) {
        Long last = lastWarning.get(player.getUniqueId());
        if (last != null && now - last < WARNING_COOLDOWN_MS) {
            return;
        }
        lastWarning.put(player.getUniqueId(), now);
        plugin.getMessages().send(player, "quests.antifarm");
    }

    public void forget(UUID uuid) {
        recent.remove(uuid);
        lastWarning.remove(uuid);
    }
}
