package ru.adventurers.core.quest;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profession.Profession;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Доска заданий: ежедневные предложения по рангу, лимит принятых заданий в день, награды. */
public class QuestManager {

    public enum AcceptResult { OK, NO_SLOT, ALREADY_ACTIVE, DONE_TODAY, DAILY_LIMIT, TOO_MANY_ACTIVE, NOT_LOADED }

    public enum TurnInResult { OK, NO_SLOT, NOT_ACTIVE, NOT_READY, NOT_LOADED }

    /** Сколько заданий предлагается в день. */
    public static final int OFFERS_PER_DAY = 5;

    private final AdventurersCore plugin;
    private final QuestRepository repository;

    private final Map<String, QuestDef> defs = new LinkedHashMap<>();
    private final Map<UUID, PlayerQuests> cache = new ConcurrentHashMap<>();

    private ZoneId zone = ZoneId.of("Europe/Moscow");
    private int resetHour = 4;
    private int dailyLimit = 5;
    private int maxActive = 3;
    private int rotationDaysAway = 1;
    private int rotationMaxSameType = 3;
    /** Что игрок видел на доске в последние дни: id -> последний день показа. */
    private final Map<UUID, Map<String, Long>> boardHistory = new ConcurrentHashMap<>();
    private volatile long prunedDay = 0;
    private BukkitTask autosaveTask;

    private final QuestGuard guard;

    public QuestGuard getGuard() {
        return guard;
    }

    public QuestManager(AdventurersCore plugin, QuestRepository repository) {
        this.guard = new QuestGuard(plugin);
        this.plugin = plugin;
        this.repository = repository;
    }

    public void init() throws SQLException {
        repository.createTables();
        reload();
        long ticks = 5L * 60L * 20L;
        autosaveTask = Bukkit.getScheduler().runTaskTimer(plugin, this::autosave, ticks, ticks);
    }

    public void reload() {
        File file = plugin.getFiles().file("quests.yml");
        if (!file.exists()) {
            plugin.getFiles().save("quests.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        try {
            zone = ZoneId.of(cfg.getString("timezone", "Europe/Moscow"));
        } catch (Exception exception) {
            plugin.getLogger().warning("quests.yml: неизвестный timezone, взят Europe/Moscow");
            zone = ZoneId.of("Europe/Moscow");
        }
        guard.reload();
        resetHour = Math.max(0, Math.min(23, cfg.getInt("reset-hour", 4)));
        dailyLimit = Math.max(1, cfg.getInt("daily-limit", 5));
        maxActive = Math.max(1, cfg.getInt("max-active", 3));
        rotationDaysAway = Math.max(0, Math.min(7, cfg.getInt("rotation.min-days-away", 1)));
        rotationMaxSameType = Math.max(1, cfg.getInt("rotation.max-same-type",
                Math.max(1, (OFFERS_PER_DAY + 1) / 2)));

        defs.clear();
        for (Map<?, ?> raw : cfg.getMapList("quests")) {
            QuestDef def = parse(raw);
            if (def != null) {
                defs.put(def.id(), def);
            }
        }
        plugin.getLogger().info("Заданий загружено: " + defs.size());
    }

    private QuestDef parse(Map<?, ?> raw) {
        String id = str(raw.get("id"));
        if (id == null) {
            plugin.getLogger().warning("quests.yml: у задания нет id: " + raw);
            return null;
        }
        Rank min = raw.get("rank") != null ? Rank.fromInput(str(raw.get("rank"))) : null;
        if (min == null) {
            plugin.getLogger().warning("quests.yml: " + id + ": неверный rank");
            return null;
        }
        Rank max = raw.get("max-rank") != null ? Rank.fromInput(str(raw.get("max-rank"))) : min;
        if (max == null || !max.isAtLeast(min)) {
            max = min;
        }

        QuestDef.Type type;
        try {
            type = QuestDef.Type.valueOf(String.valueOf(raw.get("type")).toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException exception) {
            plugin.getLogger().warning("quests.yml: " + id + ": type должен быть KILL или DELIVER");
            return null;
        }
        String target = str(raw.get("target"));
        if (target == null) {
            plugin.getLogger().warning("quests.yml: " + id + ": нет target");
            return null;
        }
        target = target.toUpperCase(Locale.ROOT);
        if (type == QuestDef.Type.DELIVER && Material.matchMaterial(target) == null) {
            plugin.getLogger().warning("quests.yml: " + id + ": неизвестный материал " + target);
            return null;
        }

        List<String> story = new ArrayList<>();
        if (raw.get("story") instanceof List<?> list) {
            for (Object line : list) {
                story.add(String.valueOf(line));
            }
        }

        Map<Profession, Integer> professionXp = new EnumMap<>(Profession.class);
        if (raw.get("profession-xp") instanceof Map<?, ?> map) {
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                Profession profession = Profession.fromInput(String.valueOf(entry.getKey()));
                if (profession != null && entry.getValue() instanceof Number number) {
                    professionXp.put(profession, number.intValue());
                }
            }
        }

        List<QuestDef.ItemReward> items = new ArrayList<>();
        if (raw.get("items") instanceof List<?> list) {
            for (Object entry : list) {
                if (entry instanceof Map<?, ?> map && map.get("material") != null
                        && Material.matchMaterial(str(map.get("material"))) != null) {
                    int amount = map.get("amount") instanceof Number n ? Math.max(1, n.intValue()) : 1;
                    items.add(new QuestDef.ItemReward(str(map.get("material")).toUpperCase(Locale.ROOT),
                            amount, str(map.get("name"))));
                }
            }
        }

        List<String> commands = new ArrayList<>();
        if (raw.get("commands") instanceof List<?> list) {
            for (Object line : list) {
                commands.add(String.valueOf(line));
            }
        }

        int amount = raw.get("amount") instanceof Number n ? Math.max(1, n.intValue()) : 1;
        int points = raw.get("points") instanceof Number n ? Math.max(0, n.intValue()) : 0;
        boolean repeatable = Boolean.TRUE.equals(raw.get("repeatable"));
        String title = str(raw.get("title"));

        return new QuestDef(id, min, max, title != null ? title : id, story, type, target,
                amount, points, professionXp, items, commands, repeatable);
    }

    private static String str(Object value) {
        return value == null ? null : String.valueOf(value);
    }

    public void shutdown() {
        if (autosaveTask != null) {
            autosaveTask.cancel();
            autosaveTask = null;
        }
        for (Map.Entry<UUID, PlayerQuests> entry : cache.entrySet()) {
            try {
                repository.save(entry.getKey(), entry.getValue());
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not save quests for " + entry.getKey());
                exception.printStackTrace();
            }
        }
        cache.clear();
    }

    // ---------------------------------------------------------------
    //  Загрузка и сохранение
    // ---------------------------------------------------------------

    public void load(Player player) {
        UUID uuid = player.getUniqueId();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            PlayerQuests data;
            Map<String, Long> history = new java.util.HashMap<>();
            try {
                data = repository.load(uuid);
                // История доски: столько дней назад, сколько нужно ротации (с запасом).
                history = repository.loadBoard(uuid, today() - Math.max(1, rotationDaysAway) - 1);
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not load quests for " + player.getName());
                exception.printStackTrace();
                return;
            }
            Map<String, Long> seen = history;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (player.isOnline()) {
                    cache.put(uuid, data);
                    boardHistory.put(uuid, seen);
                }
            });
        });
    }

    public void unload(UUID uuid) {
        guard.forget(uuid);
        boardHistory.remove(uuid);
        PlayerQuests data = cache.remove(uuid);
        if (data != null) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveNow(uuid, data));
        }
    }

    private void autosave() {
        for (UUID uuid : cache.keySet()) {
            saveAsync(uuid);
        }
    }

    private void saveAsync(UUID uuid) {
        PlayerQuests data = cache.get(uuid);
        if (data == null) {
            return;
        }
        PlayerQuests snapshot = data.copy();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> saveNow(uuid, snapshot));
    }

    private void saveNow(UUID uuid, PlayerQuests data) {
        try {
            repository.save(uuid, data);
        } catch (SQLException exception) {
            plugin.getLogger().severe("Could not save quests for " + uuid);
            exception.printStackTrace();
        }
    }

    public PlayerQuests get(UUID uuid) {
        return cache.get(uuid);
    }

    // ---------------------------------------------------------------
    //  Доска
    // ---------------------------------------------------------------

    private long today() {
        return LocalDateTime.now(zone).minusHours(resetHour).toLocalDate().toEpochDay();
    }

    private Rank rankOf(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        return profile != null ? profile.getRank() : Rank.F;
    }

    /**
     * Что видит игрок: до 5 заданий дня (одни и те же в течение суток),
     * затем принятые раньше и ещё не сданные. Порядок стабилен.
     */
    /** Задания, которые нельзя показывать сегодня: всё, что было на доске в прошлые дни. */
    private Set<String> recentIds(UUID uuid, long day) {
        Map<String, Long> history = boardHistory.get(uuid);
        if (history == null || history.isEmpty() || rotationDaysAway <= 0) {
            return Set.of();
        }
        long from = day - rotationDaysAway;
        Set<String> recent = new java.util.HashSet<>();
        for (Map.Entry<String, Long> entry : history.entrySet()) {
            if (entry.getValue() != null && entry.getValue() >= from && entry.getValue() < day) {
                recent.add(entry.getKey());
            }
        }
        return recent;
    }

    /** Запоминает показанную доску, чтобы завтра эти задания не выпали снова. */
    private void rememberBoard(UUID uuid, long day, List<QuestDef> board) {
        Map<String, Long> history = boardHistory.computeIfAbsent(uuid, id -> new java.util.concurrent.ConcurrentHashMap<>());
        boolean changed = false;
        for (QuestDef def : board) {
            Long seen = history.get(def.id());
            if (seen == null || seen < day) {
                history.put(def.id(), day);
                changed = true;
            }
        }
        if (changed) {
            List<String> ids = new ArrayList<>();
            for (QuestDef def : board) {
                ids.add(def.id());
            }
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    repository.saveBoard(uuid, day, ids);
                    pruneHistory(day);
                } catch (SQLException exception) {
                    plugin.getLogger().warning("Не удалось сохранить доску заданий для " + uuid);
                }
            });
        }
    }

    /** Раз в сутки чистим историю старше двух недель. */
    private void pruneHistory(long day) {
        if (prunedDay >= day) {
            return;
        }
        prunedDay = day;
        try {
            repository.pruneBoard(day - 14);
        } catch (SQLException exception) {
            plugin.getLogger().warning("Не удалось почистить историю доски: " + exception.getMessage());
        }
    }

    public List<QuestDef> board(Player player) {
        PlayerQuests data = cache.get(player.getUniqueId());
        if (data == null) {
            return List.of();
        }
        Rank rank = rankOf(player);
        long day = today();

        List<QuestDef> pool = new ArrayList<>();
        for (QuestDef def : defs.values()) {
            if (!def.availableFor(rank)) {
                continue;
            }
            PlayerQuests.Entry entry = data.get(def.id());
            boolean doneBefore = entry != null && entry.state == PlayerQuests.State.DONE
                    && entry.completedDay < day;
            if (doneBefore && !def.repeatable()) {
                continue; // разовое задание уже выполнено
            }
            pool.add(def);
        }
        // Правила ротации: уникальные цели, никаких вчерашних заданий, лимит по типам.
        List<QuestDef> result = QuestRotation.pick(pool, OFFERS_PER_DAY,
                player.getUniqueId().hashCode() * 31L + day * 1_000_003L + rank.ordinal(),
                rotationDaysAway, rotationMaxSameType, recentIds(player.getUniqueId(), day));
        rememberBoard(player.getUniqueId(), day, result);
        for (QuestDef def : defs.values()) {
            PlayerQuests.Entry entry = data.get(def.id());
            if (entry != null && entry.state == PlayerQuests.State.ACTIVE && !result.contains(def)) {
                result.add(def);
            }
        }
        return result;
    }

    public QuestDef slot(Player player, int slot) {
        List<QuestDef> board = board(player);
        return slot >= 1 && slot <= board.size() ? board.get(slot - 1) : null;
    }

    private int acceptedToday(PlayerQuests data) {
        long day = today();
        int count = 0;
        for (PlayerQuests.Entry entry : data.entries().values()) {
            if (entry.acceptedDay == day) {
                count++;
            }
        }
        return count;
    }

    private int activeCount(PlayerQuests data) {
        int count = 0;
        for (PlayerQuests.Entry entry : data.entries().values()) {
            if (entry.state == PlayerQuests.State.ACTIVE) {
                count++;
            }
        }
        return count;
    }

    public int dailyLeft(Player player) {
        PlayerQuests data = cache.get(player.getUniqueId());
        return data == null ? 0 : Math.max(0, dailyLimit - acceptedToday(data));
    }

    public int getDailyLimit() {
        return dailyLimit;
    }

    public int getMaxActive() {
        return maxActive;
    }

    public int activeCount(Player player) {
        PlayerQuests data = cache.get(player.getUniqueId());
        return data == null ? 0 : activeCount(data);
    }

    public int completed(UUID uuid) {
        PlayerQuests data = cache.get(uuid);
        return data == null ? 0 : data.getCompleted();
    }

    public int points(UUID uuid) {
        PlayerQuests data = cache.get(uuid);
        return data == null ? 0 : data.getPoints();
    }

    /** Прогресс для показа: KILL - счётчик, DELIVER - сколько предметов сейчас в сумке. */
    public int progress(Player player, QuestDef def) {
        PlayerQuests data = cache.get(player.getUniqueId());
        PlayerQuests.Entry entry = data != null ? data.get(def.id()) : null;
        if (entry == null || entry.state != PlayerQuests.State.ACTIVE) {
            return 0;
        }
        int value = def.type() == QuestDef.Type.KILL ? entry.progress : countItems(player, def);
        return Math.min(def.amount(), value);
    }

    /**
     * Состояние для меню: available, limited, active, ready, done, empty.
     * limited: нельзя принять (дневной лимит или слишком много активных).
     */
    public String state(Player player, int slot) {
        PlayerQuests data = cache.get(player.getUniqueId());
        QuestDef def = slot(player, slot);
        if (data == null || def == null) {
            return "empty";
        }
        PlayerQuests.Entry entry = data.get(def.id());
        long day = today();
        if (entry != null && entry.state == PlayerQuests.State.ACTIVE) {
            return progress(player, def) >= def.amount() ? "ready" : "active";
        }
        if (entry != null && entry.state == PlayerQuests.State.DONE && entry.completedDay == day) {
            return "done";
        }
        if (acceptedToday(data) >= dailyLimit || activeCount(data) >= maxActive) {
            return "limited";
        }
        return "available";
    }

    private int countItems(Player player, QuestDef def) {
        Material material = Material.matchMaterial(def.target());
        if (material == null) {
            return 0;
        }
        int total = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() == material && !plugin.getSurvival().isRankGear(item)) {
                total += item.getAmount();
            }
        }
        return total;
    }

    // ---------------------------------------------------------------
    //  Действия
    // ---------------------------------------------------------------

    public AcceptResult accept(Player player, int slot) {
        PlayerQuests data = cache.get(player.getUniqueId());
        if (data == null) {
            return AcceptResult.NOT_LOADED;
        }
        QuestDef def = slot(player, slot);
        if (def == null) {
            return AcceptResult.NO_SLOT;
        }
        PlayerQuests.Entry existing = data.get(def.id());
        long day = today();
        if (existing != null && existing.state == PlayerQuests.State.ACTIVE) {
            return AcceptResult.ALREADY_ACTIVE;
        }
        if (existing != null && existing.state == PlayerQuests.State.DONE && existing.completedDay == day) {
            return AcceptResult.DONE_TODAY;
        }
        if (acceptedToday(data) >= dailyLimit) {
            return AcceptResult.DAILY_LIMIT;
        }
        if (activeCount(data) >= maxActive) {
            return AcceptResult.TOO_MANY_ACTIVE;
        }

        PlayerQuests.Entry entry = new PlayerQuests.Entry();
        entry.state = PlayerQuests.State.ACTIVE;
        entry.progress = 0;
        entry.acceptedDay = day;
        data.entries().put(def.id(), entry);
        saveAsync(player.getUniqueId());
        // цепочка первых шагов (раздел 24): взял первое задание
        if (plugin.getOnboarding() != null) {
            plugin.getOnboarding().complete(player, "quest-taken");
        }
        return AcceptResult.OK;
    }

    /** Отказ от активного задания. Дневной лимит при этом не возвращается. */
    public boolean abandon(Player player, int slot) {
        PlayerQuests data = cache.get(player.getUniqueId());
        QuestDef def = slot(player, slot);
        if (data == null || def == null) {
            return false;
        }
        PlayerQuests.Entry entry = data.get(def.id());
        if (entry == null || entry.state != PlayerQuests.State.ACTIVE) {
            return false;
        }
        // Запись остаётся с acceptedDay: дневной лимит отказом не обойти.
        entry.state = PlayerQuests.State.ABANDONED;
        entry.progress = 0;
        saveAsync(player.getUniqueId());
        return true;
    }

    public TurnInResult turnIn(Player player, int slot) {
        PlayerQuests data = cache.get(player.getUniqueId());
        if (data == null) {
            return TurnInResult.NOT_LOADED;
        }
        QuestDef def = slot(player, slot);
        if (def == null) {
            return TurnInResult.NO_SLOT;
        }
        PlayerQuests.Entry entry = data.get(def.id());
        if (entry == null || entry.state != PlayerQuests.State.ACTIVE) {
            return TurnInResult.NOT_ACTIVE;
        }
        if (progress(player, def) < def.amount()) {
            return TurnInResult.NOT_READY;
        }
        if (def.type() == QuestDef.Type.DELIVER) {
            removeItems(player, def);
        }

        entry.state = PlayerQuests.State.DONE;
        entry.completedDay = today();
        entry.progress = def.amount();
        data.setPoints(data.getPoints() + def.points());
        data.setCompleted(data.getCompleted() + 1);
        giveRewards(player, def);
        if (plugin.getEconomy() != null) {
            plugin.getEconomy().reward(player, plugin.getEconomy().questCoins(def.id(), def.points()), "economy.reward-quest");
        }
        saveAsync(player.getUniqueId());
        if (plugin.getCovenants() != null) {
            plugin.getCovenants().getWeekly().questDone(player);
        }
        if (plugin.getGlory() != null) {
            plugin.getGlory().add(player, "QUESTS", 1);
        }
        if (plugin.getContracts() != null) {
            plugin.getContracts().progress(player, "QUEST", "ANY", 1);
        }
        if (plugin.getPets() != null) {
            plugin.getPets().onQuest(player);
        }
        // цепочка первых шагов (раздел 24): сдал первое задание
        if (plugin.getOnboarding() != null) {
            plugin.getOnboarding().complete(player, "quest-completed");
        }
        return TurnInResult.OK;
    }

    private void removeItems(Player player, QuestDef def) {
        Material material = Material.matchMaterial(def.target());
        int left = def.amount();
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType() != material || plugin.getSurvival().isRankGear(item)) {
                continue;
            }
            int take = Math.min(left, item.getAmount());
            left -= take;
            if (take == item.getAmount()) {
                player.getInventory().setItem(i, null);
            } else {
                item.setAmount(item.getAmount() - take);
            }
        }
    }

    private void giveRewards(Player player, QuestDef def) {
        for (Map.Entry<Profession, Integer> entry : def.professionXp().entrySet()) {
            plugin.getProfessions().addXp(player, entry.getKey(), entry.getValue());
        }
        for (QuestDef.ItemReward reward : def.items()) {
            Material material = Material.matchMaterial(reward.material());
            if (material == null) {
                continue;
            }
            ItemStack stack = new ItemStack(material, reward.amount());
            if (reward.name() != null) {
                var meta = stack.getItemMeta();
                if (meta != null) {
                    meta.displayName(Hud.legacy(reward.name())
                            .decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
                    stack.setItemMeta(meta);
                }
            }
            for (ItemStack extra : player.getInventory().addItem(stack).values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), extra);
            }
        }
        for (String command : def.commands()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command.replace("{player}", player.getName()));
        }
    }

    /** Убийство монстра: двигает прогресс активных заданий на убийство. */
    public void onKill(Player player, String entityType) {
        PlayerQuests data = cache.get(player.getUniqueId());
        if (data == null) {
            return;
        }
        boolean changed = false;
        for (Map.Entry<String, PlayerQuests.Entry> entry : data.entries().entrySet()) {
            QuestDef def = defs.get(entry.getKey());
            PlayerQuests.Entry progress = entry.getValue();
            if (def == null || def.type() != QuestDef.Type.KILL
                    || progress.state != PlayerQuests.State.ACTIVE
                    || progress.progress >= def.amount()) {
                continue;
            }
            if (!def.target().equals("ANY") && !def.target().equals(entityType)) {
                continue;
            }
            progress.progress++;
            changed = true;
            notifyProgress(player, def, progress.progress);
        }
        if (changed) {
            saveAsync(player.getUniqueId());
        }
    }

    private void notifyProgress(Player player, QuestDef def, int value) {
        if (value >= def.amount()) {
            plugin.getMessages().send(player, "quests.ready", Map.of("title", def.title()));
            return;
        }
        String text = plugin.getMessages().text("quests.progress-bar", "&7{title}: &f{progress}&8/&f{goal}")
                .replace("{title}", def.title())
                .replace("{progress}", String.valueOf(value))
                .replace("{goal}", String.valueOf(def.amount()));
        Component bar = Hud.legacy(text);
        plugin.getSkillHud().flash(player, bar);
    }

    // ---------------------------------------------------------------
    //  Тексты для меню и плейсхолдеров
    // ---------------------------------------------------------------

    public String goalText(QuestDef def) {
        String what = def.target().equals("ANY") ? "монстров"
                : plugin.getMessages().text("quests.targets." + def.target().toLowerCase(Locale.ROOT),
                        def.target().toLowerCase(Locale.ROOT).replace('_', ' '));
        return (def.type() == QuestDef.Type.KILL ? "Убить: " : "Принести: ") + def.amount() + " " + what;
    }

    public String rewardText(QuestDef def) {
        List<String> parts = new ArrayList<>();
        if (def.points() > 0) {
            parts.add("&6" + def.points() + " оч. гильдии");
        }
        if (plugin.getEconomy() != null && plugin.getEconomy().questCoins(def.id(), def.points()) > 0) {
            parts.add(plugin.getEconomy().format(plugin.getEconomy().questCoins(def.id(), def.points())) + " &7монет");
        }
        for (Map.Entry<Profession, Integer> entry : def.professionXp().entrySet()) {
            parts.add(plugin.getProfessions().displayName(entry.getKey()) + " &f+" + entry.getValue());
        }
        for (QuestDef.ItemReward reward : def.items()) {
            parts.add("&f" + reward.amount() + "× " + (reward.name() != null ? reward.name()
                    : reward.material().toLowerCase(Locale.ROOT).replace('_', ' ')));
        }
        return parts.isEmpty() ? "&8—" : String.join("&7, ", parts);
    }

    // ---------------------------------------------------------------
    //  Админ
    // ---------------------------------------------------------------

    public boolean adminReset(Player player) {
        PlayerQuests data = cache.get(player.getUniqueId());
        if (data == null) {
            return false;
        }
        data.entries().clear();
        PlayerQuests snapshot = data.copy();
        UUID uuid = player.getUniqueId();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                repository.deleteQuests(uuid);
                repository.save(uuid, snapshot);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });
        return true;
    }

    public boolean adminAddPoints(Player player, int delta) {
        PlayerQuests data = cache.get(player.getUniqueId());
        if (data == null) {
            return false;
        }
        data.setPoints(data.getPoints() + delta);
        saveAsync(player.getUniqueId());
        return true;
    }
}
