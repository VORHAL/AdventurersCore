package ru.adventurers.core.quest;

import ru.adventurers.core.profile.Rank;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Выбор заданий на день. Отдельный класс, чтобы правила ротации можно было
 * проверить тестом без запуска сервера.
 *
 * <p>Правила (задают, насколько дни не похожи друг на друга):
 * <ol>
 *   <li>в один день не бывает двух заданий с одинаковой целью (KILL + существо,
 *       DELIVER + материал) и двух ANY;</li>
 *   <li>задание, стоявшее на доске последние {@code minDaysAway} дней, не показывается,
 *       пока в пуле ранга есть другие варианты (обычно 1 день - значит вчерашнее
 *       сегодня не выпадет);</li>
 *   <li>в дне не больше {@code maxSameType} заданий одного типа (KILL/DELIVER),
 *       чтобы не выпадало «пять убийств» или «пять поставок» подряд;</li>
 *   <li>порядок на доске стабилен в течение дня (одинаков для всех входов игрока).</li>
 * </ol>
 *
 * <p>Если в пуле ранга мало заданий, ограничения ослабляются по порядку
 * (сначала типы, потом «вчерашние», в конце - только уникальность), и доска
 * всё равно заполняется до нужного размера.
 */
public final class QuestRotation {

    private QuestRotation() {
    }

    /**
     * @param pool        все задания, доступные игроку на этом ранге
     * @param offers      сколько заданий нужно показать
     * @param seed        стабильное зерно (ник/ранг/день) - порядок не «прыгает»
     * @param minDaysAway сколько дней задание не должно повторяться
     * @param maxSameType максимум заданий одного типа в дне
     * @param recent      id заданий, которые были на доске в последние дни
     */
    public static List<QuestDef> pick(Collection<QuestDef> pool, int offers, long seed, int minDaysAway,
                                      int maxSameType, Set<String> recent) {
        List<QuestDef> all = new ArrayList<>(pool);
        // Стабильный порядок до перемешивания: конфиг может меняться между перезапусками.
        all.sort(Comparator.comparing(QuestDef::id));
        Collections.shuffle(all, new Random(seed));

        Set<String> recentIds = recent == null ? Set.of() : recent;
        List<QuestDef> result = new ArrayList<>();
        Set<String> keys = new HashSet<>();
        Map<QuestDef.Type, Integer> types = new HashMap<>();

        // Проход 1: свежие задания, уникальные цели, с лимитом по типам.
        // Проход 2: разрешаем повторы цели (пул слишком маленький).
        // Проход 3: добираем вчерашние задания, чтобы доска не была пустой.
        for (int pass = 0; pass < 3 && result.size() < offers; pass++) {
            for (QuestDef def : all) {
                if (result.size() >= offers) {
                    break;
                }
                if (result.contains(def)) {
                    continue;
                }
                boolean fresh = pass > 1 || !recentIds.contains(def.id());
                if (!fresh) {
                    continue;
                }
                if (pass < 1 && keys.contains(goalKey(def))) {
                    continue;
                }
                int used = types.getOrDefault(def.type(), 0);
                if (pass < 1 && maxSameType > 0 && used >= maxSameType) {
                    continue;
                }
                result.add(def);
                keys.add(goalKey(def));
                types.merge(def.type(), 1, Integer::sum);
            }
            // После второго прохода ограничения по целям сняты, но типы всё ещё держим.
            if (pass == 1) {
                types.clear();
            }
        }
        // Возвращаем «дневной» порядок: как задания лежали в перемешанном пуле.
        List<QuestDef> ordered = new ArrayList<>();
        for (QuestDef def : all) {
            if (result.contains(def)) {
                ordered.add(def);
            }
        }
        return ordered;
    }

    /** Цель задания: для выбора на день одинаковые цели считаются повтором. */
    public static String goalKey(QuestDef def) {
        return def.type() + ":" + def.target().toUpperCase(java.util.Locale.ROOT);
    }

    /**
     * Ключ дня для сохранения истории: сколько заданий ранга вообще есть.
     * Нужен, чтобы понимать, насколько жёстко можно применять правила.
     */
    public static int poolSizeFor(Collection<QuestDef> pool, Rank rank) {
        int count = 0;
        for (QuestDef def : pool) {
            if (def.availableFor(rank)) {
                count++;
            }
        }
        return count;
    }

    /** Удобно для логов и тестов: «id → ключ цели». */
    public static Map<String, String> goalKeys(Collection<QuestDef> pool) {
        Map<String, String> map = new LinkedHashMap<>();
        for (QuestDef def : pool) {
            map.put(def.id(), goalKey(def));
        }
        return map;
    }
}
