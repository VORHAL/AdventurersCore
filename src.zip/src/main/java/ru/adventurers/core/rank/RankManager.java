package ru.adventurers.core.rank;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClasses;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profession.PlayerProfessions;
import ru.adventurers.core.profession.Profession;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.io.File;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Повышение ранга: условия (ranks.yml), проверка и выдача нового ранга. */
public class RankManager {

    /**
     * Условия перехода с ранга на следующий.
     *
     * @param points          очки гильдии (задания, контракты, подземелья)
     * @param quests          сдано заданий
     * @param professionLevel уровень лучшей профессии
     * @param minDays         дней на текущем ранге
     * @param needsClass      выбран класс
     * @param dungeons        пройдено подземелий всего (статистика DUNGEONS)
     * @param heroics         пройдено героических подземелий (HEROICS)
     * @param raids           пройдено рейдов (RAIDS)
     * @param gear            нужен выданный комплект текущего ранга (/ag gear)
     * @param fee             взнос монетами при повышении (0 - без взноса)
     * @param coinsPerDay     сколько монет игрок реально может отложить за день (подсказка в /ag rank)
     */
    public record Requirement(int points, int quests, int professionLevel, int minDays, boolean needsClass,
                              int dungeons, int heroics, int raids, boolean gear, long fee, long coinsPerDay) {
    }

    /** Одно условие: id (points, quests, profession, days, class), сколько есть, сколько нужно. */
    public record Status(String id, int current, int needed, boolean ok) {
    }

    public enum PromoteResult { OK, MAX_RANK, REQUIREMENTS, NO_COINS, NOT_LOADED }

    private final AdventurersCore plugin;
    private final RankRepository repository;
    private final Map<UUID, Instant> since = new ConcurrentHashMap<>();
    private final Map<Rank, Requirement> requirements = new EnumMap<>(Rank.class);

    private boolean selfPromote;
    private boolean announce;

    public RankManager(AdventurersCore plugin, RankRepository repository) {
        this.plugin = plugin;
        this.repository = repository;
    }

    public void init() throws SQLException {
        repository.createTable();
        reload();
    }

    public void reload() {
        File file = plugin.getFiles().file("ranks.yml");
        if (!file.exists()) {
            plugin.getFiles().save("ranks.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        selfPromote = cfg.getBoolean("self-promote", false);
        announce = cfg.getBoolean("announce", true);

        requirements.clear();
        for (Rank rank : Rank.values()) {
            ConfigurationSection section = cfg.getConfigurationSection("promotions." + rank.getDisplayName());
            if (section == null) {
                continue;
            }
            requirements.put(rank, new Requirement(
                    Math.max(0, section.getInt("points", 0)),
                    Math.max(0, section.getInt("quests", 0)),
                    Math.max(0, section.getInt("profession-level", 0)),
                    Math.max(0, section.getInt("min-days", 0)),
                    section.getBoolean("needs-class", false),
                    Math.max(0, section.getInt("dungeons", 0)),
                    Math.max(0, section.getInt("heroics", 0)),
                    Math.max(0, section.getInt("raids", 0)),
                    section.getBoolean("needs-gear", false),
                    Math.max(0, section.getLong("fee", 0)),
                    Math.max(0, section.getLong("coins-per-day", 0))));
        }
    }

    public boolean isSelfPromote() {
        return selfPromote;
    }

    // ---------------------------------------------------------------
    //  Загрузка
    // ---------------------------------------------------------------

    public void load(Player player) {
        UUID uuid = player.getUniqueId();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Instant value = repository.loadOrCreate(uuid);
                since.put(uuid, value);
            } catch (SQLException exception) {
                plugin.getLogger().severe("Could not load rank date for " + player.getName());
                exception.printStackTrace();
            }
        });
    }

    public void unload(UUID uuid) {
        since.remove(uuid);
    }

    // ---------------------------------------------------------------
    //  Условия
    // ---------------------------------------------------------------

    public Requirement requirementFor(Rank current) {
        return requirements.get(current);
    }

    public int daysAtRank(UUID uuid) {
        Instant start = since.get(uuid);
        if (start == null) {
            return 0;
        }
        return (int) Math.max(0, Duration.between(start, Instant.now()).toDays());
    }

    /** Условия повышения для текущего ранга игрока. Пусто на максимальном ранге. */
    public List<Status> check(Player player) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) {
            return List.of();
        }
        Requirement requirement = requirements.get(profile.getRank());
        if (profile.getRank().next() == null || requirement == null) {
            return List.of();
        }
        UUID uuid = player.getUniqueId();
        List<Status> result = new ArrayList<>();

        int points = plugin.getQuests().points(uuid);
        result.add(new Status("points", points, requirement.points(), points >= requirement.points()));

        int quests = plugin.getQuests().completed(uuid);
        result.add(new Status("quests", quests, requirement.quests(), quests >= requirement.quests()));

        if (requirement.professionLevel() > 0) {
            int best = 0;
            PlayerProfessions data = plugin.getProfessions().get(uuid);
            if (data != null) {
                for (Profession profession : data.professions()) {
                    PlayerProfessions.Progress progress = data.get(profession);
                    if (progress != null) {
                        best = Math.max(best, progress.getLevel());
                    }
                }
            }
            result.add(new Status("profession", best, requirement.professionLevel(),
                    best >= requirement.professionLevel()));
        }

        if (requirement.minDays() > 0) {
            int days = daysAtRank(uuid);
            result.add(new Status("days", days, requirement.minDays(), days >= requirement.minDays()));
        }

        if (requirement.needsClass()) {
            PlayerClasses classes = plugin.getClasses().get(uuid);
            boolean has = classes != null && classes.count() > 0;
            result.add(new Status("class", has ? 1 : 0, 1, has));
        }

        // Статистика подземелий берётся из «Славы» (те же счётчики, что у достижений).
        if (requirement.dungeons() > 0) {
            int done = gloryStat(player, "DUNGEONS");
            result.add(new Status("dungeons", done, requirement.dungeons(), done >= requirement.dungeons()));
        }
        if (requirement.heroics() > 0) {
            int done = gloryStat(player, "HEROICS");
            result.add(new Status("heroics", done, requirement.heroics(), done >= requirement.heroics()));
        }
        if (requirement.raids() > 0) {
            int done = gloryStat(player, "RAIDS");
            result.add(new Status("raids", done, requirement.raids(), done >= requirement.raids()));
        }

        if (requirement.gear()) {
            boolean has = plugin.getGuildGear() != null
                    && plugin.getGuildGear().hasClaimed(player.getUniqueId(), profile.getRank());
            result.add(new Status("gear", has ? 1 : 0, 1, has));
        }

        if (requirement.fee() > 0) {
            long balance = plugin.getEconomy() == null ? 0 : plugin.getEconomy().balance(player.getUniqueId());
            result.add(new Status("fee", (int) Math.min(Integer.MAX_VALUE, balance),
                    (int) Math.min(Integer.MAX_VALUE, requirement.fee()), balance >= requirement.fee()));
            // Подсказка: сколько дней копить взнос при обычной игре (доход занижен на четверть).
            long perDay = coinsPerDay(profile.getRank(), requirement);
            if (perDay > 0) {
                long days = (requirement.fee() + perDay - 1) / perDay;
                result.add(new Status("fee-days", 0, (int) Math.min(Integer.MAX_VALUE, days), true));
            }
        }
        return result;
    }

    /**
     * Дневной доход монетами для оценки взноса: сначала coins-per-day из ranks.yml,
     * иначе оценка economy.yml (rank-income), иначе 0 - подсказка не показывается.
     */
    private long coinsPerDay(Rank rank, Requirement requirement) {
        if (requirement.coinsPerDay() > 0) {
            return requirement.coinsPerDay();
        }
        if (plugin.getEconomy() == null) {
            return 0;
        }
        long income = plugin.getEconomy().rankIncome(rank.getDisplayName());
        return income > 0 ? income * 3 / 4 : 0;
    }

    /** Значение статистики из модуля Славы; 0, если модуль выключен. */
    private int gloryStat(Player player, String stat) {
        if (plugin.getGlory() == null) {
            return 0;
        }
        return (int) Math.min(Integer.MAX_VALUE, plugin.getGlory().stat(player, stat));
    }

    public boolean canPromote(Player player) {
        List<Status> statuses = check(player);
        if (statuses.isEmpty()) {
            return false;
        }
        for (Status status : statuses) {
            if (!status.ok()) {
                return false;
            }
        }
        return true;
    }

    // ---------------------------------------------------------------
    //  Повышение
    // ---------------------------------------------------------------

    public PromoteResult promote(Player player, boolean force) {
        PlayerProfile profile = plugin.getProfileManager().getProfile(player.getUniqueId());
        if (profile == null) {
            return PromoteResult.NOT_LOADED;
        }
        Rank next = profile.getRank().next();
        if (next == null) {
            return PromoteResult.MAX_RANK;
        }
        if (!force && !canPromote(player)) {
            return PromoteResult.REQUIREMENTS;
        }
        if (!force && plugin.getEconomy() != null) {
            Requirement requirement = requirements.get(profile.getRank());
            long fee = requirement != null && requirement.fee() > 0
                    ? requirement.fee()
                    : plugin.getEconomy().promotionCost(profile.getRank().getDatabaseName());
            if (fee > 0 && !plugin.getEconomy().charge(player, fee)) {
                return PromoteResult.NO_COINS;
            }
        }

        profile.setRank(next);
        plugin.getProfileManager().saveNow(profile);
        plugin.getProfessions().refreshLevels(player);
        plugin.getClasses().refresh(player);

        Instant now = Instant.now();
        since.put(player.getUniqueId(), now);
        UUID uuid = player.getUniqueId();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                repository.save(uuid, now);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });

        celebrate(player, next);
        if (plugin.getGlory() != null) {
            plugin.getGlory().applyBonus(player);
            plugin.getGlory().check(player, "RANK");
        }
        if (plugin.getMentors() != null) {
            plugin.getMentors().onPromote(player, next);
        }
        return PromoteResult.OK;
    }

    /** Сброс времени ранга (после админской смены ранга). */
    public void resetSince(Player player) {
        Instant now = Instant.now();
        since.put(player.getUniqueId(), now);
        UUID uuid = player.getUniqueId();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                repository.save(uuid, now);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });
    }

    private void celebrate(Player player, Rank rank) {
        String rankName = plugin.getMessages().rankName(rank);
        Component title = Hud.legacy(plugin.getMessages().text("ranks.title", "&6&lНовый ранг"));
        Component subtitle = Hud.legacy(rankName);
        player.showTitle(Title.title(title, subtitle));
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);

        plugin.getMessages().send(player, "ranks.promoted", Map.of("rank", rankName));
        if (announce) {
            for (Player other : Bukkit.getOnlinePlayers()) {
                if (!other.equals(player)) {
                    plugin.getMessages().send(other, "ranks.announce", Map.of(
                            "player", player.getName(), "rank", rankName));
                }
            }
        }
    }
}
