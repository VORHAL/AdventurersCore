package ru.adventurers.core.recipe;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profession.PlayerProfessions;
import ru.adventurers.core.profession.Profession;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Рецепты профессий. Меню: /ag craft. Настройки: recipes.yml.
 * Результат: руна, обычный предмет или расходник с эффектами (блюдо повара, эликсир алхимика).
 */
public class RecipeManager implements Listener {

    public record Ingredient(Material material, int amount, String rune, int runeLevel) {
    }

    public record Output(String kind, Material material, int amount, String name, List<String> lore,
                         List<String> effects, double levelScale, double shareRadius,
                         String rune, int runeLevel, Map<String, Integer> enchants, String rankGear,
                         String gem, int gemLevel) {
    }

    public record Recipe(String id, Profession profession, int level, String name, int xp,
                         List<Ingredient> in, Output out) {
    }

    private static final class Holder implements InventoryHolder {
        final List<Profession> professions = new ArrayList<>();
        int profIndex;
        int page;
        final List<Recipe> shown = new ArrayList<>();

        @Override
        public Inventory getInventory() {
            return null;
        }
    }

    private final AdventurersCore plugin;
    private final NamespacedKey consumableKey;
    private final NamespacedKey levelKey;
    private final Map<String, Recipe> recipes = new LinkedHashMap<>();
    /** Цена за штуку в магазине гильдии (shop.yml): по ней считаем себестоимость крафта. */
    private final Map<Material, Double> shopPrice = new HashMap<>();
    /** Цена скупки (/ag sell, economy.yml): по ней видно, сколько сырьё стоит на рынке. */
    private final Map<Material, Double> sellPrice = new HashMap<>();

    public RecipeManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.consumableKey = new NamespacedKey(plugin, "consumable");
        this.levelKey = new NamespacedKey(plugin, "consumable_level");
    }

    public void init() {
        reload();
    }

    public void reload() {
        File file = plugin.getFiles().file("recipes.yml");
        if (!file.exists()) {
            plugin.getFiles().save("recipes.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        recipes.clear();
        loadPrices();
        ConfigurationSection root = cfg.getConfigurationSection("recipes");
        if (root == null) {
            return;
        }
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) {
                continue;
            }
            try {
                Profession profession = Profession.valueOf(s.getString("profession", "").toUpperCase(Locale.ROOT));
                List<Ingredient> in = new ArrayList<>();
                for (Map<?, ?> map : s.getMapList("in")) {
                    if (map.get("rune") != null) {
                        in.add(new Ingredient(null, 1, String.valueOf(map.get("rune")),
                                map.get("level") instanceof Number n ? n.intValue() : 1));
                    } else {
                        Material material = Material.matchMaterial(String.valueOf(map.get("item")));
                        if (material == null) {
                            throw new IllegalArgumentException("предмет " + map.get("item"));
                        }
                        in.add(new Ingredient(material, map.get("amount") instanceof Number n ? n.intValue() : 1, null, 0));
                    }
                }
                ConfigurationSection o = s.getConfigurationSection("out");
                if (o == null) {
                    throw new IllegalArgumentException("нет out");
                }
                Output out;
                if (o.contains("rune")) {
                    out = new Output("rune", null, 1, null, List.of(), List.of(), 0, 0,
                            o.getString("rune"), o.getInt("level", 1), Map.of(), null, null, 0);
                } else if (o.contains("gem")) {
                    out = new Output("gem", null, 1, null, List.of(), List.of(), 0, 0,
                            null, 0, Map.of(), null, o.getString("gem"), o.getInt("level", 1));
                } else {
                    Material material = Material.matchMaterial(o.getString("material", "BREAD"));
                    if (material == null) {
                        throw new IllegalArgumentException("материал результата");
                    }
                    boolean consumable = o.contains("effects");
                    out = new Output(consumable ? "consumable" : "item", material, Math.max(1, o.getInt("amount", 1)),
                            o.getString("name"), o.getStringList("lore"), o.getStringList("effects"),
                            o.getDouble("level-scale", 0.06), o.getDouble("share-radius", 0), null, 0,
                            enchants(o.getConfigurationSection("enchants")), o.getString("rank-gear"), null, 0);
                }
                recipes.put(id, new Recipe(id, profession, Math.max(1, s.getInt("level", 1)),
                        s.getString("name", id), s.getInt("xp", 10), in, out));
            } catch (RuntimeException exception) {
                plugin.getLogger().warning("Recipe " + id + ": " + exception.getMessage());
            }
        }
    }

    /**
     * Цены для расчёта себестоимости: магазин гильдии (shop.yml) и скупка (economy.yml).
     * Читаем файлы напрямую, а не через ShopManager/EconomyManager: у них цены уже
     * пересчитаны под пачки и фильтры, а здесь нужна простая цена за штуку.
     */
    private void loadPrices() {
        shopPrice.clear();
        sellPrice.clear();
        File shop = plugin.getFiles().file("shop.yml");
        if (shop.exists()) {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(shop);
            ConfigurationSection categories = cfg.getConfigurationSection("categories");
            if (categories != null) {
                for (String category : categories.getKeys(false)) {
                    List<Map<?, ?>> goods = categories.getMapList(category + ".goods");
                    for (Map<?, ?> good : goods) {
                        Material material = Material.matchMaterial(String.valueOf(good.get("item")));
                        double amount = good.get("amount") instanceof Number n ? n.doubleValue() : 1;
                        double price = good.get("price") instanceof Number n ? n.doubleValue() : 0;
                        if (material != null && amount > 0 && price > 0) {
                            shopPrice.putIfAbsent(material, price / amount);
                        }
                    }
                }
            }
        }
        File economy = plugin.getFiles().file("economy.yml");
        if (economy.exists()) {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(economy);
            ConfigurationSection prices = cfg.getConfigurationSection("sell.prices");
            if (prices != null) {
                for (String key : prices.getKeys(false)) {
                    Material material = Material.matchMaterial(key);
                    if (material != null) {
                        sellPrice.put(material, prices.getDouble(key));
                    }
                }
            }
        }
    }

    /** Себестоимость рецепта в монетах: сырьё по цене магазина, руны - по себестоимости их рецепта. */
    public double marketCost(Recipe recipe) {
        return cost(recipe, true, 0);
    }

    /** Сколько монет дадут за сырьё этого рецепта при скупке - нижняя граница цены изделия. */
    public double sellCost(Recipe recipe) {
        return cost(recipe, false, 0);
    }

    private double cost(Recipe recipe, boolean market, int depth) {
        if (depth > 4) {
            return 0;
        }
        double total = 0;
        for (Ingredient ingredient : recipe.in) {
            if (ingredient.rune != null) {
                Recipe base = runeRecipe(ingredient.rune);
                if (base != null) {
                    total += cost(base, market, depth + 1) * 0.5 * ingredient.runeLevel;
                }
            } else {
                double unit = market
                        ? shopPrice.getOrDefault(ingredient.material, 0.0)
                        : sellPrice.getOrDefault(ingredient.material, 0.0);
                total += unit * ingredient.amount;
            }
        }
        return total;
    }

    /** Рецепт, который создаёт руну с этой руды (для цепочки «руна I -> руна II»). */
    private Recipe runeRecipe(String rune) {
        for (Recipe candidate : recipes.values()) {
            if (rune.equalsIgnoreCase(candidate.out.rune) && candidate.out.runeLevel == 1) {
                return candidate;
            }
        }
        return null;
    }

    private static String coins(double amount) {
        return String.format(Locale.ROOT, "%,.0f", amount).replace(',', ' ');
    }

    public java.util.Collection<Recipe> all() {
        return recipes.values();
    }

    private static Map<String, Integer> enchants(ConfigurationSection section) {
        Map<String, Integer> result = new LinkedHashMap<>();
        if (section != null) {
            for (String key : section.getKeys(false)) {
                result.put(key, section.getInt(key));
            }
        }
        return result;
    }

    private static Component line(String text) {
        return Hud.legacy(text).decoration(TextDecoration.ITALIC, false);
    }

    // ---------------------------------------------------------------
    //  Меню
    // ---------------------------------------------------------------

    public void open(Player player, String professionName) {
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        Holder holder = new Holder();
        if (data != null) {
            for (Profession profession : data.professions()) {
                if (recipes.values().stream().anyMatch(r -> r.profession == profession)) {
                    holder.professions.add(profession);
                }
            }
        }
        if (holder.professions.isEmpty()) {
            plugin.getMessages().send(player, "craft.no-profession");
            return;
        }
        if (professionName != null) {
            for (int i = 0; i < holder.professions.size(); i++) {
                if (holder.professions.get(i).name().equalsIgnoreCase(professionName)) {
                    holder.profIndex = i;
                }
            }
        }
        render(player, holder);
    }

    private void render(Player player, Holder holder) {
        Profession profession = holder.professions.get(holder.profIndex);
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        int level = data != null && data.has(profession) ? data.get(profession).getLevel() : 1;
        Inventory inventory = Bukkit.createInventory(holder, 54,
                Hud.legacy("&8Рецепты: &6" + plugin.getProfessions().displayName(profession)));
        List<Recipe> list = new ArrayList<>();
        for (Recipe recipe : recipes.values()) {
            if (recipe.profession == profession) {
                list.add(recipe);
            }
        }
        holder.shown.clear();
        int from = holder.page * 45;
        for (int i = from; i < Math.min(list.size(), from + 45); i++) {
            Recipe recipe = list.get(i);
            holder.shown.add(recipe);
            inventory.setItem(i - from, icon(player, recipe, level));
        }
        inventory.setItem(45, button(Material.ARROW, "&7◀ Страница", holder.page > 0));
        inventory.setItem(53, button(Material.ARROW, "&7Страница ▶", list.size() > from + 45));
        if (holder.professions.size() > 1) {
            inventory.setItem(48, button(Material.SPECTRAL_ARROW, "&e◀ Другая профессия", true));
            inventory.setItem(50, button(Material.SPECTRAL_ARROW, "&eДругая профессия ▶", true));
        }
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta meta = info.getItemMeta();
        meta.displayName(line("&6" + plugin.getProfessions().displayName(profession) + " &7уровень &f" + level));
        meta.lore(List.of(line("&7Клик по рецепту: создать."), line("&7Ингредиенты берутся из инвентаря.")));
        info.setItemMeta(meta);
        inventory.setItem(49, info);
        player.openInventory(inventory);
    }

    private ItemStack button(Material material, String name, boolean on) {
        ItemStack item = new ItemStack(on ? material : Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(on ? name : "&8·"));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack icon(Player player, Recipe recipe, int level) {
        ItemStack preview = result(recipe, level);
        ItemStack item = preview == null ? new ItemStack(Material.BARRIER) : preview.clone();
        ItemMeta meta = item.getItemMeta();
        boolean levelOk = level >= recipe.level;
        boolean haveAll = true;
        List<Component> lore = new ArrayList<>();
        if (meta.lore() != null) {
            lore.addAll(meta.lore());
        }
        lore.add(Component.empty());
        lore.add(line((levelOk ? "&a" : "&c") + "Нужен уровень профессии: " + recipe.level));
        lore.add(line("&7Ингредиенты:"));
        for (Ingredient ingredient : recipe.in) {
            int have = count(player, ingredient);
            int need = ingredient.amount;
            boolean ok = have >= need;
            haveAll &= ok;
            String name = ingredient.rune != null
                    ? "Руна " + runeTitle(ingredient.rune) + " " + ingredient.runeLevel
                    : ingredient.material.name().toLowerCase(Locale.ROOT).replace('_', ' ');
            lore.add(line((ok ? "&a" : "&c") + " " + have + "/" + need + " &7" + name));
        }
        double market = marketCost(recipe);
        double sell = sellCost(recipe);
        if (market > 0) {
            lore.add(Component.empty());
            lore.add(line("&8Себестоимость: &7" + coins(market) + " монет &8(по магазину)"));
            if (sell > 0) {
                lore.add(line("&8Сырьё скупщику: &7" + coins(sell) + " монет"));
            }
        }
        lore.add(Component.empty());
        lore.add(line(levelOk && haveAll ? "&e▶ Нажми, чтобы создать" : "&8Не хватает условий"));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private String runeTitle(String id) {
        var def = plugin.getRunes() == null ? null : plugin.getRunes().def(id);
        return def == null ? id : def.name();
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)
                || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getClickedInventory() != event.getInventory()) {
            return;
        }
        int slot = event.getSlot();
        if (slot == 45 && holder.page > 0) {
            holder.page--;
            render(player, holder);
        } else if (slot == 53 && event.getCurrentItem() != null
                && event.getCurrentItem().getType() == Material.ARROW) {
            holder.page++;
            render(player, holder);
        } else if ((slot == 48 || slot == 50) && holder.professions.size() > 1) {
            int size = holder.professions.size();
            holder.profIndex = (holder.profIndex + (slot == 50 ? 1 : size - 1)) % size;
            holder.page = 0;
            render(player, holder);
        } else if (slot >= 0 && slot < 45 && slot < holder.shown.size()) {
            craft(player, holder.shown.get(slot));
            Holder fresh = new Holder();
            fresh.professions.addAll(holder.professions);
            fresh.profIndex = holder.profIndex;
            fresh.page = holder.page;
            render(player, fresh);
        }
    }

    // ---------------------------------------------------------------
    //  Создание
    // ---------------------------------------------------------------

    private int count(Player player, Ingredient ingredient) {
        int total = 0;
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (matches(item, ingredient)) {
                total += ingredient.rune != null ? 1 : item.getAmount();
            }
        }
        return total;
    }

    private boolean matches(ItemStack item, Ingredient ingredient) {
        if (item == null || item.getType().isAir()) {
            return false;
        }
        if (ingredient.rune != null) {
            return plugin.getRunes() != null && ingredient.rune.equalsIgnoreCase(plugin.getRunes().runeId(item))
                    && plugin.getRunes().runeLevel(item) >= ingredient.runeLevel;
        }
        return item.getType() == ingredient.material && !item.getItemMeta().hasDisplayName();
    }

    private void take(Player player, Ingredient ingredient) {
        int left = ingredient.amount;
        ItemStack[] contents = player.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && left > 0; i++) {
            ItemStack item = contents[i];
            if (!matches(item, ingredient)) {
                continue;
            }
            int step = Math.min(left, item.getAmount());
            item.setAmount(item.getAmount() - step);
            contents[i] = item.getAmount() <= 0 ? null : item;
            left -= step;
        }
        player.getInventory().setStorageContents(contents);
    }

    private ItemStack result(Recipe recipe, int level) {
        Output out = recipe.out;
        if (out.kind.equals("rune")) {
            return plugin.getRunes() == null ? null : plugin.getRunes().create(out.rune, out.runeLevel);
        }
        if (out.kind.equals("gem")) {
            var type = plugin.getGems() == null ? null : plugin.getGems().type(out.gem);
            return type == null ? null : plugin.getGems().createGem(type, Math.max(1, out.gemLevel), false);
        }
        ItemStack item = new ItemStack(out.material, out.amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(out.name == null ? recipe.name : out.name));
        List<Component> lore = new ArrayList<>();
        for (String text : out.lore) {
            lore.add(line(text));
        }
        if (recipe.id.equals("uncursing") && plugin.getCurses() != null) {
            // зелье снятия проклятия помечаем своей меткой - её ловит CursedGear
            meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "uncursing"),
                    PersistentDataType.BYTE, (byte) 1);
        }
        if (out.kind.equals("consumable")) {
            for (String effect : out.effects) {
                lore.add(line("&8" + effect.replace(':', ' ')));
            }
            meta.setEnchantmentGlintOverride(true);
            meta.getPersistentDataContainer().set(consumableKey, PersistentDataType.STRING, recipe.id);
            meta.getPersistentDataContainer().set(levelKey, PersistentDataType.INTEGER, level);
        }
        if (!out.enchants.isEmpty()) {
            for (Map.Entry<String, Integer> entry : out.enchants.entrySet()) {
                org.bukkit.enchantments.Enchantment enchantment = org.bukkit.Registry.ENCHANTMENT
                        .get(NamespacedKey.minecraft(entry.getKey().toLowerCase(Locale.ROOT)));
                if (enchantment != null) {
                    meta.addEnchant(enchantment, entry.getValue(), true);
                }
            }
        }
        if (out.rankGear != null) {
            var rank = ru.adventurers.core.profile.Rank.fromInput(out.rankGear);
            if (rank != null) {
                meta.getPersistentDataContainer().set(
                        ru.adventurers.core.survival.SurvivalManager.rankGearKey(plugin),
                        PersistentDataType.STRING, rank.name());
                meta.setUnbreakable(true);
            }
        }
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public void craft(Player player, Recipe recipe) {
        PlayerProfessions data = plugin.getProfessions().get(player.getUniqueId());
        if (data == null || !data.has(recipe.profession)) {
            plugin.getMessages().send(player, "craft.no-profession");
            return;
        }
        int level = data.get(recipe.profession).getLevel();
        if (level < recipe.level) {
            plugin.getMessages().send(player, "craft.level", Map.of("level", recipe.level));
            return;
        }
        for (Ingredient ingredient : recipe.in) {
            if (count(player, ingredient) < ingredient.amount) {
                plugin.getMessages().send(player, "craft.missing");
                return;
            }
        }
        ItemStack out = result(recipe, level);
        if (out == null) {
            plugin.getMessages().send(player, "craft.error");
            return;
        }
        for (Ingredient ingredient : recipe.in) {
            take(player, ingredient);
        }
        for (ItemStack rest : player.getInventory().addItem(out).values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), rest);
        }
        if (recipe.xp > 0) {
            plugin.getProfessions().addXp(player, recipe.profession, recipe.xp);
        }
        plugin.getMessages().send(player, "craft.done", Map.of("name", recipe.name));
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_ANVIL_USE, 0.6f, 1.4f);
    }

    // ---------------------------------------------------------------
    //  Расходники
    // ---------------------------------------------------------------

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent event) {
        ItemStack item = event.getItem();
        if (!item.hasItemMeta()) {
            return;
        }
        String id = item.getItemMeta().getPersistentDataContainer().get(consumableKey, PersistentDataType.STRING);
        Recipe recipe = id == null ? null : recipes.get(id);
        if (recipe == null) {
            return;
        }
        Integer level = item.getItemMeta().getPersistentDataContainer().get(levelKey, PersistentDataType.INTEGER);
        double scale = 1.0 + recipe.out.levelScale * (level == null ? 1 : level);
        Player player = event.getPlayer();
        apply(player, recipe.out.effects, scale);
        if (recipe.out.shareRadius > 0) {
            for (Player member : plugin.getParties().shareTargets(player)) {
                if (!member.equals(player) && member.getWorld().equals(player.getWorld())
                        && member.getLocation().distanceSquared(player.getLocation())
                        <= recipe.out.shareRadius * recipe.out.shareRadius) {
                    apply(member, recipe.out.effects, scale * 0.5);
                }
            }
        }
    }

    private void apply(Player target, List<String> effects, double scale) {
        for (String spec : effects) {
            String[] parts = spec.split(":");
            PotionEffectType type = org.bukkit.Registry.EFFECT.get(org.bukkit.NamespacedKey.minecraft(parts[0].toLowerCase(Locale.ROOT)));
            if (type == null) {
                continue;
            }
            int seconds = parts.length > 1 ? Integer.parseInt(parts[1]) : 30;
            int amp = parts.length > 2 ? Integer.parseInt(parts[2]) : 0;
            target.addPotionEffect(new PotionEffect(type, (int) (seconds * scale * 20), amp));
        }
    }
}
