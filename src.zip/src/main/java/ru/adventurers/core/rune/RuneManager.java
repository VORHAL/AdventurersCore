package ru.adventurers.core.rune;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Руны Рунописца: предмет-руна вставляется в Жезл Лекаря или Щит Танка и усиливает умения.
 * Настройки: runes.yml. На предмете руны хранятся в PDC строкой "id:уровень;id:уровень".
 */
public class RuneManager {

    public record RuneDef(String id, String name, String color, Material material, String target,
                          int maxLevel, Map<String, Double> effects, String lore) {
    }

    private final AdventurersCore plugin;
    private final NamespacedKey idKey;
    private final NamespacedKey levelKey;
    private final NamespacedKey slotsKey;
    private final Map<String, RuneDef> defs = new LinkedHashMap<>();
    private int slots = 2;

    private static final String[] ROMAN = {"0", "I", "II", "III", "IV", "V"};

    public RuneManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "rune_id");
        this.levelKey = new NamespacedKey(plugin, "rune_level");
        this.slotsKey = new NamespacedKey(plugin, "item_runes");
    }

    public void init() {
        reload();
    }

    public void reload() {
        File file = plugin.getFiles().file("runes.yml");
        if (!file.exists()) {
            plugin.getFiles().save("runes.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        slots = Math.max(1, cfg.getInt("slots", 2));
        defs.clear();
        ConfigurationSection root = cfg.getConfigurationSection("runes");
        if (root == null) {
            return;
        }
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) {
                continue;
            }
            Material material = Material.matchMaterial(s.getString("material", "AMETHYST_SHARD"));
            Map<String, Double> effects = new LinkedHashMap<>();
            ConfigurationSection e = s.getConfigurationSection("effects");
            if (e != null) {
                for (String stat : e.getKeys(false)) {
                    effects.put(stat, e.getDouble(stat));
                }
            }
            defs.put(id.toLowerCase(Locale.ROOT), new RuneDef(id.toLowerCase(Locale.ROOT), s.getString("name", id),
                    s.getString("color", "&b"), material == null ? Material.AMETHYST_SHARD : material,
                    s.getString("for", "staff").toLowerCase(Locale.ROOT), Math.max(1, s.getInt("max-level", 3)),
                    effects, s.getString("lore", "")));
        }
    }

    public RuneDef def(String id) {
        return id == null ? null : defs.get(id.toLowerCase(Locale.ROOT));
    }

    public java.util.Collection<RuneDef> all() {
        return defs.values();
    }

    private static String roman(int level) {
        return level >= 0 && level < ROMAN.length ? ROMAN[level] : String.valueOf(level);
    }

    private static Component line(String text) {
        return Hud.legacy(text).decoration(TextDecoration.ITALIC, false);
    }

    private static String num(double value) {
        String text = String.format(Locale.ROOT, "%.1f", value);
        return text.endsWith(".0") ? text.substring(0, text.length() - 2) : text;
    }

    /** Текст бонуса руны данного уровня. */
    public String describe(RuneDef def, int level) {
        String percent = "";
        if (!def.effects().isEmpty()) {
            percent = num(def.effects().values().iterator().next() * level * 100);
        }
        return def.lore().replace("{percent}", percent);
    }

    public ItemStack create(String id, int level) {
        RuneDef def = def(id);
        if (def == null) {
            return null;
        }
        int lvl = Math.max(1, Math.min(def.maxLevel(), level));
        ItemStack item = new ItemStack(def.material(), 1);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(def.color() + "✦ Руна: " + def.name() + " " + roman(lvl)));
        List<Component> lore = new ArrayList<>();
        lore.add(line("&7" + describe(def, lvl)));
        lore.add(line("&8Для: " + switch (def.target()) {
            case "shield" -> "Щит Танка";
            case "sword" -> "меч или топор Бойца";
            case "bow" -> "лук или арбалет Стрелка";
            default -> "Жезл Лекаря";
        }));
        lore.add(Component.empty());
        lore.add(line("&eВставить: &fвозьмите руну в руку и введите &6/ag rune"));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, def.id());
        meta.getPersistentDataContainer().set(levelKey, PersistentDataType.INTEGER, lvl);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isRune(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(idKey, PersistentDataType.STRING);
    }

    public String runeId(ItemStack item) {
        return isRune(item) ? item.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING) : null;
    }

    public int runeLevel(ItemStack item) {
        Integer value = isRune(item)
                ? item.getItemMeta().getPersistentDataContainer().get(levelKey, PersistentDataType.INTEGER) : null;
        return value == null ? 1 : value;
    }

    // ---------------------------------------------------------------
    //  Руны на предмете
    // ---------------------------------------------------------------

    private Map<String, Integer> read(ItemStack item) {
        Map<String, Integer> result = new LinkedHashMap<>();
        if (item == null || !item.hasItemMeta()) {
            return result;
        }
        String raw = item.getItemMeta().getPersistentDataContainer().get(slotsKey, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) {
            return result;
        }
        for (String part : raw.split(";")) {
            String[] pair = part.split(":");
            if (pair.length == 2) {
                try {
                    result.put(pair[0], Integer.parseInt(pair[1]));
                } catch (NumberFormatException ignored) {
                    // пропускаем битую запись
                }
            }
        }
        return result;
    }

    private void write(ItemStack item, Map<String, Integer> runes) {
        ItemMeta meta = item.getItemMeta();
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> entry : runes.entrySet()) {
            if (sb.length() > 0) {
                sb.append(';');
            }
            sb.append(entry.getKey()).append(':').append(entry.getValue());
        }
        if (sb.length() == 0) {
            meta.getPersistentDataContainer().remove(slotsKey);
        } else {
            meta.getPersistentDataContainer().set(slotsKey, PersistentDataType.STRING, sb.toString());
        }
        // перерисовать строки рун в описании
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.removeIf(c -> net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText()
                .serialize(c).startsWith("✦"));
        for (Map.Entry<String, Integer> entry : runes.entrySet()) {
            RuneDef def = def(entry.getKey());
            if (def != null) {
                lore.add(line(def.color() + "✦ " + def.name() + " " + roman(entry.getValue()) + " &8- &7"
                        + describe(def, entry.getValue())));
            }
        }
        meta.lore(lore);
        item.setItemMeta(meta);
    }

    public enum Result { OK, NOT_RUNE, NO_TARGET, FULL, WEAKER }

    /** Вставляет руну из руки в подходящий предмет (жезл или щит) из инвентаря. */
    public Result apply(Player player) {
        ItemStack rune = player.getInventory().getItemInMainHand();
        RuneDef def = def(runeId(rune));
        if (def == null) {
            return Result.NOT_RUNE;
        }
        int level = runeLevel(rune);
        ItemStack target = null;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item == null) {
                continue;
            }
            boolean ok = switch (def.target()) {
                case "shield" -> plugin.getTank().isTankShield(item);
                case "sword" -> ru.adventurers.core.combat.WeaponSkills.isMelee(item);
                case "bow" -> ru.adventurers.core.combat.WeaponSkills.isRanged(item);
                default -> plugin.getHealer().isStaff(item);
            };
            if (ok) {
                target = item;
                break;
            }
        }
        if (target == null) {
            return Result.NO_TARGET;
        }
        Map<String, Integer> runes = read(target);
        Integer old = runes.get(def.id());
        if (old == null && runes.size() >= slots) {
            return Result.FULL;
        }
        if (old != null && old >= level) {
            return Result.WEAKER;
        }
        runes.put(def.id(), level);
        write(target, runes);
        rune.setAmount(rune.getAmount() - 1);
        player.getInventory().setItemInMainHand(rune.getAmount() <= 0 ? null : rune);
        return Result.OK;
    }

    public int slots() {
        return slots;
    }

    /** Снимает все руны с предмета в руке или со жезла/щита (руны пропадают). */
    public boolean clear(Player player) {
        boolean any = false;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer()
                    .has(slotsKey, PersistentDataType.STRING)) {
                write(item, new LinkedHashMap<>());
                any = true;
            }
        }
        return any;
    }

    /**
     * Сумма бонусов указанного параметра со всех рун на жезле и щите игрока.
     * Параметры: heal_power, heal_cooldown, mana_regen, mana_cost, pulse_radius, bolt_lifelink,
     * taunt_radius, taunt_duration, wall_reduction, wall_cooldown, dash_cooldown, dash_damage.
     */
    public double bonus(Player player, String stat) {
        double total = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item == null || !item.hasItemMeta()) {
                continue;
            }
            for (Map.Entry<String, Integer> entry : read(item).entrySet()) {
                RuneDef def = def(entry.getKey());
                if (def != null && def.effects().containsKey(stat)) {
                    total += def.effects().get(stat) * entry.getValue();
                }
            }
        }
        return total;
    }

    public List<String> installed(Player player) {
        List<String> result = new ArrayList<>();
        for (ItemStack item : player.getInventory().getContents()) {
            for (Map.Entry<String, Integer> entry : read(item).entrySet()) {
                RuneDef def = def(entry.getKey());
                if (def != null) {
                    result.add(def.color() + def.name() + " " + roman(entry.getValue()));
                }
            }
        }
        return result;
    }
}
