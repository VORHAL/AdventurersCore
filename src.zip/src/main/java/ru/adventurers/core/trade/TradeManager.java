package ru.adventurers.core.trade;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.classes.PlayerClass;
import ru.adventurers.core.economy.EconomyManager;
import ru.adventurers.core.hud.Hud;
import ru.adventurers.core.profile.PlayerProfile;
import ru.adventurers.core.profile.Rank;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Безопасный обмен предметами и монетами между двумя игроками. */
public final class TradeManager implements Listener {

    private static final int OFFER_SIZE = 18;
    private static final long REQUEST_TICKS = 20L * 30L;
    private static final long SESSION_TICKS = 20L * 60L * 5L;
    private static final double MAX_DISTANCE_SQUARED = 10.0 * 10.0;

    private static final class Session {
        final UUID first;
        final UUID second;
        final List<ItemStack> firstItems = new ArrayList<>();
        final List<ItemStack> secondItems = new ArrayList<>();
        final long[] coins = new long[2];
        final boolean[] ready = new boolean[2];
        final Map<UUID, Inventory> inventories = new HashMap<>();
        boolean closed;

        Session(UUID first, UUID second) {
            this.first = first;
            this.second = second;
        }

        int side(UUID id) {
            if (first.equals(id)) return 0;
            if (second.equals(id)) return 1;
            return -1;
        }

        UUID member(int side) {
            return side == 0 ? first : second;
        }

        UUID other(int side) {
            return member(1 - side);
        }

        List<ItemStack> items(int side) {
            return side == 0 ? firstItems : secondItems;
        }
    }

    private record View(Session session, UUID viewer) { }

    private final AdventurersCore plugin;
    private final NamespacedKey dungeonOwnerKey;
    private final NamespacedKey customClassesKey;
    private final NamespacedKey customRankKey;
    private final Map<UUID, UUID> requestsByTarget = new HashMap<>();
    private final Map<UUID, UUID> requestsBySender = new HashMap<>();
    private final Map<UUID, Session> sessionsByPlayer = new HashMap<>();
    private final Map<Inventory, View> views = new IdentityHashMap<>();

    public TradeManager(AdventurersCore plugin) {
        this.plugin = plugin;
        this.dungeonOwnerKey = new NamespacedKey(plugin, "dungeon_loot_owner");
        this.customClassesKey = new NamespacedKey(plugin, "custom_loot_classes");
        this.customRankKey = new NamespacedKey(plugin, "custom_loot_rank");
    }

    public void handle(Player player, String[] args) {
        if (args.length < 2) {
            help(player);
            return;
        }
        switch (args[1].toLowerCase()) {
            case "accept" -> accept(player);
            case "decline" -> decline(player);
            case "cancel" -> cancel(player, "&7Обмен отменён.");
            case "coins" -> {
                if (args.length < 3) {
                    player.sendMessage(Hud.legacy("&eИспользование: &f/ag trade coins <сумма>"));
                    return;
                }
                setCoins(player, args[2]);
            }
            default -> request(player, args[1]);
        }
    }

    private void help(Player player) {
        player.sendMessage(Hud.legacy("&6Обмен: &f/ag trade <игрок> &7— запрос обмена"));
        player.sendMessage(Hud.legacy("&7Принять/отклонить: &f/ag trade accept &7/ &f/ag trade decline"));
        player.sendMessage(Hud.legacy("&7Монеты: &f/ag trade coins <сумма>&7. В окне: Shift-клик по предмету — добавить, клик по своему лоту — вернуть."));
    }

    private void request(Player sender, String targetName) {
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null || !target.isOnline()) {
            sender.sendMessage(Hud.legacy("&cИгрок должен быть в сети."));
            return;
        }
        if (target.equals(sender)) {
            sender.sendMessage(Hud.legacy("&cНельзя обмениваться с самим собой."));
            return;
        }
        if (!near(sender, target)) {
            sender.sendMessage(Hud.legacy("&cДля обмена нужно находиться в одном мире не дальше 10 блоков."));
            return;
        }
        if (sessionsByPlayer.containsKey(sender.getUniqueId()) || sessionsByPlayer.containsKey(target.getUniqueId())
                || requestsBySender.containsKey(sender.getUniqueId())
                || requestsBySender.containsKey(target.getUniqueId())
                || requestsByTarget.containsKey(sender.getUniqueId())
                || requestsByTarget.containsKey(target.getUniqueId())) {
            sender.sendMessage(Hud.legacy("&cОдин из игроков уже занят другим запросом или обменом."));
            return;
        }
        UUID from = sender.getUniqueId();
        UUID to = target.getUniqueId();
        requestsByTarget.put(to, from);
        requestsBySender.put(from, to);
        sender.sendMessage(Hud.legacy("&7Запрос обмена отправлен игроку &f" + target.getName() + "&7."));
        target.sendMessage(Hud.legacy("&e" + sender.getName() + " &7предлагает обмен. Принять: &f/ag trade accept&7, отказать: &f/ag trade decline"));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (requestsByTarget.get(to) != null && requestsByTarget.get(to).equals(from)) {
                clearRequest(from, to);
                Player onlineSender = Bukkit.getPlayer(from);
                Player onlineTarget = Bukkit.getPlayer(to);
                if (onlineSender != null) onlineSender.sendMessage(Hud.legacy("&7Запрос обмена истёк."));
                if (onlineTarget != null) onlineTarget.sendMessage(Hud.legacy("&7Запрос обмена истёк."));
            }
        }, REQUEST_TICKS);
    }

    private void accept(Player target) {
        UUID targetId = target.getUniqueId();
        UUID senderId = requestsByTarget.get(targetId);
        if (senderId == null) {
            target.sendMessage(Hud.legacy("&cНет активного запроса на обмен."));
            return;
        }
        Player sender = Bukkit.getPlayer(senderId);
        clearRequest(senderId, targetId);
        if (sender == null || !sender.isOnline()) {
            target.sendMessage(Hud.legacy("&cИгрок уже вышел."));
            return;
        }
        if (!near(sender, target)) {
            target.sendMessage(Hud.legacy("&cИгрок слишком далеко для обмена."));
            sender.sendMessage(Hud.legacy("&cОбмен не начался: игрок слишком далеко."));
            return;
        }
        if (sessionsByPlayer.containsKey(senderId) || sessionsByPlayer.containsKey(targetId)) {
            target.sendMessage(Hud.legacy("&cОдин из игроков уже участвует в обмене."));
            return;
        }
        Session session = new Session(senderId, targetId);
        sessionsByPlayer.put(senderId, session);
        sessionsByPlayer.put(targetId, session);
        for (int side = 0; side < 2; side++) {
            UUID memberId = session.member(side);
            Player member = Bukkit.getPlayer(memberId);
            if (member == null) {
                cancelSession(session, "&cОбмен отменён: игрок вышел.");
                return;
            }
            Inventory inventory = Bukkit.createInventory(null, 54,
                    Hud.legacy("&6Обмен: &f" + Bukkit.getPlayer(session.other(side)).getName()));
            session.inventories.put(memberId, inventory);
            views.put(inventory, new View(session, memberId));
        }
        refresh(session);
        sender.openInventory(session.inventories.get(senderId));
        target.openInventory(session.inventories.get(targetId));
        tell(session, "&aОбмен начат. Добавляйте предметы Shift-кликом и подтвердите обе стороны.");
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!session.closed) cancelSession(session, "&7Обмен завершён по тайм-ауту.");
        }, SESSION_TICKS);
    }

    private void decline(Player target) {
        UUID sender = requestsByTarget.get(target.getUniqueId());
        if (sender == null) {
            target.sendMessage(Hud.legacy("&cНет активного запроса на обмен."));
            return;
        }
        clearRequest(sender, target.getUniqueId());
        Player requester = Bukkit.getPlayer(sender);
        target.sendMessage(Hud.legacy("&7Вы отклонили запрос."));
        if (requester != null) requester.sendMessage(Hud.legacy("&c" + target.getName() + " отклонил запрос обмена."));
    }

    private void clearRequest(UUID sender, UUID target) {
        requestsByTarget.remove(target, sender);
        requestsBySender.remove(sender, target);
    }

    private void setCoins(Player player, String amountText) {
        Session session = sessionsByPlayer.get(player.getUniqueId());
        if (session == null) {
            player.sendMessage(Hud.legacy("&cСначала начните обмен."));
            return;
        }
        long amount;
        try {
            amount = Long.parseLong(amountText);
        } catch (NumberFormatException exception) {
            player.sendMessage(Hud.legacy("&cВведите целое неотрицательное число монет."));
            return;
        }
        if (amount < 0 || plugin.getEconomy() == null || !plugin.getEconomy().has(player.getUniqueId(), amount)) {
            player.sendMessage(Hud.legacy("&cНедостаточно монет или неверная сумма."));
            return;
        }
        int side = session.side(player.getUniqueId());
        session.coins[side] = amount;
        resetReady(session);
        refresh(session);
        tell(session, "&7Предложение по монетам обновлено. Подтвердите обмен заново.");
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTradeClick(InventoryClickEvent event) {
        View view = views.get(event.getInventory());
        if (view == null || !(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        Session session = view.session();
        if (session.closed || !player.getUniqueId().equals(view.viewer())) {
            return;
        }
        int side = session.side(player.getUniqueId());
        Inventory clicked = event.getClickedInventory();
        if (clicked == null) return;

        if (clicked == event.getInventory()) {
            int slot = event.getSlot();
            if (slot >= 0 && slot < OFFER_SIZE) {
                withdrawOffer(session, side, slot, player);
            } else if (slot == 49) {
                toggleReady(session, side, player);
            } else if (slot == 53) {
                cancelSession(session, "&7Обмен отменён.");
            }
            return;
        }
        if (clicked == player.getInventory() && event.isShiftClick()) {
            int slot = event.getSlot();
            if (slot >= 0 && slot < 36) offerItem(session, side, slot, player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTradeDrag(InventoryDragEvent event) {
        if (views.containsKey(event.getInventory())) event.setCancelled(true);
    }

    private void offerItem(Session session, int side, int slot, Player player) {
        List<ItemStack> own = session.items(side);
        if (own.size() >= OFFER_SIZE) {
            player.sendMessage(Hud.legacy("&cВ окне можно выставить не больше 18 стеков."));
            return;
        }
        ItemStack item = player.getInventory().getItem(slot);
        if (item == null || item.getType().isAir()) return;
        if (isUntradeable(item)) {
            player.sendMessage(Hud.legacy("&cЭтот предмет привязан или не подлежит обмену."));
            return;
        }
        Player receiver = Bukkit.getPlayer(session.other(side));
        if (receiver == null || !canReceive(item, receiver)) {
            player.sendMessage(Hud.legacy("&cПолучатель не подходит по классу или рангу для этого предмета."));
            return;
        }
        own.add(item.clone());
        player.getInventory().setItem(slot, null);
        resetReady(session);
        refresh(session);
    }

    private void withdrawOffer(Session session, int side, int slot, Player player) {
        List<ItemStack> own = session.items(side);
        if (slot >= own.size()) return;
        ItemStack offered = own.get(slot);
        Map<Integer, ItemStack> left = player.getInventory().addItem(offered.clone());
        if (!left.isEmpty()) {
            int leftoverAmount = left.values().stream().mapToInt(ItemStack::getAmount).sum();
            offered.setAmount(leftoverAmount);
            player.sendMessage(Hud.legacy("&cВ инвентаре нет места для всего стека."));
        } else {
            own.remove(slot);
        }
        resetReady(session);
        refresh(session);
    }

    private void toggleReady(Session session, int side, Player player) {
        session.ready[side] = !session.ready[side];
        refresh(session);
        if (session.ready[0] && session.ready[1]) complete(session);
        else tell(session, "&e" + player.getName() + (session.ready[side] ? " &7подтвердил обмен." : " &7снял подтверждение."));
    }

    private void complete(Session session) {
        Player first = Bukkit.getPlayer(session.first);
        Player second = Bukkit.getPlayer(session.second);
        if (first == null || second == null || !near(first, second)) {
            cancelSession(session, "&cОбмен отменён: игрок вышел или отошёл слишком далеко.");
            return;
        }
        if (!canReceiveAll(session.firstItems, second) || !canReceiveAll(session.secondItems, first)) {
            resetReady(session);
            refresh(session);
            tell(session, "&cОбмен не подтверждён: класс или ранг одного из игроков больше не подходит.");
            return;
        }
        ItemStack[] firstInventory = simulateAdd(first.getInventory(), session.secondItems);
        ItemStack[] secondInventory = simulateAdd(second.getInventory(), session.firstItems);
        if (firstInventory == null || secondInventory == null) {
            resetReady(session);
            refresh(session);
            tell(session, "&cНужно освободить место в инвентаре перед завершением обмена.");
            return;
        }
        EconomyManager economy = plugin.getEconomy();
        if (economy == null || !economy.has(session.first, session.coins[0])
                || !economy.has(session.second, session.coins[1])) {
            resetReady(session);
            refresh(session);
            tell(session, "&cНе хватает монет для подтверждённого предложения.");
            return;
        }
        boolean firstWithdrawn = economy.withdraw(session.first, session.coins[0]);
        if (!firstWithdrawn) {
            resetReady(session);
            refresh(session);
            tell(session, "&cНе удалось списать монеты с первой стороны обмена.");
            return;
        }
        boolean secondWithdrawn = economy.withdraw(session.second, session.coins[1]);
        if (!secondWithdrawn) {
            economy.deposit(session.first, session.coins[0]);
            resetReady(session);
            refresh(session);
            tell(session, "&cНе удалось списать монеты со второй стороны обмена; первое списание возвращено.");
            return;
        }
        first.getInventory().setStorageContents(firstInventory);
        second.getInventory().setStorageContents(secondInventory);
        economy.deposit(session.first, session.coins[1]);
        economy.deposit(session.second, session.coins[0]);
        tell(session, "&aОбмен успешно завершён.");
        finish(session);
    }

    private boolean canReceiveAll(List<ItemStack> items, Player receiver) {
        for (ItemStack item : items) {
            if (isUntradeable(item) || !canReceive(item, receiver)) return false;
        }
        return true;
    }

    private ItemStack[] simulateAdd(PlayerInventory inventory, List<ItemStack> additions) {
        ItemStack[] simulated = Arrays.stream(inventory.getStorageContents())
                .map(item -> item == null ? null : item.clone()).toArray(ItemStack[]::new);
        for (ItemStack offered : additions) {
            if (offered == null || offered.getType().isAir()) continue;
            int remaining = offered.getAmount();
            int max = Math.min(inventory.getMaxStackSize(), offered.getMaxStackSize());
            for (int i = 0; i < simulated.length && remaining > 0; i++) {
                ItemStack current = simulated[i];
                if (current != null && current.isSimilar(offered)) {
                    int capacity = Math.max(0, Math.min(inventory.getMaxStackSize(), current.getMaxStackSize()) - current.getAmount());
                    int move = Math.min(capacity, remaining);
                    current.setAmount(current.getAmount() + move);
                    remaining -= move;
                }
            }
            while (remaining > 0) {
                int empty = -1;
                for (int i = 0; i < simulated.length; i++) {
                    if (simulated[i] == null || simulated[i].getType().isAir()) {
                        empty = i;
                        break;
                    }
                }
                if (empty < 0) return null;
                int amount = Math.min(max, remaining);
                ItemStack placed = offered.clone();
                placed.setAmount(amount);
                simulated[empty] = placed;
                remaining -= amount;
            }
        }
        return simulated;
    }

    private boolean canReceive(ItemStack item, Player receiver) {
        if (isUntradeable(item)) return false;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return true;
        String rankName = meta.getPersistentDataContainer().get(customRankKey, PersistentDataType.STRING);
        Rank required = Rank.fromInput(rankName);
        if (required != null) {
            PlayerProfile profile = plugin.getProfileManager().getProfile(receiver.getUniqueId());
            Rank current = profile == null ? Rank.F : profile.getRank();
            if (!current.isAtLeast(required)) return false;
        }
        String classes = meta.getPersistentDataContainer().get(customClassesKey, PersistentDataType.STRING);
        if (classes != null && !classes.isBlank()) {
            PlayerClass active = plugin.getClasses().activeClass(receiver.getUniqueId());
            if (active == null || (active != PlayerClass.UNIVERSAL
                    && !Arrays.asList(classes.split(",")).contains(active.getId()))) return false;
        }
        return true;
    }

    private boolean isUntradeable(ItemStack item) {
        if (item == null || item.getType().isAir()) return false;
        if (item.getType() == Material.BEDROCK || isDungeonBound(item)) return true;
        return (plugin.getHealer() != null && plugin.getHealer().isStaff(item))
                || (plugin.getTank() != null && plugin.getTank().isTankShield(item));
    }

    private boolean isDungeonBound(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer()
                .has(dungeonOwnerKey, PersistentDataType.STRING);
    }

    private void resetReady(Session session) {
        session.ready[0] = false;
        session.ready[1] = false;
    }

    private void refresh(Session session) {
        if (session.closed) return;
        for (int side = 0; side < 2; side++) {
            UUID viewer = session.member(side);
            Inventory inventory = session.inventories.get(viewer);
            if (inventory == null) continue;
            inventory.clear();
            List<ItemStack> own = session.items(side);
            List<ItemStack> other = session.items(1 - side);
            for (int i = 0; i < own.size() && i < OFFER_SIZE; i++) inventory.setItem(i, own.get(i).clone());
            for (int i = 0; i < other.size() && i < OFFER_SIZE; i++) inventory.setItem(27 + i, other.get(i).clone());
            inventory.setItem(20, button(Material.GOLD_INGOT, "&6Ваши монеты: &f" + session.coins[side], "&7Задать: /ag trade coins <сумма>"));
            inventory.setItem(24, button(Material.GOLD_NUGGET, "&6Монеты второй стороны: &f" + session.coins[1 - side], "&7Обмен будет завершён только после подтверждения обоих игроков."));
            inventory.setItem(22, button(Material.PAPER, "&eСостояние обмена",
                    "&7Вы: " + (session.ready[side] ? "&aготовы" : "&cне подтверждено"),
                    "&7Партнёр: " + (session.ready[1 - side] ? "&aготов" : "&cне подтверждено")));
            inventory.setItem(49, button(session.ready[side] ? Material.LIME_DYE : Material.GREEN_DYE,
                    session.ready[side] ? "&aВы подтвердили" : "&aПодтвердить обмен", "&7Изменение любого предложения сбросит оба подтверждения."));
            inventory.setItem(53, button(Material.RED_DYE, "&cОтменить обмен", "&7Все предметы вернутся владельцам."));
            inventory.setItem(45, button(Material.GRAY_STAINED_GLASS_PANE, "&8Предметы партнёра отображаются справа"));
            inventory.setItem(46, button(Material.GRAY_STAINED_GLASS_PANE, "&8Shift-клик по своему предмету добавляет его"));
            inventory.setItem(47, button(Material.GRAY_STAINED_GLASS_PANE, "&8Клик по своему лоту возвращает его"));
            inventory.setItem(48, button(Material.GRAY_STAINED_GLASS_PANE, "&8Выпавший лут из подземелий обменять нельзя"));
        }
    }

    private ItemStack button(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Hud.legacy(name));
            List<net.kyori.adventure.text.Component> lines = new ArrayList<>();
            for (String line : lore) lines.add(Hud.legacy(line));
            meta.lore(lines);
            item.setItemMeta(meta);
        }
        return item;
    }

    private boolean near(Player first, Player second) {
        return first.getWorld().equals(second.getWorld())
                && first.getLocation().distanceSquared(second.getLocation()) <= MAX_DISTANCE_SQUARED;
    }

    private void tell(Session session, String message) {
        for (UUID id : new UUID[]{session.first, session.second}) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) player.sendMessage(Hud.legacy(message));
        }
    }

    private void cancel(Player player, String message) {
        Session session = sessionsByPlayer.get(player.getUniqueId());
        if (session != null) {
            cancelSession(session, message);
            return;
        }
        UUID target = requestsBySender.remove(player.getUniqueId());
        if (target != null) {
            requestsByTarget.remove(target, player.getUniqueId());
            Player recipient = Bukkit.getPlayer(target);
            if (recipient != null) recipient.sendMessage(Hud.legacy("&7Запрос обмена отменён."));
        }
        UUID sender = requestsByTarget.remove(player.getUniqueId());
        if (sender != null) {
            requestsBySender.remove(sender, player.getUniqueId());
            Player requester = Bukkit.getPlayer(sender);
            if (requester != null) requester.sendMessage(Hud.legacy("&7Запрос обмена отменён."));
        }
        player.sendMessage(Hud.legacy(message));
    }

    private void cancelSession(Session session, String message) {
        if (session.closed) return;
        session.closed = true;
        returnOffers(session, 0);
        returnOffers(session, 1);
        for (UUID id : new UUID[]{session.first, session.second}) {
            sessionsByPlayer.remove(id, session);
            Inventory inventory = session.inventories.get(id);
            if (inventory != null) views.remove(inventory);
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                player.sendMessage(Hud.legacy(message));
                if (player.getOpenInventory().getTopInventory() == inventory) player.closeInventory();
            }
        }
    }

    private void finish(Session session) {
        if (session.closed) return;
        session.closed = true;
        for (UUID id : new UUID[]{session.first, session.second}) {
            sessionsByPlayer.remove(id, session);
            Inventory inventory = session.inventories.get(id);
            if (inventory != null) views.remove(inventory);
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.getOpenInventory().getTopInventory() == inventory) player.closeInventory();
        }
    }

    private void returnOffers(Session session, int side) {
        Player owner = Bukkit.getPlayer(session.member(side));
        if (owner == null) return;
        for (ItemStack item : session.items(side)) {
            Map<Integer, ItemStack> leftover = owner.getInventory().addItem(item.clone());
            for (ItemStack itemLeft : leftover.values()) {
                Item entity = owner.getWorld().dropItemNaturally(owner.getLocation(), itemLeft);
                entity.setOwner(owner.getUniqueId());
                entity.setPickupDelay(20);
            }
        }
        session.items(side).clear();
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        View view = views.get(event.getInventory());
        if (view != null && !view.session().closed) {
            cancelSession(view.session(), "&7Обмен отменён: окно было закрыто.");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        Session session = sessionsByPlayer.get(id);
        if (session != null) cancelSession(session, "&cОбмен отменён: игрок вышел.");
        cancel(event.getPlayer(), "&7Запрос обмена отменён: игрок вышел.");
    }

    public void shutdown() {
        for (Session session : new ArrayList<>(sessionsByPlayer.values())) {
            cancelSession(session, "&7Обмен отменён при выключении сервера.");
        }
        requestsByTarget.clear();
        requestsBySender.clear();
        views.clear();
    }
}
