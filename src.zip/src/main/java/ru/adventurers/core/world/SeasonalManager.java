package ru.adventurers.core.world;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;
import ru.adventurers.core.hud.Hud;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Сезонные модификаторы мира (раздел 26, вторая волна): одна неделя - жара, другая - туман.
 *
 * <p>Идея ровно та же, что у модификаторов подземелий (раздел 27.5), но применённая
 * ко всему миру и к другому промежутку: подземелье меняется за один заход, мир -
 * за неделю. Это самый дешёвый способ «добавить контент», потому что не добавляется
 * ни один новый блок, моб или данж - меняются множители к тому, что уже есть:
 *
 * <ul>
 *   <li><b>добыча</b> - множитель к запасу жил (жара сушит, дождь подкидывает угля);</li>
 *   <li><b>опыт профессий</b> - сезон ремесленника;</li>
 *   <li><b>урон и лечение</b> - жара бьёт по всем, прохлада лечит;</li>
 *   <li><b>голод и скорость</b> - в бурю идёшь медленнее и ешь чаще;</li>
 *   <li><b>награда за забег</b> - множитель к монетам подземелий.</li>
 * </ul>
 *
 * <p>Ключевое правило (как и у проклятий): у каждого сезона есть и плюс, и минус.
 * Сезон без минуса - это просто «неделя подарков», сезон без плюса - «неделя, когда
 * лучше не заходить». Тест проверяет оба условия.
 *
 * <p>Смена сезона считается от опорной даты в конфиге, а не от времени запуска
 * сервера: рестарт не должен сдвигать календарь, иначе игроки увидят смену сезона
 * после каждого обновления плагина.
 */
public final class SeasonalManager implements Listener {

    /**
     * Один сезон.
     *
     * @param id         идентификатор
     * @param name       название для игрока
     * @param yields     множитель запаса жил
     * @param profession множитель опыта профессий
     * @param damage     множитель урона по игрокам
     * @param healing    множитель лечения
     * @param hunger     множитель расхода голода (1.0 - как обычно)
     * @param speed      добавка к скорости (0.05 = +5%)
     * @param coins      множитель монет в подземельях
     */
    public record Season(String id, String name, double yields, double profession, double damage,
                         double healing, double hunger, double speed, double coins) {
    }

    private final AdventurersCore plugin;
    private final Map<String, Season> seasons = new LinkedHashMap<>();

    private boolean enabled = true;
    private int periodDays = 7;
    private long anchorMillis = 0;
    private boolean fixed;                 // фиксированный сезон (для проверки и ивентов)
    private String fixedId;

    private Season current;
    private String currentId;
    private BukkitTask task;

    public SeasonalManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    //  Загрузка
    // ---------------------------------------------------------------

    public void reload() {
        File file = plugin.getFiles().file("seasonal.yml");
        if (!file.exists()) {
            plugin.getFiles().save("seasonal.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        enabled = cfg.getBoolean("enabled", true);
        periodDays = Math.max(1, cfg.getInt("season.period-days", 7));
        anchorMillis = parseAnchor(cfg.getString("season.anchor", "2026-01-05"));
        fixed = cfg.getBoolean("season.fixed.enabled", false);
        fixedId = cfg.getString("season.fixed.id", "");

        seasons.clear();
        ConfigurationSection section = cfg.getConfigurationSection("seasons");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(id);
                if (s == null) {
                    continue;
                }
                Season season = new Season(id.toLowerCase(Locale.ROOT),
                        s.getString("name", id),
                        s.getDouble("yields", 1.0),
                        s.getDouble("profession-xp", 1.0),
                        s.getDouble("damage", 1.0),
                        s.getDouble("healing", 1.0),
                        s.getDouble("hunger", 1.0),
                        s.getDouble("speed", 0.0),
                        s.getDouble("coins", 1.0));
                if (!hasPlus(season) || !hasMinus(season)) {
                    plugin.getLogger().warning("Сезон " + id + ": нужен и плюс, и минус - пропущено");
                    continue;
                }
                seasons.put(season.id(), season);
            }
        }
        refresh();
        restart();
    }

    private static boolean hasPlus(Season s) {
        return s.yields() > 1 || s.profession() > 1 || s.healing() > 1 || s.speed() > 0
                || s.coins() > 1 || s.damage() < 1 || s.hunger() < 1;
    }

    private static boolean hasMinus(Season s) {
        return s.yields() < 1 || s.profession() < 1 || s.healing() < 1 || s.speed() < 0
                || s.coins() < 1 || s.damage() > 1 || s.hunger() > 1;
    }

    /** Опорная дата вида 2026-01-05 (UTC). Неверный формат - начало эпохи, то есть без сдвига. */
    private static long parseAnchor(String text) {
        if (text == null || text.isBlank()) {
            return 0;
        }
        try {
            return java.time.LocalDate.parse(text.trim())
                    .atStartOfDay(java.time.ZoneOffset.UTC).toInstant().toEpochMilli();
        } catch (RuntimeException exception) {
            return 0;
        }
    }

    public void shutdown() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }

    private void restart() {
        if (task != null) {
            task.cancel();
            task = null;
        }
        if (!enabled || seasons.isEmpty()) {
            current = null;
            return;
        }
        // раз в 5 минут: смена сезона не должна требовать рестарта
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::refresh, 20L * 60, 20L * 300);
    }

    // ---------------------------------------------------------------
    //  Текущий сезон
    // ---------------------------------------------------------------

    /** Номер сезона по календарю: (сейчас - опорная дата) / длина сезона. */
    long index(long now) {
        if (periodDays <= 0) {
            return 0;
        }
        long period = periodDays * 24L * 3_600_000L;
        return Math.floorDiv(now - anchorMillis, period);
    }

    /** Какой сезон выпадает на номер: список идёт по кругу. */
    Season seasonFor(long index) {
        if (seasons.isEmpty()) {
            return null;
        }
        List<Season> all = new ArrayList<>(seasons.values());
        int slot = (int) Math.floorMod(index, all.size());
        return all.get(slot);
    }

    /** Пересчитать текущий сезон. Вызывается по таймеру и при reload. */
    public void refresh() {
        if (!enabled || seasons.isEmpty()) {
            current = null;
            currentId = null;
            return;
        }
        Season next = fixed && seasons.containsKey(fixedId.toLowerCase(Locale.ROOT))
                ? seasons.get(fixedId.toLowerCase(Locale.ROOT))
                : seasonFor(index(System.currentTimeMillis()));
        if (next == null) {
            current = null;
            currentId = null;
            return;
        }
        boolean changed = currentId == null || !currentId.equals(next.id());
        current = next;
        currentId = next.id();
        if (changed) {
            announce();
        }
    }

    private void announce() {
        if (current == null) {
            return;
        }
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            player.sendMessage(Hud.legacy("&8──────────── &6Сезон мира &8────────────"));
            player.sendMessage(Hud.legacy("&6" + current.name()));
            for (String line : describe(current)) {
                player.sendMessage(Hud.legacy(line));
            }
            player.sendMessage(Hud.legacy("&8Сменится через: &7" + remaining()));
        }
    }

    /** Сколько осталось до смены сезона, по-человечески. */
    public String remaining() {
        long now = System.currentTimeMillis();
        long period = periodDays * 24L * 3_600_000L;
        long left = period - Math.floorMod(now - anchorMillis, period);
        long days = left / (24L * 3_600_000L);
        long hours = (left / 3_600_000L) % 24;
        return days > 0 ? days + " д " + hours + " ч" : hours + " ч";
    }

    /** Строки описания: плюсы зелёным, минусы красным, без изменений - серым. */
    public static List<String> describe(Season season) {
        List<String> lines = new ArrayList<>();
        add(lines, season.yields(), "Запас жил: ", (season.yields() - 1) * 100);
        add(lines, season.profession(), "Опыт профессий: ", (season.profession() - 1) * 100);
        add(lines, season.damage(), "Получаемый урон: ", (season.damage() - 1) * 100);
        add(lines, season.healing(), "Лечение: ", (season.healing() - 1) * 100);
        add(lines, season.hunger(), "Расход голода: ", (season.hunger() - 1) * 100);
        add(lines, season.coins(), "Монеты в подземельях: ", (season.coins() - 1) * 100);
        add(lines, 1.0 + season.speed(), "Скорость: ", season.speed() * 100);
        return lines;
    }

    private static void add(List<String> lines, double factor, String label, double percent) {
        if (Math.abs(factor - 1.0) < 0.005) {
            return;
        }
        // плюс - зелёным, минус - красным; направление видно по знаку процента
        String color = percent > 0 ? "&a" : "&c";
        lines.add(color + String.format(Locale.ROOT, "%+.0f%%", percent) + "&7 " + label);
    }

    // ---------------------------------------------------------------
    //  Доступ для остальных менеджеров
    // ---------------------------------------------------------------

    public boolean enabled() {
        return enabled && current != null;
    }

    public Season current() {
        return current;
    }

    public Map<String, Season> seasons() {
        return seasons;
    }

    /** Множитель запаса жил (жара сушит жилы, дождь подкидывает). */
    public double yieldsFactor() {
        return enabled() ? current.yields() : 1.0;
    }

    /** Множитель опыта профессий. */
    public double professionFactor() {
        return enabled() ? current.profession() : 1.0;
    }

    /** Множитель монет подземелий. */
    public double coinsFactor() {
        return enabled() ? current.coins() : 1.0;
    }

    /** Множитель урона по игрокам (сезон бьёт по всем, не только в данже). */
    public double damageFactor() {
        return enabled() ? current.damage() : 1.0;
    }

    /** Множитель лечения. */
    public double healingFactor() {
        return enabled() ? current.healing() : 1.0;
    }

    /** Итоговый множитель лечения для игрока: сезон × проклятия × подземелье. */
    public double healMultiplier(Player player) {
        double factor = healingFactor();
        if (plugin.getCurses() != null) {
            factor *= plugin.getCurses().healFactor(player);
        }
        if (plugin.getDungeons() != null) {
            factor *= plugin.getDungeons().healFactor(player);
        }
        return factor;
    }

    /** Состояние сезона для игрока: /ag season. */
    public void info(Player player) {
        if (!enabled || seasons.isEmpty()) {
            player.sendMessage(Hud.legacy("&7Сезоны мира выключены (seasonal.yml)."));
            return;
        }
        refresh();
        player.sendMessage(Hud.legacy("&8──────────── &6Сезон мира &8────────────"));
        player.sendMessage(Hud.legacy("&6" + current.name()));
        for (String line : describe(current)) {
            player.sendMessage(Hud.legacy(line));
        }
        player.sendMessage(Hud.legacy("&8Сменится через: &7" + remaining()));
    }

    /** Админская смена сезона до следующего перезапуска: /ag admin season <id>. */
    public boolean force(String id, org.bukkit.command.CommandSender sender) {
        Season season = seasons.get(id.toLowerCase(Locale.ROOT));
        if (season == null) {
            return false;
        }
        fixed = true;
        fixedId = season.id();
        current = season;
        currentId = season.id();
        announce();
        sender.sendMessage(Hud.legacy("&aСезон принудительно выставлен: &f" + season.name()
                + " &7(до /ag admin season reset)"));
        return true;
    }

    public void forceNone() {
        fixed = false;
        fixedId = "";
        refresh();
    }

    // ---------------------------------------------------------------
    //  События
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!enabled() || !(event.getEntity() instanceof Player player)) {
            return;
        }
        if (plugin.getDungeons() != null && plugin.getDungeons().inDungeon(player)) {
            return;   // внутри данжа работает модификатор забега, а не сезон мира
        }
        if (current.damage() != 1.0) {
            event.setDamage(event.getDamage() * current.damage());
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHeal(EntityRegainHealthEvent event) {
        if (!enabled() || current.healing() == 1.0 || !(event.getEntity() instanceof Player player)) {
            return;
        }
        if (plugin.getDungeons() != null && plugin.getDungeons().inDungeon(player)) {
            return;
        }
        event.setAmount(Math.max(0, event.getAmount() * current.healing()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHunger(FoodLevelChangeEvent event) {
        if (!enabled() || current.hunger() <= 1.0 || !(event.getEntity() instanceof Player)) {
            return;
        }
        // Усиливаем только потерю сытости: восполнение не трогаем.
        int before = ((Player) event.getEntity()).getFoodLevel();
        if (event.getFoodLevel() >= before) {
            return;
        }
        int loss = before - event.getFoodLevel();
        int extra = (int) Math.round(loss * (current.hunger() - 1.0));
        if (extra > 0) {
            event.setFoodLevel(Math.max(0, event.getFoodLevel() - extra));
        }
    }
}
