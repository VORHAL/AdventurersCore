package ru.adventurers.core.world;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDispenseLootEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.PiglinBarterEvent;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import ru.adventurers.core.AdventurersCore;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Правила мира: истощение жил (лимит ресурсов по чанкам) и вырезание брони из лута.
 * Настройки: world.yml. Состояние запасов хранится в world-data.yml. Только основной поток.
 */
public class WorldRulesManager implements Listener {

    private static final int PLACED_LIMIT = 60_000;
    private static final long SAVE_PERIOD_TICKS = 20L * 60 * 10;

    private static final class Pool {
        String id;
        String name;
        double capacity;
        double regenPerHour;
        boolean placeNoDrops;
    }

    private static final class Entry {
        double used;
        long time;
    }

    private final AdventurersCore plugin;

    private boolean resEnabled = true;
    private boolean explosions = true;
    private long warnMs = 20_000L;
    private final Map<String, Pool> pools = new LinkedHashMap<>();
    private final Map<Material, Pool> byMaterial = new EnumMap<>(Material.class);
    // "мир|cx|cz" -> категория -> запас
    private final Map<String, Map<String, Entry>> chunks = new HashMap<>();
    private final Set<String> placed = new LinkedHashSet<>();
    private final Map<UUID, Long> lastWarn = new HashMap<>();

    private boolean lootEnabled = true;
    private boolean lootChests = true;
    private boolean lootVaults = true;
    private boolean lootMobs = true;
    private boolean lootBarter = true;
    private boolean lootTrades = true;
    private final List<String> removeNames = new ArrayList<>();

    private BukkitTask saveTask;

    public WorldRulesManager(AdventurersCore plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    //  Запуск и настройки
    // ---------------------------------------------------------------

    public void init() {
        reload();
        loadData();
        saveTask = Bukkit.getScheduler().runTaskTimer(plugin, this::saveData, SAVE_PERIOD_TICKS, SAVE_PERIOD_TICKS);
    }

    public void shutdown() {
        if (saveTask != null) {
            saveTask.cancel();
        }
        saveData();
    }

    public void reload() {
        File file = plugin.getFiles().file("world.yml");
        if (!file.exists()) {
            plugin.getFiles().save("world.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);

        resEnabled = cfg.getBoolean("resources.enabled", true);
        explosions = cfg.getBoolean("resources.explosions", true);
        warnMs = Math.max(1, cfg.getInt("resources.warn-seconds", 20)) * 1000L;
        pools.clear();
        byMaterial.clear();
        ConfigurationSection section = cfg.getConfigurationSection("resources.pools");
        if (section != null) {
            for (String id : section.getKeys(false)) {
                ConfigurationSection s = section.getConfigurationSection(id);
                if (s == null) {
                    continue;
                }
                Pool pool = new Pool();
                pool.id = id;
                pool.name = s.getString("name", id);
                pool.capacity = Math.max(0, s.getDouble("capacity", 10));
                pool.regenPerHour = Math.max(0, s.getDouble("regen-per-hour", 1));
                pool.placeNoDrops = s.getBoolean("place-no-drops", true);
                pools.put(id, pool);
                for (String name : s.getStringList("blocks")) {
                    for (Material material : Material.values()) {
                        if (matches(name, material.name())) {
                            byMaterial.putIfAbsent(material, pool);
                        }
                    }
                }
            }
        }

        lootEnabled = cfg.getBoolean("loot-filter.enabled", true);
        lootChests = cfg.getBoolean("loot-filter.chests", true);
        lootVaults = cfg.getBoolean("loot-filter.vaults", true);
        lootMobs = cfg.getBoolean("loot-filter.mob-drops", true);
        lootBarter = cfg.getBoolean("loot-filter.piglin-barter", true);
        lootTrades = cfg.getBoolean("loot-filter.villager-trades", true);
        removeNames.clear();
        for (String name : cfg.getStringList("loot-filter.remove")) {
            removeNames.add(name.toUpperCase(Locale.ROOT));
        }
    }

    private static boolean matches(String pattern, String name) {
        String p = pattern.toUpperCase(Locale.ROOT);
        return p.startsWith("_") ? name.endsWith(p) : name.equals(p);
    }

    private boolean isRemoved(ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return false;
        }
        String name = item.getType().name();
        for (String pattern : removeNames) {
            if (matches(pattern, name)) {
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------
    //  Запасы чанков
    // ---------------------------------------------------------------

    private static String chunkKey(Block block) {
        return block.getWorld().getName() + "|" + (block.getX() >> 4) + "|" + (block.getZ() >> 4);
    }

    private static String blockKey(Block block) {
        return block.getWorld().getName() + "|" + block.getX() + "|" + block.getY() + "|" + block.getZ();
    }

    private double usedNow(Pool pool, Entry entry, long now) {
        double hours = Math.max(0, now - entry.time) / 3_600_000.0;
        return Math.max(0, entry.used - hours * pool.regenPerHour);
    }

    /** Запас жилы с учётом сезона мира (раздел 29): жара сушит, дождь подкидывает. */
    private double capacityOf(Pool pool) {
        double season = plugin.getSeasonal() == null ? 1.0 : plugin.getSeasonal().yieldsFactor();
        return Math.max(1, pool.capacity * season);
    }

    /** Тратит единицу запаса. false, если жила пуста. */
    private boolean consume(Pool pool, String chunk) {
        long now = System.currentTimeMillis();
        Map<String, Entry> map = chunks.computeIfAbsent(chunk, k -> new HashMap<>());
        Entry entry = map.computeIfAbsent(pool.id, k -> new Entry());
        double used = usedNow(pool, entry, now);
        if (used + 1.0 > capacityOf(pool) + 1e-9) {
            entry.used = used;
            entry.time = now;
            return false;
        }
        entry.used = used + 1.0;
        entry.time = now;
        return true;
    }

    private boolean exempt(Player player) {
        return player.getGameMode() != GameMode.SURVIVAL || player.hasPermission("ag.bypass.resources");
    }

    // ---------------------------------------------------------------
    //  Ресурсы: события
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!resEnabled) {
            return;
        }
        Pool pool = byMaterial.get(event.getBlockPlaced().getType());
        if (pool == null || !pool.placeNoDrops) {
            return;
        }
        if (placed.size() >= PLACED_LIMIT) {
            Iterator<String> it = placed.iterator();
            it.next();
            it.remove();
        }
        placed.add(blockKey(event.getBlockPlaced()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!resEnabled || exempt(event.getPlayer())) {
            return;
        }
        Block block = event.getBlock();
        Pool pool = byMaterial.get(block.getType());
        if (pool == null) {
            return;
        }
        if (placed.remove(blockKey(block))) {
            deplete(event, false);
            return;
        }
        if (!consume(pool, chunkKey(block))) {
            deplete(event, true);
            warn(event.getPlayer(), pool);
        }
    }

    private void deplete(BlockBreakEvent event, boolean tell) {
        event.setDropItems(false);
        event.setExpToDrop(0);
    }

    private void warn(Player player, Pool pool) {
        long now = System.currentTimeMillis();
        Long last = lastWarn.get(player.getUniqueId());
        if (last != null && now - last < warnMs) {
            return;
        }
        lastWarn.put(player.getUniqueId(), now);
        plugin.getMessages().send(player, "world.depleted", Map.of("res", pool.name));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent event) {
        filterExplosion(event.blockList());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        filterExplosion(event.blockList());
    }

    private void filterExplosion(List<Block> blocks) {
        if (!resEnabled || !explosions) {
            return;
        }
        Iterator<Block> it = blocks.iterator();
        while (it.hasNext()) {
            Block block = it.next();
            Pool pool = byMaterial.get(block.getType());
            if (pool != null && !consume(pool, chunkKey(block))) {
                it.remove();
            }
        }
    }

    // ---------------------------------------------------------------
    //  Лут: события
    // ---------------------------------------------------------------

    @EventHandler(priority = EventPriority.HIGH)
    public void onLoot(LootGenerateEvent event) {
        if (lootEnabled && lootChests) {
            event.getLoot().removeIf(this::isRemoved);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onVault(BlockDispenseLootEvent event) {
        if (lootEnabled && lootVaults) {
            List<ItemStack> list = new ArrayList<>(event.getDispensedLoot());
            list.removeIf(this::isRemoved);
            event.setDispensedLoot(list);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onMobDeath(EntityDeathEvent event) {
        if (lootEnabled && lootMobs && !(event.getEntity() instanceof Player)) {
            event.getDrops().removeIf(this::isRemoved);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBarter(PiglinBarterEvent event) {
        if (lootEnabled && lootBarter) {
            event.getOutcome().removeIf(this::isRemoved);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTrade(VillagerAcquireTradeEvent event) {
        if (lootEnabled && lootTrades && isRemoved(event.getRecipe().getResult())) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------
    //  Админка: /ag admin resources [reset [all]]
    // ---------------------------------------------------------------

    public void info(Player player) {
        Location loc = player.getLocation();
        Block block = loc.getBlock();
        String chunk = chunkKey(block);
        long now = System.currentTimeMillis();
        Map<String, Entry> map = chunks.getOrDefault(chunk, Map.of());
        plugin.getMessages().send(player, "world.info-header", Map.of(
                "x", block.getX() >> 4, "z", block.getZ() >> 4));
        for (Pool pool : pools.values()) {
            Entry entry = map.get(pool.id);
            double used = entry == null ? 0 : usedNow(pool, entry, now);
            plugin.getMessages().send(player, "world.info-line", Map.of(
                    "res", pool.name,
                    "left", fmt(Math.max(0, capacityOf(pool) - used)),
                    "cap", fmt(capacityOf(pool)),
                    "regen", fmt(pool.regenPerHour)));
        }
    }

    public void reset(CommandSender sender, boolean all, Player player) {
        if (all) {
            chunks.clear();
        } else if (player != null) {
            chunks.remove(chunkKey(player.getLocation().getBlock()));
        }
        plugin.getMessages().send(sender, "world.reset-ok");
    }

    private static String fmt(double value) {
        return value == Math.floor(value) ? String.valueOf((long) value) : String.format(Locale.US, "%.1f", value);
    }

    // ---------------------------------------------------------------
    //  Сохранение
    // ---------------------------------------------------------------

    private void loadData() {
        File file = plugin.getFiles().file("world-data.yml");
        if (!file.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        for (String line : cfg.getStringList("chunks")) {
            String[] parts = line.split("\\|");
            if (parts.length != 6) {
                continue;
            }
            try {
                String chunk = parts[0] + "|" + parts[1] + "|" + parts[2];
                Entry entry = new Entry();
                entry.used = Double.parseDouble(parts[4]);
                entry.time = Long.parseLong(parts[5]);
                chunks.computeIfAbsent(chunk, k -> new HashMap<>()).put(parts[3], entry);
            } catch (NumberFormatException ignored) {
                // битая строка - пропускаем
            }
        }
    }

    private void saveData() {
        long now = System.currentTimeMillis();
        List<String> lines = new ArrayList<>();
        Iterator<Map.Entry<String, Map<String, Entry>>> chunkIt = chunks.entrySet().iterator();
        while (chunkIt.hasNext()) {
            Map.Entry<String, Map<String, Entry>> chunk = chunkIt.next();
            Iterator<Map.Entry<String, Entry>> it = chunk.getValue().entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Entry> e = it.next();
                Pool pool = pools.get(e.getKey());
                double used = pool == null ? 0 : usedNow(pool, e.getValue(), now);
                if (used < 0.05) {
                    it.remove();
                    continue;
                }
                lines.add(chunk.getKey() + "|" + e.getKey() + "|" + String.format(Locale.US, "%.3f", used) + "|" + now);
            }
            if (chunk.getValue().isEmpty()) {
                chunkIt.remove();
            }
        }
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("chunks", lines);
        try {
            cfg.save(plugin.getFiles().file("world-data.yml"));
        } catch (IOException exception) {
            plugin.getLogger().warning("Could not save world-data.yml: " + exception.getMessage());
        }
    }
}
