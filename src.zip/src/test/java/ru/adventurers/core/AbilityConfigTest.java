package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;
import ru.adventurers.core.profile.Rank;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Способности по рангу (раздел 22 отчёта): F - 1 умение, E/D - 2, C - 3, с B - ультимейт.
 *
 * <p>Тест читает abilities.yml так же, как AbilityManager, и проверяет главное:
 * <ul>
 *   <li>в наборе каждого класса ровно 4 умения и первое открыто с F;</li>
 *   <li>лестница открытий монотонная: ни один ранг не теряет умение по сравнению с предыдущим;</li>
 *   <li>число умений на рангах совпадает с задуманным (1/2/2/3/4/4/4/4);</li>
 *   <li>ультимейт открывается не раньше B и у него есть настройки в разделе ultimates;</li>
 *   <li>ранг нельзя купить: в donate.yml RANK в запрещённых, в season-pass нет reward rank:</li>
 * </ul>
 */
class AbilityConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = AbilityConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Map<String, Object>> abilities() {
        return (Map<String, Map<String, Object>>) resource("abilities.yml").get("abilities");
    }

    /** Лестница: ранг -> сколько умений открыто (по самому полному набору). */
    private static Map<Rank, Integer> ladder(String classId) {
        Map<String, Object> set = abilities().get(classId);
        Map<Rank, Integer> ladder = new LinkedHashMap<>();
        for (Rank rank : Rank.values()) {
            int count = 0;
            for (Object value : set.values()) {
                String unlock = String.valueOf(((Map<String, Object>) value).get("unlock-rank"));
                Rank required = Rank.fromInput(unlock);
                if (required == null || rank.ordinal() >= required.ordinal()) {
                    count++;
                }
            }
            ladder.put(rank, count);
        }
        return ladder;
    }

    @Test
    void everyClassHasFourAbilitiesStartingAtF() {
        Map<String, Map<String, Object>> abilities = abilities();
        Assertions.assertTrue(abilities.size() >= 4, "наборов умений должно быть минимум 4: " + abilities.keySet());
        for (Map.Entry<String, Map<String, Object>> entry : abilities.entrySet()) {
            Map<String, Object> set = entry.getValue();
            Assertions.assertEquals(4, set.size(),
                    "у класса " + entry.getKey() + " должно быть 4 умения (3 базовых + ультимейт)");
            long atF = set.values().stream()
                    .map(value -> (Map<String, Object>) value)
                    .filter(value -> "F".equals(String.valueOf(value.get("unlock-rank"))))
                    .count();
            Assertions.assertEquals(1, atF, "у класса " + entry.getKey() + " с F открыто ровно одно умение");
            for (Map.Entry<String, Object> ability : set.entrySet()) {
                Map<String, Object> value = (Map<String, Object>) ability.getValue();
                Assertions.assertNotNull(value.get("name"), entry.getKey() + "." + ability.getKey() + ": нет названия");
                Assertions.assertNotNull(Rank.fromInput(String.valueOf(value.get("unlock-rank"))),
                        entry.getKey() + "." + ability.getKey() + ": неизвестный ранг "
                                + value.get("unlock-rank"));
            }
        }
    }

    @Test
    void ladderMatchesTheDesign() {
        Map<Rank, Integer> expected = new LinkedHashMap<>();
        expected.put(Rank.F, 1);
        expected.put(Rank.E, 2);
        expected.put(Rank.D, 2);
        expected.put(Rank.C, 3);
        expected.put(Rank.B, 4);
        expected.put(Rank.A, 4);
        expected.put(Rank.A_PLUS, 4);
        expected.put(Rank.S, 4);
        for (String classId : abilities().keySet()) {
            Assertions.assertEquals(expected, ladder(classId), "лестница умений класса " + classId
                    + " не совпадает с задуманной F-1, E/D-2, C-3, B+-4");
        }
    }

    @Test
    void ladderNeverGoesDown() {
        for (String classId : abilities().keySet()) {
            Map<Rank, Integer> ladder = ladder(classId);
            int previous = 0;
            for (Map.Entry<Rank, Integer> step : ladder.entrySet()) {
                Assertions.assertTrue(step.getValue() >= previous,
                        classId + ": на ранге " + step.getKey() + " умений меньше, чем на предыдущем");
                previous = step.getValue();
            }
        }
    }

    @Test
    void ultimatesOpenFromBAndHaveSettings() {
        Map<String, Object> cfg = resource("abilities.yml");
        Map<String, Map<String, Object>> ultimates = (Map<String, Map<String, Object>>) cfg.get("ultimates");
        Assertions.assertNotNull(ultimates, "в abilities.yml нет раздела ultimates");
        for (Map.Entry<String, Map<String, Object>> entry : abilities().entrySet()) {
            String classId = entry.getKey();
            for (Map.Entry<String, Object> ability : entry.getValue().entrySet()) {
                Map<String, Object> value = (Map<String, Object>) ability.getValue();
                Rank unlock = Rank.fromInput(String.valueOf(value.get("unlock-rank")));
                boolean ultimate = unlock != null && unlock.ordinal() >= Rank.B.ordinal();
                if (!ultimate) {
                    continue;
                }
                Map<String, Object> settings = ultimates.getOrDefault(classId, Map.of())
                        .entrySet().stream()
                        .filter(e -> e.getKey().equals(ability.getKey()))
                        .map(e -> (Map<String, Object>) e.getValue())
                        .findFirst().orElse(null);
                Assertions.assertNotNull(settings,
                        "у ультимейта " + classId + "." + ability.getKey() + " нет настроек в ultimates");
                Assertions.assertTrue(settings.containsKey("cooldown-seconds"),
                        "ультимейт " + classId + "." + ability.getKey() + " без кулдауна");
                int cooldown = ((Number) settings.get("cooldown-seconds")).intValue();
                Assertions.assertTrue(cooldown >= 100,
                        "ультимейт не должен жаться чаще, чем раз в 100 секунд: " + cooldown);
            }
        }
    }

    @Test
    void rankCannotBeBought() {
        Map<String, Object> donate = resource("donate.yml");
        Map<String, Object> rules = (Map<String, Object>) donate.get("rules");
        List<String> forbidden = (List<String>) rules.get("forbidden");
        Assertions.assertTrue(forbidden.contains("RANK"),
                "ранг должен быть в списке запрещённых к продаже, иначе умения можно купить");
        Assertions.assertEquals(Boolean.FALSE, rules.get("server-access-for-sale"),
                "доступ на сервер не продаётся");
        String raw;
        try (InputStream in = AbilityConfigTest.class.getClassLoader().getResourceAsStream("donate.yml")) {
            raw = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
        Assertions.assertFalse(raw.contains("reward: \"rank:"),
                "в сезонном пропуске не должно быть наград-рангов");
    }

    @Test
    void hintsExistSoLockedAbilityDoesNotLookLikeBug() {
        Map<String, Object> cfg = resource("abilities.yml");
        Map<String, Object> hints = (Map<String, Object>) cfg.get("hints");
        Assertions.assertNotNull(hints, "нет раздела hints: игрок не поймёт, почему кнопка не работает");
        Assertions.assertTrue(String.valueOf(hints.get("locked")).contains("{rank}"),
                "подсказка о закрытом умении должна называть ранг");
        Assertions.assertTrue(String.valueOf(hints.get("locked")).contains("{ability}"),
                "подсказка о закрытом умении должна называть умение");
    }
}
