package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * S-ранг и Мир Избранных (раздел 23 отчёта).
 *
 * <p>Что проверяется и почему именно это:
 * <ul>
 *   <li>мир открывается не раньше 5 игроков с S-рангом - иначе первый дошедший
 *       заходит один, умирает на первой волне и решает, что контент сломан;</li>
 *   <li>вход только с S: ранг нельзя купить, значит и мир нельзя купить;</li>
 *   <li>за волны не платят монетами - только осколками на косметику, иначе
 *       экономика раздела 15 поедет;</li>
 *   <li>HP волны растёт так, что забег занимает 10-20 минут, а не 55;</li>
 *   <li>моб на волне не жирнее босса подземелья своего ранга (иначе это стена).</li>
 * </ul>
 */
class AscendedConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> cfg(String name) {
        try (InputStream in = AscendedConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    /** Урон группы S в секунду: из модели раздела 14 (босс S 8 000 HP за 2.5 мин). */
    private static final double GROUP_DPS = 53;

    @Test
    void gateOpensOnlyForFiveSRankPlayers() {
        Map<String, Object> gate = (Map<String, Object>) cfg("ascended.yml").get("gate");
        int required = ((Number) gate.get("required-s-rank")).intValue();
        Assertions.assertEquals(5, required,
                "мир должен открываться после 5 игроков с S-рангом, а не " + required);
        Assertions.assertEquals(Boolean.TRUE, gate.get("announce"),
                "об открытии мира надо объявить в чат: это событие сервера");
        Assertions.assertTrue(String.valueOf(gate.get("hint-locked")).contains("{have}"),
                "подсказка должна показывать, сколько S-игроков уже есть");
    }

    @Test
    void entryRequiresSRankAndRunsAreLimited() {
        Map<String, Object> limits = (Map<String, Object>) cfg("ascended.yml").get("limits");
        Assertions.assertEquals("S", String.valueOf(limits.get("min-rank")),
                "вход в Мир Избранных только с S-ранга");
        int runs = ((Number) limits.get("runs-per-day")).intValue();
        Assertions.assertTrue(runs >= 1 && runs <= 10, "заходов в сутки должно быть 1-10, а не " + runs);
        int group = ((Number) limits.get("group-size")).intValue();
        Assertions.assertTrue(group >= 2 && group <= 10, "группа 2-10 человек, а не " + group);
    }

    @Test
    void wavesArePacedByTheDamageModel() {
        Map<String, Object> waves = (Map<String, Object>) cfg("ascended.yml").get("waves");
        double growth = ((Number) waves.get("hp-growth")).doubleValue();
        double bossMult = ((Number) waves.get("boss-hp-multiplier")).doubleValue();
        double baseHp = ((Number) waves.get("base-hp")).doubleValue();
        int count = ((Number) waves.get("waves-per-run")).intValue();
        int bossEvery = ((Number) waves.get("boss-every")).intValue();
        int pause = ((Number) waves.get("pause-seconds")).intValue();
        Assertions.assertTrue(growth > 1.0 && growth <= 1.20,
                "рост HP за волну должен быть 1.0-1.20, иначе последняя волна - стена: " + growth);

        double fightSeconds = 0;
        for (int wave = 1; wave <= count; wave++) {
            double hp = baseHp * Math.pow(growth, wave - 1);
            if (bossEvery > 0 && wave % bossEvery == 0) {
                hp *= bossMult;
            }
            double seconds = hp / GROUP_DPS;
            Assertions.assertTrue(seconds <= 240,
                    "волна " + wave + " длится " + Math.round(seconds) + " с - это стена, а не волна");
            fightSeconds += seconds;
        }
        double runMinutes = (fightSeconds + pause * count) / 60.0;
        Assertions.assertTrue(runMinutes >= 10 && runMinutes <= 20,
                "забег должен занимать 10-20 минут, а не " + String.format("%.1f", runMinutes));
    }

    @Test
    void singleMobIsNotTankierThanARankBoss() {
        Map<String, Object> waves = (Map<String, Object>) cfg("ascended.yml").get("waves");
        double baseHp = ((Number) waves.get("base-hp")).doubleValue();
        double growth = ((Number) waves.get("hp-growth")).doubleValue();
        double bossMult = ((Number) waves.get("boss-hp-multiplier")).doubleValue();
        int maxMobs = ((Number) waves.get("max-mobs-per-wave")).intValue();
        int count = ((Number) waves.get("waves-per-run")).intValue();
        int bossEvery = ((Number) waves.get("boss-every")).intValue();
        // босс подземелья S - 8 000 HP (раздел 14); моб волны не должен его догонять
        for (int wave = 1; wave <= count; wave++) {
            boolean boss = bossEvery > 0 && wave % bossEvery == 0;
            double total = baseHp * Math.pow(growth, wave - 1) * (boss ? bossMult : 1.0);
            double perMob = total / maxMobs;
            Assertions.assertTrue(perMob <= 8000,
                    "на волне " + wave + " один моб жирнее босса подземелья S: " + Math.round(perMob));
        }
    }

    @Test
    void rewardsAreShardsNotCoins() {
        Map<String, Object> rewards = (Map<String, Object>) cfg("ascended.yml").get("rewards");
        Assertions.assertNull(rewards.get("coins"),
                "за волны нельзя платить монетами: это ломает экономику раздела 15");
        Assertions.assertNull(rewards.get("coins-base"), "монет в наградах Избранных быть не должно");
        double shards = ((Number) rewards.get("shards-base")).doubleValue();
        double growth = ((Number) rewards.get("shards-growth")).doubleValue();
        int bossShards = ((Number) rewards.get("shards-boss")).intValue();
        Map<String, Object> waves = (Map<String, Object>) cfg("ascended.yml").get("waves");
        int count = ((Number) waves.get("waves-per-run")).intValue();
        int bossEvery = ((Number) waves.get("boss-every")).intValue();
        double total = 0;
        for (int wave = 1; wave <= count; wave++) {
            total += shards + (wave - 1) * growth;
            if (bossEvery > 0 && wave % bossEvery == 0) {
                total += bossShards;
            }
        }
        Assertions.assertTrue(total >= 60 && total <= 130,
                "осколков за забег " + Math.round(total) + ": титул должен браться за 1-2 забега");
    }

    @Test
    void worldIsSafeForAGroup() {
        Map<String, Object> world = (Map<String, Object>) cfg("ascended.yml").get("world");
        Assertions.assertEquals(Boolean.FALSE, world.get("pvp"),
                "в Мире Избранных PvP выключен: это PvE-испытание");
        Assertions.assertEquals(18000, ((Number) world.get("time")).intValue(),
                "в мире всегда ночь: так задумано по атмосфере");
        int radius = ((Number) world.get("platform-radius")).intValue();
        Assertions.assertTrue(radius >= 40 && radius <= 100,
                "площадка должна вмещать группу из 5 и волну мобов: " + radius);
    }
}
