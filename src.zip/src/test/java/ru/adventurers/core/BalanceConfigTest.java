package ru.adventurers.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.*;
import java.util.Comparator;

/**
 * Тесты конфигов на сходимость баланса. Запускаются при mvn test/package,
 * поэтому сломанная правка YAML или невыполнимое условие ранга валят сборку.
 */
class BalanceConfigTest {

    private static final List<String> RANKS = List.of("F", "E", "D", "C", "B", "A", "A+", "S");

    @SuppressWarnings("unchecked")
    private Map<String, Object> load(String name) {
        try (InputStream in = getClass().getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Object get(Map<String, Object> root, String path) {
        Object cur = root;
        for (String part : path.split("\\.")) {
            Assertions.assertTrue(((Map<String, Object>) cur).containsKey(part), "нет ключа " + path);
            cur = ((Map<String, Object>) cur).get(part);
        }
        return cur;
    }

    /** Потолок профессии на ранге должен позволять выполнить требование ранга. */
    @Test
    @SuppressWarnings("unchecked")
    void professionCapAllowsRankRequirements() {
        Map<String, Object> ranks = load("ranks.yml");
        Map<String, Object> caps = (Map<String, Object>) get(load("professions.yml"), "level-cap-by-rank");
        Map<String, Object> promotions = (Map<String, Object>) get(ranks, "promotions");
        promotions.forEach((rank, value) -> {
            int needed = ((Number) ((Map<String, Object>) value).getOrDefault("profession-level", 0)).intValue();
            int cap = ((Number) caps.get(rank)).intValue();
            Assertions.assertTrue(cap >= needed,
                    "ранг " + rank + ": нужен уровень " + needed + ", потолок " + cap + " - ранг непроходим");
        });
    }

    /**
     * Ранг не должен закрываться за один день только очками.
     *
     * <p>Дневной доход - это средний день: 5 заданий ранга (доска выдаёт 5 в день,
     * поэтому сумма ВСЕХ заданий пула в разы больше дневного дохода).
     * Средний день дополнительно ограничен сверху: самый дорогой день (5 самых
     * дорогих заданий) тоже должен быть меньше требования ранга.
     */
    @Test
    @SuppressWarnings("unchecked")
    void rankPointsOutrunDailyQuestIncome() {
        Map<String, List<Integer>> byRank = new HashMap<>();
        for (Object entry : (List<Object>) get(load("quests.yml"), "quests")) {
            Map<String, Object> quest = (Map<String, Object>) entry;
            byRank.computeIfAbsent((String) quest.get("rank"), key -> new ArrayList<>())
                    .add(((Number) quest.get("points")).intValue());
        }
        Map<String, Object> promotions = (Map<String, Object>) get(load("ranks.yml"), "promotions");
        promotions.forEach((rank, value) -> {
            int needed = ((Number) ((Map<String, Object>) value).get("points")).intValue();
            List<Integer> points = byRank.getOrDefault(rank, List.of());
            Assertions.assertFalse(points.isEmpty(), "ранг " + rank + ": нет заданий этого ранга");
            double averageDay = points.stream().mapToInt(Integer::intValue).average().orElse(0) * 5;
            List<Integer> sorted = new ArrayList<>(points);
            sorted.sort(Comparator.reverseOrder());
            int bestDay = sorted.stream().limit(5).mapToInt(Integer::intValue).sum();
            Assertions.assertTrue(needed > averageDay,
                    "ранг " + rank + ": нужно " + needed + " очков при среднем дне " + Math.round(averageDay));
            Assertions.assertTrue(needed > bestDay,
                    "ранг " + rank + ": нужно " + needed + " очков, а лучший день даёт " + bestDay);
        });
    }

    /** Магазин не должен продавать дешевле цены скупки (иначе бесконечные деньги). */
    @Test
    @SuppressWarnings("unchecked")
    void shopNeverUndercutsSellPrices() {
        Map<String, Object> sell = (Map<String, Object>) get(load("economy.yml"), "sell.prices");
        Map<String, Object> categories = (Map<String, Object>) get(load("shop.yml"), "categories");
        for (Object category : categories.values()) {
            for (Object good : (List<Object>) ((Map<String, Object>) category).get("goods")) {
                Map<String, Object> item = (Map<String, Object>) good;
                String id = (String) item.get("item");
                Object sellPrice = sell.get(id);
                if (sellPrice == null) {
                    continue;
                }
                double unit = ((Number) item.get("price")).doubleValue() / ((Number) item.get("amount")).doubleValue();
                double ratio = unit / ((Number) sellPrice).doubleValue();
                Assertions.assertTrue(ratio >= 1.5,
                        id + ": магазин " + ratio + "x от скупки - возможен арбитраж");
            }
        }
    }

    /** Награды за вторжения растут вместе с рангом. */
    @Test
    @SuppressWarnings("unchecked")
    void invasionRewardsGrowWithRank() {
        Map<String, Object> tiers = (Map<String, Object>) get(load("invasions.yml"), "tiers");
        int previous = 0;
        for (String rank : RANKS) {
            Map<String, Object> tier = (Map<String, Object>) tiers.get(rank);
            Assertions.assertNotNull(tier, "нет уровня вторжения " + rank);
            int coins = ((Number) tier.get("coins")).intValue();
            Assertions.assertTrue(coins >= previous, "вторжение " + rank + " платит меньше предыдущего");
            previous = coins;
        }
        Assertions.assertEquals(0, previous - ((Number) ((Map<String, Object>) tiers.get("S")).get("coins")).intValue());
    }

    /**
     * Вторжение - «повод зайти сегодня», а не источник монет: награда минус плата за вход
     * должна давать 1-3 дня дохода ранга. Без платы на F награда почти равнялась дневному
     * доходу при двух попытках на игрока - портал был бесконечным станком.
     */
    @Test
    @SuppressWarnings("unchecked")
    void invasionPaysAboutTwoDays() {
        Map<String, Object> income = (Map<String, Object>)
                ((Map<String, Object>) load("economy.yml")).get("rank-income");
        Map<String, Object> tiers = (Map<String, Object>)
                ((Map<String, Object>) load("invasions.yml")).get("tiers");
        for (Map.Entry<String, Object> entry : tiers.entrySet()) {
            String rank = entry.getKey();
            Map<String, Object> tier = (Map<String, Object>) entry.getValue();
            long coins = ((Number) tier.get("coins")).longValue();
            long cost = tier.get("cost") instanceof Number value ? value.longValue() : 0;
            double daily = ((Number) income.get(rank)).doubleValue();
            double days = (coins - cost) / daily;
            Assertions.assertTrue(cost > 0, "вторжение " + rank + ": вход бесплатный - портал печатает монеты");
            Assertions.assertTrue(days >= 1.0 && days <= 3.0,
                    "вторжение " + rank + ": чистая награда " + (coins - cost) + " = " + String.format("%.2f", days)
                            + " дня дохода (нужно 1-3)");
            Assertions.assertTrue(cost < coins, "вторжение " + rank + ": вход дороже награды");
        }
    }

    /** Все материалы из shop.yml существуют в Paper 1.21.11 (проверяется по списку API). */
    @Test
    @SuppressWarnings("unchecked")
    void shopMaterialsExist() {
        Set<String> materials = new java.util.HashSet<>();
        for (org.bukkit.Material material : org.bukkit.Material.values()) {
            materials.add(material.name());
        }
        Map<String, Object> categories = (Map<String, Object>) get(load("shop.yml"), "categories");
        for (Object category : categories.values()) {
            for (Object good : (List<Object>) ((Map<String, Object>) category).get("goods")) {
                String id = (String) ((Map<String, Object>) good).get("item");
                Assertions.assertTrue(materials.contains(id), "магазин продаёт несуществующий предмет " + id);
            }
        }
    }

    /** Тестовое подземелье должно быть проходимым: лут и награды заданы. */
    @Test
    @SuppressWarnings("unchecked")
    void dungeonTestHasRewards() {
        Map<String, Object> dungeon = load("dungeons/test.yml");
        Map<String, Object> rewards = (Map<String, Object>) dungeon.get("rewards");
        Assertions.assertTrue(((Number) rewards.get("coins")).intValue() > 0);
        Assertions.assertTrue(((Number) rewards.get("points")).intValue() > 0);
        Assertions.assertFalse(((List<Object>) rewards.get("loot")).isEmpty(), "нет таблицы лута");
    }
}
