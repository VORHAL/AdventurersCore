package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Контракты гильдии как источник прогресса.
 *
 * <p>Ловит две вещи, которые нельзя увидеть глазами в конфиге:
 * <ul>
 *   <li>пропуск на одиночный заход в подземелье раньше выдавал только админ
 *       (в коде {@code grantSoloPass} вызывался лишь из админской команды), то есть
 *       условие {@code solo.requires-pass} запирало одиночную игру для всех;</li>
 *   <li>контракт с целью, которой нет в игре, невозможно закрыть - счётчик молча стоит.</li>
 * </ul>
 */
class ContractConfigTest {

    private static final List<String> LADDER = List.of("F", "E", "D", "C", "B", "A", "A+", "S");

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = ContractConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> contracts() {
        return (List<Map<String, Object>>) resource("contracts.yml").get("contracts");
    }

    /** На каждом ранге должен быть хотя бы один способ получить пропуск в подземелье. */
    @Test
    void everyRankCanEarnSoloPass() {
        Map<String, Integer> best = new LinkedHashMap<>();
        for (Map<String, Object> contract : contracts()) {
            int passes = contract.get("passes") instanceof Number n ? n.intValue() : 0;
            if (passes <= 0) {
                continue;
            }
            String band = String.valueOf(contract.get("rank"));
            best.merge(band, passes, Math::max);
        }
        for (String band : List.of("F", "C", "B", "A", "S")) {
            Assertions.assertTrue(best.containsKey(band),
                    "на полосе рангов " + band + " нет контракта с пропуском в подземелье: "
                            + "одиночный заход недоступен");
            Assertions.assertTrue(best.get(band) >= 1, "пропуск на " + band + " нулевой");
        }
    }

    /**
     * Пропуск не должен быть дороже, чем одно подземелье: недельный контракт на 40-60 убийств
     * даёт один пропуск, месячный - 2-4. Если пропусков больше, чем подземелий в контракте,
     * игрок просто копит их и перестаёт ходить с группой.
     */
    @Test
    void soloPassesAreScarce() {
        // На A/A+ месячные контракты требуют 10-20 заходов, поэтому недельный может дать 2.
        Map<String, Integer> capacity = Map.of("WEEKLY", 2, "MONTHLY", 4, "RARE", 3);
        for (Map<String, Object> contract : contracts()) {
            int passes = contract.get("passes") instanceof Number n ? n.intValue() : 0;
            if (passes <= 0) {
                continue;
            }
            String period = String.valueOf(contract.get("period"));
            Assertions.assertTrue(passes <= capacity.get(period),
                    "контракт " + contract.get("id") + " (" + period + ") даёт " + passes
                            + " пропусков - больше потолка " + capacity.get(period));
        }
    }

    /** Полосы рангов в контрактах должны покрывать всю лестницу, иначе на ранге пусто. */
    @Test
    void contractBandsCoverLadder() {
        Map<String, Integer> weekly = new LinkedHashMap<>();
        for (Map<String, Object> contract : contracts()) {
            if (!"WEEKLY".equals(String.valueOf(contract.get("period")))) {
                continue;
            }
            weekly.merge(String.valueOf(contract.get("rank")), 1, Integer::sum);
        }
        for (String band : List.of("F", "C", "B", "A", "S")) {
            Assertions.assertTrue(weekly.getOrDefault(band, 0) >= 8,
                    "недельных контрактов на полосе " + band + ": " + weekly.getOrDefault(band, 0)
                            + ", нужно минимум 8 (иначе недели повторяются)");
        }
    }

    /** max-rank не может быть ниже rank: такой контракт не увидит никто. */
    @Test
    void rankBandsAreValid() {
        for (Map<String, Object> contract : contracts()) {
            Object max = contract.get("max-rank");
            if (max == null) {
                continue;
            }
            int from = LADDER.indexOf(String.valueOf(contract.get("rank")));
            int to = LADDER.indexOf(String.valueOf(max));
            Assertions.assertTrue(from >= 0, contract.get("id") + ": неизвестный ранг " + contract.get("rank"));
            Assertions.assertTrue(to >= 0, contract.get("id") + ": неизвестный max-rank " + max);
            Assertions.assertTrue(to >= from, contract.get("id") + ": max-rank выше rank");
        }
    }

    /** Цели контрактов: тип из списка игры, количество больше нуля, награда есть. */
    @Test
    void contractTargetsAreSane() {
        Set<String> types = Set.of("KILL", "DUNGEON", "QUEST", "DELIVER");
        Set<String> dungeonTargets = Set.of("ANY", "HEROIC", "RAID");
        List<String> problems = new ArrayList<>();
        for (Map<String, Object> contract : contracts()) {
            String id = String.valueOf(contract.get("id"));
            String type = String.valueOf(contract.get("type"));
            if (!types.contains(type)) {
                problems.add(id + ": неизвестный тип " + type);
                continue;
            }
            if (type.equals("DUNGEON") && !dungeonTargets.contains(String.valueOf(contract.get("target")))) {
                problems.add(id + ": для DUNGEON цель должна быть ANY/HEROIC/RAID");
            }
            if (!(contract.get("amount") instanceof Number amount) || amount.intValue() <= 0) {
                problems.add(id + ": количество не задано");
            }
            boolean reward = (contract.get("coins") instanceof Number coins && coins.longValue() > 0)
                    || (contract.get("points") instanceof Number points && points.intValue() > 0);
            if (!reward) {
                problems.add(id + ": нет награды");
            }
        }
        Assertions.assertTrue(problems.isEmpty(), String.join("\n", problems));
    }

    /**
     * Награда контракта должна быть заметна на фоне заданий того же ранга:
     * недельный контракт - не меньше дневного дохода очков, иначе его никто не берёт.
     */
    @Test
    @SuppressWarnings("unchecked")
    void contractRewardsBeatDailyQuests() {
        Map<String, Object> quests = resource("quests.yml");
        Map<String, Integer> totalPoints = new LinkedHashMap<>();
        Map<String, Integer> count = new LinkedHashMap<>();
        for (Object raw : (List<Object>) quests.get("quests")) {
            Map<String, Object> quest = (Map<String, Object>) raw;
            String rank = String.valueOf(quest.get("rank"));
            count.merge(rank, 1, Integer::sum);
            totalPoints.merge(rank, ((Number) quest.get("points")).intValue(), Integer::sum);
        }
        List<String> problems = new ArrayList<>();
        for (Map<String, Object> contract : contracts()) {
            if (!"WEEKLY".equals(String.valueOf(contract.get("period")))) {
                continue;
            }
            String band = String.valueOf(contract.get("rank"));
            String rank = band.equals("F") ? "F" : band;
            double daily = totalPoints.getOrDefault(rank, 0) / (double) Math.max(1, count.getOrDefault(rank, 1)) * 5;
            int points = contract.get("points") instanceof Number n ? n.intValue() : 0;
            int limit = "F".equals(band) ? 15 : 40;
            if (points < limit) {
                problems.add(contract.get("id") + ": " + points + " очков - меньше " + limit
                        + " (дневной доход ранга " + Math.round(daily) + ")");
            }
        }
        Assertions.assertTrue(problems.isEmpty(), "недельные контракты почти не дают очков:\n"
                + String.join("\n", problems));
    }
}
