package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Проверки ковенантов: экономика, уровни, цели недели и то, что все игровые события
 * (задания, подземелья, контракты, вклады) вообще попадают в рейтинг.
 *
 * <p>Главная ловушка, которую эти тесты ловят: конфиг выглядит нормально, а событие
 * нигде не вызывается - тогда рейтинг недели молча пустой.
 */
class CovenantConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = CovenantConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    /** Дневной доход по рангам (economy.yml rank-income): от него считаем сроки. */
    @SuppressWarnings("unchecked")
    private static Map<String, Long> income() {
        Map<String, Long> map = new LinkedHashMap<>();
        Map<String, Object> raw = (Map<String, Object>) resource("economy.yml").get("rank-income");
        raw.forEach((rank, value) -> map.put(rank, ((Number) value).longValue()));
        return map;
    }

    /**
     * Основание ковенанта должно быть по карману на минимальном ранге, но не бесплатным:
     * 1-3 дня игры одному (или пара часов на группу).
     */
    @Test
    @SuppressWarnings("unchecked")
    void createCostFitsEarliestAllowedRank() {
        Map<String, Object> create = (Map<String, Object>) resource("covenants.yml").get("create");
        long cost = ((Number) create.get("cost")).longValue();
        String rank = String.valueOf(create.get("min-rank"));
        long daily = income().getOrDefault(rank, 0L);
        Assertions.assertTrue(daily > 0, "в economy.yml rank-income нет ранга " + rank);
        double days = cost / (double) daily;
        Assertions.assertTrue(days >= 1.0, "основание стоит " + cost + " при доходе " + daily
                + "/день: это меньше дня игры, слишком дёшево (" + days + ")");
        Assertions.assertTrue(days <= 20.0, "основание стоит " + cost + " при доходе " + daily
                + "/день: копить " + Math.round(days) + " дней - слишком долго для входа в ковенанты");
    }

    /** Земли: первый участок доступен, последний - цель на сезон, а не на вечер. */
    @Test
    @SuppressWarnings("unchecked")
    void territoryPricesScaleLikeARankLadder() {
        Map<String, Object> sizes = (Map<String, Object>)
                ((Map<String, Object>) resource("covenants.yml").get("territory")).get("sizes");
        Assertions.assertTrue(sizes.size() >= 4, "нужно минимум 4 размера участка");
        long previousPrice = 0;
        int previousSide = 0;
        int previousLevel = 0;
        long first = -1;
        long last = -1;
        for (Map.Entry<String, Object> entry : sizes.entrySet()) {
            Map<String, Object> size = (Map<String, Object>) entry.getValue();
            long price = ((Number) size.get("price")).longValue();
            int side = ((Number) size.get("side")).intValue();
            int level = ((Number) size.get("level")).intValue();
            Assertions.assertTrue(side > previousSide, "размер " + entry.getKey() + ": сторона не растёт");
            Assertions.assertTrue(price > previousPrice, "размер " + entry.getKey() + ": цена не растёт");
            Assertions.assertTrue(level >= previousLevel, "размер " + entry.getKey() + ": уровень падает");
            // Цена за блок должна расти: большие участки не должны быть выгоднее на блок.
            double perBlock = price / (double) (side * side);
            if (previousSide > 0) {
                double previousPerBlock = previousPrice / (double) (previousSide * previousSide);
                Assertions.assertTrue(perBlock >= previousPerBlock * 0.95,
                        "размер " + entry.getKey() + ": цена за блок падает - все будут брать самый большой");
            }
            if (first < 0) {
                first = price;
            }
            last = price;
            previousPrice = price;
            previousSide = side;
            previousLevel = level;
        }
        // Первый участок: 5 игроков на E копят его за несколько вечеров (доход ковенанта x5).
        long dailyTeam = income().get("E") * 5;
        Assertions.assertTrue(first / (double) dailyTeam <= 10,
                "первый участок стоит " + first + ", а ковенант из 5 игроков на E зарабатывает "
                        + dailyTeam + " в день: копить больше 10 дней");
        Assertions.assertTrue(last > first * 20, "цитадель должна быть целью на сезон, а не вторым апгрейдом");
    }

    /** Уровни ковенанта: растут, лимит участников растёт, верхний уровень достижим за сезон. */
    @Test
    @SuppressWarnings("unchecked")
    void levelsGrowAndStayReachable() {
        List<Object> levels = (List<Object>) resource("covenants.yml").get("levels");
        Assertions.assertTrue(levels.size() >= 4, "нужно минимум 4 уровня ковенанта");
        long previousContributed = -1;
        int previousMembers = 0;
        for (Object entryRaw : levels) {
            Map<String, Object> level = (Map<String, Object>) entryRaw;
            long contributed = ((Number) level.get("contributed")).longValue();
            int members = ((Number) level.get("members")).intValue();
            Assertions.assertTrue(contributed > previousContributed, "порог уровня не растёт");
            Assertions.assertTrue(members > previousMembers, "лимит участников не растёт");
            previousContributed = contributed;
            previousMembers = members;
        }
        // Верхний уровень: 5 игроков на B вкладывают ~половину дохода -> не дольше сезона (150 дней).
        long topRequirement = previousContributed;
        long teamDaily = income().get("B") / 2 * 5;
        long days = topRequirement / teamDaily;
        Assertions.assertTrue(days <= 150, "верхний уровень требует " + topRequirement
                + " вкладов, это " + days + " дней даже для пятерых на B - больше сезона");
    }

    /** Цели недели: все типы, которые умеет код, и награды скромнее наград рейтинга. */
    @Test
    @SuppressWarnings("unchecked")
    void weeklyGoalsUseSupportedTypes() {
        Map<String, Object> weekly = (Map<String, Object>) resource("covenants.yml").get("weekly");
        List<Object> goals = (List<Object>) weekly.get("goals");
        Assertions.assertTrue(goals.size() >= 4, "целей недели должно быть несколько, иначе недели одинаковые");
        List<String> supported = List.of("DEPOSIT", "DUNGEON", "QUEST", "CONTRACT", "POINTS");
        Map<String, Integer> seen = new HashMap<>();
        for (Object goalRaw : goals) {
            Map<String, Object> goal = (Map<String, Object>) goalRaw;
            String type = String.valueOf(goal.get("type"));
            Assertions.assertTrue(supported.contains(type), "цель типа " + type + " код не умеет считать");
            Assertions.assertTrue(((Number) goal.get("target")).longValue() > 0, "цель " + type + " без цели");
            Assertions.assertTrue(((Number) goal.get("reward")).longValue() > 0, "цель " + type + " без награды");
            Assertions.assertTrue(String.valueOf(goal.get("name")).contains("{target}"),
                    "в названии цели " + type + " нет {target} - игрок не увидит, сколько нужно");
            seen.merge(type, 1, Integer::sum);
        }
        for (String type : supported) {
            Assertions.assertTrue(seen.containsKey(type), "нет цели типа " + type + ": недели будут повторяться");
        }
        List<Long> rewards = new ArrayList<>();
        for (Object value : (List<Object>) weekly.get("rewards")) {
            rewards.add(((Number) value).longValue());
        }
        Assertions.assertTrue(rewards.get(0) > rewards.get(1) && rewards.get(1) > rewards.get(2),
                "награды топ-3 должны убывать");
        // Первое место не должно быть больше месячного дохода ковенанта из 5 человек на E.
        long monthIncome = income().get("E") * 30;
        Assertions.assertTrue(rewards.get(0) <= monthIncome,
                "награда за первое место " + rewards.get(0) + " больше месячного дохода ковенанта (" + monthIncome + ")");
    }

    /**
     * Каждое событие, за которое дают очки, должно вызываться из кода.
     * Проверяем по исходникам: если кто-то уберёт вызов, тест упадёт.
     */
    @Test
    void everyScoreEventIsWired() throws Exception {
        java.nio.file.Path src = java.nio.file.Path.of("src/main/java/ru/adventurers/core");
        Assertions.assertTrue(src.toFile().isDirectory(), "нет каталога исходников: " + src.toAbsolutePath());
        String quest = src.resolve("quest/QuestManager.java").toFile().exists()
                ? java.nio.file.Files.readString(src.resolve("quest/QuestManager.java")) : "";
        String dungeon = java.nio.file.Files.readString(src.resolve("dungeon/DungeonManager.java"));
        String contract = java.nio.file.Files.readString(src.resolve("contract/ContractManager.java"));
        String covenant = java.nio.file.Files.readString(src.resolve("covenant/CovenantManager.java"));
        Assertions.assertTrue(quest.contains("questDone("), "задания не дают очков ковенанту");
        Assertions.assertTrue(dungeon.contains("dungeonCleared("), "подземелья не дают очков ковенанту");
        Assertions.assertTrue(contract.contains("contractDone("), "контракты не дают очков ковенанту");
        Assertions.assertTrue(covenant.contains("weekly.deposited("), "вклады в казну не дают очков");
    }

    /** Банк: вкладки открываются по уровню, цена растёт, прав на снятие не больше, чем на просмотр. */
    @Test
    @SuppressWarnings("unchecked")
    void bankTabsAreOrderedAndSafe() {
        Map<String, Object> bank = (Map<String, Object>) resource("covenants.yml").get("bank");
        Map<String, Object> tabs = (Map<String, Object>) bank.get("tabs");
        Assertions.assertTrue(tabs.size() <= 6, "в коде максимум 6 вкладок (Covenant.TABS)");
        List<String> order = List.of("MEMBER", "OFFICER", "LEADER");
        long previousPrice = -1;
        int previousLevel = 0;
        boolean first = true;
        for (Map.Entry<String, Object> entry : tabs.entrySet()) {
            Map<String, Object> tab = (Map<String, Object>) entry.getValue();
            long price = ((Number) tab.get("price")).longValue();
            int level = ((Number) tab.get("level")).intValue();
            String view = String.valueOf(tab.get("view"));
            String deposit = String.valueOf(tab.get("deposit"));
            String withdraw = String.valueOf(tab.get("withdraw"));
            if (!first) {
                Assertions.assertTrue(price > previousPrice, "вкладка " + entry.getKey() + ": цена не растёт");
                Assertions.assertTrue(level >= previousLevel, "вкладка " + entry.getKey() + ": уровень падает");
            }
            // Снимать может не больше прав, чем смотреть.
            Assertions.assertTrue(order.indexOf(withdraw) >= order.indexOf(view),
                    "вкладка " + entry.getKey() + ": снимать может " + withdraw + ", а видеть " + view);
            Assertions.assertTrue(order.indexOf(deposit) >= order.indexOf(view),
                    "вкладка " + entry.getKey() + ": класть может " + deposit + ", а видеть " + view);
            first = false;
            previousPrice = price;
            previousLevel = level;
        }
    }
}
