package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Проклятые предметы (раздел 28): сила в обмен на цену.
 *
 * <p>Bukkit в тестах не поднят, поэтому проверяется не поведение в игре, а то, что
 * можно проверить на файлах: у каждого проклятия есть и плюс, и минус, минус не
 * «бесплатный» и не смертельный, шанс и ранг осмысленны, а зелье снятия вообще
 * существует в рецептах. Логика описания лора перенесена сюда построчно из
 * {@code CursedGear.describe} - если в коде добавят новый параметр и забудут
 * про лор, тест это не поймает, поэтому в списке ниже перечислены все поля.
 */
class CursedGearTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = CursedGearTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new AssertionError("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Map<String, Object>> curses() {
        Object raw = resource("cursed.yml").get("curses");
        Assertions.assertTrue(raw instanceof Map, "нет раздела curses в cursed.yml");
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : ((Map<?, ?>) raw).entrySet()) {
            out.put(String.valueOf(entry.getKey()), (Map<String, Object>) entry.getValue());
        }
        return out;
    }

    private static double num(Map<String, Object> map, String key, double fallback) {
        return map.get(key) instanceof Number n ? n.doubleValue() : fallback;
    }

    private static boolean hasPlus(Map<String, Object> curse) {
        return num(curse, "attack-damage", 0) > 0 || num(curse, "armor", 0) > 0
                || num(curse, "move-speed", 0) > 0 || num(curse, "heal-factor", 1) > 1;
    }

    private static boolean hasMinus(Map<String, Object> curse) {
        return num(curse, "attack-damage", 0) < 0 || num(curse, "armor", 0) < 0
                || num(curse, "move-speed", 0) < 0 || num(curse, "taken", 1) > 1
                || num(curse, "heal-factor", 1) < 1 || num(curse, "hunger-seconds", 0) > 0;
    }

    @Test
    void everyCurseHasPlusAndMinus() {
        Map<String, Map<String, Object>> all = curses();
        Assertions.assertTrue(all.size() >= 5, "мало проклятий: " + all.size());
        for (Map.Entry<String, Map<String, Object>> entry : all.entrySet()) {
            Assertions.assertTrue(hasPlus(entry.getValue()),
                    entry.getKey() + ": только минус - такое никто не наденет");
            Assertions.assertTrue(hasMinus(entry.getValue()),
                    entry.getKey() + ": только плюс - это не проклятие, а подарок");
            Assertions.assertNotNull(entry.getValue().get("name"), entry.getKey() + ": нет названия для лора");
        }
    }

    @Test
    void curseIsPainfulButNotSuicidal() {
        for (Map.Entry<String, Map<String, Object>> entry : curses().entrySet()) {
            String id = entry.getKey();
            Map<String, Object> curse = entry.getValue();
            double taken = num(curse, "taken", 1);
            double heal = num(curse, "heal-factor", 1);
            double speed = num(curse, "move-speed", 0);
            double armor = num(curse, "armor", 0);
            double damage = num(curse, "attack-damage", 0);
            // +35% получаемого урона - потолок: выше этого предмет уже не «риск», а мусор.
            Assertions.assertTrue(taken >= 1.0 && taken <= 1.35, id + ": taken вне 1.00-1.35");
            // Лечение не режем ниже половины: лекарь должен оставаться полезным.
            Assertions.assertTrue(heal >= 0.5 && heal <= 1.4, id + ": heal-factor вне 0.50-1.40");
            // Скорость в пределах ±15%: иначе телеграф непроходим или тривиален.
            Assertions.assertTrue(speed >= -0.15 && speed <= 0.15, id + ": move-speed вне ±15%");
            // Плюс не больше 6 брони и 5 урона: проклятая вещь не должна заменять весь сет.
            Assertions.assertTrue(armor >= -3 && armor <= 6, id + ": armor вне -3..6");
            Assertions.assertTrue(damage >= -2 && damage <= 5, id + ": attack-damage вне -2..5");
            int hunger = (int) num(curse, "hunger-seconds", 0);
            Assertions.assertTrue(hunger == 0 || hunger >= 10,
                    id + ": голод чаще раза в 10 секунд - это не цена, а издевательство");
        }
    }

    @Test
    void cursedChanceAndRankAreSane() {
        Map<String, Object> root = resource("cursed.yml");
        Assertions.assertEquals(Boolean.TRUE, root.get("enabled"), "проклятия должны быть включены по умолчанию");
        @SuppressWarnings("unchecked")
        Map<String, Object> settings = (Map<String, Object>) root.get("cursed");
        Assertions.assertNotNull(settings);
        double chance = num(settings, "chance", 0);
        // 5-25%: реже - никто не увидит, чаще - перестанет быть событием.
        Assertions.assertTrue(chance >= 0.05 && chance <= 0.25, "chance вне 5-25%: " + chance);
        String minRank = String.valueOf(settings.get("min-rank"));
        Assertions.assertTrue(List.of("C", "B", "A", "A+", "S").contains(minRank),
                "min-rank должен быть не ниже C, иначе проклятия придут новичку: " + minRank);
        int refresh = (int) num(settings, "refresh-ticks", 0);
        Assertions.assertTrue(refresh >= 5 && refresh <= 40, "refresh-ticks вне 5-40: " + refresh);
    }

    @Test
    void uncursingPotionExistsInRecipes() {
        @SuppressWarnings("unchecked")
        Map<String, Object> recipes = (Map<String, Object>) resource("recipes.yml").get("recipes");
        Assertions.assertNotNull(recipes, "нет раздела recipes");
        Object raw = recipes.get("uncursing");
        Assertions.assertTrue(raw instanceof Map, "нет рецепта uncursing - снять проклятие будет нечем");
        @SuppressWarnings("unchecked")
        Map<String, Object> recipe = (Map<String, Object>) raw;
        Assertions.assertEquals("ALCHEMIST", String.valueOf(recipe.get("profession")));
        Assertions.assertTrue(((Number) recipe.getOrDefault("level", 0)).intValue() >= 1);
        Assertions.assertTrue(recipe.get("in") instanceof List, "у рецепта нет ингредиентов");
    }

    @Test
    void curseNamesAreUniqueAndIdSafe() {
        List<String> names = new ArrayList<>();
        for (Map.Entry<String, Map<String, Object>> entry : curses().entrySet()) {
            String id = entry.getKey();
            Assertions.assertTrue(id.matches("[a-z][a-z0-9_]{2,20}"),
                    "id проклятия должен набираться с руки (для /ag admin gear curse): " + id);
            String name = String.valueOf(entry.getValue().get("name"));
            Assertions.assertFalse(names.contains(name), "два проклятия с одним названием: " + name);
            names.add(name);
        }
    }

    /**
     * Балансная проверка: сумма всех плюсов и минусов по «весу».
     * Урон и броня в одних единицах не живут, поэтому считаем грубо: 1 урон = 2 очка,
     * 1 броня = 1 очко, 10% скорости = 1.5, 10% лечения = 1.5, 10% получаемого урона = -2.
     * Проклятие с весом ниже 1 - почти бесплатное усиление, выше 6 - невыгодное.
     */
    @Test
    void curseWeightsStayInBand() {
        for (Map.Entry<String, Map<String, Object>> entry : curses().entrySet()) {
            Map<String, Object> curse = entry.getValue();
            double weight = num(curse, "attack-damage", 0) * 2
                    + num(curse, "armor", 0)
                    + num(curse, "move-speed", 0) / 0.10 * 1.5
                    + (num(curse, "heal-factor", 1) - 1) / 0.10 * 1.5
                    + (num(curse, "taken", 1) - 1) / 0.10 * -2
                    + (num(curse, "hunger-seconds", 0) > 0 ? -2 : 0);
            Assertions.assertTrue(weight >= 0.5 && weight <= 6.0,
                    entry.getKey() + ": вес " + String.format("%.1f", weight) + " вне 0.5-6.0"
                            + " (ниже - подарок, выше - никто не возьмёт)");
        }
    }
}
