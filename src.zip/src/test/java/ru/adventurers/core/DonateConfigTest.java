package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;
import ru.adventurers.core.donate.DonateManager;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * Донат без pay2win (раздел 20 отчёта). Главное требование задачи звучало жёстко:
 * «без pay2win». Поэтому здесь проверяется не «красиво ли в конфиге», а что
 * магазин физически не может продать силу:
 *
 * <ul>
 *   <li>в donate.yml нет ни одного товара с запрещённым эффектом (урон, здоровье,
 *       броня, скорость, ранг, очки, ступени испытаний);</li>
 *   <li>каналы донат-бустов ограничены белым списком, каналов силы в нём нет;</li>
 *   <li>любой процент буста не больше max-power-percent (10%), иначе он бы стал силой;</li>
 *   <li>монет в одной покупке не больше max-coins-per-purchase;</li>
 *   <li>цены магазина - в самоцветах, самоцветы не конвертируются в монеты;</li>
 *   <li>сезонный пропуск не выдаёт доступ на сервер (в нём только косметика и монеты).</li>
 * </ul>
 */
class DonateConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = DonateConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> allOffers(Map<String, Object> cfg) {
        List<Map<String, Object>> offers = new java.util.ArrayList<>();
        Map<String, Object> boosts = (Map<String, Object>) cfg.get("server-boosts");
        boosts.values().forEach(value -> offers.add((Map<String, Object>) value));
        Map<String, Object> cosmetics = (Map<String, Object>) cfg.get("cosmetics");
        for (Object section : cosmetics.values()) {
            ((Map<String, Object>) section).values().forEach(value -> offers.add((Map<String, Object>) value));
        }
        Map<String, Object> comfort = (Map<String, Object>) cfg.get("comfort");
        comfort.values().forEach(value -> offers.add((Map<String, Object>) value));
        return offers;
    }

    @Test
    void shopHasSomethingToSellAndIsEnabled() {
        Map<String, Object> cfg = resource("donate.yml");
        Assertions.assertEquals(Boolean.TRUE, cfg.get("enabled"), "donate.yml: магазин должен быть включён");
        List<Map<String, Object>> offers = allOffers(cfg);
        Assertions.assertTrue(offers.size() >= 15, "товаров слишком мало: " + offers.size());
        for (Map<String, Object> offer : offers) {
            Assertions.assertNotNull(offer.get("price"), "у товара нет цены: " + offer);
            Assertions.assertTrue(((Number) offer.get("price")).longValue() > 0, "цена должна быть > 0");
        }
    }

    @Test
    void noForbiddenEffectsAreSold() {
        Map<String, Object> cfg = resource("donate.yml");
        Map<String, Object> rules = (Map<String, Object>) cfg.get("rules");
        List<String> forbidden = (List<String>) rules.get("forbidden");
        Assertions.assertTrue(forbidden.contains("DAMAGE") && forbidden.contains("HEALTH")
                && forbidden.contains("RANK"), "в правилах должны быть запрещены сила и ранг");

        String raw;
        try (InputStream in = DonateConfigTest.class.getClassLoader().getResourceAsStream("donate.yml")) {
            raw = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
        // проверяем только сами товары: от раздела boosts до раздела правил
        int from = raw.indexOf("boosts:");
        int to = raw.indexOf("\nrules:");
        Assertions.assertTrue(from > 0 && to > from, "donate.yml: не найдены разделы boosts/rules");
        String body = raw.substring(from, to);
        // каждое поле вида "ключ: значение" проверяем отдельно: комментарии выше
        // перечисляют запрещённые эффекты словами, и это не должно считаться продажей
        for (String line : body.split("\n")) {
            String clean = line.trim();
            if (clean.startsWith("#") || !clean.contains(":")) {
                continue;
            }
            String key = clean.substring(0, clean.indexOf(':')).trim().toLowerCase();
            if (key.equals("icon") || key.equals("applies-to") || key.equals("channel")) {
                continue;   // название предмета и канал эффекта не продают силу
            }
            String value = clean.substring(clean.indexOf(':') + 1).trim().toUpperCase();
            for (String effect : forbidden) {
                Assertions.assertFalse(value.contains(effect),
                        "в товарах магазина найден запрещённый эффект " + effect + ": " + clean);
            }
        }
    }

    @Test
    void boostsStayWithinPowerLimit() {
        Map<String, Object> cfg = resource("donate.yml");
        Map<String, Object> rules = (Map<String, Object>) cfg.get("rules");
        int maxPercent = ((Number) rules.get("max-power-percent")).intValue();
        // 50% допустимы только потому, что ускоритель общий для всех игроков сервера:
        // покупатель не получает преимущества перед остальными, окно просто идёт всем
        Assertions.assertTrue(maxPercent <= 50, "лимит серверного окна не может быть больше 50%");
        Map<String, Object> boosts = (Map<String, Object>) cfg.get("server-boosts");
        Assertions.assertFalse(boosts.isEmpty(), "нет ни одного серверного ускорителя");
        for (Map.Entry<String, Object> entry : boosts.entrySet()) {
            Map<String, Object> boost = (Map<String, Object>) entry.getValue();
            int percent = ((Number) boost.getOrDefault("percent", 0)).intValue();
            Assertions.assertTrue(Math.abs(percent) <= maxPercent,
                    "ускоритель " + entry.getKey() + " слишком сильный: " + percent + "%");
            String channel = String.valueOf(boost.get("channel"));
            Assertions.assertTrue(DonateManager.allowedChannel(channel),
                    "ускоритель " + entry.getKey() + " действует на запрещённый канал " + channel);
            Assertions.assertTrue(((Number) boost.get("minutes")).intValue() > 0,
                    "ускоритель " + entry.getKey() + " должен быть ограничен по времени");
            Assertions.assertTrue(String.valueOf(boost.get("desc")).contains("Всем"),
                    "ускоритель " + entry.getKey() + " обязан действовать на всех игроков сервера");
        }
        // личных числовых бустов быть не должно: очки и монеты покупают силу
        Assertions.assertNull(cfg.get("boosts"),
                "личные бусты (boosts) запрещены: они дают покупателю преимущество");
    }

    @Test
    void coinsInShopAreCapped() {
        Map<String, Object> cfg = resource("donate.yml");
        Map<String, Object> rules = (Map<String, Object>) cfg.get("rules");
        long cap = ((Number) rules.get("max-coins-per-purchase")).longValue();
        Assertions.assertTrue(cap <= 24000, "монет в покупке слишком много: " + cap);
        Assertions.assertEquals(0, ((Number) rules.get("max-coins-per-purchase")).longValue(),
                "за настоящие деньги монеты не продаются вообще");
        Map<String, Object> pass = (Map<String, Object>) cfg.get("season-pass");
        for (String branch : List.of("free-rewards", "paid-rewards")) {
            List<Map<String, Object>> steps = (List<Map<String, Object>>) pass.get(branch);
            Assertions.assertNotNull(steps, "нет ветки " + branch);
            for (Map<String, Object> step : steps) {
                Object reward = String.valueOf(step.get("reward"));
                if (reward.toString().startsWith("coins:")) {
                    long coins = Long.parseLong(reward.toString().substring("coins:".length()));
                    Assertions.assertTrue(coins <= cap, "в пропуске слишком много монет: " + coins);
                }
                Assertions.assertFalse(reward.toString().startsWith("rank:"),
                        "пропуск не должен выдавать ранг");
                Assertions.assertFalse(reward.toString().startsWith("access:"),
                        "пропуск не должен продавать доступ на сервер");
            }
        }
    }

    @Test
    void welcomeBonusIsSmallAndCurrencyIsSeparate() {
        Map<String, Object> cfg = resource("donate.yml");
        Map<String, Object> currency = (Map<String, Object>) cfg.get("currency");
        int welcome = ((Number) currency.get("welcome")).intValue();
        Assertions.assertTrue(welcome > 0 && welcome <= 30,
                "приветственные самоцветы должны хватать на мелочь, но не на всё: " + welcome);
        Map<String, Object> economy = resource("economy.yml");
        Assertions.assertNull(economy.get("gems"),
                "самоцветы не должны попадать в economy.yml: иначе их можно будет обменять на монеты");
    }

    @Test
    void comfortIsAlsoReachableWithoutPaying() {
        Map<String, Object> cfg = resource("donate.yml");
        Map<String, Object> comfort = (Map<String, Object>) cfg.get("comfort");
        // «удобство» - это ускорение, а не доступ: каждый товар должен иметь лимит
        // и должен дублироваться бесплатным путём (это записано в комментарии к разделу)
        for (Map.Entry<String, Object> entry : comfort.entrySet()) {
            Map<String, Object> item = (Map<String, Object>) entry.getValue();
            int limit = ((Number) item.getOrDefault("limit", 1)).intValue();
            Assertions.assertTrue(limit >= 1 && limit <= 3,
                    "у удобства " + entry.getKey() + " должен быть лимит 1..3, а не бесконечность");
        }
    }
}
