package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Проверки подземелий и рейдов: шаблон рейда D должен быть рабочим конфигом,
 * а не «файлом для вида».
 *
 * <p>Проверяется: рейд действительно рейдовый (type, состав, недельный локаут),
 * доступен с D, комнаты не выходят за границы шаблона, триггеры и точки волн
 * внутри карты, у боссов есть фазы, награды не выше дневного дохода ранга,
 * и рейдовый лут не обесценивает подземный.
 */
class DungeonConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = DungeonConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    private static Map<String, Object> dungeon(String id) {
        return resource("dungeons/" + id + ".yml");
    }

    @SuppressWarnings("unchecked")
    private static List<Integer> ints(Object raw) {
        List<Integer> list = new ArrayList<>();
        for (Object value : (List<Object>) raw) {
            list.add(((Number) value).intValue());
        }
        return list;
    }

    /** Рейд D должен быть ровно тем, что ждёт код: type raid, 10 игроков, 2+2 роли. */
    @Test
    @SuppressWarnings("unchecked")
    void raidTemplateIsRealRaid() {
        Map<String, Object> raid = dungeon("crypt_d");
        Assertions.assertEquals("raid", String.valueOf(raid.get("type")), "type должен быть raid");
        Assertions.assertEquals("D", String.valueOf(raid.get("min-rank")), "первый рейд должен быть с D");
        Map<String, Object> players = (Map<String, Object>) raid.get("players");
        Assertions.assertEquals(10, ((Number) players.get("min")).intValue());
        Assertions.assertEquals(10, ((Number) players.get("max")).intValue());
        Map<String, Object> require = (Map<String, Object>) raid.get("require");
        Assertions.assertTrue(((Number) require.get("tanks")).intValue() >= 1, "у рейда должны быть танки");
        Assertions.assertTrue(((Number) require.get("healers")).intValue() >= 1, "у рейда должны быть лекари");
        // Рейд - недельный контент: 7 дней локаута и в обычном, и в героическом режиме.
        Assertions.assertEquals(7, ((Number) raid.get("lockout-days")).intValue());
        Map<String, Object> heroic = (Map<String, Object>) raid.get("heroic");
        Assertions.assertEquals(7, ((Number) heroic.get("lockout-days")).intValue());
        Assertions.assertEquals("D", String.valueOf(heroic.get("min-rank")), "героик рейда тоже должен быть с D");
    }

    /** Встроенные подземелья: id файла -> из него же берутся проверки. */
    private static final List<String> BUILTIN = List.of("test", "archive_e", "mines_d", "crypt_d",
            "cathedral_c", "raid_crimson_c", "forge_b", "spire_a", "abyss_ap", "throne_s");

    /**
     * Бой должен длиться: босс живёт хотя бы полминуты на группе своего ранга,
     * а мобы заметно толще обычного моба. Раньше числа были в 5-10 раз меньше,
     * и босс умирал за 10-20 секунд (см. tools/dungeon_encounters.py).
     */
    @Test
    @SuppressWarnings("unchecked")
    void bossesSurviveLongerThanAGlance() {
        Map<String, Double> weapon = Map.of("F", 5.0, "E", 6.0, "D", 7.5, "C", 9.0,
                "B", 11.0, "A", 13.0, "A+", 15.0, "S", 17.0);
        Map<String, Double> minBossHp = Map.of("F", 2000.0, "E", 2500.0, "D", 3000.0, "C", 3500.0,
                "B", 4500.0, "A", 5500.0, "A+", 6500.0, "S", 7500.0);
        for (String id : BUILTIN) {
            Map<String, Object> def = dungeon(id);
            String rank = String.valueOf(def.get("min-rank"));
            double health = ((Number) def.get("mob-health")).doubleValue();
            Assertions.assertTrue(health >= 1.5,
                    id + ": mob-health " + health + " - мобы почти не толще обычных");
            Map<String, Object> rooms = (Map<String, Object>) def.get("rooms");
            // Промежуточные боссы (рейд, многоэтапные подземелья) намеренно слабее финального:
            // им положено 50-60% HP финального, финальному - полная норма ранга.
            List<Map<String, Object>> bosses = new ArrayList<>();
            for (Map.Entry<String, Object> entry : rooms.entrySet()) {
                Map<String, Object> boss = (Map<String, Object>)
                        ((Map<String, Object>) entry.getValue()).get("boss");
                if (boss != null) {
                    bosses.add(boss);
                }
            }
            for (int index = 0; index < bosses.size(); index++) {
                Map<String, Object> boss = bosses.get(index);
                boolean last = index == bosses.size() - 1;
                double need = minBossHp.getOrDefault(rank, 2000.0) * (last ? 1.0 : 0.5);
                double hp = ((Number) boss.get("health")).doubleValue();
                Assertions.assertTrue(hp >= need,
                        id + "/босс " + (index + 1) + ": " + hp + " HP при ранге " + rank
                                + ", нужно минимум " + need + " - группа убьёт его быстрее, чем за полминуты");
                Assertions.assertTrue(boss.get("damage") != null,
                        id + "/босс " + (index + 1) + ": у босса нет урона");
                Assertions.assertTrue(((Number) boss.get("damage")).doubleValue() > 0,
                        id + "/босс " + (index + 1) + ": урон босса 0");
            }
        }
    }

    /** Всё, что расставляет комнаты, должно лежать внутри pos1..pos2. */
    @Test
    @SuppressWarnings("unchecked")
    void roomsFitInsideTemplate() {
        for (String id : BUILTIN) {
            Map<String, Object> def = dungeon(id);
            Map<String, Object> template = (Map<String, Object>) def.get("template");
            List<Integer> pos1 = ints(template.get("pos1"));
            List<Integer> pos2 = ints(template.get("pos2"));
            int[] min = new int[3];
            int[] max = new int[3];
            for (int axis = 0; axis < 3; axis++) {
                min[axis] = Math.min(pos1.get(axis), pos2.get(axis));
                max[axis] = Math.max(pos1.get(axis), pos2.get(axis));
            }
            Map<String, Object> rooms = (Map<String, Object>) def.get("rooms");
            Assertions.assertNotNull(rooms, id + ": нет комнат");
            for (Map.Entry<String, Object> entry : rooms.entrySet()) {
                Map<String, Object> room = (Map<String, Object>) entry.getValue();
                checkPoint(id + "/" + entry.getKey() + " trigger", room.get("trigger"), min, max);
                if (room.get("at") != null) {
                    checkPoint(id + "/" + entry.getKey() + " at", room.get("at"), min, max);
                }
                for (Object waveRaw : (List<Object>) room.getOrDefault("waves", List.of())) {
                    Map<String, Object> wave = (Map<String, Object>) waveRaw;
                    checkPoint(id + "/" + entry.getKey() + " wave", wave.get("at"), min, max);
                }
                if (room.get("boss") instanceof Map<?, ?> bossRaw) {
                    Map<String, Object> boss = (Map<String, Object>) bossRaw;
                    checkPoint(id + "/" + entry.getKey() + " boss", boss.get("at"), min, max);
                }
                for (String key : List.of("seal", "unlock")) {
                    for (Object regionRaw : (List<Object>) room.getOrDefault(key, List.of())) {
                        Map<String, Object> region = (Map<String, Object>) regionRaw;
                        checkPoint(id + "/" + entry.getKey() + " " + key + " from", region.get("from"), min, max);
                        checkPoint(id + "/" + entry.getKey() + " " + key + " to", region.get("to"), min, max);
                    }
                }
            }
            checkPoint(id + "/spawn", def.get("spawn"), min, max);
        }
    }

    /**
     * Точка должна стоять в СВОЁМ зале, а не просто внутри шаблона. Зал - это отрезок между
     * двумя перегородками (они заданы seal/unlock в конфиге): волна, спавнящаяся за стеной,
     * не видна игроку, а комната при этом не закрывается.
     *
     * <p>Перегородки берутся из конфига, а не из шага 18: в test.yml карта сделана руками
     * (стены на 27 и 41), и жёсткая сетка дала бы ложную ошибку. Для новых карт шаг как раз 18.
     */
    @Test
    @SuppressWarnings("unchecked")
    void everyPointIsInItsOwnHall() {
        for (String id : BUILTIN) {
            Map<String, Object> def = dungeon(id);
            Map<String, Object> template = (Map<String, Object>) def.get("template");
            int minX = Math.min(ints(template.get("pos1")).get(0), ints(template.get("pos2")).get(0));
            int maxX = Math.max(ints(template.get("pos1")).get(0), ints(template.get("pos2")).get(0));
            Map<String, Object> rooms = (Map<String, Object>) def.get("rooms");

            Set<Integer> dividerSet = new java.util.TreeSet<>();
            for (Object roomRaw : rooms.values()) {
                Map<String, Object> room = (Map<String, Object>) roomRaw;
                for (String key : List.of("seal", "unlock")) {
                    for (Object regionRaw : (List<Object>) room.getOrDefault(key, List.of())) {
                        int x = ints(((Map<String, Object>) regionRaw).get("from")).get(0);
                        if (x > minX && x < maxX) {
                            dividerSet.add(x);
                        }
                    }
                }
            }
            List<Integer> edges = new ArrayList<>();
            edges.add(minX);
            edges.addAll(dividerSet);
            edges.add(maxX);

            for (Map.Entry<String, Object> entry : rooms.entrySet()) {
                Map<String, Object> room = (Map<String, Object>) entry.getValue();
                int triggerX = ints(room.get("trigger")).get(0);
                int hall = -1;
                for (int i = 0; i + 1 < edges.size(); i++) {
                    if (triggerX > edges.get(i) && triggerX < edges.get(i + 1)) {
                        hall = i;
                        break;
                    }
                }
                // Триггер идёт ПЕРВЫМ в комнате и может стоять на самой перегородке
                // (test.yml: триггер на x=20, дверь на x=18): тогда зал - следующий отрезок.
                if (hall < 0) {
                    for (int i = 0; i + 1 < edges.size(); i++) {
                        if (triggerX >= edges.get(i) && triggerX < edges.get(i + 1)) {
                            hall = i;
                            break;
                        }
                    }
                }
                Assertions.assertTrue(hall >= 0,
                        id + "/" + entry.getKey() + ": триггер x=" + triggerX + " не попал ни в один зал " + edges);
                int left = edges.get(hall);
                int right = edges.get(hall + 1);
                List<Object> points = new ArrayList<>();
                points.add(room.get("trigger"));
                for (Object waveRaw : (List<Object>) room.getOrDefault("waves", List.of())) {
                    points.add(((Map<String, Object>) waveRaw).get("at"));
                }
                if (room.get("boss") instanceof Map<?, ?> bossRaw) {
                    points.add(((Map<String, Object>) bossRaw).get("at"));
                }
                for (Object raw : points) {
                    int x = ints(raw).get(0);
                    // Сам триггер может стоять на перегородке (по нему комната и открывается),
                    // а вот волны и босс обязаны быть внутри зала.
                    boolean onEdge = raw == room.get("trigger") && (x == left || x == right);
                    Assertions.assertTrue(onEdge || (x > left && x < right),
                            id + "/" + entry.getKey() + ": x=" + x + " вне своего зала " + left + ".." + right
                                    + " (зал считается по триггеру)");
                }
            }
        }
    }

    /**
     * Тема карты должна быть у каждого подземелья и отличаться от соседей: buildtest строит
     * из theme.*, и если у двух карт совпадают все пять блоков, они выглядят одной картой.
     * Названия блоков сверяются со списком материалов Paper отдельным инструментом
     * (tools/check_entities.py), здесь - состав и уникальность.
     */
    @Test
    @SuppressWarnings("unchecked")
    void everyDungeonHasItsOwnTheme() {
        Map<String, List<String>> themes = new LinkedHashMap<>();
        for (String id : BUILTIN) {
            Map<String, Object> theme = (Map<String, Object>) dungeon(id).get("theme");
            Assertions.assertNotNull(theme, id + ": нет theme.* - buildtest построит серую коробку");
            List<String> blocks = new ArrayList<>();
            for (String key : List.of("floor", "wall", "ceiling", "light", "accent")) {
                Object value = theme.get(key);
                Assertions.assertNotNull(value, id + ": в theme нет " + key);
                blocks.add(String.valueOf(value));
            }
            themes.put(id, blocks);
        }
        Set<String> seen = new java.util.HashSet<>();
        for (Map.Entry<String, List<String>> entry : themes.entrySet()) {
            String fingerprint = String.join(",", entry.getValue());
            Assertions.assertTrue(seen.add(fingerprint),
                    entry.getKey() + ": тема совпадает с другим подземельем (" + fingerprint + ")");
        }
    }

    private static void checkPoint(String what, Object raw, int[] min, int[] max) {
        Assertions.assertNotNull(raw, what + ": нет координат");
        List<Integer> point = ints(raw);
        Assertions.assertEquals(3, point.size(), what + ": нужно три координаты");
        for (int axis = 0; axis < 3; axis++) {
            int value = point.get(axis);
            Assertions.assertTrue(value >= min[axis] && value <= max[axis],
                    what + ": координата " + value + " вне шаблона (" + min[axis] + ".." + max[axis] + ")");
        }
    }

    /**
     * Для каждого ранга лестницы должно быть подземелье этого ранга (или ниже),
     * и у него должен быть героический режим: ворота B->A требуют 5 героиков,
     * A->A+ 20 героиков, A+->S 45. Без контента эти ворота непроходимы.
     */
    @Test
    void everyRankHasDungeonAndHeroic() {
        Map<String, List<String>> byRank = new LinkedHashMap<>();
        for (String id : BUILTIN) {
            Map<String, Object> def = dungeon(id);
            String rank = String.valueOf(def.get("min-rank"));
            byRank.computeIfAbsent(rank, key -> new ArrayList<>()).add(id);
            Map<String, Object> heroic = (Map<String, Object>) def.get("heroic");
            Assertions.assertNotNull(heroic, id + ": нет секции heroic");
            Assertions.assertTrue(Boolean.TRUE.equals(heroic.get("enabled")), id + ": героик выключен");
            Assertions.assertTrue(heroic.get("rewards") instanceof Map, id + ": у героика нет наград");
            Map<String, Object> rewards = (Map<String, Object>) heroic.get("rewards");
            Assertions.assertTrue(((Number) rewards.get("points")).intValue()
                    > ((Number) ((Map<String, Object>) def.get("rewards")).get("points")).intValue(),
                    id + ": героик не должен давать меньше очков, чем обычный проход");
        }
        for (String rank : List.of("F", "E", "D", "C", "B", "A", "A+", "S")) {
            Assertions.assertFalse(byRank.getOrDefault(rank, List.of()).isEmpty(),
                    "нет подземелья ранга " + rank + " - вторжения и ворота ранга ведут в пустоту");
        }
        Assertions.assertTrue(byRank.getOrDefault("D", List.of()).size() >= 2,
                "на D должно быть и подземелье, и рейд");
    }

    /**
     * Рейдов должно хватать на ворота: на A+ нужно 8 рейдов при недельном локауте.
     * Один рейд = 8 недель (56 дней) - дольше самой лестницы (45 дней на A+).
     * Два рейда = ~4 недели: ворота идут вровень с путём.
     */
    @Test
    @SuppressWarnings("unchecked")
    void raidLockoutsFitLadder() {
        int raids = 0;
        int lockout = 0;
        for (String id : BUILTIN) {
            Map<String, Object> def = dungeon(id);
            if (!"raid".equals(String.valueOf(def.get("type")))) {
                continue;
            }
            raids++;
            int days = ((Number) def.getOrDefault("lockout-days", 7)).intValue();
            lockout = Math.max(lockout, days);
        }
        Assertions.assertTrue(raids >= 2, "для ворот A+ (8 рейдов) нужно минимум два рейда, есть " + raids);
        int neededRaids = 8;
        int minDays = 45;
        int daysWithAll = neededRaids * lockout / raids;
        Assertions.assertTrue(daysWithAll <= minDays,
                "8 рейдов при " + raids + " рейдах и локауте " + lockout + " дней = " + daysWithAll
                        + " дней, а на A+ по min-days " + minDays + " - ворота рейдов станут блокирующими");
    }

    /**
     * Уровни и редкости рун в наградах должны существовать: код молча срезает уровень
     * до max-level и не знает редкости, которых нет в runes.yml.
     */
    @Test
    @SuppressWarnings("unchecked")
    void runeRewardsAreValid() {
        Map<String, Object> runes = (Map<String, Object>) resource("runes.yml").get("runes");
        Set<String> rarities = Set.of("COMMON", "UNCOMMON", "RARE", "EPIC", "LEGENDARY");
        for (String id : BUILTIN) {
            Map<String, Object> def = dungeon(id);
            List<Object> all = new ArrayList<>((List<Object>) ((Map<String, Object>) def.get("rewards")).get("loot"));
            all.addAll((List<Object>) ((Map<String, Object>) ((Map<String, Object>) def.get("heroic"))
                    .get("rewards")).getOrDefault("extra-loot", List.of()));
            for (Object entryRaw : all) {
                Map<String, Object> entry = (Map<String, Object>) entryRaw;
                if (entry.get("rune") == null) {
                    continue;
                }
                String rune = String.valueOf(entry.get("rune"));
                Map<String, Object> runeDef = (Map<String, Object>) runes.get(rune);
                Assertions.assertNotNull(runeDef, id + ": руны " + rune + " нет в runes.yml");
                int maxLevel = ((Number) runeDef.getOrDefault("max-level", 3)).intValue();
                int level = ((Number) entry.getOrDefault("level", 1)).intValue();
                Assertions.assertTrue(level <= maxLevel, id + ": руна " + rune + " уровня " + level
                        + " при max-level " + maxLevel + " (код срежет уровень молча)");
                if (entry.get("rarity") != null) {
                    Assertions.assertTrue(rarities.contains(String.valueOf(entry.get("rarity"))),
                            id + ": неизвестная редкость " + entry.get("rarity"));
                }
            }
        }
    }

    /** Вторжения должны вести на существующие подземелья (иначе портал в пустоту). */
    @Test
    @SuppressWarnings("unchecked")
    void invasionsPointToExistingDungeons() {
        Map<String, Object> tiers = (Map<String, Object>) resource("invasions.yml").get("tiers");
        for (Map.Entry<String, Object> entry : tiers.entrySet()) {
            Map<String, Object> tier = (Map<String, Object>) entry.getValue();
            for (Object idRaw : (List<Object>) tier.get("dungeons")) {
                String id = String.valueOf(idRaw);
                Map<String, Object> def = dungeon(id);
                Assertions.assertNotNull(def, "вторжение " + entry.getKey() + " ведёт на несуществующее " + id);
                Assertions.assertNotEquals("raid", String.valueOf(def.get("type")),
                        "вторжение " + entry.getKey() + " ведёт на рейд " + id
                                + ": портал не соберёт 10 человек с ролями");
            }
        }
    }

    /** У боссов есть фазы, у волн - мобы: иначе зал не работает как зал. */
    @Test
    @SuppressWarnings("unchecked")
    void raidRoomsHaveContent() {
        Map<String, Object> raid = dungeon("crypt_d");
        Map<String, Object> rooms = (Map<String, Object>) raid.get("rooms");
        int bosses = 0;
        for (Map.Entry<String, Object> entry : rooms.entrySet()) {
            Map<String, Object> room = (Map<String, Object>) entry.getValue();
            String type = String.valueOf(room.get("type"));
            if ("boss".equals(type)) {
                bosses++;
                Map<String, Object> boss = (Map<String, Object>) room.get("boss");
                Assertions.assertNotNull(boss, entry.getKey() + ": нет boss");
                Assertions.assertTrue(((Number) boss.get("health")).intValue() >= 300,
                        entry.getKey() + ": босс рейда на D слабее 300 HP");
                Assertions.assertFalse(((List<Object>) boss.getOrDefault("phases", List.of())).isEmpty(),
                        entry.getKey() + ": у босса нет фаз");
            } else {
                Assertions.assertFalse(((List<Object>) room.getOrDefault("waves", List.of())).isEmpty(),
                        entry.getKey() + ": нет волн");
            }
        }
        Assertions.assertTrue(bosses >= 2, "в рейде должно быть минимум два босса, сейчас " + bosses);
    }

    /** Награда рейда не должна превышать дневной доход ранга очками (иначе ранг фармится рейдами). */
    @Test
    @SuppressWarnings("unchecked")
    void raidRewardsFitDailyIncome() {
        Map<String, Integer> daily = new HashMap<>();
        for (Object entry : (List<Object>) resource("quests.yml").get("quests")) {
            Map<String, Object> quest = (Map<String, Object>) entry;
            daily.merge(String.valueOf(quest.get("rank")), ((Number) quest.get("points")).intValue(), Integer::sum);
        }
        // Дневной доход ранга = средний день из 5 заданий, как в BalanceConfigTest.
        Map<String, Map<String, Object>> defs = new LinkedHashMap<>();
        for (String id : BUILTIN) {
            defs.put(id, dungeon(id));
        }
        for (Map.Entry<String, Map<String, Object>> entry : defs.entrySet()) {
            Map<String, Object> def = entry.getValue();
            String rank = String.valueOf(def.get("min-rank"));
            List<Integer> points = new ArrayList<>();
            for (Object questRaw : (List<Object>) resource("quests.yml").get("quests")) {
                Map<String, Object> quest = (Map<String, Object>) questRaw;
                if (rank.equals(String.valueOf(quest.get("rank")))) {
                    points.add(((Number) quest.get("points")).intValue());
                }
            }
            double averageDay = points.stream().mapToInt(Integer::intValue).average().orElse(0) * 5;
            Map<String, Object> rewards = (Map<String, Object>) def.get("rewards");
            int reward = ((Number) rewards.get("points")).intValue();
            Assertions.assertTrue(reward <= averageDay * 2.5,
                    entry.getKey() + ": награда " + reward + " очков при среднем дне " + Math.round(averageDay));
        }
    }

    /** Рейдовая таблица лута должна быть в данных для всех режимов, которые использует код. */
    @Test
    @SuppressWarnings("unchecked")
    void lootModesCoverEveryRank() {
        Map<String, Object> modes = (Map<String, Object>) resource("dungeon-loot.yml").get("modes");
        for (String mode : List.of("normal", "heroic", "raid", "raid-heroic")) {
            Map<String, Object> ranks = (Map<String, Object>) ((Map<String, Object>) modes.get(mode)).get("ranks");
            for (String rank : List.of("F", "E", "D", "C", "B", "A", "A+", "S")) {
                Assertions.assertNotNull(ranks.get(rank), "dungeon-loot.yml: " + mode + " без ранга " + rank);
                Map<String, Object> chances = (Map<String, Object>) ranks.get(rank);
                double sum = 0;
                for (Object value : chances.values()) {
                    sum += ((Number) value).doubleValue();
                }
                Assertions.assertEquals(100.0, sum, 0.51, "dungeon-loot.yml: " + mode + "/" + rank
                        + " сумма шансов " + sum + " (должна быть 100)");
            }
        }
        // ЛЕГЕНДАРКА в рейде на D допустима, на F-E - нет (см. раздел 4 отчёта).
        Map<String, Object> raid = (Map<String, Object>) ((Map<String, Object>) modes.get("raid"));
        Map<String, Object> ranks = (Map<String, Object>) raid.get("ranks");
        Assertions.assertEquals(0.0, ((Number) ((Map<String, Object>) ranks.get("F")).get("LEGENDARY")).doubleValue(),
                "рейд на F не должен давать легендарку");
    }
}
