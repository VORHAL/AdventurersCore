package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.adventurers.core.dungeon.DungeonMechanics;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Проверки новых механик подземелий: телеграфы (зоны), ярость, каст и модификаторы.
 *
 * <p>Bukkit в тестах не поднят, поэтому зоны проверяются на «чистой» геометрии:
 * {@link Geo} повторяет формулы {@code DungeonMechanics.inside(...)}, а совпадение
 * с рабочим кодом закреплено тем, что формулы взяты из него один в один.
 * Если формулу в {@code DungeonMechanics} поменяют, а тут нет — тест продолжит
 * зеленеть, поэтому он дополнительно сверяет конфиг: у каждой зоны есть радиус,
 * у конуса — угол, и урон в пределах разумного.
 */
class DungeonMechanicsTest {

    /** Подземелья лежат по одному файлу в resources/dungeons, отсюда и собираем. */
    private static Map<String, Map<String, Object>> allDungeons() {
        java.io.File dir = new java.io.File("src/main/resources/dungeons");
        Assertions.assertTrue(dir.isDirectory(), "нет каталога src/main/resources/dungeons");
        java.io.File[] files = dir.listFiles((d, name) -> name.endsWith(".yml"));
        Assertions.assertNotNull(files);
        Map<String, Map<String, Object>> out = new java.util.LinkedHashMap<>();
        for (java.io.File file : files) {
            @SuppressWarnings("unchecked")
            Map<String, Object> def = new Yaml().load(read(file));
            out.put(file.getName(), def);
        }
        return out;
    }

    private static String read(java.io.File file) {
        try {
            return java.nio.file.Files.readString(file.toPath());
        } catch (java.io.IOException e) {
            throw new AssertionError("не читается " + file, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = DungeonMechanicsTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new AssertionError("не читается " + name, e);
        }
    }

    /**
     * Геометрия зон — построчный перенос {@code DungeonMechanics.inside}:
     * смотрим расстояние от центра, затем расстояние до луча (LINE, коридор
     * шириной 2.4 блока, потому что допуск perpendicular <= 1.2) либо угол (CONE).
     * Единичное направление по умолчанию — +Z.
     */
    private static final class Geo {
        static boolean inside(String shape, double radius, double angle,
                              double dx, double dz, double[] dir) {
            double distance = Math.hypot(dx, dz);
            if (distance > radius) {
                return false;
            }
            double dlen = Math.hypot(dir[0], dir[1]);
            double ux = dir[0] / dlen;
            double uz = dir[1] / dlen;
            double dot = dx * ux + dz * uz;
            switch (shape) {
                case "LINE" -> {
                    double px = dx - ux * dot;
                    double pz = dz - uz * dot;
                    return Math.hypot(px, pz) <= 1.2 && dot >= 0;
                }
                case "CONE" -> {
                    if (distance < 0.01) {
                        return true;
                    }
                    double cos = Math.min(1.0, dot / distance);
                    return Math.toDegrees(Math.acos(cos)) <= angle / 2.0;
                }
                default -> {
                    return true;
                }
            }
        }
    }

    private static final double[] FORWARD = {0, 1};   // взгляд в +Z

    @Test
    void circleZoneHitsInsideAndSparesOutside() {
        Assertions.assertTrue(Geo.inside("CIRCLE", 4, 0, 0, 0, FORWARD), "в центре — задевает");
        Assertions.assertTrue(Geo.inside("CIRCLE", 4, 0, 3.9, 0, FORWARD), "3.9 из 4 — задевает");
        Assertions.assertFalse(Geo.inside("CIRCLE", 4, 0, 4.1, 0, FORWARD), "4.1 из 4 — уже нет");
        Assertions.assertFalse(Geo.inside("CIRCLE", 4, 0, 0, 6, FORWARD), "позади и далеко — нет");
    }

    @Test
    void lineZoneIsCorridorNotCircle() {
        // Коридор длиной 8 и полной шириной 2.4 блока (допуск 1.2 в сторону).
        Assertions.assertTrue(Geo.inside("LINE", 8, 0, 0, 4, FORWARD), "по центру впереди — задевает");
        Assertions.assertTrue(Geo.inside("LINE", 8, 0, 1.1, 4, FORWARD), "1.1 в сторону — ещё в коридоре");
        Assertions.assertFalse(Geo.inside("LINE", 8, 0, 1.5, 4, FORWARD), "1.5 в сторону — уже мимо");
        Assertions.assertFalse(Geo.inside("LINE", 8, 0, 0, -3, FORWARD), "позади — не задевает");
        Assertions.assertFalse(Geo.inside("LINE", 8, 0, 0, 9, FORWARD), "дальше длины — не задевает");
        // Коридор поворачивается вместе с боссом: смотрим вбок — там и коридор.
        Assertions.assertTrue(Geo.inside("LINE", 8, 0, 4, 0, new double[]{1, 0}), "босс смотрит в +X — задевает по +X");
        Assertions.assertFalse(Geo.inside("LINE", 8, 0, 0, 4, new double[]{1, 0}), "а по +Z, как раньше, — уже нет");
    }

    @Test
    void coneZoneRespectsAngle() {
        // Конус 90°: сектор ±45° вокруг направления взгляда, радиус 6.
        Assertions.assertTrue(Geo.inside("CONE", 6, 90, 0, 5, FORWARD), "прямо вперёд — задевает");
        Assertions.assertTrue(Geo.inside("CONE", 6, 90, 3, 3, FORWARD), "45° вбок — на границе, задевает");
        Assertions.assertFalse(Geo.inside("CONE", 6, 90, 5, 1, FORWARD), "почти вбок — не задевает");
        Assertions.assertFalse(Geo.inside("CONE", 6, 90, 0, 7, FORWARD), "дальше радиуса — не задевает");
        // Широкий конус 180° задевает и то, что стоит сбоку.
        Assertions.assertTrue(Geo.inside("CONE", 6, 180, 5, 1, FORWARD), "конус 180° — бок тоже");
    }

    @Test
    void enrageStacksDoNotRepeatEveryTick() {
        // Порог 5 минут: первая ступень на 300-й секунде и только раз в 30 секунд.
        Assertions.assertFalse(DungeonMechanics.enraged(299, 5, 0), "до порога ярости нет");
        Assertions.assertTrue(DungeonMechanics.enraged(300, 5, 0), "на пороге — сработала");
        Assertions.assertFalse(DungeonMechanics.enraged(305, 5, 1), "через 5 секунд — тишина, не каждый тик");
        Assertions.assertTrue(DungeonMechanics.enraged(330, 5, 1), "через 30 секунд — вторая ступень");
        Assertions.assertFalse(DungeonMechanics.enraged(3600, 0, 0), "enrage-minutes: 0 — механика выключена");
    }

    @Test
    void zoneDamageIsTurnedOffBeforeItsHealthThreshold() {
        Map<String, Map<String, Object>> defs = allDungeons();
        int zones = 0;
        for (Map.Entry<String, Map<String, Object>> entry : defs.entrySet()) {
            for (Map<String, Object> boss : bossesOf(entry.getValue())) {
                List<Map<String, Object>> list = asZones(boss.get("zones"));
                for (Map<String, Object> zone : list) {
                    zones++;
                    String shape = String.valueOf(zone.getOrDefault("shape", "CIRCLE")).toUpperCase();
                    Assertions.assertTrue(List.of("CIRCLE", "LINE", "CONE").contains(shape),
                            entry.getKey() + ": неизвестная форма зоны " + shape);
                    double radius = num(zone.get("radius"), 0);
                    Assertions.assertTrue(radius > 0, entry.getKey() + ": у зоны нет радиуса");
                    if ("CONE".equals(shape)) {
                        double angle = num(zone.get("angle"), 0);
                        Assertions.assertTrue(angle > 0 && angle <= 360, entry.getKey() + ": конус без угла");
                    }
                    double damage = num(zone.get("damage"), 0);
                    Assertions.assertTrue(damage > 0, entry.getKey() + ": зона без урона");
                    double atHealth = num(zone.get("at-health"), 101);
                    Assertions.assertTrue(atHealth > 0 && atHealth <= 100,
                            entry.getKey() + ": at-health должен быть 1..100");
                    double every = num(zone.get("every-seconds"), 1);
                    Assertions.assertTrue(every >= 1, entry.getKey() + ": зона чаще раза в секунду");
                }
            }
        }
        Assertions.assertTrue(zones > 0, "ни одной зоны в конфиге — телеграфы не настроены");
    }

    @Test
    void everyModifierHasBothAPlusAndAMinus() {
        @SuppressWarnings("unchecked")
        Map<String, Object> dungeons = resource("dungeons.yml");
        @SuppressWarnings("unchecked")
        Map<String, Object> mods = (Map<String, Object>) dungeons.get("modifiers");
        Assertions.assertNotNull(mods, "нет раздела modifiers");
        Assertions.assertTrue(mods.size() >= 4, "мало модификаторов: " + mods.size());
        for (Map.Entry<String, Object> entry : mods.entrySet()) {
            @SuppressWarnings("unchecked")
            Map<String, Object> mod = (Map<String, Object>) entry.getValue();
            boolean plus = num(mod.get("coins-factor"), 1) > 1
                    || num(mod.get("player-damage"), 1) > 1
                    || num(mod.get("loot-bonus"), 0) > 0;
            boolean minus = num(mod.get("mob-health"), 1) > 1
                    || num(mod.get("mob-damage"), 1) > 1
                    || num(mod.get("player-taken"), 1) > 1
                    || num(mod.get("time-factor"), 1) < 1
                    || num(mod.get("heal-factor"), 1) < 1
                    || num(mod.get("player-damage"), 1) < 1;
            Assertions.assertTrue(plus, entry.getKey() + ": только минусы, никто не возьмёт");
            Assertions.assertTrue(minus, entry.getKey() + ": только плюсы, это не модификатор, а подарок");
            Assertions.assertFalse(
                    mod.containsKey("mob-coins") || mod.containsKey("points-factor"),
                    entry.getKey() + ": ключ, который код не читает");
        }
    }

    /**
     * Именные награды (раздел 30): у каждой должна быть своя модель, и модель должна
     * быть нарисована в паке. Без этого теста «босс-дроп» тихо получает арт ранга,
     * и отличить его от обычного лута в инвентаре невозможно.
     */
    @Test
    void everyNamedDropHasItsOwnPackModel() {
        java.io.File textures = new java.io.File("../AdventurersPack/AdventurersPack/assets/adventurers/textures/item");
        if (!textures.isDirectory()) {
            return;   // пак не рядом - тест про конфиги, а не про ассеты
        }
        int named = 0;
        for (Map.Entry<String, Map<String, Object>> entry : allDungeons().entrySet()) {
            for (Object rawLoot : allLoot(entry.getValue())) {
                @SuppressWarnings("unchecked")
                Map<String, Object> loot = (Map<String, Object>) rawLoot;
                Object customId = loot.get("custom-id");
                if (customId == null) {
                    continue;
                }
                named++;
                Object model = loot.get("model");
                Assertions.assertNotNull(model, entry.getKey() + ": у именного дропа " + customId
                        + " нет model - он получит арт ранга, как обычный лут");
                String name = String.valueOf(model);
                Assertions.assertTrue(name.matches("[a-z][a-z0-9_]+"),
                        entry.getKey() + ": имя модели должно быть простым: " + name);
                Assertions.assertTrue(new java.io.File(textures, name + ".png").isFile(),
                        entry.getKey() + ": в паке нет текстуры " + name + ".png");
            }
        }
        Assertions.assertTrue(named >= 10, "именных дропов слишком мало: " + named);
    }

    /**
     * Арт должен соответствовать предмету (раздел 30): меч - клинок, топор - топор,
     * трезубец - копьё, лук - лук, щит - щит. Иначе игрок получает «топор», который
     * нарисован мечом, и это видно сразу. Проверка нарочно по материалам, а не по custom-id:
     * именно материал решает, как предмет ведёт себя в бою.
     */
    @Test
    void bossArtMatchesTheItemItIsDrawnFor() {
        // порядок важен: PICKAXE содержит AXE, поэтому проверяем длинные ключи первыми
        List<Map.Entry<String, List<String>>> forms = List.of(
                Map.entry("PICKAXE", List.of("pick")),
                Map.entry("CHESTPLATE", List.of("season_guard")),
                Map.entry("SWORD", List.of("blade", "oath")),
                Map.entry("AXE", List.of("axe", "cleaver")),
                Map.entry("TRIDENT", List.of("spear")),
                Map.entry("BOW", List.of("bow", "song")),
                Map.entry("SHIELD", List.of("shield", "aegis", "bastion", "wall")));
        int checked = 0;
        for (Map.Entry<String, Map<String, Object>> entry : allDungeons().entrySet()) {
            for (Object rawLoot : allLoot(entry.getValue())) {
                @SuppressWarnings("unchecked")
                Map<String, Object> loot = (Map<String, Object>) rawLoot;
                if (loot.get("custom-id") == null || loot.get("model") == null) {
                    continue;
                }
                String item = String.valueOf(loot.get("item"));
                String model = String.valueOf(loot.get("model"));
                List<String> allowed = forms.stream()
                        .filter(e -> item.contains(e.getKey()))
                        .map(Map.Entry::getValue).findFirst().orElse(null);
                if (allowed == null) {
                    continue;
                }
                checked++;
                Assertions.assertTrue(allowed.stream().anyMatch(model::contains),
                        entry.getKey() + ": " + item + " нарисован моделью " + model
                                + ", а ожидалось одно из " + allowed);
            }
        }
        Assertions.assertTrue(checked >= 20, "именных дропов с моделью слишком мало: " + checked);
    }

    /** Все строки лута подземелья: в комнатах, на боссах и в наградах. */
    @SuppressWarnings("unchecked")
    private static List<Object> allLoot(Map<String, Object> def) {
        List<Object> out = new ArrayList<>();
        Object rewards = def.get("rewards");
        if (rewards instanceof Map<?, ?> map && map.get("loot") instanceof List<?> list) {
            out.addAll(list);
        }
        if (def.get("rooms") instanceof Map<?, ?> rooms) {
            for (Object roomRaw : rooms.values()) {
                if (!(roomRaw instanceof Map<?, ?> room)) {
                    continue;
                }
                if (room.get("loot") instanceof List<?> list) {
                    out.addAll(list);
                }
                if (room.get("extra-loot") instanceof List<?> list) {
                    out.addAll(list);
                }
                if (room.get("boss") instanceof Map<?, ?> boss && boss.get("loot") instanceof List<?> list) {
                    out.addAll(list);
                }
            }
        }
        return out;
    }

    @Test
    void modifierIdsInConfigMatchCommandSuggestions() {
        @SuppressWarnings("unchecked")
        Map<String, Object> mods = (Map<String, Object>) resource("dungeons.yml").get("modifiers");
        Assertions.assertNotNull(mods);
        List<String> ids = new ArrayList<>(mods.keySet());
        for (String id : ids) {
            Assertions.assertTrue(id.matches("[a-z][a-z0-9_]{2,20}"),
                    "id модификатора должен быть простым для ввода с руки: " + id);
        }
    }

    @Test
    void enrageTimerIsConfiguredOnBosses() {
        int bosses = 0;
        int withEnrage = 0;
        for (Map.Entry<String, Map<String, Object>> entry : allDungeons().entrySet()) {
            for (Map<String, Object> boss : bossesOf(entry.getValue())) {
                bosses++;
                double minutes = num(boss.get("enrage-minutes"), 0);
                if (minutes > 0) {
                    withEnrage++;
                    Assertions.assertTrue(minutes >= 2 && minutes <= 30,
                            "ярость через " + minutes + " мин — либо мгновенно, либо никогда");
                }
            }
        }
        Assertions.assertTrue(bosses > 0, "боссов нет");
        Assertions.assertEquals(bosses, withEnrage,
                "у каждого босса должен быть enrage-minutes, иначе бой можно тянуть вечно");
    }

    /** Все боссы файла: комнаты в разделе rooms, сам босс — в ключе boss. */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> bossesOf(Map<String, Object> def) {
        List<Map<String, Object>> out = new ArrayList<>();
        Object roomsRaw = def.get("rooms");
        if (!(roomsRaw instanceof Map<?, ?> rooms)) {
            return out;
        }
        for (Object roomRaw : rooms.values()) {
            if (roomRaw instanceof Map<?, ?> room && room.get("boss") instanceof Map<?, ?> boss) {
                out.add((Map<String, Object>) boss);
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> asZones(Object raw) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (raw instanceof List<?> list) {
            for (Object item : list) {
                if (item instanceof Map<?, ?> map) {
                    out.add((Map<String, Object>) map);
                }
            }
        }
        return out;
    }

    private static double num(Object value, double fallback) {
        return value instanceof Number n ? n.doubleValue() : fallback;
    }
}
