package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;
import ru.adventurers.core.event.EventStage;
import ru.adventurers.core.event.EventType;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Еженедельные испытания (раздел 19 отчёта): проверяется то, что нельзя увидеть глазами
 * в конфиге - что восемь испытаний реально разные, что ступени растут монотонно,
 * что босс не оказывается легче обычной ступени и что награда не ломает экономику.
 *
 * <p>Баланс наград считается тем же кодом, что и в игре ({@link EventStage#build}),
 * поэтому тест ловит расхождение конфига и кода: если кто-то поменяет формулу в Java,
 * а в events.yml оставит старые числа, тест это увидит.
 */
class EventConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = EventConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Map<String, Object>> events() {
        return (Map<String, Map<String, Object>>) resource("events.yml").get("events");
    }

    private static EventStage stage(Map<String, Object> event, int stage) {
        return EventStage.build(
                ((Number) event.get("stages")).intValue(),
                ((Number) event.get("boss-every")).intValue(),
                ((Number) event.get("hp-base")).doubleValue(),
                ((Number) event.get("hp-growth")).doubleValue(),
                ((Number) event.get("dmg-base")).doubleValue(),
                ((Number) event.get("dmg-growth")).doubleValue(),
                ((Number) event.get("mob-base")).intValue(),
                ((Number) event.get("mob-growth")).intValue(),
                ((Number) event.get("coins-base")).longValue(),
                ((Number) event.get("coins-growth")).doubleValue(),
                ((Number) event.get("points-base")).intValue(),
                ((Number) event.get("points-growth")).doubleValue(),
                ((Number) event.get("loot-base")).intValue(),
                ((Number) event.get("loot-every")).intValue()).get(stage - 1);
    }

    @Test
    void allEightModesAreConfiguredAndOpen() {
        Map<String, Map<String, Object>> events = events();
        Assertions.assertEquals(EventType.values().length, events.size(),
                "в events.yml должны быть все 8 испытаний: " + events.keySet());
        for (EventType type : EventType.values()) {
            Assertions.assertTrue(events.containsKey(type.getId()),
                    "в events.yml нет испытания " + type.getId());
            Map<String, Object> event = events.get(type.getId());
            Assertions.assertEquals(Boolean.TRUE, event.get("open"),
                    "испытание " + type.getId() + " закрыто, но должно участвовать в ротации");
            Assertions.assertTrue(((Number) event.get("stages")).intValue() >= 10,
                    "у испытания " + type.getId() + " слишком мало ступеней");
            Assertions.assertTrue(((Number) event.get("attempts")).intValue() > 0,
                    "без лимита попыток испытание " + type.getId() + " можно фармить");
            Assertions.assertTrue(((Number) event.get("time-limit-seconds")).intValue() >= 300,
                    "лимит времени слишком мал: " + type.getId());
        }
    }

    /** «Тяжесть» ступени: суммарное здоровье волны, а не здоровье одного моба. */
    private static double weight(EventStage stage) {
        return stage.hpFactor() * stage.mobs();
    }

    @Test
    void stagesGrowMonotonically() {
        // Босс - сознательный всплеск: его здоровье x1.6 и награда x2.2. Поэтому:
        //   * обычная ступень тяжелее предыдущей обычной;
        //   * босс тяжелее ступени перед ним;
        //   * ступень после босса тяжелее ступени ДО босса (иначе после босса идёт «отдых»).
        // Без этой проверки легко получить башню, где пятый этаж легче четвёртого -
        // ровно это и случилось, когда босс заменял собой волну мобов.
        for (Map.Entry<String, Map<String, Object>> entry : events().entrySet()) {
            int stages = ((Number) entry.getValue().get("stages")).intValue();
            // награда растёт от обычной ступени к обычной: у босса сознательный всплеск x2.2,
            // и следующая за ним обычная ступень НИЖЕ босса - это нормально и так задумано
            double previousCoins = 0;
            for (int i = 1; i <= stages; i++) {
                EventStage stage = stage(entry.getValue(), i);
                if (stage.boss()) {
                    Assertions.assertTrue(stage.coins() > previousCoins,
                            entry.getKey() + ": босс на " + i + " платит не больше прошлой ступени");
                } else {
                    Assertions.assertTrue(stage.coins() > previousCoins,
                            entry.getKey() + ": награда не растёт на ступени " + i);
                    previousCoins = stage.coins();
                }

                if (i == 1) {
                    continue;
                }
                EventStage before = stage(entry.getValue(), i - 1);
                if (stage.boss()) {
                    Assertions.assertTrue(weight(stage) > weight(before),
                            entry.getKey() + ": босс на " + i + " легче ступени " + (i - 1));
                } else if (!before.boss()) {
                    Assertions.assertTrue(weight(stage) > weight(before),
                            entry.getKey() + ": ступень " + i + " легче предыдущей");
                }
                if (before.boss() && i >= 3) {
                    EventStage beforeBoss = stage(entry.getValue(), i - 2);
                    Assertions.assertTrue(weight(stage) > weight(beforeBoss),
                            entry.getKey() + ": после босса ступень " + i + " легче, чем до босса");
                }
            }
        }
    }

    @Test
    void bossStageIsNeverEasierThanPrevious() {
        for (Map.Entry<String, Map<String, Object>> entry : events().entrySet()) {
            int every = ((Number) entry.getValue().get("boss-every")).intValue();
            if (every <= 0) {
                continue;
            }
            int stages = ((Number) entry.getValue().get("stages")).intValue();
            for (int i = Math.max(every, 2); i <= stages; i += every) {
                EventStage boss = stage(entry.getValue(), i);
                EventStage before = stage(entry.getValue(), i - 1);
                Assertions.assertTrue(boss.boss(), entry.getKey() + ": ступень " + i + " должна быть боссом");
                Assertions.assertTrue(boss.hpFactor() > before.hpFactor(),
                        entry.getKey() + ": босс на " + i + " слабее предыдущей ступени");
                Assertions.assertTrue(boss.mobs() >= before.mobs(),
                        entry.getKey() + ": на боссе свита меньше, чем на обычной ступени");
                // Большая охота - исключение: там КАЖДАЯ ступень босс, всплеска x2.2 нет,
                // награда растёт обычным множителем. Проверяем, что она всё равно растёт.
                double expected = every == 1 ? 1.0 : 1.5;
                Assertions.assertTrue(boss.coins() > before.coins() * expected,
                        entry.getKey() + ": босс должен платить заметно больше");
            }
        }
    }

    @Test
    void rewardForBestStageMatchesRankIncome() {
        // дневной доход ранга F и S из economy.yml (раздел 15 отчёта)
        long incomeF = 312;
        long incomeS = 8100;
        Map<String, Object> scale = (Map<String, Object>) resource("events.yml").get("rank-scale");
        double scaleF = ((Number) scale.get("F")).doubleValue();
        double scaleS = ((Number) scale.get("S")).doubleValue();
        for (Map.Entry<String, Map<String, Object>> entry : events().entrySet()) {
            int stages = ((Number) entry.getValue().get("stages")).intValue();
            EventStage best = stage(entry.getValue(), stages);
            double daysF = best.coins() * scaleF / incomeF;
            double daysS = best.coins() * scaleS / incomeS;
            Assertions.assertTrue(daysF >= 3.0 && daysF <= 5.5,
                    entry.getKey() + ": лучшая ступень = " + String.format("%.1f", daysF)
                            + " дней дохода F (нужно 3-5.5)");
            Assertions.assertTrue(daysS >= 3.0 && daysS <= 5.5,
                    entry.getKey() + ": лучшая ступень = " + String.format("%.1f", daysS)
                            + " дней дохода S (нужно 3-5.5)");
        }
    }

    @Test
    void firstStageIsNotWorthFarming() {
        Map<String, Object> scale = (Map<String, Object>) resource("events.yml").get("rank-scale");
        double scaleF = ((Number) scale.get("F")).doubleValue();
        for (Map.Entry<String, Map<String, Object>> entry : events().entrySet()) {
            EventStage first = stage(entry.getValue(), 1);
            double days = first.coins() * scaleF / 312;
            Assertions.assertTrue(days <= 1.0,
                    entry.getKey() + ": первая ступень даёт " + String.format("%.2f", days)
                            + " дня дохода F - её будут фармить");
        }
    }

    @Test
    void everyEventHasTitlesAndLoot() {
        Map<String, Object> cfg = resource("events.yml");
        Map<String, Object> titles = (Map<String, Object>) cfg.get("titles");
        long eventTitles = titles.values().stream()
                .map(value -> (Map<String, Object>) value)
                .filter(title -> String.valueOf(title.get("unlock")).startsWith("other:event-"))
                .count();
        Assertions.assertTrue(eventTitles >= 8, "на испытания должно быть минимум 8 титулов: " + eventTitles);
        for (Map.Entry<String, Map<String, Object>> entry : events().entrySet()) {
            Map<String, Object> event = entry.getValue();
            Assertions.assertNotNull(event.get("rewards"), entry.getKey() + ": нет таблицы добычи");
            Assertions.assertNotNull(event.get("theme"), entry.getKey() + ": нет блоков арены");
            Map<String, Object> theme = (Map<String, Object>) event.get("theme");
            Assertions.assertEquals(4, theme.size(), entry.getKey() + ": в теме арены 4 блока");
            Assertions.assertTrue(String.valueOf(event.get("title-unlock")).startsWith("other:event-"),
                    entry.getKey() + ": титул должен открываться через other:event-...");
        }
    }

    @Test
    void titlesInGloryYmlPointToRegisteredKeys() {
        Map<String, Object> glory = (Map<String, Object>) resource("glory.yml").get("titles");
        Map<String, Object> events = (Map<String, Object>) resource("events.yml").get("titles");
        Map<String, String> declared = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : events.entrySet()) {
            Map<String, Object> title = (Map<String, Object>) entry.getValue();
            declared.put(String.valueOf(title.get("unlock")), String.valueOf(title.get("name")));
        }
        int found = 0;
        for (Object value : glory.values()) {
            Map<String, Object> title = (Map<String, Object>) value;
            String unlock = String.valueOf(title.get("unlock"));
            if (unlock.startsWith("other:event-")) {
                Assertions.assertTrue(declared.containsKey(unlock),
                        "в glory.yml есть титул с ключом " + unlock + ", которого нет в events.yml");
                found++;
            }
        }
        Assertions.assertTrue(found >= 8, "ивентовых титулов в glory.yml: " + found);
    }

    @Test
    void limitedAttemptsKeepWeeklyRewardBounded() {
        Map<String, Map<String, Object>> events = events();
        for (Map.Entry<String, Map<String, Object>> entry : events.entrySet()) {
            int attempts = ((Number) entry.getValue().get("attempts")).intValue();
            // попытки ограничивают фарм: даже идеальная игра даёт одну награду за лучшую ступень,
            // а попытки нужны только чтобы её достичь - проверим, что лимит не «1 попытка»
            Assertions.assertTrue(attempts >= 2 && attempts <= 5,
                    entry.getKey() + ": попыток в сутки должно быть 2-5, а не " + attempts);
        }
        Assertions.assertEquals(5, ((Number) resource("events.yml").get("attempts-per-day")).intValue(),
                "общий лимит попыток в events.yml должен быть 5");
    }
}
