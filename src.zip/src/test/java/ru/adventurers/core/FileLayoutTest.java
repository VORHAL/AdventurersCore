package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import ru.adventurers.core.config.PluginFiles;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Порядок в конфигах (раздел 21 отчёта).
 *
 * <p>Смысл теста: конфиг, который лежит в jar, но не описан в раскладке, при первом запуске
 * останется в корне - и «порядок» снова превратится в 39 файлов вперемешку. Поэтому
 * проверяется сцепка «ресурсы плагина ↔ таблица раскладки» и то, что в коде больше нет
 * прямых saveResource("x.yml") для корневых файлов.
 */
class FileLayoutTest {

    private static final Path RESOURCES = Path.of("src/main/resources");

    private static List<String> resourceFiles() throws IOException {
        if (!Files.isDirectory(RESOURCES)) {
            return List.of();
        }
        List<String> names = new ArrayList<>();
        try (Stream<Path> walk = Files.walk(RESOURCES)) {
            walk.filter(Files::isRegularFile)
                    .map(path -> RESOURCES.relativize(path).toString().replace('\\', '/'))
                    .forEach(names::add);
        }
        names.sort(String::compareTo);
        return names;
    }

    @Test
    void everyRootConfigIsInTheLayout() throws IOException {
        List<String> files = resourceFiles();
        Assertions.assertFalse(files.isEmpty(), "не найдены ресурсы плагина");
        List<String> missing = new ArrayList<>();
        for (String name : files) {
            if (name.contains("/")) {
                continue;   // вложенные ресурсы (схемы подземелий) не переносятся
            }
            if (!name.endsWith(".yml") && !name.endsWith(".png")) {
                continue;
            }
            if (name.equals("plugin.yml") || name.equals("paper-plugin.yml")) {
                continue;   // служебный файл самого плагина, его читает сервер
            }
            if (!PluginFiles.layout().contains(name) && !PluginFiles.isRoot(name)) {
                missing.add(name);
            }
        }
        Assertions.assertTrue(missing.isEmpty(),
                "эти файлы не описаны в раскладке и останутся в корне: " + missing);
    }

    @Test
    void layoutHasNoGhostFiles() throws IOException {
        List<String> files = resourceFiles();
        Set<String> described = new LinkedHashSet<>(PluginFiles.layout());
        for (String name : described) {
            if (name.equals("config.yml") || name.equals("messages.yml")) {
                continue;
            }
            if (name.endsWith("-data.yml") || PluginFiles.folderOf(name).equals("data")) {
                continue;   // служебные файлы плагин создаёт сам, в jar их может не быть
            }
            Assertions.assertTrue(files.contains(name),
                    "в раскладке описан файл, которого нет в jar: " + name);
        }
    }

    @Test
    void filesAreSpreadAcrossFoldersAndNothingCollides() {
        List<String> files = PluginFiles.layout();
        Set<String> folders = new LinkedHashSet<>();
        for (String name : files) {
            String folder = PluginFiles.folderOf(name);
            if (!folder.isEmpty()) {
                folders.add(folder);
            }
        }
        Assertions.assertTrue(folders.size() >= 6,
                "конфиги должны быть разложены минимум по 6 папкам, а не " + folders);
        // имя файла не должно встречаться дважды: иначе file("x.yml") вернёт не тот путь
        Assertions.assertEquals(files.size(), new LinkedHashSet<>(files).size(),
                "в раскладке есть повторяющиеся имена файлов");
        // по смыслу: броня и бой - в combat, испытания и донат - в events, пол - в content
        Assertions.assertEquals("combat", PluginFiles.folderOf("tank.yml"));
        Assertions.assertEquals("combat", PluginFiles.folderOf("gear.yml"));
        Assertions.assertEquals("combat", PluginFiles.folderOf("abilities.yml"));
        Assertions.assertEquals("events", PluginFiles.folderOf("events.yml"));
        Assertions.assertEquals("events", PluginFiles.folderOf("donate.yml"));
        Assertions.assertEquals("events", PluginFiles.folderOf("ascended.yml"));
        Assertions.assertEquals("content", PluginFiles.folderOf("gender.yml"));
        Assertions.assertEquals("dungeons", PluginFiles.folderOf("dungeon-loot.yml"));
        Assertions.assertEquals("economy", PluginFiles.folderOf("economy.yml"));
        Assertions.assertEquals("world", PluginFiles.folderOf("tab.yml"));
    }

    @Test
    void unknownNamesStayInRoot() {
        // структуры данных (папки схем, вложенные пути) переносить нельзя - они и есть структура
        Assertions.assertEquals("", PluginFiles.folderOf("dungeons"));
        Assertions.assertEquals("", PluginFiles.folderOf("dungeons/test.yml"));
        Assertions.assertEquals("", PluginFiles.folderOf("lang/ru_ru.yml"));
    }

    @Test
    void schemeIsPrintedForAdmin() {
        String scheme = PluginFiles.describe();
        for (String folder : List.of("content/", "combat/", "economy/", "dungeons/", "world/",
                "events/", "data/", "корень/")) {
            Assertions.assertTrue(scheme.contains(folder), "в схеме нет папки " + folder);
        }
        Assertions.assertTrue(scheme.contains("messages.yml"), "messages.yml должен остаться в корне");
    }

    @Test
    void codeDoesNotSaveRootConfigsDirectly() throws IOException {
        Path source = Path.of("src/main/java");
        if (!Files.isDirectory(source)) {
            return;
        }
        List<String> offenders = new ArrayList<>();
        try (Stream<Path> walk = Files.walk(source)) {
            for (Path file : walk.filter(path -> path.toString().endsWith(".java")).toList()) {
                if (file.toString().contains("PluginFiles.java")) {
                    continue;
                }
                String text = Files.readString(file);
                for (String name : PluginFiles.layout()) {
                    if (text.contains("saveResource(\"" + name + "\"")) {
                        offenders.add(file.getFileName() + " → " + name);
                    }
                }
            }
        }
        Assertions.assertTrue(offenders.isEmpty(),
                "конфиги кладутся в корень мимо раскладки: " + offenders);
    }
}
