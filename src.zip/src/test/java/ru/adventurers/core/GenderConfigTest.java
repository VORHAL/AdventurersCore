package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;
import ru.adventurers.core.profile.Gender;

import java.io.InputStream;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Пол персонажа (раздел 17 отчёта): косметика, но настройки и имена моделей должны сходиться,
 * иначе игрок выберет «женский», а в игре увидит мужскую броню или пустой значок.
 *
 * <p>Проверяется: пол читается из конфига и из команды, обязательность выбора задана,
 * значок включён в чате и TAB, женские модели называются по тому же шаблону, что собирает
 * PackItems (armor_female_<класс>_<ранг>_<часть>), и пол не даёт никаких характеристик.
 */
class GenderConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = GenderConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    private static final List<String> RANKS = List.of("f", "e", "d", "c", "b", "a", "a_plus", "s");
    private static final List<String> PIECES = List.of("helmet", "chestplate", "leggings", "boots");

    @Test
    void genderValuesAreReadFromConfigAndCommand() {
        Map<String, Object> cfg = resource("gender.yml");
        Assertions.assertEquals(Boolean.TRUE, cfg.get("enabled"), "gender.yml: окно должно быть включено");
        Assertions.assertEquals(Boolean.TRUE, cfg.get("required"),
                "gender.yml: выбор обязателен (решение по разделу 17)");
        Assertions.assertNotNull(cfg.get("menu"), "gender.yml: нет меню");
        // команда понимает русские и английские варианты
        Assertions.assertEquals(Gender.MALE, Gender.parse("male"));
        Assertions.assertEquals(Gender.MALE, Gender.parse("м"));
        Assertions.assertEquals(Gender.FEMALE, Gender.parse("Ж"));
        Assertions.assertEquals(Gender.FEMALE, Gender.parse("female"));
        Assertions.assertNull(Gender.parse("боевой вертолёт"), "опечатка не должна молча давать пол");
        Assertions.assertFalse(Gender.UNSET.isChosen());
        Assertions.assertEquals(Gender.UNSET, Gender.fromInput(null));
        Assertions.assertEquals(Gender.UNSET, Gender.fromInput(""));
    }

    @Test
    @SuppressWarnings("unchecked")
    void genderBadgeIsInChatAndTab() {
        Map<String, Object> chat = resource("chat.yml");
        Map<String, Object> channels = (Map<String, Object>) chat.get("channels");
        int withGender = 0;
        for (Object raw : channels.values()) {
            Map<String, Object> channel = (Map<String, Object>) raw;
            if (String.valueOf(channel.getOrDefault("format", "")).contains("{gender}")) {
                withGender++;
            }
        }
        Assertions.assertEquals(channels.size(), withGender,
                "в chat.yml не во всех каналах есть {gender} - значок пола пропадёт в части каналов");

        Map<String, Object> tab = resource("tab.yml");
        Assertions.assertTrue(String.valueOf(tab.get("name-format")).contains("{gender}"),
                "tab.yml name-format без {gender} - в TAB пола не будет");

        Map<String, Object> card = (Map<String, Object>) chat.get("name-card");
        List<String> lines = (List<String>) card.get("lines");
        Assertions.assertTrue(lines.stream().anyMatch(line -> line.contains("{gender}")),
                "в карточке игрока нет строки с полом");
    }

    @Test
    void femaleArmorNamesMatchPackItems() {
        // PackItems: armor_female_<класс|ранг>_<ранг>_<часть> и слой female_<класс|rank>_<ранг>.
        // Список классов - тот же, что в frames.yml pack.gear-classes.
        Map<String, Object> frames = resource("frames.yml");
        @SuppressWarnings("unchecked")
        Map<String, Object> pack = (Map<String, Object>) frames.get("pack");
        @SuppressWarnings("unchecked")
        List<String> classes = (List<String>) pack.get("gear-classes");
        Assertions.assertNotNull(classes, "frames.yml: нет pack.gear-classes");
        int expected = 0;
        for (String playerClass : classes) {
            for (String rank : RANKS) {
                for (String piece : PIECES) {
                    String model = "armor_female_" + playerClass + "_" + rank + "_" + piece;
                    Assertions.assertTrue(model.equals(model.toLowerCase(Locale.ROOT)), model);
                    expected++;
                }
            }
        }
        // 3 класса x 8 рангов x 4 части + общая броня 8 x 4
        Assertions.assertEquals(3 * 8 * 4, expected);
        Assertions.assertEquals("female", Gender.FEMALE.modelPart());
        Assertions.assertEquals("male", Gender.MALE.modelPart());
        Assertions.assertEquals("", Gender.UNSET.modelPart(), "у невыбранного пола модели нет - общая");
    }

    @Test
    void genderChangesNothingButLooks() {
        // Пол не должен попадать в разделы, которые влияют на бой: классы, баланс, урон.
        for (String name : List.of("classes.yml", "ranks.yml", "survival.yml", "pets.yml")) {
            String text;
            try (InputStream in = GenderConfigTest.class.getClassLoader().getResourceAsStream(name)) {
                Assertions.assertNotNull(in, "нет ресурса " + name);
                text = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            } catch (Exception e) {
                throw new IllegalStateException(name, e);
            }
            Assertions.assertFalse(text.contains("female") || text.contains("gender"),
                    name + ": пол - это внешность, характеристики от него зависеть не должны");
        }
    }
}
