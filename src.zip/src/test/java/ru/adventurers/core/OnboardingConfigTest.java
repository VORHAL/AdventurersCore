package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Втягивание игроков (раздел 24 отчёта).
 *
 * <p>Главная мысль: новичок уходит не из-за бедности, а из-за непонимания. Поэтому
 * тест проверяет не «есть ли награды», а то, что цепочка первых шагов короткая,
 *各 шаг - одно действие, подсказки не превращаются в спам, и награды не ломают
 * экономику первых рангов (дневной доход F - 312 монет, раздел 15).
 */
class OnboardingConfigTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = OnboardingConfigTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> steps() {
        return (List<Map<String, Object>>) (List<?>) resource("onboarding.yml").get("steps");
    }

    @Test
    void chainIsShortAndEachStepIsOneAction() {
        List<Map<String, Object>> steps = steps();
        Assertions.assertTrue(steps.size() >= 4 && steps.size() <= 8,
                "первых шагов должно быть 4-8, а не " + steps.size());
        Set<String> ids = new java.util.LinkedHashSet<>();
        for (Map<String, Object> step : steps) {
            String id = String.valueOf(step.get("id"));
            Assertions.assertTrue(ids.add(id), "повторяющийся этап: " + id);
            String hint = String.valueOf(step.get("hint"));
            Assertions.assertTrue(hint.contains("/ag "),
                    "в подсказке этапа " + id + " нет конкретной команды - новичок не поймёт, что делать");
            Assertions.assertTrue(hint.length() <= 130,
                    "подсказка этапа " + id + " слишком длинная для HUD: " + hint.length());
            Assertions.assertNotNull(step.get("done-when"),
                    "у этапа " + id + " нет события (done-when), значит он никогда не засчитается");
            Assertions.assertNotNull(step.get("reward"), "у этапа " + id + " нет награды");
        }
        // первым должен быть класс: без класса игра не работает
        Assertions.assertEquals("class-chosen", String.valueOf(steps.get(0).get("done-when")),
                "первый этап - выбор класса");
    }

    @Test
    void rewardsDoNotBreakLowRankEconomy() {
        // дневной доход F - 312 монет (economy.yml, раздел 15); вся цепочка не должна
        // давать больше двух дней: иначе новичок «обогатится» не играя
        long coins = 0;
        int points = 0;
        for (Map<String, Object> step : steps()) {
            Map<String, Object> reward = (Map<String, Object>) step.get("reward");
            coins += reward.get("coins") instanceof Number value ? value.longValue() : 0;
            points += reward.get("points") instanceof Number value ? value.intValue() : 0;
        }
        Assertions.assertTrue(coins <= 2 * 312,
                "вся цепочка даёт " + coins + " монет - это больше двух дней дохода F");
        Assertions.assertTrue(points <= 120,
                "очков за цепочку слишком много: " + points);
        Assertions.assertTrue(coins >= 300, "цепочка должна давать заметную первую награду");
    }

    @Test
    void hintsDoNotTurnIntoSpam() {
        Map<String, Object> cfg = resource("onboarding.yml");
        int interval = ((Number) cfg.get("hint-interval-seconds")).intValue();
        int attempts = ((Number) cfg.get("hint-attempts")).intValue();
        Assertions.assertTrue(interval >= 60, "подсказки чаще раза в минуту - это спам: " + interval);
        Assertions.assertTrue(attempts >= 1 && attempts <= 3,
                "напоминаний про один шаг должно быть 1-3, а не " + attempts);
        Assertions.assertEquals(Boolean.TRUE, cfg.get("hud"), "подсказки идут в HUD, а не в чат");
    }

    @Test
    void newbieTitleEndsOnItsOwn() {
        Map<String, Object> cfg = resource("onboarding.yml");
        int hours = ((Number) cfg.get("newbie-title-hours")).intValue();
        Assertions.assertTrue(hours >= 24 && hours <= 168,
                "титул новичка должен сниматься сам за 1-7 дней: " + hours);
        Assertions.assertTrue(String.valueOf(cfg.get("newbie-title")).contains("Новичок"),
                "титул новичка должен быть понятным");
    }

    @Test
    void returningIsNotAPayout() {
        Map<String, Object> returning = (Map<String, Object>) resource("onboarding.yml").get("returning");
        Assertions.assertEquals(Boolean.TRUE, returning.get("enabled"), "возвращение включено");
        int days = ((Number) returning.get("after-days")).intValue();
        Assertions.assertTrue(days >= 2 && days <= 14, "порог возвращения 2-14 дней: " + days);
        // награды за отсутствие быть не должно: это наказывает тех, кто играет каждый день
        Assertions.assertNull(returning.get("reward"),
                "за отсутствие нельзя платить: это наказывает активных игроков");
        Assertions.assertNotNull(returning.get("offer-quests"),
                "возвращение должно предлагать цели на сегодня, а не подарок");
    }

    @Test
    void inviteRespectsQuietHours() {
        Map<String, Object> invite = (Map<String, Object>) resource("onboarding.yml").get("invite");
        Assertions.assertEquals(Boolean.TRUE, invite.get("enabled"), "зов на сервер включён");
        int cooldown = ((Number) invite.get("cooldown-minutes")).intValue();
        Assertions.assertTrue(cooldown >= 20, "зов чаще раза в 20 минут - это спам: " + cooldown);
        List<Integer> quiet = (List<Integer>) invite.get("quiet-hours");
        Assertions.assertEquals(2, quiet.size(), "нужны тихие часы: ночью звать бессмысленно");
        List<String> messages = (List<String>) invite.get("messages");
        Assertions.assertTrue(messages.size() >= 2, "нужно несколько вариантов зова, а не один");
        for (String message : messages) {
            Assertions.assertTrue(message.contains("/ag"),
                    "зов должен вести в конкретное занятие, а не «зайди»: " + message);
        }
    }
}
