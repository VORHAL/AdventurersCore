package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Согласие конфигов с ресурспаком: какие модели предметов и слои брони пак реально рисует.
 *
 * <p>Самого пака на сборочной машине нет, поэтому здесь закреплены ФАКТЫ пака
 * AdventurersPack, от которых зависит выбор пути в PackItems:
 * <ul>
 *   <li>у бойца, лекаря и танка броня нарисована на всех рангах:
 *       armor_fighter_f ... armor_fighter_s, и есть классовые слои equipment/fighter_f;</li>
 *   <li>у универсала отдельных моделей нет - ему достаётся общая броня ранга
 *       (armor_a_plus_helmet, equipment/rank_a_plus);</li>
 *   <li>оружие и щиты названы ТОЛЬКО по рангу (weapon_sword_f, shield_s, shield_tank),
 *       класс в их имя не входит - поэтому PackItems не должен подставлять класс в оружие;</li>
 *   <li>оружие "sword_f" (без weapon_) в паке тоже есть, но плагин его не просит.</li>
 * </ul>
 *
 * <p>Полная сверка по самим файлам пака - tools/pack_models.py &lt;папка пака&gt;:
 * он читает assets/adventurers/items и equipment и печатает, чего не хватает.
 */
class PackModelTest {

    private static final List<String> RANKS = List.of(
            "f", "e", "d", "c", "b", "a", "a_plus", "s");
    private static final List<String> PIECES = List.of(
            "helmet", "chestplate", "leggings", "boots");
    /** Классы, у которых в паке есть свои модели брони (assets/adventurers/items/armor_<класс>_*). */
    private static final List<String> PACK_CLASSES = List.of("fighter", "healer", "tank");
    /** Классы плагина вместе с универсалом. */
    private static final List<String> PLUGIN_CLASSES = List.of("tank", "healer", "fighter", "universal");

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = PackModelTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> packSection() {
        Map<String, Object> frames = resource("frames.yml");
        Map<String, Object> pack = (Map<String, Object>) frames.get("pack");
        Assertions.assertNotNull(pack, "в frames.yml нет раздела pack");
        return pack;
    }

    private static List<String> gearClasses() {
        List<String> ids = new ArrayList<>();
        Object value = packSection().get("gear-classes");
        if (value instanceof List<?> list) {
            for (Object id : list) {
                ids.add(String.valueOf(id).toLowerCase(Locale.ROOT));
            }
        }
        return ids;
    }

    /** Имя ранга в модели - ровно Rank.name().toLowerCase(), иначе клиент модель не найдёт. */
    @Test
    void rankNamesInModelsMatchThePack() {
        for (String rank : RANKS) {
            Assertions.assertEquals(rank.toLowerCase(Locale.ROOT), rank, rank);
            Assertions.assertFalse(rank.contains("-"), "в паке подчёркивание, не дефис: " + rank);
        }
        Assertions.assertEquals(8, RANKS.size(), "рангов в лестнице восемь: F..S");
    }

    /**
     * Главная проверка: классовая броня включается ровно для тех классов, для которых пак её нарисовал.
     * Если класс попал в gear-classes, а арта в паке нет - игрок увидит ванильную броню вместо
     * классовой; если не попал, хотя арт есть - классовая разница просто пропадёт.
     */
    @Test
    void classArmorIsEnabledForExactlyTheClassesThePackDraws() {
        List<String> configured = gearClasses();
        for (String playerClass : PLUGIN_CLASSES) {
            boolean inPack = PACK_CLASSES.contains(playerClass);
            boolean enabled = configured.contains(playerClass);
            Assertions.assertEquals(inPack, enabled,
                    "frames.yml pack.gear-classes: у класса " + playerClass + " "
                            + (inPack ? "ЕСТЬ" : "НЕТ") + " своя броня в паке, а в списке он "
                            + (enabled ? "есть" : "отсутствует"));
        }
        Assertions.assertEquals(PACK_CLASSES.size(), configured.size(),
                "в gear-classes лишние классы: " + configured);
    }

    /** Все общие модели (их просит любой класс) и классовые (только классы из gear-classes). */
    @Test
    void everyRequestedModelExists() {
        Set<String> shared = new LinkedHashSet<>();
        Set<String> perClass = new LinkedHashSet<>();
        for (String rank : RANKS) {
            for (String piece : PIECES) {
                shared.add("armor_" + rank + "_" + piece);
            }
            shared.add("equipment/rank_" + rank);
            shared.add("shield_" + rank);
            for (String weapon : List.of("sword", "axe", "mace", "spear", "bow", "crossbow")) {
                shared.add("weapon_" + weapon + "_" + rank);
            }
        }
        shared.add("shield_tank");
        shared.add("staff");
        shared.add("gem_raw");
        for (String family : List.of("hp", "mana", "cure")) {
            for (int level = 1; level <= 3; level++) {
                shared.add("potion_" + family + "_" + level);
            }
        }
        for (String rank : RANKS) {
            for (String piece : PIECES) {
                perClass.add("armor_<класс>_" + rank + "_" + piece);
            }
            perClass.add("equipment/<класс>_" + rank);
        }
        // 8 рангов x 4 части брони + 8 слоёв + 8 щитов + 6 видов оружия x 8 рангов
        Assertions.assertEquals(8 * 4 + 8 + 8 + 6 * 8, shared.size() - 1 - 1 - 1 - 9,
                "состав общих моделей изменился - обновите PackItems и этот тест");
        // 8 рангов x 4 части + 8 слоёв на каждый класс с собственным артом
        Assertions.assertEquals(8 * 4 + 8, perClass.size());
        for (String model : perClass) {
            Assertions.assertFalse(gearClasses().isEmpty(),
                    "классовых моделей нет ни у кого, если pack.gear-classes пуст");
            Assertions.assertFalse(model.contains("universal"),
                    "универсал не должен получать классовую модель - её нет в паке: " + model);
        }
    }

    /** Оружие и щит названы по рангу: класс в их имя не подставляется (в паке таких файлов нет). */
    @Test
    void weaponsAndShieldsDoNotCarryTheClass() {
        Assertions.assertNotNull(packSection().get("item-models"), "в frames.yml нет pack.item-models");
        for (String rank : RANKS) {
            for (String weapon : List.of("sword", "axe", "mace", "spear", "bow", "crossbow")) {
                String model = "weapon_" + weapon + "_" + rank;
                for (String playerClass : PACK_CLASSES) {
                    Assertions.assertFalse(model.contains(playerClass),
                            "в паке нет " + model.replace(rank, playerClass + "_" + rank)
                                    + " - оружие только по рангу");
                }
            }
            Assertions.assertFalse(("shield_" + rank).contains("tank"), "щит танка только shield_tank");
        }
    }
}
