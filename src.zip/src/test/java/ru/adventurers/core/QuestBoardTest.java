package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;
import ru.adventurers.core.profile.Rank;
import ru.adventurers.core.quest.QuestDef;
import ru.adventurers.core.quest.QuestRotation;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Тесты доски заданий и контрактов.
 *
 * <p>Главное, что здесь проверяется: доска не повторяется день ото дня.
 * Симулируем 30 дней на каждом ранге теми же правилами, что в игре
 * ({@link QuestRotation}), и требуем, чтобы:
 * <ul>
 *   <li>в один день не было двух заданий с одинаковой целью;</li>
 *   <li>соседние дни не пересекались (задание не показывается два дня подряд);</li>
 *   <li>за 30 дней игрок увидел почти все задания своего ранга;</li>
 *   <li>в пуле каждого ранга хватает заданий на ротацию.</li>
 * </ul>
 */
class QuestBoardTest {

    private static final List<Rank> LADDER = List.of(Rank.F, Rank.E, Rank.D, Rank.C, Rank.B, Rank.A, Rank.A_PLUS, Rank.S);

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = QuestBoardTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<QuestDef> quests() {
        List<QuestDef> list = new ArrayList<>();
        for (Object entry : (List<Object>) resource("quests.yml").get("quests")) {
            Map<String, Object> raw = (Map<String, Object>) entry;
            Rank min = Rank.fromInput(String.valueOf(raw.get("rank")));
            Object maxRaw = raw.get("max-rank");
            Rank max = maxRaw == null ? min : Rank.fromInput(String.valueOf(maxRaw));
            list.add(new QuestDef(
                    String.valueOf(raw.get("id")), min, max,
                    String.valueOf(raw.get("title")),
                    List.of(),
                    QuestDef.Type.valueOf(String.valueOf(raw.get("type"))),
                    String.valueOf(raw.get("target")).toUpperCase(),
                    ((Number) raw.get("amount")).intValue(),
                    ((Number) raw.get("points")).intValue(),
                    Map.of(), List.of(), List.of(),
                    Boolean.TRUE.equals(raw.get("repeatable"))));
        }
        return list;
    }

    private static List<QuestDef> poolFor(List<QuestDef> all, Rank rank) {
        List<QuestDef> pool = new ArrayList<>();
        for (QuestDef def : all) {
            if (def.availableFor(rank)) {
                pool.add(def);
            }
        }
        return pool;
    }

    /** 30 дней подряд: доска, история, как в QuestManager. */
    private static List<List<QuestDef>> simulate(List<QuestDef> pool, int days) {
        int minDaysAway = 1;
        int maxSameType = 3;
        long seed = 12345L;
        Map<String, Long> history = new java.util.HashMap<>();
        List<List<QuestDef>> boards = new ArrayList<>();
        for (int day = 0; day < days; day++) {
            Set<String> recent = new HashSet<>();
            for (Map.Entry<String, Long> entry : history.entrySet()) {
                if (entry.getValue() >= day - minDaysAway && entry.getValue() < day) {
                    recent.add(entry.getKey());
                }
            }
            List<QuestDef> board = QuestRotation.pick(pool, 5, seed + day * 1_000_003L, minDaysAway, maxSameType, recent);
            for (QuestDef def : board) {
                history.merge(def.id(), (long) day, Math::max);
            }
            boards.add(board);
        }
        return boards;
    }

    /** На каждом ранге достаточно заданий, чтобы ротация вообще могла работать. */
    @Test
    void everyRankHasEnoughQuests() {
        List<QuestDef> all = quests();
        for (Rank rank : LADDER) {
            int size = poolFor(all, rank).size();
            Assertions.assertTrue(size >= 12,
                    "ранг " + rank.getDisplayName() + ": в пуле " + size + " заданий, нужно минимум 12 "
                            + "(5 в день без повторов при ротации)");
        }
    }

    /** Что видно в один день: без двух заданий с одной целью и без перекоса по типам. */
    @Test
    void oneDayHasNoDuplicateGoals() {
        List<QuestDef> all = quests();
        for (Rank rank : LADDER) {
            List<QuestDef> pool = poolFor(all, rank);
            for (List<QuestDef> board : simulate(pool, 30)) {
                Assertions.assertEquals(5, board.size(),
                        "ранг " + rank.getDisplayName() + ": на доске " + board.size() + " заданий вместо 5");
                Set<String> goals = new LinkedHashSet<>();
                Map<QuestDef.Type, Integer> types = new EnumMap<>(QuestDef.Type.class);
                for (QuestDef def : board) {
                    Assertions.assertTrue(goals.add(QuestRotation.goalKey(def)),
                            "ранг " + rank.getDisplayName() + ": на доске две цели " + QuestRotation.goalKey(def));
                    types.merge(def.type(), 1, Integer::sum);
                }
                for (Map.Entry<QuestDef.Type, Integer> entry : types.entrySet()) {
                    Assertions.assertTrue(entry.getValue() <= 3,
                            "ранг " + rank.getDisplayName() + ": " + entry.getValue()
                                    + " заданий типа " + entry.getKey() + " в один день");
                }
            }
        }
    }

    /** Соседние дни не должны пересекаться: иначе «каждый день одно и то же». */
    @Test
    void consecutiveDaysDoNotRepeat() {
        List<QuestDef> all = quests();
        for (Rank rank : LADDER) {
            List<List<QuestDef>> boards = simulate(poolFor(all, rank), 30);
            for (int day = 1; day < boards.size(); day++) {
                Set<String> yesterday = new HashSet<>();
                for (QuestDef def : boards.get(day - 1)) {
                    yesterday.add(def.id());
                }
                for (QuestDef def : boards.get(day)) {
                    Assertions.assertFalse(yesterday.contains(def.id()),
                            "ранг " + rank.getDisplayName() + ": задание " + def.id()
                                    + " выпало и в день " + (day - 1) + ", и в день " + day);
                }
            }
        }
    }

    /** За месяц игрок должен увидеть почти весь пул ранга, а не 5 любимых заданий. */
    @Test
    void monthCoversAlmostWholePool() {
        List<QuestDef> all = quests();
        for (Rank rank : LADDER) {
            List<QuestDef> pool = poolFor(all, rank);
            Set<String> seen = new HashSet<>();
            for (List<QuestDef> board : simulate(pool, 30)) {
                for (QuestDef def : board) {
                    seen.add(def.id());
                }
            }
            double coverage = seen.size() / (double) pool.size();
            Assertions.assertTrue(coverage >= 0.9,
                    "ранг " + rank.getDisplayName() + ": за 30 дней увидели " + seen.size() + " из "
                            + pool.size() + " заданий (" + Math.round(coverage * 100) + "%)");
        }
    }

    /** Доска детерминирована: одинаковый вход - одинаковый день (не «прыгает» при перезаходе). */
    @Test
    void boardIsStableWithinDay() {
        List<QuestDef> all = quests();
        for (Rank rank : LADDER) {
            List<QuestDef> pool = poolFor(all, rank);
            List<QuestDef> first = QuestRotation.pick(pool, 5, 777L, 1, 3, Set.of());
            List<QuestDef> second = QuestRotation.pick(pool, 5, 777L, 1, 3, Set.of());
            Assertions.assertEquals(first, second, "ранг " + rank.getDisplayName() + ": доска нестабильна");
        }
    }

    /** Полный перебор на маленьком пуле: правило ослабляется, но доска заполняется. */
    @Test
    void tinyPoolStillFillsBoard() {
        List<QuestDef> all = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            all.add(new QuestDef("only_" + i, Rank.F, Rank.S, "t", List.of(), QuestDef.Type.KILL,
                    "ZOMBIE", 1, 1, Map.of(), List.of(), List.of(), true));
        }
        List<QuestDef> board = QuestRotation.pick(all, 5, 1L, 3, 3, Set.of("only_0", "only_1", "only_2"));
        Assertions.assertEquals(3, board.size(), "из трёх заданий доска должна собрать три");
    }

    /** Контракты: у каждой полосы рангов достаточно заказов, награды растут с рангом. */
    @Test
    @SuppressWarnings("unchecked")
    void contractsHaveDepthAndRisingRewards() {
        List<Object> list = (List<Object>) resource("contracts.yml").get("contracts");
        Map<String, Integer> weekly = new java.util.HashMap<>();
        Map<String, Integer> monthly = new java.util.HashMap<>();
        Map<String, Integer> rare = new java.util.HashMap<>();
        for (Object entry : list) {
            Map<String, Object> raw = (Map<String, Object>) entry;
            String period = String.valueOf(raw.get("period"));
            String band = String.valueOf(raw.get("rank"));
            Map<String, Integer> target = switch (period) {
                case "WEEKLY" -> weekly;
                case "MONTHLY" -> monthly;
                default -> rare;
            };
            target.merge(band, 1, Integer::sum);
        }
        for (String band : List.of("F", "C", "B", "A", "S")) {
            Assertions.assertTrue(weekly.getOrDefault(band, 0) >= 6,
                    "полоса " + band + ": недельных контрактов " + weekly.getOrDefault(band, 0) + ", нужно >= 6");
            Assertions.assertTrue(monthly.getOrDefault(band, 0) >= 4,
                    "полоса " + band + ": месячных контрактов " + monthly.getOrDefault(band, 0) + ", нужно >= 4");
            Assertions.assertTrue(rare.getOrDefault(band, 0) >= 4,
                    "полоса " + band + ": редких контрактов " + rare.getOrDefault(band, 0) + ", нужно >= 4");
        }
        // Дневной доход с заданий по полосам (economy.yml quests.coins-per-point = 6):
        // недельный контракт не должен платить больше ~2 дней, иначе экономика взносов ломается.
        Map<String, Long> pointsPerDay = Map.of("F", 81L, "C", 115L, "B", 390L, "A", 530L, "S", 1350L);
        Map<String, Long> coinsPerDay = Map.of("F", 486L, "C", 690L, "B", 2340L, "A", 3180L, "S", 8100L);
        for (Object entry : list) {
            Map<String, Object> raw = (Map<String, Object>) entry;
            if (!"WEEKLY".equals(String.valueOf(raw.get("period")))) {
                continue;
            }
            String band = String.valueOf(raw.get("rank"));
            long coins = ((Number) raw.get("coins")).longValue();
            long points = ((Number) raw.get("points")).longValue();
            Assertions.assertTrue(coins <= coinsPerDay.get(band) * 2,
                    raw.get("id") + ": недельный контракт платит " + coins + " монет при дневном доходе "
                            + coinsPerDay.get(band) + " - это больше двух дней");
            Assertions.assertTrue(points <= pointsPerDay.get(band),
                    raw.get("id") + ": недельный контракт даёт " + points + " очков при дневном доходе "
                            + pointsPerDay.get(band) + " - ранг закрывается контрактами");
        }
    }

    /** Точки доски должны быть разнообразны: ни одна цель не занимает больше трети пула. */
    @Test
    void poolIsDiverse() {
        List<QuestDef> all = quests();
        for (Rank rank : LADDER) {
            List<QuestDef> pool = poolFor(all, rank);
            Map<String, Integer> goals = new java.util.HashMap<>();
            int kills = 0;
            int delivers = 0;
            for (QuestDef def : pool) {
                goals.merge(QuestRotation.goalKey(def), 1, Integer::sum);
                if (def.type() == QuestDef.Type.KILL) {
                    kills++;
                } else {
                    delivers++;
                }
            }
            for (Map.Entry<String, Integer> entry : goals.entrySet()) {
                Assertions.assertTrue(entry.getValue() <= Math.max(2, pool.size() / 3),
                        "ранг " + rank.getDisplayName() + ": цель " + entry.getKey() + " встречается "
                                + entry.getValue() + " раз из " + pool.size());
            }
            Assertions.assertTrue(kills >= 4 && delivers >= 4,
                    "ранг " + rank.getDisplayName() + ": мало разных типов заданий (KILL " + kills
                            + ", DELIVER " + delivers + ")");
        }
    }

    /** Тест-«детектор подкрутки»: если кто-то уберёт ротацию, дни снова совпадут. */
    @Test
    void oldShuffleWouldRepeatAndNewDoesNot() {
        List<QuestDef> all = quests();
        List<QuestDef> pool = poolFor(all, Rank.F);
        Random random = new Random(42L);
        List<List<QuestDef>> naive = new ArrayList<>();
        for (int day = 0; day < 10; day++) {
            List<QuestDef> copy = new ArrayList<>(pool);
            java.util.Collections.shuffle(copy, random);
            naive.add(copy.subList(0, 5));
        }
        boolean repeated = false;
        for (int day = 1; day < naive.size() && !repeated; day++) {
            Set<String> yesterday = new HashSet<>();
            for (QuestDef def : naive.get(day - 1)) {
                yesterday.add(def.id());
            }
            for (QuestDef def : naive.get(day)) {
                if (yesterday.contains(def.id())) {
                    repeated = true;
                }
            }
        }
        Assertions.assertTrue(repeated, "старый способ (просто shuffle) обязан повторять задания - "
                + "иначе тест не доказывает пользу ротации");
    }
}
