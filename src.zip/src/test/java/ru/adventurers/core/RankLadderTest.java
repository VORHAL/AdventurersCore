package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Тесты новой лестницы рангов (затягивание до S). Проверяют не «красоту», а то,
 * что путь физически проходим и не превращается в бессмысленный гринт:
 *  1) суммарный срок пути > 100 дней (S - финал сезона, а не «ещё один ранг»);
 *  2) min-days не убывает: чем выше ранг, тем дольше на нём держат;
 *  3) условия подземелий/героиков/рейдов тоже не убывают (нельзя пройти A+ без роста);
 *  4) вложенный взнос (fee) реалистичен: не больше 30 дней дохода с одних заданий;
 *  5) у каждого ранга есть комплект набора (инече needs-gear невыполним).
 */
class RankLadderTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = RankLadderTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> promotions() {
        return (Map<String, Object>) resource("ranks.yml").get("promotions");
    }

    private static int intOf(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value == null ? 0 : ((Number) value).intValue();
    }

    private static long longOf(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value == null ? 0 : ((Number) value).longValue();
    }

    /** Путь F -> S должен занимать заметное время: сумма min-days. */
    @Test
    void ladderTakesMonthsNotDays() {
        int total = 0;
        for (Object value : promotions().values()) {
            total += intOf((Map<String, Object>) value, "min-days");
        }
        Assertions.assertTrue(total >= 100,
                "сумма min-days = " + total + " дней: путь до S слишком короткий (цель 120-160)");
        Assertions.assertTrue(total <= 220,
                "сумма min-days = " + total + " дней: путь до S неоправданно длинный (цель 120-160)");
    }

    /** Срок на ранге не должен уменьшаться при движении вверх по лестнице. */
    @Test
    void minDaysNeverDecrease() {
        int previous = 0;
        for (String rank : List.of("F", "E", "D", "C", "B", "A", "A+")) {
            Map<String, Object> requirements = (Map<String, Object>) promotions().get(rank);
            Assertions.assertNotNull(requirements, "нет условий для ранга " + rank);
            int days = intOf(requirements, "min-days");
            Assertions.assertTrue(days >= previous,
                    "ранг " + rank + ": срок " + days + " дней меньше, чем на предыдущем ранге (" + previous + ")");
            previous = days;
        }
    }

    /** Очки, задания и счётчики подземелий растут монотонно - прогресс должен быть виден. */
    @Test
    void requirementsGrowWithRank() {
        int points = 0;
        int quests = 0;
        int dungeons = 0;
        int heroics = 0;
        int raids = 0;
        for (String rank : List.of("F", "E", "D", "C", "B", "A", "A+")) {
            Map<String, Object> requirements = (Map<String, Object>) promotions().get(rank);
            Assertions.assertTrue(intOf(requirements, "points") > points, "ранг " + rank + ": очки не выросли");
            Assertions.assertTrue(intOf(requirements, "quests") > quests, "ранг " + rank + ": задания не выросли");
            Assertions.assertTrue(intOf(requirements, "dungeons") >= dungeons,
                    "ранг " + rank + ": подземелья уменьшились");
            Assertions.assertTrue(intOf(requirements, "heroics") >= heroics,
                    "ранг " + rank + ": героики уменьшились");
            Assertions.assertTrue(intOf(requirements, "raids") >= raids, "ранг " + rank + ": рейды уменьшились");
            points = intOf(requirements, "points");
            quests = intOf(requirements, "quests");
            dungeons = intOf(requirements, "dungeons");
            heroics = intOf(requirements, "heroics");
            raids = intOf(requirements, "raids");
        }
    }

    /** Взнос не должен требовать копить дольше, чем длится сам ранг по min-days. */
    @Test
    void feesAreReachableWithinRankTime() {
        Map<String, Object> income = (Map<String, Object>) resource("economy.yml").get("rank-income");
        Assertions.assertNotNull(income, "в economy.yml нет rank-income - подсказка по взносу не работает");
        promotions().forEach((rank, value) -> {
            Map<String, Object> requirements = (Map<String, Object>) value;
            long fee = longOf(requirements, "fee");
            if (fee <= 0) {
                return;
            }
            Object dailyValue = income.get(rank);
            Assertions.assertNotNull(dailyValue, "в economy.yml rank-income нет ранга " + rank);
            long daily = ((Number) dailyValue).longValue();
            int days = intOf(requirements, "min-days");
            long needDays = (fee + daily - 1) / daily;
            Assertions.assertTrue(needDays <= days,
                    "ранг " + rank + ": взнос " + fee + " при доходе " + daily + " в день = "
                            + needDays + " дней, а на ранге нужно всего " + days);
        });
    }

    /**
     * Худшее условие ранга не должно быть пустым: если ворота на подземелья слабее,
     * чем очки и задания, они ничего не фильтруют и ранг держится только min-days.
     * Считаем «самое жёсткое» условие при темпе: 5 заданий в день, 5 подземелий в неделю.
     */
    @Test
    @SuppressWarnings("unchecked")
    void dungeonGatesActuallyGate() {
        Map<String, Object> quests = resource("quests.yml");
        Map<String, Integer> count = new LinkedHashMap<>();
        Map<String, Integer> points = new LinkedHashMap<>();
        for (Object raw : (List<Object>) quests.get("quests")) {
            Map<String, Object> quest = (Map<String, Object>) raw;
            String rank = String.valueOf(quest.get("rank"));
            count.merge(rank, 1, Integer::sum);
            points.merge(rank, intOf(quest, "points"), Integer::sum);
        }
        int previousDungeons = 0;
        int previousPoints = 0;
        int previousQuests = 0;
        for (Map.Entry<String, Object> entry : promotions().entrySet()) {
            String rank = entry.getKey();
            Map<String, Object> requirements = (Map<String, Object>) entry.getValue();
            double dungeonDays = (intOf(requirements, "dungeons") - previousDungeons) * 7.0 / 5.0;
            int neededPoints = intOf(requirements, "points") - previousPoints;
            int neededQuests = intOf(requirements, "quests") - previousQuests;
            double dailyPoints = points.getOrDefault(rank, 1) * 5.0 / Math.max(1, count.getOrDefault(rank, 1));
            double pointDays = neededPoints / dailyPoints;
            double questDays = neededQuests / 5.0;
            // Ворота должны быть не меньше половины срока ранга: иначе они декоративные.
            // На F и E подземелий нет намеренно: игрок только учится.
            if (intOf(requirements, "dungeons") > 0) {
                Assertions.assertTrue(dungeonDays >= intOf(requirements, "min-days") / 2,
                    rank + ": нужно " + intOf(requirements, "dungeons") + " подземелий суммарно, это "
                            + Math.round(dungeonDays) + " дней при 5 в неделю, а на ранге положено "
                            + intOf(requirements, "min-days") + " - ворота декоративные");
            }
            Assertions.assertTrue(pointDays <= intOf(requirements, "min-days") + 1
                            || questDays <= intOf(requirements, "min-days") + 1,
                    rank + ": очки (" + Math.round(pointDays) + " дн.) и задания (" + Math.round(questDays)
                            + " дн.) оба дольше min-days (" + intOf(requirements, "min-days")
                            + ") - ранг закрывается одним способом");
            previousDungeons = intOf(requirements, "dungeons");
            previousPoints = intOf(requirements, "points");
            previousQuests = intOf(requirements, "quests");
        }
    }

    /**
     * Ворота рейдов должны быть проходимы на ранге, где рейды открываются.
     * Рейд требует полного состава (party.yml raid.min-rank), поэтому требование
     * "столько-то рейдов" на ранг ниже доступа к рейдам - непроходимое условие.
     */
    @Test
    @SuppressWarnings("unchecked")
    void raidGatesMatchRaidAccess() {
        Map<String, Object> party = resource("party.yml");
        String minRankText = String.valueOf(((Map<String, Object>) party.get("raid")).get("min-rank"));
        List<String> ladder = List.of("F", "E", "D", "C", "B", "A", "A+", "S");
        int access = ladder.indexOf(minRankText);
        Assertions.assertTrue(access >= 0, "party.yml: неизвестный raid.min-rank " + minRankText);
        for (Map.Entry<String, Object> entry : promotions().entrySet()) {
            Map<String, Object> requirements = (Map<String, Object>) entry.getValue();
            if (intOf(requirements, "raids") > 0) {
                int rankIndex = ladder.indexOf(entry.getKey());
                Assertions.assertTrue(rankIndex >= access,
                        "ранг " + entry.getKey() + " требует рейды, а рейды доступны только с " + minRankText);
            }
        }
    }

    /** needs-gear имеет смысл только там, где Мастеру Гильдии есть что выдать. */
    @Test
    void gearRequirementHasKits() throws Exception {
        Map<String, Object> kits = (Map<String, Object>) resource("guildgear.yml").get("kits");
        Assertions.assertNotNull(kits, "в guildgear.yml нет kits");
        promotions().forEach((rank, value) -> {
            Map<String, Object> requirements = (Map<String, Object>) value;
            if (!Boolean.TRUE.equals(requirements.get("needs-gear"))) {
                return;
            }
            Object kit = kits.get(rank);
            Assertions.assertNotNull(kit, "ранг " + rank + " требует набор, но в guildgear.yml его нет");
            Assertions.assertFalse(((List<Object>) kit).isEmpty(), "ранг " + rank + ": пустой набор");
        });
    }
}
