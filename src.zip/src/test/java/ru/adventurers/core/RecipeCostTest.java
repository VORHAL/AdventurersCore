package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Себестоимость рецептов и цены магазина.
 *
 * <p>Проверяет то, что нельзя увидеть глазами в конфиге: что крафт выгоден, что магазин
 * не даёт арбитража, и что у каждой профессии есть работа на своём ранге.
 * Числа для сверки - ровно те, по которым балансировались recipes.yml/shop.yml/economy.yml:
 * цена изделия = рыночная себестоимость сырья x 1.6 (см. tools/craft_cost.py).
 */
class RecipeCostTest {

    private static final List<String> PROFESSIONS = List.of(
            "RUNESMITH", "ARMORSMITH", "WEAPONSMITH", "JEWELER", "ALCHEMIST", "COOK", "HUNTER", "MINER");

    @SuppressWarnings("unchecked")
    private static Map<String, Object> load(String name) {
        try (InputStream in = RecipeCostTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new IllegalStateException("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> recipes() {
        return (Map<String, Object>) load("recipes.yml").get("recipes");
    }

    /** Цена за штуку в магазине гильдии. */
    @SuppressWarnings("unchecked")
    private static Map<String, Double> shopPrices() {
        Map<String, Double> prices = new LinkedHashMap<>();
        Map<String, Object> categories = (Map<String, Object>) load("shop.yml").get("categories");
        for (Object category : categories.values()) {
            for (Object raw : (List<Object>) ((Map<String, Object>) category).get("goods")) {
                Map<String, Object> good = (Map<String, Object>) raw;
                double amount = ((Number) good.get("amount")).doubleValue();
                double price = ((Number) good.get("price")).doubleValue();
                prices.putIfAbsent((String) good.get("item"), price / amount);
            }
        }
        return prices;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Double> sellPrices() {
        Map<String, Double> prices = new LinkedHashMap<>();
        Map<String, Object> raw = (Map<String, Object>)
                ((Map<String, Object>) load("economy.yml").get("sell")).get("prices");
        raw.forEach((item, value) -> prices.put(item, ((Number) value).doubleValue()));
        return prices;
    }

    @SuppressWarnings("unchecked")
    private static Set<String> runeIds() {
        Set<String> ids = new LinkedHashSet<>();
        Map<String, Object> runes = (Map<String, Object>) load("runes.yml").get("runes");
        ids.addAll(runes.keySet());
        return ids;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> rankCaps() {
        return (Map<String, Object>) load("professions.yml").get("level-cap-by-rank");
    }

    /**
     * Правило магазина: цена за штуку ровно в 1.5-4 раза выше скупки.
     * Ниже 1.5 - арбитраж (купил и сдал скупщику). Выше 4 - дешевле купить, чем добывать и крафтить.
     */
    @Test
    void shopNeverUndercutsSellPricesByMargin() {
        Map<String, Double> shop = shopPrices();
        Map<String, Double> sell = sellPrices();
        List<String> problems = new ArrayList<>();
        for (Map.Entry<String, Double> entry : shop.entrySet()) {
            String item = entry.getKey();
            Double sellPrice = sell.get(item);
            if (sellPrice == null) {
                problems.add(item + ": в магазине есть, а в скупке цены нет");
                continue;
            }
            double ratio = entry.getValue() / sellPrice;
            if (ratio < 1.5 || ratio > 4.0) {
                problems.add(String.format(Locale.ROOT, "%s: магазин %.2f / скупка %.2f = %.2fx",
                        item, entry.getValue(), sellPrice, ratio));
            }
        }
        Assertions.assertTrue(problems.isEmpty(), "цены магазина и скупки рассинхронизированы:\n"
                + String.join("\n", problems));
    }

    /**
     * Себестоимость: рыночная цена сырья должна быть выше того, что даёт скупка этого сырья,
     * и не должна превышать цену, за которую изделие имеет смысл продавать игрокам.
     * Для рун цепочка I->II->III считается накопительно, поэтому сравниваем уровни 1, 2 и 3.
     */
    @Test
    void recipeCostMatchesIntendedItemPrice() {
        Map<String, Double> shop = shopPrices();
        Map<String, Double> sell = sellPrices();
        Map<String, Object> recipes = recipes();
        // себестоимость рун 1 уровня: из неё считаются уровни 2 и 3
        Map<String, Double> rune1 = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : recipes.entrySet()) {
            Map<String, Object> out = (Map<String, Object>)
                    ((Map<String, Object>) entry.getValue()).get("out");
            if (out.containsKey("rune") && ((Number) out.getOrDefault("level", 1)).intValue() == 1) {
                rune1.put((String) out.get("rune"), ingredientCost((Map<String, Object>) entry.getValue(), shop, rune1));
            }
        }
        List<String> problems = new ArrayList<>();
        for (Map.Entry<String, Object> entry : recipes.entrySet()) {
            String id = entry.getKey();
            Map<String, Object> recipe = (Map<String, Object>) entry.getValue();
            double market = ingredientCost(recipe, shop, rune1);
            double scrap = ingredientSell(recipe, sell, recipes);
            if (market <= 0) {
                problems.add(id + ": сырьё не оценивается - рецепт нельзя скрафтить за монеты");
                continue;
            }
            if (market < scrap * 1.2) {
                problems.add(String.format(Locale.ROOT,
                        "%s: купить сырьё (%s) дешевле, чем сдать его скупщику (%s) - арбитраж",
                        id, round(market), round(scrap)));
            }
        }
        Assertions.assertTrue(problems.isEmpty(), "себестоимость рецептов не сходится:\n"
                + String.join("\n", problems));
    }

    /** Сырьё любого рецепта должно продаваться в магазине гильдии: иначе крафт недостижим на практике. */
    @Test
    void everyIngredientIsAvailableInShop() {
        Map<String, Double> shop = shopPrices();
        Set<String> runes = runeIds();
        List<String> missing = new ArrayList<>();
        for (Map.Entry<String, Object> entry : recipes().entrySet()) {
            for (Object raw : (List<Object>) ((Map<String, Object>) entry.getValue()).get("in")) {
                Map<String, Object> ingredient = (Map<String, Object>) raw;
                if (ingredient.containsKey("rune")) {
                    if (!runes.contains(String.valueOf(ingredient.get("rune")))) {
                        missing.add(entry.getKey() + ": нет руны " + ingredient.get("rune") + " в runes.yml");
                    }
                } else if (!shop.containsKey(String.valueOf(ingredient.get("item")))) {
                    missing.add(entry.getKey() + ": " + ingredient.get("item") + " не продаётся в магазине");
                }
            }
        }
        Assertions.assertTrue(missing.isEmpty(), "сырьё недоступно:\n" + String.join("\n", missing));
    }

    /**
     * Материал руны должен быть тем материалом, который продаёт магазин: руны I уровня
     * собираются из 6-16 единиц материала своей руны (см. runes.yml), и если этого материала
     * в магазине нет - рунописцу нечего крафтить.
     */
    @Test
    @SuppressWarnings("unchecked")
    void runeMaterialsAreSoldInShop() {
        Map<String, Double> shop = shopPrices();
        Map<String, Object> runes = (Map<String, Object>) load("runes.yml").get("runes");
        List<String> missing = new ArrayList<>();
        for (Map.Entry<String, Object> entry : runes.entrySet()) {
            String material = String.valueOf(((Map<String, Object>) entry.getValue()).get("material"));
            if (!shop.containsKey(material)) {
                missing.add(entry.getKey() + ": " + material);
            }
        }
        Assertions.assertTrue(missing.isEmpty(), "материал рун не продаётся в магазине: "
                + String.join(", ", missing));
    }

    /**
     * Камень из passives.yml должен быть крафтуемым: пассивка даёт эффект «как будто камень
     * вставлен в вещь», но если рецепта нет, игрок этот камень никогда не увидит и не поймёт бонус.
     */
    @Test
    @SuppressWarnings("unchecked")
    void passiveGemsAreCraftable() {
        Set<String> crafted = new LinkedHashSet<>();
        for (Object raw : recipes().values()) {
            Map<String, Object> out = (Map<String, Object>) ((Map<String, Object>) raw).get("out");
            if (out != null && out.get("gem") != null && ((Number) out.getOrDefault("level", 1)).intValue() == 1) {
                crafted.add(String.valueOf(out.get("gem")).toLowerCase(Locale.ROOT));
            }
        }
        Map<String, Object> gems = (Map<String, Object>) load("gems.yml").get("gems");
        List<String> missing = new ArrayList<>();
        for (Object classRaw : ((Map<String, Object>) load("passives.yml").get("passives")).values()) {
            for (Object entryRaw : ((Map<String, Object>) classRaw).values()) {
                Object grants = ((Map<String, Object>) entryRaw).get("grants");
                if (!(grants instanceof Map<?, ?> grantMap)) {
                    continue;
                }
                for (Object gem : grantMap.keySet()) {
                    String id = String.valueOf(gem).toLowerCase(Locale.ROOT);
                    if (!gems.containsKey(id)) {
                        missing.add("нет камня " + id + " в gems.yml");
                    } else if (!crafted.contains(id)) {
                        missing.add(id + ": нет рецепта 1 уровня (ювелир не может его сделать)");
                    }
                }
            }
        }
        Assertions.assertTrue(missing.isEmpty(), "пассивки выдают камни, которых нет: \n"
                + String.join("\n", missing));
    }

    /** У каждой профессии есть рецепт на том уровне, который доступен уже на ранге F. */
    @Test
    void everyProfessionHasWorkOnFirstRanks() {
        Map<String, Object> caps = rankCaps();
        int capF = ((Number) caps.get("F")).intValue();
        int capE = ((Number) caps.get("E")).intValue();
        Map<String, Integer> earliest = new LinkedHashMap<>();
        for (Map.Entry<String, Object> entry : recipes().entrySet()) {
            Map<String, Object> recipe = (Map<String, Object>) entry.getValue();
            String profession = String.valueOf(recipe.get("profession"));
            int level = ((Number) recipe.getOrDefault("level", 1)).intValue();
            earliest.merge(profession, level, Math::min);
        }
        for (String profession : PROFESSIONS) {
            Assertions.assertTrue(earliest.containsKey(profession), "у профессии " + profession + " нет рецептов");
            int level = earliest.get(profession);
            Assertions.assertTrue(level <= capF,
                    profession + ": первый рецепт с " + level + " уровня, а на F потолок " + capF);
            long fCount = recipes().values().stream()
                    .filter(r -> profession.equals(((Map<String, Object>) r).get("profession")))
                    .filter(r -> ((Number) ((Map<String, Object>) r).getOrDefault("level", 1)).intValue() <= capE)
                    .count();
            Assertions.assertTrue(fCount >= 2, profession + ": на первых двух рангах (F-" + capE
                    + ") меньше двух рецептов, профессию нечем качать");
        }
    }

    /**
     * Руны и камни не должны требовать ранга выше того, на котором их можно скрафтить.
     * Раньше «Таран I» (2 уровень профессии = F/E) требовал незерит, который открывается на A+.
     */
    @Test
    void runeAndGemRecipesRespectRankGate() {
        Map<String, Object> caps = rankCaps();
        int cap = ((Number) caps.get("S")).intValue();
        Map<String, List<String>> gearRank = new LinkedHashMap<>();
        gearRank.put("NETHERITE", List.of("A+"));
        gearRank.put("DIAMOND", List.of("B", "C", "A"));
        gearRank.put("EMERALD", List.of("D"));
        List<String> problems = new ArrayList<>();
        for (Map.Entry<String, Object> entry : recipes().entrySet()) {
            Map<String, Object> recipe = (Map<String, Object>) entry.getValue();
            String out = String.valueOf(recipe.get("out"));
            boolean finished = out.contains("rune=") || out.contains("gem=");
            if (!finished) {
                continue;
            }
            int level = ((Number) recipe.getOrDefault("level", 1)).intValue();
            Assertions.assertTrue(level <= cap, entry.getKey() + ": уровень " + level + " выше потолка");
        }
    }

    /** Ни один рецепт не должен стоить дороже, чем изделие продаётся в магазине (если оно там есть). */
    @Test
    void craftingBeatsBuyingFinishedGoods() {
        Map<String, Double> shop = shopPrices();
        Map<String, Object> recipes = recipes();
        Map<String, Double> rune1 = new LinkedHashMap<>();
        List<String> problems = new ArrayList<>();
        for (Map.Entry<String, Object> entry : recipes.entrySet()) {
            Map<String, Object> recipe = (Map<String, Object>) entry.getValue();
            Map<String, Object> out = (Map<String, Object>) recipe.get("out");
            if (!out.containsKey("material") || out.containsKey("effects")) {
                continue;
            }
            Double shopUnit = shop.get(String.valueOf(out.get("material")));
            if (shopUnit == null) {
                continue;
            }
            double market = ingredientCost(recipe, shop, rune1);
            int amount = ((Number) out.getOrDefault("amount", 1)).intValue();
            if (market > shopUnit * amount) {
                problems.add(String.format(Locale.ROOT, "%s: себестоимость %s > цена магазина %s",
                        entry.getKey(), round(market), round(shopUnit * amount)));
            }
        }
        Assertions.assertTrue(problems.isEmpty(), "крафт дороже магазина:\n" + String.join("\n", problems));
    }

    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    private static double ingredientCost(Map<String, Object> recipe, Map<String, Double> shop,
                                         Map<String, Double> rune1) {
        double total = 0;
        for (Object raw : (List<Object>) recipe.get("in")) {
            Map<String, Object> ingredient = (Map<String, Object>) raw;
            int amount = ((Number) ingredient.getOrDefault("amount", 1)).intValue();
            if (ingredient.containsKey("rune")) {
                double base = rune1.getOrDefault(String.valueOf(ingredient.get("rune")), 0.0);
                total += base * Math.max(1, ((Number) ingredient.getOrDefault("level", 1)).intValue()) * 0.7;
            } else {
                total += shop.getOrDefault(String.valueOf(ingredient.get("item")), 0.0) * amount;
            }
        }
        return total;
    }

    @SuppressWarnings("unchecked")
    private static double ingredientSell(Map<String, Object> recipe, Map<String, Double> sell,
                                         Map<String, Object> all) {
        double total = 0;
        for (Object raw : (List<Object>) recipe.get("in")) {
            Map<String, Object> ingredient = (Map<String, Object>) raw;
            int amount = ((Number) ingredient.getOrDefault("amount", 1)).intValue();
            if (!ingredient.containsKey("rune")) {
                total += sell.getOrDefault(String.valueOf(ingredient.get("item")), 0.0) * amount;
            }
        }
        return total;
    }

    private static String round(double value) {
        return String.format(Locale.ROOT, "%,.0f", value).replace(',', ' ');
    }
}
