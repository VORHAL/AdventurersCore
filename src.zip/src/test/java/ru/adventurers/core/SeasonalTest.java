package ru.adventurers.core;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Сезонные модификаторы мира (раздел 29).
 *
 * <p>Проверяется то, что можно проверить без сервера: у каждого сезона есть и плюс,
 * и минус; множители в разумных пределах (сезон не должен ломать экономику и бой);
 * календарь считается от опорной даты, а не от запуска сервера, поэтому рестарт
 * не сдвигает сезон; список идёт по кругу без пропусков.
 *
 * <p>Арифметика сезона повторена здесь построчно из {@code SeasonalManager.index}
 * и {@code seasonFor}: если формулу в коде поменяют, а тут нет - тест этого не заметит,
 * поэтому дополнительно сверяется, что смещение на ровно один период даёт следующий сезон.
 */
class SeasonalTest {

    @SuppressWarnings("unchecked")
    private static Map<String, Object> resource(String name) {
        try (InputStream in = SeasonalTest.class.getClassLoader().getResourceAsStream(name)) {
            Assertions.assertNotNull(in, "нет ресурса " + name);
            return new Yaml().load(in);
        } catch (Exception e) {
            throw new AssertionError("не читается " + name, e);
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Map<String, Object>> seasons() {
        Object raw = resource("seasonal.yml").get("seasons");
        Assertions.assertTrue(raw instanceof Map, "нет раздела seasons");
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : ((Map<?, ?>) raw).entrySet()) {
            out.put(String.valueOf(entry.getKey()), (Map<String, Object>) entry.getValue());
        }
        return out;
    }

    private static double num(Map<String, Object> map, String key, double fallback) {
        return map.get(key) instanceof Number n ? n.doubleValue() : fallback;
    }

    private static boolean hasPlus(Map<String, Object> s) {
        return num(s, "yields", 1) > 1 || num(s, "profession-xp", 1) > 1 || num(s, "healing", 1) > 1
                || num(s, "speed", 0) > 0 || num(s, "coins", 1) > 1
                || num(s, "damage", 1) < 1 || num(s, "hunger", 1) < 1;
    }

    private static boolean hasMinus(Map<String, Object> s) {
        return num(s, "yields", 1) < 1 || num(s, "profession-xp", 1) < 1 || num(s, "healing", 1) < 1
                || num(s, "speed", 0) < 0 || num(s, "coins", 1) < 1
                || num(s, "damage", 1) > 1 || num(s, "hunger", 1) > 1;
    }

    @Test
    void everySeasonHasPlusAndMinus() {
        Map<String, Map<String, Object>> all = seasons();
        Assertions.assertTrue(all.size() >= 4, "мало сезонов: " + all.size());
        for (Map.Entry<String, Map<String, Object>> entry : all.entrySet()) {
            Assertions.assertTrue(hasPlus(entry.getValue()),
                    entry.getKey() + ": только минусы - неделя, когда лучше не заходить");
            Assertions.assertTrue(hasMinus(entry.getValue()),
                    entry.getKey() + ": только плюсы - неделя подарков, а не сезон");
            Assertions.assertNotNull(entry.getValue().get("name"), entry.getKey() + ": нет названия");
        }
    }

    @Test
    void multipliersStayInSafeBand() {
        for (Map.Entry<String, Map<String, Object>> entry : seasons().entrySet()) {
            String id = entry.getKey();
            Map<String, Object> s = entry.getValue();
            // Запас жил: шире ±30% ломает экономику ресурсов из world.yml.
            Assertions.assertTrue(num(s, "yields", 1) >= 0.7 && num(s, "yields", 1) <= 1.3,
                    id + ": yields вне 0.70-1.30");
            Assertions.assertTrue(num(s, "profession-xp", 1) >= 0.8 && num(s, "profession-xp", 1) <= 1.25,
                    id + ": profession-xp вне 0.80-1.25 - прогресс профессий и так медленный");
            Assertions.assertTrue(num(s, "damage", 1) >= 0.85 && num(s, "damage", 1) <= 1.15,
                    id + ": damage вне 0.85-1.15 - сезон не должен быть сложностью");
            Assertions.assertTrue(num(s, "healing", 1) >= 0.85 && num(s, "healing", 1) <= 1.15,
                    id + ": healing вне 0.85-1.15");
            Assertions.assertTrue(num(s, "hunger", 1) >= 0.8 && num(s, "hunger", 1) <= 1.35,
                    id + ": hunger вне 0.80-1.35");
            Assertions.assertTrue(num(s, "coins", 1) >= 0.85 && num(s, "coins", 1) <= 1.20,
                    id + ": coins вне 0.85-1.20 - иначе сезон печатает деньги");
            Assertions.assertTrue(num(s, "speed", 0) >= -0.06 && num(s, "speed", 0) <= 0.06,
                    id + ": speed вне ±6%");
        }
    }

    @Test
    void calendarIsAnchoredNotRelativeToStart() {
        Map<String, Object> root = resource("seasonal.yml");
        @SuppressWarnings("unchecked")
        Map<String, Object> season = (Map<String, Object>) root.get("season");
        Assertions.assertNotNull(season);
        int period = ((Number) season.getOrDefault("period-days", 0)).intValue();
        Assertions.assertTrue(period >= 1 && period <= 30, "period-days вне 1-30: " + period);
        String anchor = String.valueOf(season.get("anchor"));
        LocalDate anchorDate = LocalDate.parse(anchor);   // неверный формат упадёт здесь
        long anchorMillis = anchorDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli();

        // Арифметика из SeasonalManager.index / seasonFor
        int size = seasons().size();
        java.util.function.LongFunction<Integer> slotAt = now ->
                (int) Math.floorMod(Math.floorDiv(now - anchorMillis, period * 24L * 3_600_000L), size);

        int first = slotAt.apply(anchorMillis);
        int second = slotAt.apply(anchorMillis + period * 24L * 3_600_000L);
        int before = slotAt.apply(anchorMillis - 24L * 3_600_000L);
        Assertions.assertEquals((first + 1) % size, second, "через один период должен идти следующий сезон");
        Assertions.assertEquals((first - 1 + size) % size, before, "за день до опорной даты - предыдущий сезон");
        // Через полный круг возвращаемся к тому же сезону: пропусков нет.
        int full = slotAt.apply(anchorMillis + (long) size * period * 24L * 3_600_000L);
        Assertions.assertEquals(first, full, "круг сезонов не замкнулся");
        // Рестарт сервера ничего не сдвигает: номер зависит только от даты.
        Assertions.assertEquals(slotAt.apply(anchorMillis + 3L * 24 * 3_600_000L),
                slotAt.apply(anchorMillis + 3L * 24 * 3_600_000L),
                "номер сезона должен быть функцией времени, а не состояния");
    }

    @Test
    void forcedSeasonPointsToRealId() {
        @SuppressWarnings("unchecked")
        Map<String, Object> fixed = (Map<String, Object>) ((Map<String, Object>)
                resource("seasonal.yml").get("season")).get("fixed");
        Assertions.assertNotNull(fixed, "нет season.fixed");
        if (Boolean.TRUE.equals(fixed.get("enabled"))) {
            String id = String.valueOf(fixed.get("id"));
            Assertions.assertTrue(seasons().containsKey(id),
                    "принудительный сезон указывает на несуществующий id: " + id);
        }
    }

    @Test
    void seasonsHaveDifferentCharacters() {
        // Сезоны не должны быть клонами: если два сезона одинаковы по эффектам, это один сезон.
        List<String> signatures = new ArrayList<>();
        for (Map.Entry<String, Map<String, Object>> entry : seasons().entrySet()) {
            Map<String, Object> s = entry.getValue();
            String signature = String.join("|",
                    String.valueOf(num(s, "yields", 1)),
                    String.valueOf(num(s, "profession-xp", 1)),
                    String.valueOf(num(s, "damage", 1)),
                    String.valueOf(num(s, "healing", 1)),
                    String.valueOf(num(s, "hunger", 1)),
                    String.valueOf(num(s, "speed", 0)),
                    String.valueOf(num(s, "coins", 1)));
            Assertions.assertFalse(signatures.contains(signature),
                    entry.getKey() + ": такой же набор множителей уже есть у другого сезона");
            signatures.add(signature);
        }
    }
}
